/* Noor Prep Filler – page helper (main world). Mirrors LMS Smart Lesson Planner timeslot logic. */
(function () {
  "use strict";
  if (window.__noorPrepHelper) return;
  window.__noorPrepHelper = true;

  const $ = window.jQuery || window.$;
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function courseNumericId(strict=false) {
    // Official method: cid is embedded in the page's timeslot AJAX call
    try {
      for (const s of document.scripts) {
        const m = (s.textContent || "").match(
          /ajaxSelectLectureTimeslotsByDate"\s*,\s*\{\s*date\s*:\s*dateValue\s*,\s*cid\s*:\s*(\d+)/
        );
        if (m) return m[1];
      }
    } catch (_) {}
    // Fallbacks
    try {
      for (const s of strict ? [] : document.scripts) {
        const m = (s.textContent || "").match(/cid\s*:\s*(\d{3,})/);
        if (m) return m[1];
      }
    } catch (_) {}
    const hid = document.querySelector(
      'input[name="data[Preparation][course_id]"], input[name*="course_id"], #course_id'
    );
    if (hid && /^\d+$/.test(hid.value)) return hid.value;
    return "";
  }

  function weeksMap() {
    try {
      if (typeof weeks_dates === "object" && weeks_dates) return weeks_dates;
    } catch (_) {}
    const out = {};
    const sel = document.getElementById("week_id-1");
    if (sel) {
      for (const o of sel.options) {
        const d = o.text.match(/(\d{4}-\d{2}-\d{2}).*?(\d{4}-\d{2}-\d{2})/);
        if (o.value && d) out[o.value] = { [d[1]]: d[2] };
      }
    }
    return out;
  }

  function weekForDate(date) {
    const w = weeksMap();
    for (const id of Object.keys(w)) {
      const keys = Object.keys(w[id] || {});
      if (!keys.length) continue;
      const start = keys[0];
      const end = w[id][start];
      if (date >= start && date <= end) return id;
    }
    return "";
  }

  // Match the actual Noor <select multiple> elements by their visible Arabic labels.
  // Chosen hides the native select; updating its options and firing chosen:updated
  // ensures that the selected chips and submitted form values agree.
  // Noor uses both native single-select and Chosen multi-select widgets.
  // The old matcher searched only select[multiple] and missed the "المستوى"
  // field on preparation pages where it is a regular single select.
  function fillMultiChoices({ groups }) {
    const norm = s => String(s||'').normalize('NFKC')
      .replace(/[\u064b-\u065f\u0640]/g,'').replace(/[إأآ]/g,'ا')
      .replace(/\s+/g,' ').trim().toLowerCase();
    const labels = {
      levels:['المستوى','المستويات','مستوى التعلم','المستوى المعرفي'],
      strategies:['الاستراتيجيات','استراتيجيات التدريس'],
      resources:['المصادر التعليمية','مصادر التعلم','الوسائل التعليمية']
    };
    const out = {};
    const all = [...document.querySelectorAll('select')]
      .filter(el => !el.disabled && !el.closest('#stnNoorHub,#noor-prep-panel'));
    function evidence(el){
      const bits=[el.id,el.name,el.getAttribute('aria-label'),el.getAttribute('data-placeholder')];
      if(el.id){
        for(const label of document.querySelectorAll('label[for]'))if(label.htmlFor===el.id)bits.push(label.textContent);
      }
      // Search the closest form control, never a whole row of unrelated selects.
      let node=el.parentElement;
      for(let depth=0;node&&depth<4;depth++,node=node.parentElement){
        const controls=node.querySelectorAll('select');
        if(controls.length!==1)break;
        const ls=[...node.querySelectorAll('label,.control-label')];
        for(const label of ls)if(!label.closest('.chosen-container,.select2-container'))bits.push(label.textContent);
        if(node.previousElementSibling && /^(?:label|span|small|div)$/i.test(node.previousElementSibling.tagName)){
          const t=node.previousElementSibling.textContent||'';if(t.length<90)bits.push(t);
        }
      }
      return norm(bits.filter(Boolean).join(' '));
    }
    for(const [group, desired] of Object.entries(groups||{})){
      const wanted=[...new Set((Array.isArray(desired)?desired:[]).map(norm).filter(Boolean))];
      if(!wanted.length){out[group]={status:'skipped'};continue;}
      const candidates=all.filter(el=>labels[group]?.some(label=>evidence(el).includes(norm(label))));
      if(candidates.length!==1){out[group]={status:candidates.length?'ambiguous':'not_found',found:candidates.length};continue;}
      const select=candidates[0];
      const matching=[...select.options].filter(option=>{
        if(option.disabled||!String(option.value||'').trim())return false;
        const name=norm(option.textContent);
        return wanted.some(w=>w===name || (w.length>5&&name.includes(w)));
      });
      let fallback=false;
      if(!matching.length&&group==='levels'){
        // "التذكّر" is offered by some Noor forms instead of "الفهم".
        // Never select an arbitrary unrelated option when nothing matches.
        const recall=[...select.options].find(o=>!o.disabled && String(o.value||'').trim() && norm(o.textContent)==='التذكر');
        if(recall){matching.push(recall);fallback=true;}
      }
      if(!matching.length){out[group]={status:'no_matching_options',available:[...select.options].map(o=>o.textContent.trim()).slice(0,15)};continue;}
      const chosen=select.multiple?matching:matching.slice(0,1);
      for(const option of chosen)option.selected=true;
      if(!select.multiple)select.value=chosen[0].value;
      select.dispatchEvent(new Event('input',{bubbles:true}));
      select.dispatchEvent(new Event('change',{bubbles:true}));
      if($)try{$(select).trigger('chosen:updated').trigger('change.select2');}catch(_){}
      const applied=chosen.filter(option=>option.selected);
      out[group]={status:applied.length?(fallback?'selected_fallback':'selected'):'not_selected',
        matched:applied.map(x=>x.textContent.trim()),kind:select.multiple?'multiple':'single'};
    }
    return out;
  }

  // Read the *selected* item from Noor's official jsTree first, before guessing from page text.
  // This works even when no previous click was observed by the extension.
  function treeTitle(raw) {
    const fragment=document.createElement('template');
    fragment.innerHTML=String(raw??'');
    for(const label of fragment.content.querySelectorAll('span,small,b,i')){
      if(/^(?:درس|lesson|وحدة|unit|محور|فصل|term|كتاب)$/i.test(label.textContent.trim()))label.remove();
    }
    return fragment.content.textContent.replace(/\s+/g,' ').trim();
  }
  function getActiveTreeLesson() {
    const tree = document.querySelector('#jstree_node_tree');
    const clean = treeTitle;
    if (!tree) return {ok:false,reason:'tree_not_found'};
    let inst = null;
    try {const jq=window.jQuery||window.$;inst = jq && jq.fn && jq.fn.jstree ? jq('#jstree_node_tree').jstree(true) : null;}catch (_){ }
    let items = [];
    if (inst) {
      try {items = inst.get_selected(true) || [];}catch (_){}
      if (!items.length) {
        for(const selected of tree.querySelectorAll('.jstree-clicked,[aria-selected="true"]')) {
          const li=selected.closest('li[id]');
          if(li){try{const item=inst.get_node(li.id);if(item){items=[item];break;}}catch(_){}}
        }
      }
    }
    const readSemester = path => {
      for(const text of path) {
        if(/^(?:الأول|الاول|اول)$/.test(text)||/(?:الفصل\s*(?:الدراسي\s*)?(?:الأول|الاول|1)|(?:first|1st)\s*(?:semester|term)|semester\s*(?:1|one)|term\s*1)/i.test(text)) return '1';
        if(/^(?:الثاني|ثاني)$/.test(text)||/(?:الفصل\s*(?:الدراسي\s*)?(?:الثاني|2)|(?:second|2nd)\s*(?:semester|term)|semester\s*(?:2|two)|term\s*2)/i.test(text)) return '2';
      }
      return '';
    };
    const isParentLabel = text => /^(?:كتاب|عرض الشجرة|book|الفصل|semester|term|المحور)(?:\s|$)/i.test(text);
    for(const item of items) {
      const chain=[];let n=item;
      for(let i=0;i<9 && n;i++){
        const text=clean(n.text || n.original?.text || '');
        if(text) chain.push({text,id:n.id,nodeId:String(n.li_attr?.node_id||n.original?.li_attr?.node_id||n.a_attr?.node_id||''),children:n.children||[]});
        if(!n.parent||n.parent==='#')break;
        try{n=inst.get_node(n.parent);}catch(_){break;}
      }
      if(chain.length<3 || isParentLabel(chain[0].text) || (chain[0].children||[]).length)continue; // 'الوحدة الأولى: القراءة' is a LEAF under an Arabic محور
      const text=chain[0].text;
      if(!text || text.length>180)continue;
      const unit=chain.slice(1).find(x=>/^(?:المحور|الوحدة|Unit|Theme|وحدة|Chapter)/i.test(x.text)) || chain[1];
      const unitText = /^(?:الفصل|semester|term|كتاب|book)/i.test(unit?.text||'')?'':(unit?.text||'');
      const semester=readSemester(chain.map(x=>x.text));
      return {ok:true,lesson:text,unit:unitText,semester,source:'jstree',nodeId:chain[0].id,lessonNodeId:chain[0].nodeId,unitNodeId:unit?.nodeId||'',termNodeId:chain.slice(2).find(x=>readSemester([x.text]))?.nodeId||''};
    }
    // DOM fallback for the visible selected lesson when jsTree is not initialized yet.
    const selected=[...tree.querySelectorAll('.jstree-clicked,[aria-selected="true"]')];
    for(const el of selected){
      const li=el.closest('li');if(!li||li.querySelector(':scope > ul > li'))continue;
      const nodes=[];let current=li;
      while(current&&nodes.length<9){
        const anchor=current.querySelector(':scope > a, :scope > .jstree-anchor');
        const t=clean(anchor?.innerHTML || current.firstElementChild?.innerHTML||'');
        if(t)nodes.push(t);
        current=current.parentElement?.closest('li');
      }
      if(nodes.length>=3&&!isParentLabel(nodes[0])){
        const unit=nodes.slice(1).find(t=>/^(?:المحور|الوحدة|Unit|Theme|وحدة)/i.test(t))||nodes[1];
        return {ok:true,lesson:nodes[0],unit:/^(?:الفصل|semester|term|كتاب|book)/i.test(unit)?'':unit,semester:readSemester(nodes),source:'tree-dom'};
      }
    }
    return {ok:false,reason:'no_selected_lesson'};
  }

  const commands = {
    activeTreeLesson: getActiveTreeLesson,
    fillMultiChoices,
    courseId({strict=false}={}) {
      return { cid: courseNumericId(strict) };
    },

    ping() {
      const cid = courseNumericId();
      return {
        ok: true,
        hasJq: !!$,
        hasCk: !!window.CKEDITOR,
        editors: window.CKEDITOR ? Object.keys(window.CKEDITOR.instances) : [],
        cid,
        hasDateRow: !!document.getElementById("publishdate-1"),
        hasWeek: !!document.getElementById("week_id-1"),
        hasSave: !!document.querySelector(
          '#add_preparation_form input[type="submit"], #add_preparation_form button[type="submit"]'
        ),
      };
    },

    formDebug() {
      const cid = courseNumericId();
      const rows = [];
      for (let n = 1; n <= 5; n++) {
        rows.push({
          n,
          date: document.getElementById("publishdate-" + n)?.value || "",
          week: document.getElementById("week_id-" + n)?.value || "",
          slots: document.querySelectorAll('.lecture_timeslots[date-i="' + n + '"]').length,
        });
      }
      return { cid, weeks: Object.keys(weeksMap()).length, rows };
    },

    setObjective({ text }) {
      const el = document.getElementById("PreparationObjective");
      if (!el || !text) return { set: false };
      el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { set: true, len: el.value.length };
    },

    setTitle({ text }) {
      const el =
        document.getElementById("PreparationTitle") ||
        document.querySelector('input[name*="title" i]');
      if (!el || !text) return { set: false };
      el.value = text;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return { set: true };
    },

    async fillEditors({ map }) {
      const done = [];
      if (!window.CKEDITOR) return { done, error: "no_ckeditor" };
      for (const [name, html] of Object.entries(map || {})) {
        const inst = window.CKEDITOR.instances[name];
        if (!inst) continue;
        await new Promise((res) => {
          let finished = false;
          const end = () => {
            if (!finished) {
              finished = true;
              res();
            }
          };
          try {
            inst.setData(html, { callback: end });
          } catch (e) {
            end();
          }
          setTimeout(end, 3000);
        });
        try {
          inst.updateElement();
          inst.fire("change");
        } catch (e) {}
        done.push(name);
      }
      return { done };
    },

    setTextareas({ map }) {
      const done = [];
      for (const [id, text] of Object.entries(map || {})) {
        const el =
          document.getElementById(id) ||
          document.querySelector(`textarea[name*="${id}"]`);
        if (!el) continue;
        el.value = text;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        done.push(id);
      }
      return { done };
    },

    checkOutcomes({ phrases }) {
      let n = 0;
      const list = (phrases || []).map((p) => String(p).toLowerCase().slice(0, 30));
      document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
        const label = cb.closest("label") || cb.parentElement;
        const text = (label?.textContent || "").toLowerCase();
        for (const p of list) {
          if (p.length > 12 && text.includes(p)) {
            if (!cb.checked) {
              cb.click();
              n++;
            }
            break;
          }
        }
      });
      document
        .querySelectorAll('input[type="checkbox"][name^="Preparation[criteria]"]')
        .forEach((cb) => {
          if (cb.offsetParent !== null && !cb.checked && !cb.disabled) {
            cb.click();
            n++;
          }
        });
      return { checked: n };
    },

    publishFlags() {
      let n = 0;
      document.querySelectorAll('input[type="checkbox"]').forEach((cb) => {
        const txt = (
          (cb.closest("label") || cb.parentElement || {}).textContent || ""
        ).toLowerCase();
        if (
          (txt.includes("publish the preparation") ||
            txt.includes("apply this preparation to all") ||
            txt.includes("نشر التحضير") ||
            txt.includes("نشر") ||
            txt.includes("تطبيق هذا التحضير") ||
            txt.includes("تطبيق") ||
            txt.includes("على جميع الشعب") ||
            txt.includes("جميع الشعب")) &&
          !cb.checked
        ) {
          cb.click();
          n++;
        }
      });
      return { n };
    },

    async timeslots({ dates, cid: givenCid }) {
      const cid = /^\d+$/.test(String(givenCid || ""))
        ? String(givenCid)
        : courseNumericId();
      if (!cid || !$) return { error: "no_course", days: [], cid: cid || "" };
      const days = [];
      const queue = [...(dates || [])];
      async function worker() {
        while (queue.length) {
          const date = queue.shift();
          try {
            let r = await $.post(
              "/teacher/timeslots/ajaxSelectLectureTimeslotsByDate",
              { date, cid, pub: date }
            );
            if (typeof r === "string") r = JSON.parse(r);
            const items = (r.timeslots || []).map((t) => ({
              tsId: String(t.LecturesTimeslot?.id || ""),
              period: String(t.Timeslot?.title || "").trim(),
              course: t.LecturesTimeslot?.course_title || "",
              level: t.LecturesTimeslot?.level_title || "",
              section: t.LecturesTimeslot?.section_title || "",
              has: Number(t.LecturesTimeslot?.has_preparation) === 1,
            }));
            days.push({ date, week: weekForDate(date), items });
          } catch (e) {
            days.push({
              date,
              week: weekForDate(date),
              items: [],
              error: String(e.message || e),
            });
          }
        }
      }
      await Promise.all([worker(), worker(), worker()]);
      days.sort((a, b) => (a.date < b.date ? -1 : 1));
      return { days, cid };
    },

    async applyPeriods({ picks }) {
      if (!$) return { error: "no_jquery", results: [] };
      const rows = (picks || []).slice(0, 20);

      try {
        if (Array.isArray(window.dayDisabled)) window.dayDisabled.length = 0;
      } catch (e) {}

      for (let n = 1; n <= 20; n++) {
        const inp = document.getElementById("publishdate-" + n);
        if (inp && inp.value) {
          inp.value = "";
          try {
            $(inp).val("").trigger("change");
          } catch (_) {}
        }
        const box =
          inp && $(inp).parent().parent().find(".lecture_timeslots_div");
        if (box && box.length) box.html("");
      }

      const results = [];
      for (let idx = 0; idx < rows.length; idx++) {
        const n = idx + 1;
        const { date, tsIds } = rows[idx];

        // Reveal extra date rows via "add" button
        for (
          let tries = 0;
          tries < 25 &&
          n > 1 &&
          $(".section" + n).length &&
          $(".section" + n).css("display") === "none";
          tries++
        ) {
          $(".add_new_button").first().trigger("click");
          await sleep(80);
        }
        // Some pages use different class names — try generic add
        if (n > 1 && !document.getElementById("publishdate-" + n)) {
          for (let tries = 0; tries < 15; tries++) {
            const addBtn =
              document.querySelector(".add_new_button") ||
              document.querySelector('[class*="add_new"]') ||
              document.querySelector('a[onclick*="add"]');
            if (addBtn) addBtn.click();
            await sleep(100);
            if (document.getElementById("publishdate-" + n)) break;
          }
        }

        // Set week first (required for LMS to accept the date)
        const week = weekForDate(date);
        const sel = document.getElementById("week_id-" + n);
        if (sel && week) {
          try {
            $(sel).val(week).trigger("change");
          } catch (_) {
            sel.value = week;
            sel.dispatchEvent(new Event("change", { bubbles: true }));
          }
          const wrap = sel.parentElement;
          const styled = wrap && wrap.querySelector(".select-styled");
          const opt = [...sel.options].find((o) => o.value === week);
          if (styled && opt) styled.textContent = opt.text;
          if (wrap)
            wrap.querySelectorAll(".select-options li").forEach((li) =>
              li.classList.toggle("active", li.getAttribute("rel") === week)
            );
        }

        const inp = document.getElementById("publishdate-" + n);
        if (!inp) {
          results.push({ date, ok: false, reason: "no_row", n });
          continue;
        }

        try {
          $(inp).val(date).trigger("change");
        } catch (_) {
          inp.value = date;
          inp.dispatchEvent(new Event("change", { bubbles: true }));
          inp.dispatchEvent(new Event("input", { bubbles: true }));
        }

        // Wait for period checkboxes to load for this date row
        let checked = 0;
        let foundBoxes = 0;
        for (let t = 0; t < 50; t++) {
          await sleep(200);
          const boxes = document.querySelectorAll(
            '.lecture_timeslots[date-i="' + n + '"]'
          );
          if (!boxes.length) continue;
          foundBoxes = boxes.length;
          for (const id of tsIds || []) {
            const cb = document.querySelector(
              '.lecture_timeslots[date-i="' +
                n +
                '"][ts-id="' +
                CSS.escape(String(id)) +
                '"]'
            );
            if (cb && !cb.checked && !cb.disabled) {
              cb.checked = true;
              try {
                $(cb).trigger("change");
              } catch (_) {
                cb.dispatchEvent(new Event("change", { bubbles: true }));
              }
              checked++;
            }
          }
          break;
        }
        results.push({
          date,
          ok: checked > 0,
          checked,
          foundBoxes,
          week: week || "",
          n,
        });
      }
      return { results };
    },



    async curriculum() {
      let inst;
      for(let attempt=0;attempt<40&&!inst;attempt++){
        if($?.fn?.jstree)inst=$("#jstree_node_tree").jstree(true);
        if(!inst)await sleep(200);
      }
      if(!inst)return {error:"no_tree_instance",units:[]};
      const open=async id=>{
        if(inst.is_open(id)||inst.is_leaf(id))return;
        await new Promise(resolve=>{
          const timer=setTimeout(resolve,5000);
          inst.open_node(id,()=>{clearTimeout(timer);resolve();},0);
        });
      };
      let root;
      for(let attempt=0;attempt<25&&!root;attempt++){
        const roots=inst.get_node("#")?.children||[];
        root=roots.length===1?inst.get_node(roots[0]):null;
        if(!root)await sleep(200);
      }
      if(!root)return {error:"no_root",units:[]};
      await open(root.id);
      root=inst.get_node(root.id);

      const sub = async (id) => {
        try {
          let r = await $.post("/schadmin/nodes/get_sub_nodes", {
            parent_node_id: id,
            custom_lessons: ($("#match_lessons_list").val && $("#match_lessons_list").val()) || ""
          });
          if (typeof r === "string") r = JSON.parse(r);
          return r && typeof r === "object" ? r : {};
        } catch (e) {
          return { __error: String(e.message || e) };
        }
      };

      const units = [];
      let incomplete=false;
      const children = root.children || [];
      for (const tid of children) {
        const tn = inst.get_node(tid);
        if (!tn) continue;
        const termId =
          (tn.li_attr && tn.li_attr.node_id) ||
          (tn.a_attr && tn.a_attr.node_id) ||
          "";
        if (!termId){incomplete=true;continue;}
        const us = await sub(termId);
        if (us.__error){incomplete=true;continue;}
        for (const [unitId, unit] of Object.entries(us)) {
          if (unitId === "__error") continue;
          const ls = await sub(unitId);
          if (ls.__error){incomplete=true;continue;}
          const lessons = Object.entries(ls)
            .filter(([k]) => k !== "__error")
            .map(([id, title]) => ({
              id: String(id),
              title: treeTitle(title?.title??title?.text??title?.name??title)
            }));
          if (lessons.length) {
            units.push({
              termId: String(termId),
              term: treeTitle(tn.text),
              unitId: String(unitId),
              unit: treeTitle(unit?.title??unit?.text??unit?.name??unit),
              lessons
            });
          }
        }
      }

      // Recover named units and lesson leaves already loaded by the official tree.
      if (!units.length&&!incomplete) {
        for (const tid of children) {
          const term=inst.get_node(tid),termId=term?.li_attr?.node_id||term?.a_attr?.node_id;
          if(!termId)continue;
          await open(tid);
          for(const uid of term.children||[]){
            const unit=inst.get_node(uid),unitId=unit?.li_attr?.node_id||unit?.a_attr?.node_id;
            if(!unitId)continue;
            await open(uid);
            const lessons=[];
            for(const lid of unit.children||[]){
              const lesson=inst.get_node(lid),id=lesson?.li_attr?.node_id||lesson?.a_attr?.node_id;
              const title=treeTitle(lesson?.text);
              if(id&&title&&lesson.children?.length===0)lessons.push({id:String(id),title});
            }
            if(lessons.length)units.push({termId:String(termId),term:treeTitle(term.text),unitId:String(unitId),unit:treeTitle(unit.text),lessons});
          }
        }
      }

      return {
        units,
        ...(incomplete?{error:"incomplete_tree"}:{}),
        rootChildren: children.length,
        treeId: "jstree_node_tree"
      };
    },

    async selectLesson({ termId, unitId, lessonId, title }) {
      if (!$ || !$.fn || !$.fn.jstree) return { ok: false, reason: "no_tree" };
      const inst = $("#jstree_node_tree").jstree(true);
      if (!inst) return { ok: false, reason: "no_tree" };

      const byNode = (nid) => {
        try {
          const flat = inst.get_json("#", { flat: true });
          const n = flat.find(
            (x) => x.li_attr && String(x.li_attr.node_id) === String(nid)
          );
          return n ? n.id : null;
        } catch (e) {
          return null;
        }
      };

      const waitFor = async (fn, ms) => {
        ms = ms || 10000;
        for (let t = 0; t < ms; t += 150) {
          const v = fn();
          if (v) return v;
          await sleep(150);
        }
        return null;
      };

      // Path: open term → unit → lesson (official logic)
      if (termId && unitId && lessonId) {
        if (!(await waitFor(() => byNode(termId), 8000))) {
          // continue to title fallback
        } else {
          for (const [nid, next] of [
            [termId, unitId],
            [unitId, lessonId]
          ]) {
            const id = byNode(nid);
            if (!id) break;
            if (!byNode(next)) {
              inst.deselect_all(true);
              inst.select_node(id);
              if (!(await waitFor(() => byNode(next), 8000))) {
                break;
              }
            }
            try { inst.open_node(id); } catch (_) {}
            await sleep(200);
          }
          const lid = byNode(lessonId);
          if (lid) {
            inst.deselect_all(true);
            inst.select_node(lid);
            const got = await waitFor(() => {
              const v = document.getElementById("lesson-id");
              const t = document.getElementById("PreparationTitle");
              return v && String(v.value) === String(lessonId) && t && t.value.trim()
                ? t.value.trim()
                : null;
            }, 10000);
            if (got) {
              await waitFor(
                () =>
                  document.querySelector(
                    'input[type="checkbox"][name^="Preparation[criteria]"]'
                  ) || document.getElementById("PreparationObjective"),
                4000
              );
              return { ok: true, title: got, lessonId: String(lessonId), method: "node_id" };
            }
          }
        }
      }

      // Fallback: click tree anchor by title text
      if (title) {
        const want = String(title).replace(/\s+/g, " ").trim().toLowerCase();
        const anchors = document.querySelectorAll(
          "#jstree_node_tree a.jstree-anchor, #jstree_node_tree a"
        );
        let clicked = null;
        for (const a of anchors) {
          const t = (a.textContent || "").replace(/\s+/g, " ").trim().toLowerCase();
          if (t === want || t.includes(want) || want.includes(t)) {
            a.click();
            clicked = a.textContent.trim();
            break;
          }
        }
        if (clicked) {
          await sleep(800);
          const got = await waitFor(() => {
            const t = document.getElementById("PreparationTitle");
            return t && t.value.trim() ? t.value.trim() : null;
          }, 8000);
          if (got) {
            return { ok: true, title: got, method: "title_click" };
          }
          return { ok: true, title: clicked, method: "title_click_unverified" };
        }
      }

      return { ok: false, reason: "not_selected", termId, unitId, lessonId };
    },


    detectLmsPage() {
      const url = (location.href || "").toLowerCase();
      const body = (document.body && document.body.innerText) || "";
      const has = (s) => body.indexOf(s) !== -1 || url.indexOf(s.toLowerCase()) !== -1;
      return {
        url: location.href,
        isPrep: /add_preparation|preparation/.test(url),
        isHomework:
          /homework|assignment|e-?task|واجب|مهام/.test(url) ||
          has("إنشاء واجب") || has("واجب إلكتروني") || has("Add homework"),
        isAttachment:
          /attachment|resource|مرفق|مستودع|content/.test(url) ||
          has("مرفقات المادة") || has("رفع مرفق") || has("Course attachments"),
        hasFileInput: !!document.querySelector('input[type="file"]'),
        titleInputs: Array.from(
          document.querySelectorAll('input[type="text"], input[name*="title" i], #title')
        ).slice(0, 8).map((el) => el.id || el.name || el.className)
      };
    },

    fillHomeworkDraft({ title, description, dueDate, publishDate, lateDate, autoSubmit, grade }) {
      const done = [];
      const failed = [];
      const setVal = (el, v) => {
        if (!el || v == null || v === "") return false;
        try {
          const proto = el instanceof HTMLTextAreaElement
            ? HTMLTextAreaElement.prototype
            : HTMLInputElement.prototype;
          const desc = Object.getOwnPropertyDescriptor(proto, "value");
          if (desc && desc.set) desc.set.call(el, v);
          else el.value = v;
        } catch (_) {
          el.value = v;
        }
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        try {
          if (window.jQuery) window.jQuery(el).val(v).trigger("input").trigger("change");
        } catch (_) {}
        return true;
      };

      const findByLabel = (labelText) => {
        const want = String(labelText || "").trim();
        const labels = document.querySelectorAll("label, .control-label, .form-label");
        for (const lab of labels) {
          const tx = (lab.textContent || "").replace(/\s+/g, " ").trim();
          if (!tx || tx.length > 90) continue;
          if (tx === want || tx.indexOf(want) !== -1) {
            const forId = lab.getAttribute("for");
            if (forId) {
              const el = document.getElementById(forId);
              if (el) return el;
            }
            const wrap = lab.closest(".form-group, .mb-3, .row, .input, li, div") || lab.parentElement;
            if (wrap) {
              const el = wrap.querySelector(
                "input:not([type=checkbox]):not([type=radio]), textarea, select"
              );
              if (el) return el;
            }
          }
        }
        return null;
      };

      // Title
      let titleEl =
        document.getElementById("HomeworkTitle") ||
        document.getElementById("title") ||
        document.querySelector('input[name*="title" i]') ||
        document.querySelector('input[name*="name" i]') ||
        findByLabel("العنوان");
      if (setVal(titleEl, title)) done.push("title");
      else failed.push("title");

      // Comments / description (التعليقات)
      let descEl =
        document.querySelector("#HomeworkDescription, #description, #instructions") ||
        document.querySelector('textarea[name*="comment" i]') ||
        document.querySelector('textarea[name*="desc" i]') ||
        document.querySelector('textarea[name*="instruction" i]') ||
        document.querySelector('textarea[name*="content" i]') ||
        findByLabel("التعليقات") ||
        findByLabel("الوصف");
      if (description) {
        if (setVal(descEl, description)) done.push("description");
        if (window.CKEDITOR) {
          for (const name of Object.keys(window.CKEDITOR.instances || {})) {
            if (/desc|instruction|content|body|question|comment/i.test(name)) {
              try {
                const html = String(description || "")
                  .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
                  .replace(/\n/g, "<br>");
                window.CKEDITOR.instances[name].setData(html);
                window.CKEDITOR.instances[name].updateElement();
                done.push("ck:" + name);
              } catch (_) {}
            }
          }
        }
      }

      // Dates helpers
      function fmtDateTime(d) {
        const p = (n) => String(n).padStart(2, "0");
        return (
          d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate()) +
          " " + p(d.getHours()) + ":" + p(d.getMinutes()) + ":00"
        );
      }
      function fmtDate(d) {
        const p = (n) => String(n).padStart(2, "0");
        return d.getFullYear() + "-" + p(d.getMonth() + 1) + "-" + p(d.getDate());
      }

      const now = new Date();
      let due = dueDate ? new Date(dueDate) : new Date(now.getTime() + 3 * 86400000);
      if (isNaN(due.getTime())) due = new Date(now.getTime() + 3 * 86400000);
      due.setHours(13, 26, 0, 0);
      let pub = publishDate ? new Date(publishDate) : now;
      if (isNaN(pub.getTime())) pub = now;
      let late = lateDate ? new Date(lateDate) : new Date(due.getTime());
      if (isNaN(late.getTime())) late = new Date(due.getTime());

      const dateFields = [
        {
          keys: ["publish", "Publish", "start"],
          labels: ["تاريخ النشر"],
          valueDt: fmtDateTime(pub),
          valueD: fmtDate(pub)
        },
        {
          keys: ["due", "Due", "deadline", "submission"],
          labels: ["تاريخ التسليم"],
          valueDt: fmtDateTime(due),
          valueD: fmtDate(due)
        },
        {
          keys: ["late", "Late"],
          labels: ["تاريخ التسليم المتأخر"],
          valueDt: fmtDateTime(late),
          valueD: fmtDate(late)
        }
      ];

      for (const item of dateFields) {
        let el = null;
        for (const k of item.keys) {
          el =
            document.querySelector('input[name*="' + k + '" i]') ||
            document.querySelector('input[id*="' + k + '" i]');
          if (el) break;
        }
        if (!el) {
          for (const lab of item.labels) {
            el = findByLabel(lab);
            if (el) break;
          }
        }
        if (!el) {
          failed.push(item.keys[0]);
          continue;
        }
        const isDt =
          (el.type && el.type.indexOf("datetime") !== -1) ||
          (el.value && /\d{2}:\d{2}/.test(el.value)) ||
          (el.placeholder && /:/.test(el.placeholder));
        const val = isDt || el.type === "text" ? item.valueDt : item.valueD;
        if (setVal(el, val)) done.push(item.keys[0]);
        else failed.push(item.keys[0]);
      }

      // Section checkboxes under "نشر لفصول"
      try {
        const gradeHint = String(grade || "").toLowerCase();
        const boxes = Array.from(document.querySelectorAll('input[type="checkbox"]'));
        let checked = 0;
        for (const cb of boxes) {
          const lab = cb.closest("label") || cb.parentElement;
          const tx = ((lab && lab.textContent) || cb.value || "").trim();
          if (!tx || /خاص|كلمة|دفتر|روزنامة|مفردات|إجابات|ترتيب|تسليمات|مرفق|نقاط|صفر|عرض/.test(tx)) continue;
          if (/Grade|صف|Eleven|Twelve|Ten|عشر|فصل/i.test(tx)) {
            if (!gradeHint || tx.toLowerCase().indexOf(gradeHint) !== -1 || /1|Eleven|حادي/.test(tx)) {
              if (!cb.checked) {
                cb.click();
                checked++;
              }
              if (checked >= 1) break;
            }
          }
        }
        if (!checked) {
          for (const cb of boxes) {
            const tx = ((cb.closest("label") || cb.parentElement || {}).textContent || "");
            if (/اختيار\s*الكل/.test(tx)) {
              cb.click();
              checked++;
              break;
            }
          }
        }
        if (checked) done.push("sections:" + checked);
      } catch (_) {}

      let submitted = false;
      if (autoSubmit) {
        const btn =
          Array.from(document.querySelectorAll("button, input[type=submit], a.btn")).find((b) =>
            /إضافة|حفظ|Submit|Create|Publish/i.test((b.textContent || b.value || "").trim())
          ) || null;
        if (btn) {
          btn.click();
          submitted = true;
          done.push("submit");
        } else failed.push("submit");
      }

      return { ok: done.length > 0, done, failed, submitted };
    },

    fillAttachmentMeta({ title, description }) {
      const done = [];
      const setVal = (el, v) => {
        if (!el || !v) return false;
        el.value = v;
        el.dispatchEvent(new Event("input", { bubbles: true }));
        el.dispatchEvent(new Event("change", { bubbles: true }));
        return true;
      };
      const titleEl =
        document.querySelector('input[name*="title" i]') ||
        document.querySelector('input[name*="name" i]') ||
        document.getElementById("title");
      if (setVal(titleEl, title)) done.push("title");
      const descEl =
        document.querySelector('textarea[name*="desc" i]') ||
        document.querySelector('textarea[name*="note" i]');
      if (setVal(descEl, description)) done.push("description");
      const file = document.querySelector('input[type="file"]');
      return { done, hasFileInput: !!file };
    },

    fillExtraFields({ strategies, materials, notes }) {
      const done = [];
      const trySet = (selectors, value) => {
        if (!value) return;
        for (const sel of selectors) {
          const el = document.querySelector(sel);
          if (!el) continue;
          if (el.tagName === "TEXTAREA" || el.tagName === "INPUT") {
            el.value = value;
            el.dispatchEvent(new Event("input", { bubbles: true }));
            el.dispatchEvent(new Event("change", { bubbles: true }));
            done.push(sel);
            return;
          }
        }
      };
      trySet(
        [
          "#strategies", "#PreparationStrategies",
          'textarea[name*="strateg" i]', 'textarea[id*="strateg" i]',
          'textarea[name*="approach" i]'
        ],
        strategies
      );
      trySet(
        [
          "#materials", "#PreparationMaterials", "#teaching_aids",
          'textarea[name*="material" i]', 'textarea[id*="material" i]',
          'textarea[name*="resource" i]', 'textarea[name*="aid" i]'
        ],
        materials
      );
      trySet(
        [
          "#notes", "#parent_notes", "#student_notes",
          'textarea[name*="comment" i]', 'textarea[name*="note" i]'
        ],
        notes
      );
      // try CKEDITOR instances for common names
      if (window.CKEDITOR) {
        const ckMap = {
          strategies: strategies,
          teaching_aids: materials,
          materials: materials,
          learning_resources: materials,
          teacher_notes: notes
        };
        for (const [name, val] of Object.entries(ckMap)) {
          if (!val || !window.CKEDITOR.instances[name]) continue;
          try {
            window.CKEDITOR.instances[name].setData(
              String(val).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\n/g, "<br>")
            );
            window.CKEDITOR.instances[name].updateElement();
            done.push("ck:" + name);
          } catch (_) {}
        }
      }
      return { done };
    },

    reviewPreparationState() {
      const form=document.getElementById('add_preparation_form');
      if(!form)return {ok:false,reason:'preparation_form_missing'};
      const selected=getActiveTreeLesson();
      if(!selected?.ok||!selected.nodeId)return {ok:false,reason:'lesson_not_selected'};
      const title=(document.getElementById('PreparationTitle')||form.querySelector('input[name*="title" i]'))?.value?.trim()||'';
      const objective=(document.getElementById('PreparationObjective'))?.value?.trim()||'';
      if(title.length<5||objective.length<10)return {ok:false,reason:'title_or_objectives_incomplete',title};
      // Only accept the true "المستوى" control. Do not infer Bloom level
      // from an unrelated select (week or content visibility).
      const clean=t=>String(t||'').normalize('NFKC').replace(/[إأآ]/g,'ا')
          .replace(/[ً-ٟـ]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
      const levels=[];
      for(const el of form.querySelectorAll('select')){
        let evidence=clean([el.id,el.name,el.getAttribute('aria-label'),
          ...[...document.querySelectorAll('label[for]')].filter(x=>x.htmlFor&&x.htmlFor===el.id).map(x=>x.textContent)].join(' '));
        let parent=el.parentElement;
        for(let i=0;parent&&i<4;i++,parent=parent.parentElement){
          if(parent.querySelectorAll('select').length!==1)break;
          evidence+=' '+clean([...parent.querySelectorAll('label,.control-label')].map(x=>x.textContent).join(' '));
        }
        if(!/(?:^|\s)(?:المستوى|مستوى|levels?|bloom)(?:\s|$)/.test(evidence))continue;
        const selectedOpts=[...el.selectedOptions].filter(o=>o.value&&o.value!=='0'&&!o.disabled).map(o=>o.textContent.trim());
        levels.push(...selectedOpts);
      }
      if(!levels.length)return {ok:false,reason:'level_not_selected',title};
      const publishDates=[...form.querySelectorAll('input[id^="publishdate-"]')].filter(x=>x.value).map(x=>x.value);
      if(!publishDates.length)return {ok:false,reason:'period_dates_not_selected',title,levels};
      return {ok:true,title,objectiveLength:objective.length,levels,lessonNodeId:String(selected.nodeId),publishDates};
    },

    clickSave() {
      const form=document.getElementById('add_preparation_form');
      const btn=form?.querySelector('input[type="submit"],button[type="submit"]');
      if(!form||!btn||btn.disabled)return {ok:false,reason:'no_official_enabled_save_button'};
      if(typeof form.checkValidity==='function'&&!form.checkValidity())
        return {ok:false,reason:'required_form_fields_invalid'};
      // Respond to the extension BEFORE clicking: Noor may synchronously navigate,
      // which previously discarded the postMessage reply and reported uncertainty.
      // This timer is intentionally one-shot; there is no auto-retry.
      const stopToken=sessionStorage.getItem('stnNoorStopAll:v1');
      setTimeout(()=>{
        if(stopToken!==sessionStorage.getItem('stnNoorStopAll:v1')||!btn.isConnected||btn.disabled||!form.isConnected)return;
        try{sessionStorage.setItem('stnNoorPrepSubmitReceipt:v1',JSON.stringify({
          phase:'clicked',at:Date.now(),path:location.pathname,
          teacherId:(()=>{try{return JSON.parse(sessionStorage.getItem('stnHubPrepTransfer:v3')||'null')?.teacherId||''}catch(_){return ''}})(),
          cid:(()=>{try{return JSON.parse(sessionStorage.getItem('stnHubPrepTransfer:v3')||'null')?.course?.cid||''}catch(_){return ''}})()
        }))}catch(_){}
        btn.click();
      },300);
      return {ok:true,scheduled:true};
    },
  };

  window.addEventListener("message", async (ev) => {
    if (ev.source !== window || !ev.data || ev.data.__noor !== "req") return;
    const { id, cmd, args } = ev.data;
    try {
      const fn = commands[cmd];
      if (!fn) throw new Error("unknown_cmd:" + cmd);
      const result = await fn(args || {});
      window.postMessage(
        { __noor: "res", id, ok: true, result },
        location.origin
      );
    } catch (e) {
      window.postMessage(
        {
          __noor: "res",
          id,
          ok: false,
          error: String(e.message || e),
        },
        location.origin
      );
    }
  });

  window.postMessage({ __noor: "ready" }, location.origin);
})();
