/* Read the curriculum from each of the teacher's verified course routes. */
(function(root){
 'use strict';
 const KEY='stnNoorCurriculumScan:v1';
 const DAY=24*60*60*1000;
 const dashboard='/teacher';
 const pathIs=(path,prefix)=>path.toLowerCase().startsWith(prefix);
 const prepIndex='/teacher/courses/preparations_index/';
 const addPrep='/teacher/courses/add_preparation/';
 const dashboardPage=()=>/^\/teacher\/?$/i.test(location.pathname);
 const cid=url=>decodeURIComponent(url.pathname.match(/\/cid:([^/]+)/i)?.[1]||'');
 function officialURL(value,prefix){
  try{
   const url=new URL(value,location.href);
   if(url.origin===location.origin&&pathIs(url.pathname,prefix)&&!url.username&&!url.password){url.hash='';return url;}
  }catch(_){}
  return null;
 }
 function addLinks(){
  return [...new Set([...document.querySelectorAll('a[href*="add_preparation"]')]
   .map(a=>officialURL(a.href,addPrep)?.href).filter(Boolean))];
 }
 function load(){
  try{
   const job=JSON.parse(sessionStorage.getItem(KEY)||'null');
   if(job&&Date.now()-job.at<45*60*1000)return job;
   sessionStorage.removeItem(KEY);
  }catch(_){}
  return null;
 }
 const save=job=>sessionStorage.setItem(KEY,JSON.stringify(job));
 let cancellation=0;
 const cancel=()=>{cancellation++;sessionStorage.removeItem(KEY);};
 const cacheKey=(teacher,cid)=>'stnNoorVerifiedCurriculum:v1:'+teacher+':'+cid;
 const marker=teacher=>'stnNoorCurriculumScanned:v1:'+teacher;
 const normalize=value=>String(value||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 async function until(check,attempts,active){
  for(let attempt=0;attempt<attempts&&active();attempt++){
   const value=check();if(value)return value;
   await wait(250);
  }
  return null;
 }
 function routeFor(course){
  if(!/^\d+$/.test(course?.cidNumeric||''))return null;
  const route=officialURL(course.routes?.preparation,prepIndex);
  return route&&cid(route)===course.cidNumeric?route:new URL(prepIndex+'cid:'+course.cidNumeric,location.origin);
 }
 function currentTree(tree,teacher,id){
  return tree?.teacher===teacher&&tree.cid===id&&tree.units?.length&&Date.now()-tree.at<30*DAY;
 }
 function validUnits(units){
  return Array.isArray(units)&&units.length>0&&units.every(unit=>unit.termId&&unit.unitId&&unit.unit&&
   Array.isArray(unit.lessons)&&unit.lessons.length>0&&unit.lessons.every(lesson=>lesson.id&&lesson.title));
 }
 function go(job,stage,path){
  const next=new URL(path,location.origin);
  const here=new URL(location.href);here.hash='';
  save({...job,stage,target:next.href});
  if(next.href===here.href)return false;
  location.replace(next.href);return true;
 }
 function create({teacher,allowed,onProgress,onFinish}){
  let running=false;
  async function start({force=false}={}){
   if(running||load())return;
   running=true;
   const epoch=cancellation;
   try{
    const id=await teacher();
    if(!id||!await allowed())return;
    const previous=(await browser.storage.local.get(marker(id)))[marker(id)];
    if(!force&&previous)return;
    const job={id:crypto.randomUUID(),teacher:id,at:Date.now(),force,queue:null,index:0,completed:0,missed:[]};
    if(!await allowed()||await teacher()!==id||epoch!==cancellation)return;
    if(go(job,'dashboard',dashboard))return;
   }finally{running=false;}
   await resume();
  }
  async function resume(){
   const job=load();
   if(running||!job)return;
   running=true;
   const active=()=>load()?.id===job.id;
   try{
    if(await teacher()!==job.teacher){if(active())cancel();return;}
    if(!active())return;
    const page=new URL(location.href);page.hash='';
    if((job.stage!=='dashboard'||!dashboardPage())&&page.href!==job.target){cancel();return;}
    const catalog=root.NoorCourseCatalog;
    if(job.stage==='dashboard'){
     await catalog?.init?.();
     const cards=()=>catalog?.cards?.()||[];
     if(!job.queue){
      await until(()=>cards().length,20,active);
      if(!active())return;
      const queue=[...new Map(cards().map(card=>[normalize(card.label),card.label])).values()];
      if(!queue.length){cancel();onFinish({missingCards:true,completed:0,missed:[]});return;}
      job.queue=queue;
     }
     if(job.index===job.queue.length){
      await browser.storage.local.set({[marker(job.teacher)]:Date.now()});
      if(active()){cancel();onFinish(job);}
      return;
     }
     const label=job.queue[job.index];
     onProgress(job);
     const matching=()=>cards().filter(card=>normalize(card.label)===normalize(label));
     const matches=await until(()=>matching().length&&matching(),16,active)||[];
     if(!active())return;
     if(matches.length!==1){advance(job,false);return;}
     const getRoute=()=>{
      catalog.scan();
      const courses=catalog.all().filter(course=>normalize(course.label)===normalize(label)&&routeFor(course));
      return courses.length===1?routeFor(courses[0]):null;
     };
     let route=getRoute();
     if(!route){
      const card=matches[0].element;
      const button=card.querySelector('[data-toggle="popover"],[data-bs-toggle="popover"],button:not([type=submit])')||card;
      button.click();
      route=await until(getRoute,20,active);
     }
     if(!active())return;
     if(!route){advance(job,false);return;}
     job.cid=cid(route);
     if(!job.force){
      const key=cacheKey(job.teacher,job.cid);
      if(currentTree((await browser.storage.local.get(key))[key],job.teacher,job.cid)){
       if(active())advance(job,true);return;
      }
     }
     await catalog.flush?.();
     if(active())go(job,'index',route.href);
     return;
    }
    onProgress(job);
    if(job.stage==='index'){
     if(!pathIs(page.pathname,prepIndex)||cid(page)!==job.cid){advance(job,false);return;}
     const links=await until(()=>{const found=addLinks();return found.length&&found;},20,active);
     if(!active())return;
     if(links?.length!==1){advance(job,false);return;}
     const add=officialURL(links[0],addPrep);
     if(/^\d+$/.test(cid(add))&&cid(add)!==job.cid){advance(job,false);return;}
     go(job,'tree',add.href);
     return;
    }
    if(job.stage==='tree'){
     let units;
     try{
      const bridge=root.NoorPrepBridge2828;
      if(!bridge?.onAddPage())throw Error('missing preparation page');
      const identity=await bridge.courseIdentity().catch(()=>null);
      if(identity?.cid&&String(identity.cid)!==job.cid)throw Error('different class');
      if(!active())return;
      units=await bridge.curriculum();
     }catch(_){}
     if(!active())return;
     if(!validUnits(units)){advance(job,false);return;}
     await browser.storage.local.set({[cacheKey(job.teacher,job.cid)]:{teacher:job.teacher,cid:job.cid,at:Date.now(),units}});
     if(active())advance(job,true);
    }
   }finally{running=false;}
  }
  function advance(job,success){
   const next={...job,index:job.index+1,completed:job.completed+Number(success)};
   if(!success)next.missed=[...job.missed,job.queue[job.index]];
   go(next,'dashboard',dashboard);
   if(dashboardPage())setTimeout(()=>resume().catch(onError),0);
  }
  function onError(){
   const job=load();
   if(job){cancel();onFinish({...job,interrupted:true});}
  }
  return {start:opts=>start(opts).catch(onError),resume:()=>resume().catch(onError)};
 }
 root.NoorCurriculumDiscovery=Object.freeze({create,load,cancel,addLinks,dashboardPage});
})(globalThis);
