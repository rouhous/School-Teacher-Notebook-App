# Noor Unified Tools 2.8.36 — numeric unit and lesson resolution

- Teacher chooses course and service separately; chosen service persists within the Firefox Noor tab and does not switch to Grades based on the currently open URL.
- Accepts number-only Unit/Theme and Lesson fields, displaying the official title when resolved from the Noor preparation curriculum. Resolves with verified term/unit/lesson IDs and rejects ambiguity, including Unit 4 / Lesson 4 and Theme 4 / Unit 4.
- Safely stores curriculum metadata by teacher and verified numeric Noor class CID after reading the authenticated preparation tree. Other services can use the stored titles but stop if the curriculum has not been verified. No student data or Gemini keys are written into curriculum cache.
- Removes potentially wrong lesson-autofill across classes. Never guesses a class ID, never saves SCORM to an unverified course, and never publishes an activity with invalid or unrequested question types.
- JavaScript syntax and a numeric resolver test suite checked. Authenticated Noor end-to-end publishing still requires a live teacher-session test.

Signed releases use the existing Firefox extension ID and GitHub/Mozilla pipeline; do not directly publish unsigned XPIs.
