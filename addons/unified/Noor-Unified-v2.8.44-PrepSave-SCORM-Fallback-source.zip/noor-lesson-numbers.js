/* Noor unit/lesson number resolver 2.8.36. Uses verified curriculum titles and node IDs.
 * No guess based on a raw number: ambiguity stops publishing. */
(function(root){'use strict';
 const norm=v=>String(v||'').normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/\s+/g,' ').trim().toLowerCase();
 const digit=v=>{const converted=String(v||'').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776));return converted};
 const ordinalMap={'اول':1,'اولى':1,'ثاني':2,'ثانيه':2,'ثالث':3,'ثالثه':3,'رابع':4,'رابعه':4,'خامس':5,'خامسه':5,'سادس':6,'سادسه':6,'سابع':7,'سابعه':7,'ثامن':8,'ثامنه':8,'تاسع':9,'تاسعه':9,'عاشر':10,'عاشره':10,'حادي عشر':11,'حاديه عشره':11,'ثاني عشر':12,'ثانيه عشره':12};
 const ar=t=>norm(t).replace(/ة/g,'ه').replace(/(^|\s)ال(?=اول|ثاني|ثالث|رابع|خامس|سادس|سابع|ثامن|تاسع|عاشر|حادي)/g,'$1');
 function number(v,kind){
  const str=digit(v).trim();if(/^\d{1,2}$/.test(str))return Number(str);
  // Science Noor tree: unit "4 الخلايا والكائنات الحية", lesson "4-1 خصائص...".
  // The first digit is the UNIT; the second is the LESSON, not the reverse.
  const pair=/(?:^|\s)(\d{1,2})\s*[-–.]\s*(\d{1,2})(?=\s|$)/.exec(str);
  if(pair)return Number(kind==='unit'?pair[1]:pair[2]);
  if(kind==='unit'){
   const opening=/^\s*(\d{1,2})(?=\s+[^0-9]|\s*$)/.exec(str);
   if(opening)return Number(opening[1]);
  }
  const prefix=kind==='unit'?/(?:^|\s)(?:Unit|Theme|الوحدة|وحدة|ثيم)\s*[:#.-]?\s*(\d{1,2})(?!\d)/i:
     /(?:^|\s)(?:Lesson|الدرس|درس)\s*[:#.-]?\s*(\d{1,2})(?!\d)/i;
  const match=prefix.exec(str);if(match)return Number(match[1]);
  const natural=ar(str);
  const opener=(kind==='unit'?/(?:^|\s)(?:الوحده|وحده|unit|theme)\s*[:#.-]?\s*/i:
    /(?:^|\s)(?:الدرس|درس|lesson)\s*[:#.-]?\s*/i).exec(natural);
  if(opener){
    const tail=ar(natural.slice(opener.index+opener[0].length));
    for(const [key,n] of Object.entries(ordinalMap).sort((a,b)=>b[0].length-a[0].length)){
      if(tail===key||new RegExp('^'+key+'(?=$|[\\s:،.-])').test(tail))return n;
    }
  }
  return null;
 }

 function term(v){const text=norm(v);if(/الثاني|second|semester\s*2|term\s*2|الفصل\s*2/.test(text))return '2';
  if(/الاول|first|semester\s*1|term\s*1|الفصل\s*1/.test(text))return '1';return ''}
 function same(value,input,kind){if(!String(input||'').trim())return false;
  if(norm(value)===norm(input))return true;
  const wanted=digit(input).trim();const n=number(value,kind),requested=number(wanted,kind);
  // A numbered request (4, 4-1, or "الدرس الأول") can match a verified
  // tree title. Two different descriptive titles are NEVER treated as equal.
  const indexed=/^\d{1,2}(?:\s*[-–.]\s*\d{1,2})?$/.test(wanted) ||
    /^(?:الوحدة|وحدة|الدرس|درس|unit|theme|lesson)\s+(?:(?:ال)?[\u0621-\u064a]+|\d{1,2})$/i.test(wanted);
  // A composite teacher input 5-1 must never match a different unit's 4-1.
  const composite=/^(\d{1,2})\s*[-–.]\s*(\d{1,2})$/.exec(wanted);
  if(composite){const actual=/(?:^|\s)(\d{1,2})\s*[-–.]\s*(\d{1,2})(?=\s|$)/.exec(digit(value));
   return !!actual&&Number(actual[1])===Number(composite[1])&&Number(actual[2])===Number(composite[2]);}
  return indexed && requested!==null && n===requested;
 }
 function resolve(units,{semester,unit,lesson,manualSelection}={}){
   const trees=Array.isArray(units)?units:[];
   let matches=[];
   for(const u of trees){
    const manual=manualSelection&&String(manualSelection.termId||'')===String(u.termId||'') &&
      String(manualSelection.unitId||'')===String(u.unitId||'');
    if(manualSelection&&!manual)continue;
    if(!manualSelection&&!same(u.unit,unit,'unit'))continue;
    const t=term(u.term);
    if(t&&semester&&t!==String(semester))continue;
    for(const l of u.lessons||[]){
     if(manualSelection){if(String(manualSelection.lessonId||'')!==String(l.id||''))continue;}
     else if(!same(l.title,lesson,'lesson'))continue;
     // For combined Science codes like 4-1, verify the explicit unit prefix.
     const pair=/(?:^|\s)(\d{1,2})\s*[-–.]\s*(\d{1,2})(?=\s|$)/.exec(digit(l.title));
     const selectedUnit=number(u.unit,'unit');
     if(pair&&selectedUnit!==null&&Number(pair[1])!==selectedUnit)continue;
     if(!u.termId||!u.unitId||!l.id)continue;
     matches.push({termId:String(u.termId),unitId:String(u.unitId),lessonId:String(l.id),unit:String(u.unit),title:String(l.title),semester:t||String(semester||'')});
    }
   }
   if(matches.length!==1)return {ok:false,reason:matches.length===0?'not_found':'ambiguous',count:matches.length};
   return {ok:true,...matches[0]};
 }
 root.NoorLessonNumbers=Object.freeze({number,term,resolve});
})(typeof globalThis==='object'?globalThis:this);
