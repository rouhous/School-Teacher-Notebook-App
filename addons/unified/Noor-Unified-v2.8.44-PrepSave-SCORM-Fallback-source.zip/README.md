# Noor Unified 2.8.44 — Preparation save handshake and SCORM image fallback

Based on 2.8.43. Preserves teacher accounts, authorization, lesson selection and the existing Mozilla extension ID.

## Changes

1. Auto-save preparation: the official Noor form now validates its required fields, acknowledges the submission request BEFORE the single save-button click and performs that click once after a short delay. This avoids misreporting failure solely because Noor navigates before the response reaches the add-on. A submission receipt is stored per tab; absence of a server confirmation remains **unverified**, never retried automatically.
2. After navigation, a Noor success alert can mark a preparation save confirmed. Without an explicit success alert, the add-on reports that it clicked the button but cannot verify server persistence. It does not claim false success.
3. SCORM image setting: Gemini 3D with SVG fallback (default), Gemini 3D with no-image fallback, SVG directly, or no image. This makes Gemini image quota/plan errors such as HTTP 429 non-blocking when a fallback is selected. Text/question generation still needs Gemini and will stop on its own errors.
4. Embedded SVG fallback is a local vector illustration chosen by broad subject context (science, math, language, social studies); it is labeled accurately as SVG, **not** a Gemini 3D rendering. No images / external assets are required in no-image mode. All SCORM ZIPs remain offline-capable.

## Verification needed

The user must test on the live authenticated Noor preparation form because the exact server-side save response and navigation behavior cannot be established by local tests. The single-click protection remains in place.
