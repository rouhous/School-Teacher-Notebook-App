/* The active teacher is linked from the approved School Teacher Notebook session.
 * Keys never move between accounts and are never synced to a remote backend as settings. */
(function () {
  'use strict';
  const api = typeof browser !== 'undefined' ? browser : chrome;
  const ID_KEY = 'stnActiveTeacherId';
  const KEY_PREFIX = 'stnGeminiKey:';
  const validId = id => typeof id === 'string' && /^[A-Za-z0-9_:\-.]{3,200}$/.test(id);
  const validKey = key => /^AIza[\w-]{20,}$/.test(String(key || '').trim());
  const storageKey = id => KEY_PREFIX + id;
  async function active() {
    const data = await api.storage.local.get(ID_KEY);
    const id = String(data[ID_KEY] || '');
    return validId(id) ? id : '';
  }
  async function read() {
    const id = await active();
    if (!id) return {id:'',key:''};
    const data = await api.storage.local.get(storageKey(id));
    return {id,key:validKey(data[storageKey(id)]) ? data[storageKey(id)] : ''};
  }
  async function save(key) {
    const id = await active();
    if (!id) throw Error('افتح دفتر المعلم بحساب Google المعتمد أولًا لربط هذا المفتاح.');
    if (!validKey(key)) throw Error('صيغة مفتاح Gemini غير صحيحة.');
    await api.storage.local.set({[storageKey(id)]:String(key).trim()});
    return id;
  }
  async function remove() {
    const id = await active();
    if (!id) throw Error('لا يوجد حساب معلم مرتبط.');
    await api.storage.local.remove(storageKey(id));
  }
  async function migrateLegacy() {
    const id = await active();
    if (!id) throw Error('اربط حساب المعلم أولًا.');
    const legacy = (await api.storage.local.get('noorTeacherGeminiKey')).noorTeacherGeminiKey;
    if (!validKey(legacy)) throw Error('لا يوجد مفتاح من الإضافة القديمة.');
    await save(legacy);
    await api.storage.local.remove('noorTeacherGeminiKey');
    return id;
  }
  window.NOOR_TEACHER_PROFILE = Object.freeze({active,read,save,remove,migrateLegacy,validKey,ID_KEY});
})();
