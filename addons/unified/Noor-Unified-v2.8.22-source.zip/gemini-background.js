// Gemini is billed/limited against each linked teacher's own API project.
// The key stays in Firefox extension storage and is transmitted only via HTTPS
// to the existing prep relay while generating; SCORM generation calls Gemini directly.
const STN_TEACHER_KEY='stnActiveTeacherId';
const STN_KEY_PREFIX='stnGeminiKey:';
const STN_NOTEBOOK_URL='https://rouhous.github.io/School-Teacher-Notebook-App/school-edition/school-notebook.html';
const STN_NOOR_ORIGIN='https://lms.moe.gov.om/';
const keyPattern=/^AIza[\w-]{20,}$/;
async function teacherContext(){
  const {stnActiveTeacherId}=await browser.storage.local.get(STN_TEACHER_KEY);
  const id=String(stnActiveTeacherId||'');
  if(!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))throw Error('افتح دفتر المعلم بحساب Google المعتمد، ثم ارجع إلى نور.');
  const {['stnGeminiKey:'+id]:key}=await browser.storage.local.get(STN_KEY_PREFIX+id);
  if(!keyPattern.test(String(key||'')))throw Error('لم يتم حفظ مفتاح Gemini لهذا المعلم.');
  return {id,key};
}
const fromNotebook=sender=>String(sender?.url||'').startsWith(STN_NOTEBOOK_URL);
const fromNoor=sender=>String(sender?.url||'').startsWith(STN_NOOR_ORIGIN);
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!msg||!fromNotebook(sender))return false;
 if(msg.type==='STN_SET_ACTIVE_TEACHER')return (async()=>{
   const id=String(msg.teacherId||'');
   if(!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))return {ok:false,error:'invalid_teacher_id'};
   await browser.storage.local.set({stnActiveTeacherId:id});return {ok:true};
 })();
 if(msg.type==='STN_STORE_GRADES')return (async()=>{
   const p=msg.payload;
   const id=(await browser.storage.local.get(STN_TEACHER_KEY)).stnActiveTeacherId;
   if(!id||msg.teacherId!==id||p?.schema!=='teacher-notebook-noor-v1' ||
      !Array.isArray(p.students)||!Array.isArray(p.assessments)||
      p.students.length>300||p.assessments.length>120||JSON.stringify(p).length>500000)
     return {ok:false,error:'invalid_payload'};
   const safe={schema:p.schema,exportedAt:String(p.exportedAt||''),className:String(p.className||'').slice(0,120),
     assessments:p.assessments.map(a=>({id:String(a.id||''),name:String(a.name||'').slice(0,100),max:Number(a.max)||0})),
     students:p.students.map(st=>({name:String(st.name||'').slice(0,180),studentNumber:String(st.studentNumber||'').slice(0,40),
       grades:Object.fromEntries(Object.entries(st.grades||{}).slice(0,120).map(([k,v])=>[String(k).slice(0,80),String(v??'').slice(0,30)]))}))};
   await browser.storage.local.set({['stnGrades:'+id]:safe});
   return {ok:true,count:safe.students.length};
 })();
 return false;
});
const NOOR_SB_URL='https://czljzhwmtqmtmlsbwgyz.supabase.co';
const NOOR_SB_PUBLIC='sb_publishable_fwWBrwdO6rsJxzQRS1dfLw_laESLi4U';
let noorAuthPromise;
async function noorGetSessionToken(){
 if(noorAuthPromise)return noorAuthPromise;
 noorAuthPromise=(async()=>{
  const saved=await browser.storage.local.get('noorSbSession');
  let session=saved.noorSbSession;
  const request=async(path,body)=>{
   const res=await fetch(NOOR_SB_URL+'/auth/v1/'+path,{method:'POST',headers:{'Content-Type':'application/json','apikey':NOOR_SB_PUBLIC},body:JSON.stringify(body)});
   const json=await res.json();if(!res.ok)throw Error(json.msg||json.error_description||json.message||'Auth HTTP '+res.status);return json;
  };
  if(session?.access_token && session.expires_at && Date.now()<session.expires_at-120000)return session.access_token;
  if(session?.refresh_token){try{session=await request('token?grant_type=refresh_token',{refresh_token:session.refresh_token});}catch{session=null;}}
  if(!session?.access_token)session=await request('signup',{});
  if(!session?.access_token)throw Error('لم تُرجع خدمة المصادقة جلسة صالحة');
  session.expires_at=Date.now()+Math.max(60,Number(session.expires_in)||3600)*1000;
  await browser.storage.local.set({noorSbSession:session});
  return session.access_token;
 })();
 try{return await noorAuthPromise;}finally{noorAuthPromise=null;}
}
browser.runtime.onMessage.addListener((msg,sender) => {
 if (!msg || msg.type !== 'NOOR_GEMINI_GENERATE' || !fromNoor(sender)) return false;
 return (async()=>{
 let key; try {({key}=await teacherContext())}catch(e){return {ok:false,error:String(e.message||e)}}
 const count=Math.max(1,Math.min(40,Number(msg.count)||10));
 const prompt=String(msg.prompt||'').slice(0,6500)+`\nReturn ONLY JSON with exactly ${count} questions: {"title":"...","questions":[{"question":"...","options":["...","...","...","..."],"correct":0,"explanation":"..."}]}. Each question must have exactly 4 options, one correct index 0-3. No markdown. Do not invent specific textbook facts not in supplied context. If lesson details are missing, write broadly relevant questions and avoid unsupported curriculum claims.`;
 try {
  const ctrl=new AbortController(); const timer=setTimeout(()=>ctrl.abort(),90000);
  let res;
  try {res=await fetch('https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent', {method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify({contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.6,maxOutputTokens:16000}}),signal:ctrl.signal});} finally {clearTimeout(timer)}
  const payload=await res.json();
  if(!res.ok) return {ok:false,error:(payload.error?.message||('HTTP '+res.status)).slice(0,500)};
  const raw=payload.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('')||'';
  const data=JSON.parse(raw);
  if(!Array.isArray(data.questions)||data.questions.length!==count) throw Error('عدد الأسئلة غير مطابق للمطلوب. حاول مرة أخرى.');
  for(const q of data.questions){if(typeof q.question!=='string'||!Array.isArray(q.options)||q.options.length!==4||!q.options.every(x=>typeof x==='string')||!Number.isInteger(q.correct)||q.correct<0||q.correct>3||typeof q.explanation!=='string') throw Error('صيغة سؤال غير صحيحة. حاول مجددًا.');}
  return {ok:true,data:{title:String(data.title||'Interactive Activity').slice(0,150),questions:data.questions}};
 } catch(e){return {ok:false,error:e.name==='AbortError'?'انتهت مهلة Gemini. حاول مجددًا.':String(e.message||e).slice(0,400)};}
})();
});
// Protected preparation generation. Never bundle Gemini secrets in the extension.
browser.runtime.onMessage.addListener((msg,sender) => {
 if (!msg || msg.type !== 'NOOR_PREP_GENERATE' || !fromNoor(sender)) return false;
 return (async()=>{
 let personalKey; try {({key:personalKey}=await teacherContext())}catch(e){return {ok:false,error:String(e.message||e)}}
 let token;
 try { token=await noorGetSessionToken(); }
 catch(e) {return {ok:false,error:'تعذر إنشاء جلسة تلقائية. فعّل Anonymous Sign-ins في Supabase Auth أولًا. '+String(e.message||e).slice(0,180)};}
 try {
  const ctrl=new AbortController();const timer=setTimeout(()=>ctrl.abort(),60000);
  let response;
  try {response=await fetch('https://czljzhwmtqmtmlsbwgyz.supabase.co/functions/v1/noor-generate-prep',{
   method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+token,'apikey':NOOR_SB_PUBLIC},
   body:JSON.stringify({subject:msg.subject,grade:msg.grade,unit:msg.unit,lesson:msg.lesson,lessonText:msg.lessonText,fields:msg.fields,geminiApiKey:personalKey}),signal:ctrl.signal});}
  finally{clearTimeout(timer)}
  const data=await response.json();
  if(!response.ok)return {ok:false,error:[String(data.error||'generation_error'),data.detail?String(data.detail):'', 'HTTP '+response.status].filter(Boolean).join(' — ').slice(0,500)};
  return {ok:true,fields:data.fields||{}};
 }catch(e){return {ok:false,error:String(e.message||e)}}
})();
});
