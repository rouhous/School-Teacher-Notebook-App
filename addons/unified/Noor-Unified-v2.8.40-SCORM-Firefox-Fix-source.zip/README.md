# Noor Unified 2.8.40 — SCORM publication workflow (TEST BUILD)

**Derived directly from the user-supplied Mozilla-signed 2.8.38 XPI. The original signed 2.8.38 was not modified.**

## Scope

- Preserves existing preparation, activities, grades, teacher license, Gemini generation and SCORM 1.2 packaging.
- Adds a per-SCORM preselected action: **review uploaded draft** (default) or **automatic save if every safety check passes**.
- Generated SCORM ZIPs are still downloaded as backups. For a single package, the extension temporarily retains the ZIP in teacher-scoped browser local storage while navigating across Noor pages. Imported SCORM ZIPs follow the same workflow.
- Navigates to a previously verified class-specific SCORM link, or cautiously follows uniquely labelled visible controls for: Electronic Library → Interactive lessons → Create interactive lesson. It never guesses opaque CID/TID values or calls unpublished portal APIs.
- On a verified form, tries to select SCORM instead of HTML5, title, description, English language if uniquely identified, publication date where a native date control exists, the exact lesson tree item, class checkbox, and the correct ZIP input (not cover image). It shows a compact field-summary preview.
- If auto-save was chosen **before** generation/import, the extension attempts **one** save click only after the identified grade, subject, class, lesson tree, file, SCORM radio, publishing date, and unique Save/Publish button pass checks. It flags the final result as **unverified** rather than claiming that Noor accepted it.
- Stops with an Arabic reason if Noor's live controls are ambiguous. Pending package can be resumed or canceled from the SCORM panel. No repeated submission after an uncertain save.
- SCORM files over 5 MiB, or multiple files in one request, require separate handling and are not blindly auto-published.

## Critical limitation

**The complete authenticated Noor workflow has not been validated in the user's live portal**. Its DOM, tree widget, form upload semantics, final save and success page may differ from the safe selectors. Therefore this is a test release candidate, not a validated production auto-publisher. A signed installation and on-site smoke test are required before enabling automatic updates.

The supplied Mozilla signature covers 2.8.38 only. This 2.8.40 source/unsigned XPI must be signed afresh by Mozilla to install persistently in Firefox. Never copy `META-INF` from a different signed version into the modified archive.

## Local checks

- All unminified extension JavaScript passes `node --check`.
- Manifest JS/CSS references exist and original Firefox ID / update URL are preserved.
- SCORM 1.2 ZIP generator created a manifest-bearing package with representative MCQ, true/false, order and match questions.
- External authenticated Noor browser verification was not possible, and the local browser's navigation environment blocks browser test URLs. No end-to-end claim is made.

## Suggested Noor smoke test

1. Install a **Mozilla-signed** development candidate, log into the teacher's own Noor account and open the correct class card.
2. Choose subject, class/section, semester, unit and lesson. Select `🎮 مساق تفاعلي SCORM` and **🔎 رفع الملف وعرضه للمراجعة**.
3. Generate one package or import a ZIP. Verify electronic-library navigation, the create-interactive-lesson form, SCORM radio, tree and class selection, title/date, and uploaded ZIP. Verify no Save was clicked in review mode.
4. Repeat with **💾 حفظ تلقائي إذا تحقق كل شرط** only in an authorized test lesson. Check the portal list for the newly saved item; on uncertainty, do not retry blindly.
5. Verify an ambiguous lesson or wrong section fails closed without uploading or saving.

Build filename does NOT imply Firefox signing or successful Noor publishing.

## 2.8.40 Firefox SCORM navigation fix
Replaced typed-array subarray() in the SCORM temporary ZIP serializer with index-only encoding. Avoids Firefox Xray cross-compartment constructor permission denial immediately after SCORM ZIP generation. The original ZIP generator, upload verification, review/auto-save controls, and class selection safeguards are unchanged.
