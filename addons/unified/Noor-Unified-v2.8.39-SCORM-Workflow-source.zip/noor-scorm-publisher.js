/* Noor Unified 2.8.39 — SCORM page-to-page publisher (Firefox content script).
 * Never sends a file to an invented endpoint. Uses the teacher's visible Noor
 * navigation, selects only uniquely identified form controls, verifies class
 * before attaching, and never claims a submission succeeded from a click.
 * Unknown Noor UI => stop, preserve the package, explain the blocker.
 */
(function(root){'use strict';
 if(window.top!==window||!/^\/teacher(?:\/|$)/i.test(location.pathname)||root.NoorScormPublisher)return;
 const JOB='stnScormPublishJob:v1',FILE='stnScormTempZip:v1:',MAX=5*1024*1024,TTL=45*60*1000;
 const norm=s=>String(s||'').normalize('NFKC').replace(/[إأآ]/g,'ا').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const tidy=s=>String(s||'').replace(/\s+/g,' ').trim();
 const sleep=t=>new Promise(r=>setTimeout(r,t));
 const inHub=el=>Boolean(el?.closest?.('#stnNoorHub,#noor-prep-panel'));
 const visible=el=>Boolean(el&&el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden');
 const isScorm=()=>/\/teacher\/attachments\/(?:index|upload)\/Scorm(?:\/|$)/i.test(location.pathname);
 const isScormForm=()=>isScorm()&&/\/upload\/Scorm\b/i.test(location.pathname)||isScorm()&&!![...document.querySelectorAll('input[type="file"]')].find(e=>!inHub(e)&&/\.zip|scorm/i.test([e.name,e.id,e.accept].join(' ')));
 const get=()=>{try{const j=JSON.parse(sessionStorage.getItem(JOB)||'null');if(!j)return null;if(Date.now()-j.at>TTL){sessionStorage.removeItem(JOB);return null}return j}catch(_){return null}};
 const set=j=>sessionStorage.setItem(JOB,JSON.stringify({...j,updated:Date.now()}));
 function notice(message){
  const panel=document.getElementById('stnHubPanel'),s=document.getElementById('stnHubStatus');
  if(panel)panel.hidden=false;
  const svc=document.getElementById('stnHubService');if(svc&&svc.value!=='scorm'){svc.value='scorm';svc.dispatchEvent(new Event('change',{bubbles:true}));}
  if(s)s.textContent=String(message);
 }
 async function teacher(){try{return String(await root.NOOR_TEACHER_PROFILE?.active?.()||'')}catch(_){return ''}}
 const fileKey=j=>FILE+j.id;
 function encode(bytes){let s='';for(let i=0;i<bytes.length;i+=8192)s+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(s)}
 function decode(str){const s=atob(str);const a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return a}
 async function cleanup(j){if(!j)return;try{await browser.storage.local.remove(fileKey(j))}catch(_){}sessionStorage.removeItem(JOB)}
 async function cancel(){const j=get();await cleanup(j);notice('ألغي النشر المعلّق. لم يتغير شيء في نور. احتفظت بنسخة SCORM المنزلة.');}
 async function start(file,opts){
  if(!file||file.size<100||file.size>MAX)throw Error('الملف كبير جدًا للتنقل التلقائي (الحد 5 ميغابايت) أو فارغ. احتفظ بالنسخة المنزلة وارفعها يدويًا.');
  if(!/\.zip$/i.test(file.name)||!root.NoorScorm?.hasManifest?.(await file.arrayBuffer()))throw Error('حزمة SCORM ليست ZIP صالحًا بملف imsmanifest.xml.');
  if(get()&&!['paused','staged','submitted_unknown','done'].includes(get().phase))throw Error('توجد عملية نشر جارية؛ استكملها أو ألغها قبل بدء عملية جديدة.');
  const t=await teacher();
  if(!t||!opts.teacherId||t!==String(opts.teacherId))throw Error('لم تثبت هوية المعلم قبل نقل ملف SCORM.');
  const c=opts.course;
  if(!c?.verified||!/^\d+$/.test(String(c.cid||''))||!c.grade||!c.label||!c.subject||norm(c.subject)!==norm(opts.subject))throw Error('لم تثبت المادة والصف من بطاقة نور.');
  if(!opts.unit||!opts.lesson)throw Error('تحديد الوحدة والدرس في شجرة نور مطلوب.');
  const existing=get();if(existing)await cleanup(existing);
  const j={id:'s'+Date.now()+'-'+Math.random().toString(36).slice(2,9),at:Date.now(),teacherId:t,
   mode:opts.mode==='auto'?'auto':'review',phase:'route',step:'',clicks:0,
   cid:String(c.cid),grade:Number(c.grade),label:tidy(c.label),subject:tidy(opts.subject),
   semester:String(opts.semester),unit:tidy(opts.unit),lesson:tidy(opts.lesson),
   filename:file.name,formPath:'',verifiedLesson:false,attached:false};
  const bin=encode(new Uint8Array(await file.arrayBuffer()));
  try{await browser.storage.local.set({[fileKey(j)]:{at:j.at,teacherId:t,name:file.name,base64:bin}})}
  catch(e){throw Error('لم أستطع حفظ نسخة SCORM مؤقتًا أثناء التنقل: '+String(e?.message||e))}
  set(j);notice('حُفظ ملف SCORM مؤقتًا لهذه العملية؛ جارٍ فتح بوابة الدرس التفاعلي للصف المحدد.');
  setTimeout(()=>advance().catch(e=>pause(get(),String(e?.message||e))),250);
  return {ok:true,queued:true,id:j.id};
 }
 function uniqueLink(regex){
  const nodes=[...document.querySelectorAll('a,button,[role="button"]')]
   .filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&regex.test(norm(e.innerText||e.textContent||e.getAttribute('title')||'')))
   .filter(e=>tidy(e.innerText||e.textContent||e.getAttribute('title')).length<80);
  const seen=new Set();return nodes.filter(e=>{const u=e.closest('a')||e;const k=u.href||e.id||norm(e.textContent);if(seen.has(k))return false;seen.add(k);return true});
 }
 function takeNavigation(j,action,label){
  if(!action||!visible(action))return false;
  const target=action.closest('a')||action;
  if(target.tagName==='A'&&target.href){const u=new URL(target.href,location.href);if(u.origin!==location.origin||!/^\/teacher(?:\/|$)/i.test(u.pathname))return false;}
  if(j.clicks>=8)throw Error('تجاوز عدد خطوات التنقل. لن تتكرر النقرات.');
  j.clicks++;j.phase='route';j.step=label;j.lastPath=location.pathname;j.lastAt=Date.now();set(j);
  notice('جارٍ فتح: '+label+' ...');target.click();return true;
 }
 function pause(j,reason){if(!j)return;const reasonText=String(reason||'تعذر تحديد العنصر بشكل آمن').slice(0,350);
  j.phase='paused';j.reason=reasonText;set(j);
  notice('توقف النشر الآلي بأمان: '+reasonText+' — ملف SCORM محفوظ مؤقتًا، ولم أضغط حفظ. افتح الصفحة الصحيحة ثم اضغط «استكمال النشر الموجود».');
 }
 function pickNav(j){
  const known=root.NoorCourseCatalog?.get?.(j.cid);
  if(!known||Number(known.grade)!==j.grade||norm(known.label)!==norm(j.label))throw Error('هوية الصف لم تطابق سجل الصفوف الرسمي.');
  const routes=known.routes||{};
  if(routes.scorm){const u=new URL(routes.scorm,location.href);
   if(u.origin!==location.origin||!/^\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(u.pathname))throw Error('رابط SCORM غير متوقع.');
   if(u.pathname!==location.pathname){j.phase='route';j.step='official_scorm_route';j.clicks++;set(j);notice('فتح مساقات SCORM من الرابط الرسمي المحفوظ لهذا الصف...');location.assign(u.href);return true;}
  }
  // When the class's SCORM route is not saved, browse only uniquely labelled
  // official visible navigation items. No manufactured CID/TID or hidden API.
  const steps=[[/^(?:بوابه\s+)?(?:المكتبه الالكترونيه|e-?library|electronic library)$/i,'المكتبة الإلكترونية'],
   [/^(?:الدروس? التفاعليه|دروس تفاعليه|interactive lessons?|مساقات تفاعليه)$/i,'الدروس التفاعلية'],
   [/^(?:انشاء|اضافه|رفع)\s+(?:درس|مساق)\s+تفاعلي$/i,'إنشاء درس تفاعلي']];
  for(const [re,label] of steps){const options=uniqueLink(re);if(options.length===1)return takeNavigation(j,options[0],label)}
  return false;
 }
 function fieldText(el){return norm([el.getAttribute('placeholder'),el.id,el.name,el.getAttribute('aria-label'),
  [...(el.labels||[])].map(x=>x.textContent).join(' '),el.closest('.form-group,.form-row')?.querySelector('label')?.textContent].join(' '))}
 function searchField(filter,selectors){const matches=[...document.querySelectorAll(selectors)].filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&filter(fieldText(e),e));return matches.length===1?matches[0]:null}
 function nativeValue(el,value){const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value')?.set?.call(el,String(value));el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
 function fileInput(){const inputs=[...document.querySelectorAll('input[type="file"]')].filter(e=>!e.disabled&&!inHub(e));
  const looks=inputs.filter(e=>{const t=fieldText(e)+' '+norm(e.accept);
   return !/غلاف|صوره|cover|image|jpe?g|png|webp|avatar/.test(t) && /scorm|zip|file|attachment|ملف|upload|\.zip/.test(t)});
  if(looks.length===1)return looks[0];
  const other=inputs.filter(e=>!/غلاف|صوره|image|cover|jpe?g|png|webp/.test(fieldText(e)+' '+norm(e.accept)));
  return other.length===1?other[0]:null;
 }
 function optionOfRadio(text){const want=norm(text);
  const radios=[...document.querySelectorAll('input[type="radio"]')].filter(e=>!e.disabled&&!inHub(e));
  const hits=radios.filter(e=>{const t=norm([...(e.labels||[])].map(x=>x.textContent).join(' ')+(e.closest('label')?.textContent||''));return new RegExp('(^|\\s)'+want+'($|\\s)').test(t)});
  return hits.length===1?hits[0]:null;
 }
 function treeCandidate(j){
  const selectors='.jstree-anchor,.fancytree-title,[role="treeitem"],.tree-node-title,.treeview a,.tree a,.ztree a,[data-lesson-id]';
  const nodes=[...document.querySelectorAll(selectors)].filter(e=>visible(e)&&!inHub(e)&&!e.closest('nav'));
  const matches=nodes.filter(e=>norm(e.textContent)===norm(j.lesson));
  const unique=[...new Set(matches)];return unique.length===1?unique[0]:null;
 }
 function treeSelected(node){if(!node)return false;
  const scope=node.closest('li,[role="treeitem"]')||node;
  return Boolean(node.getAttribute('aria-selected')==='true'||scope.getAttribute('aria-selected')==='true'||
   node.classList.contains('jstree-clicked')||node.classList.contains('fancytree-selected')||
   scope.classList.contains('jstree-checked')||scope.classList.contains('jstree-clicked')||
   scope.classList.contains('selected')||scope.querySelector('input[type="checkbox"]:checked'));
 }
 function treeOpen(){return uniqueLink(/^(?:عرض الشجره|عرض الشجرة|شجره الدروس|شجرة الدروس)$/i)}
 function exactSaveButton(){const els=[...document.querySelectorAll('button,input[type="submit"],a.btn')]
  .filter(e=>visible(e)&&!e.disabled&&!inHub(e));
  const names=/^(?:حفظ|حفظ ونشر|نشر|اضافه|اضافه الدرس|save|publish|submit)$/i;
  const matches=els.filter(e=>names.test(norm(e.textContent||e.value||e.title)));
  return matches.length===1?matches[0]:null;
 }
 function requiredUnfilled(){return [...document.querySelectorAll('input[required],select[required],textarea[required]')]
  .filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&e.type!=='hidden'&&e.type!=='radio'&&e.type!=='checkbox'&&e.type!=='file')
  .filter(e=>!String(e.value||'').trim());}
 async function stage(j){
  if(!isScorm())throw Error('صفحة الدرس التفاعلي في نور غير مفتوحة.');
  const c=root.NoorCourseCatalog?.get?.(j.cid);
  if(!c||norm(c.label)!==norm(j.label)||Number(c.grade)!==j.grade||norm(root.NoorCourseCatalog?.subjectOf?.(c.label)||'')!==norm(j.subject))throw Error('الصف أو المادة الحالية لا تطابق اختيارك.');
  const course={cid:j.cid,grade:j.grade,label:j.label,subject:j.subject,verified:true};
  const result=root.NoorScormClassEvidence?.ensureSelected?.(course);
  if(!result?.ok)throw Error('لم أتحقق من كتاب الصف والفصل المراد النشر له: '+(result?.reason||'not_found'));
  const type=optionOfRadio('SCORM');if(!type)throw Error('لم يظهر خيار واحد مؤكد لنوع الدرس SCORM في نور.');
  if(!type.checked){type.click();type.dispatchEvent(new Event('change',{bubbles:true}))}
  if(!type.checked)throw Error('تعذر تحديد SCORM في نوع الدرس.');
  const title=searchField(s=>/(?:^|\s)(?:العنوان|title)(?:\s|$)/i.test(s),'input[type="text"],input:not([type]),textarea');
  if(!title)throw Error('لم أميز حقل عنوان الدرس عن باقي الحقول.');
  if(!title.value||norm(title.value)!==norm(j.unit+' — '+j.lesson))nativeValue(title,j.unit+' — '+j.lesson);
  const desc=searchField(s=>/(?:^|\s)(?:الوصف|description)(?:\s|$)/i.test(s),'textarea,input[type="text"]');
  if(desc&&!desc.value)nativeValue(desc,'درس تفاعلي في '+j.subject+' — '+j.unit+' — '+j.lesson);
  const languages=[...document.querySelectorAll('select')].filter(e=>visible(e)&&!inHub(e)&&/اللغة|language/.test(fieldText(e)));
  if(languages.length===1&&!languages[0].value){const matching=[...languages[0].options].filter(o=>/english|الانجليزيه/.test(norm(o.textContent)));if(matching.length===1)nativeValue(languages[0],matching[0].value)}
  const date=searchField(s=>/تاريخ النشر|publish.*date|publication.*date/.test(s),'input[type="date"],input[type="text"]');
  if(date&&date.type==='date'&&!date.value){
   const local=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
   nativeValue(date,local);
  }
  // Text-calendar widgets are not standardized and may require a picker. Never
  // submit a required publication date that Noor has not itself accepted.
  const dateConfirmed=Boolean(date&&String(date.value||'').trim());
  if(!treeCandidate(j)){
   const open=treeOpen();
   if(open.length===1&&j.phase!=='tree_opened'){
    j.phase='tree_opened';set(j);open[0].click();await sleep(800);
   }
  }
  const tree=treeCandidate(j);
  if(tree&&!treeSelected(tree)){
   j.phase='tree_selection';set(j);tree.click();await sleep(450);
  }
  const selected=treeSelected(treeCandidate(j));
  if(!selected){
   // A label match without a selected tree node is NOT an official lesson mapping.
   throw Error('لم أجد درسًا واحدًا محددًا ومؤكدًا في شجرة نور: '+j.lesson+'. اختره في الشجرة ثم استكمل النشر.');
  }
  j.verifiedLesson=true;
  const input=fileInput();if(!input)throw Error('لم أميز خانة رفع ZIP عن خانة صورة الغلاف.');
  if(!input.files?.length){const temp=(await browser.storage.local.get(fileKey(j)))[fileKey(j)];
   if(!temp||temp.teacherId!==j.teacherId||temp.name!==j.filename)throw Error('اختفى الملف المؤقت أو اختلف حساب المعلم.');
   const bytes=decode(temp.base64),file=new File([bytes],temp.name,{type:'application/zip'});
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;
   input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  }
  if(input.files?.length!==1||input.files[0].name!==j.filename)throw Error('لم يتأكد إرفاق الملف إلى حقل SCORM الصحيح.');
  j.attached=true;j.formPath=location.pathname;j.phase='staged';set(j);
  const preview=document.getElementById('stnHubPreview');
  if(preview){preview.hidden=false;preview.textContent='معاينة النشر قبل الحفظ\nالصف: '+j.label+'\nالمادة: '+j.subject+
   '\nالفصل: '+j.semester+'\nالوحدة: '+j.unit+'\nالدرس: '+j.lesson+'\nSCORM: '+j.filename+
   '\nحالة الرفع: ملف مرتبط بخانة ZIP\nتاريخ النشر: '+(dateConfirmed?date.value:'غير محدد');}
  notice('✓ تم تجهيز مسودة SCORM: الصف والدرس والملف ونوع SCORM مؤكدون. '+(j.mode==='auto'?'جارٍ فحص صلاحية الحفظ...':'ظهرت معاينة بيانات الدرس في لوحة الإضافة؛ راجعها واحفظ من نور. لم أضغط حفظ.'));
  if(j.mode!=='auto')return;
  await sleep(1500);
  if(!dateConfirmed)throw Error('تاريخ النشر لم يُؤكّد في نور. اختره من التقويم قبل الحفظ التلقائي.');
  // The portal may need time to finish processing ZIP after change event.
  if(location.pathname!==j.formPath||!input.isConnected||input.files?.length!==1||!treeSelected(treeCandidate(j))||!type.checked)throw Error('تغيّر النموذج أثناء تجهيز الملف؛ أوقف الحفظ.');
  if(requiredUnfilled().length)throw Error('في نموذج نور حقول مطلوبة غير مكتملة؛ توقفت قبل الحفظ.');
  const button=exactSaveButton();
  if(!button)throw Error('زر الحفظ/النشر النهائي غير مميز بدقة في هذه النسخة من نور. لم يُضغط حفظ.');
  j.phase='submitted_unknown';j.submittedAt=Date.now();set(j);
  notice('تم الضغط على زر الحفظ مرة واحدة. التحقق من قبول نور جارٍ؛ لا تكرر الإرسال.');
  button.click();
 }
 let running=false;
 async function advance(){
  if(running)return;
  const j=get();if(!j||!['route','paused','tree_opened','tree_selection'].includes(j.phase))return;
  running=true;
  try{
   const t=await teacher();if(t!==j.teacherId)throw Error('تغيّر حساب المعلم؛ لن يُستخدم ملف معلم آخر.');
   root.NoorCourseCatalog?.scan?.();
   if(!isScormForm()){
    if(isScorm()){
     const create=uniqueLink(/^(?:(?:انشاء|اضافه|رفع)\s+(?:درس|مساق)\s+تفاعلي|درس تفاعلي جديد)$/i);
     if(create.length===1){takeNavigation(j,create[0],'إنشاء درس تفاعلي');return}
     if(create.length>1)throw Error('ظهر أكثر من زر لإنشاء درس تفاعلي؛ يجب اختيار الصفحة المناسبة.');
    }
    if(pickNav(j))return;
    throw Error('لم أجد رابطًا واحدًا مؤكدًا إلى «المكتبة الإلكترونية ← درس تفاعلي ← إنشاء درس تفاعلي».');
   }
   await stage(j);
  }catch(e){pause(get(),String(e?.message||e))}finally{running=false}
 }
 async function resume(){const j=get();if(!j){notice('لا توجد عملية نشر SCORM معلقة.');return}
  if(j.phase==='submitted_unknown'){notice('سبق الضغط على حفظ. افتح قائمة الدروس في نور وتحقق من النتيجة؛ لا يمكن تكرار الحفظ آليًا.');return}
  if(j.phase==='staged'){notice('المسودة جاهزة للمراجعة. حفظها الآن يدويًا في نور، أو أعد العملية بخيار الحفظ التلقائي.');return}
  j.phase='route';set(j);notice('جارٍ استكمال SCORM من الصفحة الحالية...');advance();
 }
 root.NoorScormPublisher=Object.freeze({start,resume,cancel,inspect:()=>{const j=get();return j?{phase:j.phase,grade:j.grade,lesson:j.lesson,mode:j.mode,reason:j.reason}:null}});
 setTimeout(()=>{const j=get();if(j){
   if(j.phase==='submitted_unknown'){notice('تمت محاولة حفظ SCORM سابقًا، لكن نتيجة نور لم تُتحقق. افحص قائمة الدروس، ولا تكرر الحفظ.');return}
   if(j.phase==='staged'){notice('الدرس التفاعلي جاهز للمراجعة على هذه الصفحة. لن يتكرر الرفع بعد تحديث الصفحة.');return}
   if(j.phase==='route'||j.phase==='tree_opened'||j.phase==='tree_selection')advance();
   else if(j.phase==='paused')notice('عملية SCORM معلقة: '+j.reason+' — اضغط «استكمال النشر الموجود» بعد فتح صفحة نور الصحيحة.');
  }},950);
})(typeof globalThis==='object'?globalThis:this);
