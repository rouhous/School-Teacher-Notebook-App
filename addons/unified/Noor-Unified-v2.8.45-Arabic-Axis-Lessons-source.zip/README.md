Noor Unified 2.8.45 — Arabic محور / named lesson tree fix

Source based on Noor Unified 2.8.44 (maintains automatic/manual selection, preparation auto-save guards, Gemini image fallback, SCORM, grade transfer, and activities).

Changes:
- Arabic curriculum: semester > محور > named lesson (including leaf lessons whose title starts with "الوحدة الأولى:"). The selected leaf is not rejected simply because its label starts with "الوحدة".
- The main-world Noor jsTree reader returns official lesson/unit/term node_id attributes as evidence and the content-world bridge exposes the selected leaf.
- Preparation generation first verifies the teacher's selected official leaf ID against the class- and teacher-scoped official curriculum; otherwise falls back to exact unit + lesson title + semester match. It never treats the selected axis as a lesson and never picks a similar-sounding sibling.
- Arabic محور numbering is recognized as a unit designation, preserving named lesson titles rather than replacing them with numbers.
- Automatic detection remains default; teacher manual selection remains available.

Local tests: node syntax validation across JS files; named Arabic محور lesson matching; ID integrity; parent node rejection; incorrect semester rejection. Real Noor end-to-end saving remains unverified.

Mozilla signing: use existing release-noor-signed.yml workflow and version 2.8.45. Do not alter signed XPI in place.
