# Noor Unified Tools v2.8.26 — merged preparation + smart activities (Firefox)

**Status: developer preview, unsigned.** The XPI must be signed through Mozilla Add-on Developer Hub with the **same Firefox extension ID** as 2.8.24 before it can be permanently installed or offered as an automatic update. The live 2.8.24 signed link and `updates.json` must stay unchanged until a signed 2.8.26 file is verified.

## One teacher interface

The new `noor-hub.js` panel offers **Preparation / Activity & Test / Grades / Interactive SCORM Course**, then class, semester, unit/theme, lesson, and **Generate with Gemini** or **Import File**. It reads selected lessons from Noor's visible tree and offers verified class choices only from the current Noor page's class labels and links. It **does not** infer a grade from the `cid` URL token: numeric index and opaque course IDs must remain distinct. The older prep/grade/activity panels are hidden from the teacher, while their engines are reused internally.

## Integrated modules

- **Preparation**: retained v2.8.25 field filling and lesson-tree detection. No bundled historical lesson preparations. Gemini-generated preparation is staged for review; filling an active Noor preparation form requires explicit confirmation and does not press final Save.
- **Activities/Tests**: merged *Noor Smart Activities v0.6.11* question import, normalization and class-aware automation into `smart/src/`. The automation can navigate Noor activity/question forms and populate supported question types; it pauses if Noor's fields, class, lesson or "إضافة مفردة" controls cannot be verified. New Gemini activities use a teacher-specific bank, **not** a global/shared sample bank.
- **Grades**: existing Notebook grade export and exact-row preview retained. Choose the target assessment if multiple exist. Grades are filled only after a class comparison and teacher approval; final save remains inside Noor.
- **SCORM**: a new `noor-scorm.js` creates valid structural SCORM 1.2 ZIPs with `imsmanifest.xml`, `index.html`, `questions.js`, `runtime.js`, calls SCORM `LMSInitialize`, `LMSSetValue`, `LMSCommit`, `LMSFinish`, and stores a score. A test ZIP passes ZIP and XML verification. On a verified SCORM attachment form the tool tries to attach the ZIP and title to uniquely identified controls; it **does not** press final Publish/Save until the real Noor fields can be tested. If those controls are not uniquely found, the teacher receives the ZIP for manual upload.

## Shared personal Gemini key

The common key is **`stnGeminiKey:<verifiedNotebookTeacherId>`**, scoped to the active logged-in School Teacher Notebook account. Both `gemini-background.js` (preparation / SCORM) and `smart-background.js` (activities / PDF interpretation) read the same credential and contact Google directly. Both support `AQ.` and `AIza` formats. There is no shared owner key, no duplicate activation, and no automatic Google project/key creation via OAuth. Teacher change clears the active unfinished activity job to prevent accidental cross-account submission; each teacher's own key and library remain separate.

## Noor routes examined

| Service | User-provided Noor route |
|---|---|
| Home | `/teacher` |
| Preparation | `/teacher/courses/preparations_index/cid:<numeric>` |
| Activities | `/teacher/homeworks/index/cid:<numeric>` |
| Interactive SCORM | `/teacher/attachments/index/Scorm/cid:<opaque>/tid:<opaque>` |

Those shapes are based on user-provided screenshots and URLs. The site is authenticated, and its live HTML was not accessible to these development tools, so class-tree selectors and uploading fields require testing with the teacher's signed-in Firefox. In particular, numeric preparation/activity course IDs **cannot be transformed** into SCORM's opaque `cid/tid`. The tool stops rather than guessing the class or link. Grade URLs and final save behavior also remain to be mapped live.

## QA

- All first-party JS files passed `node --check`.
- All manifest background/content/CSS paths exist.
- A sample SCORM package passed `unzip -t` and valid `imsmanifest.xml` parsing, with the exact files listed in the manifest present.
- A mock Noor tree UI rendered the single toolbar and detected Unit 3 / Lesson 1. This is **not** an end-to-end Noor acceptance test.

## Next steps

1. Install the unsigned ZIP temporarily using Firefox debugging or have the finished XPI signed by Mozilla with ID `noor-prep-filler-private-2026@rouhous.github.io`.
2. Test each of the four routes while logged into Noor and Notebook. Use a demo activity/grade list and verify matching before saving any real records.
3. Report any step where the hub says it cannot verify the class, the selected lesson, the upload control or "Add Item" button, with screenshots of that exact stage.
4. Once accepted, upload the **signed** XPI to `School-Teacher-Notebook-App/addons/files/` and then update `addons/updates.json` to 2.8.26. Do not add the unsigned archive to that feed.
