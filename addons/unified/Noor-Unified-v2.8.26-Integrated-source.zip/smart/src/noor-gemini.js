/* Gemini assessment adapter for the Noor floating panel. No API key in this file. */
(function(root){'use strict';
const KINDS=Object.freeze([
 {kind:'mcq',label:'اختيار من متعدد',default:true},
 {kind:'true_false',label:'صح / خطأ',default:true},
 {kind:'multi_select',label:'متعدد الإجابات',default:true},
 {kind:'matching',label:'توصيل عمودين',default:true},
 {kind:'fill_blanks',label:'ملء الفراغات',default:true},
 {kind:'short_text',label:'إجابة قصيرة',default:false},
 {kind:'essay',label:'سؤال إنشائي',default:false},
 {kind:'pairing',label:'اقتران',default:false}
]);
const allowed=new Set(KINDS.map(x=>x.kind));
const trim=(value,max=200)=>String(value??'').trim().slice(0,max);
function makeRequest(input){
 const grade=Number(input.grade),unit=trim(input.unit,80),lesson=trim(input.lesson,80);
 const selected=[...new Set(Array.isArray(input.kinds)?input.kinds:[])];
 if(!Number.isInteger(grade)||grade<1||grade>12)throw Error('افتح واجب الصف الصحيح في نور حتى تتعرف الإضافة على الصف تلقائيًا.');
 if(!unit||!lesson)throw Error('اختر الوحدة والدرس أولًا.');
 if(!selected.length||selected.some(x=>!allowed.has(x)))throw Error('اختر نوع سؤال واحدًا على الأقل من الأنواع المدعومة في نور.');
 const count=Number(input.count);
 if(!Number.isInteger(count)||count<1||count>30)throw Error('عدد الأسئلة يجب أن يكون بين 1 و30.');
 const difficulty=trim(input.difficulty,20);
 if(!['easy','medium','mixed','hard'].includes(difficulty))throw Error('مستوى الصعوبة غير معروف.');
 const title=trim(input.title,150)||`أنشطة Gemini — ${unit} / ${lesson}`;
 const instructions=trim(input.description,1800);
 const limits='Questions MUST be valid for the Noor LMS editors. MCQ: exactly 3 or 4 options and answer exactly equal to one option. Multi-select: 3 to 5 options and 2 or more correct answers that are options. Matching: 2 to 5 complete {left,right} pairs, no images. Pairing: 2 to 5 complete {left,right} pairs, no images. Fill_blanks: supply blanks array with ordered answers, 1 to 5 blanks. True_false: answer must be boolean true or false. Short_text: provide a precise model answer. Essay: provide model answer and keep teacher manual marking in mind. Never generate a question requiring pictures, audio, files, answer attachments, or unavailable media. Use no student names or data. All points must be positive. Use only the requested question types and make a balanced mix when multiple are chosen. Avoid questions that rely on a listening recording or a textbook passage not supplied. Do not invent official textbook quotations.';
 return {mode:'generate',grade:String(grade),subject:'English',unit,lesson,activityType:'assignment',title,count,difficulty,
  supportedKinds:selected,description:[limits,instructions&&'Teacher focus: '+instructions].filter(Boolean).join('\n').slice(0,5200)};
}
function parseResult(result,context,schema){
 if(!result||!Array.isArray(result.questions)||!result.questions.length)throw Error('لم يُرجع Gemini أسئلة. جرّب عددًا أقل.');
 const valid=[],issues=[],allow=new Set(context.supportedKinds);
 for(let i=0;i<result.questions.length;i++){
  const raw=result.questions[i];
  if(!raw||!allow.has(raw.kind)){issues.push(`سؤال ${i+1}: نوع غير مطلوب`);continue;}
  const q=schema.normalizeQuestion({...raw,source:'gemini'}, {grade:context.grade,subject:'English',unit:context.unit,lesson:context.lesson});
  if(!q){issues.push(`سؤال ${i+1}: تعذر قراءة السؤال`);continue;}
  const errs=schema.validateQuestion(q);
  if((q.kind==='matching'||q.kind==='pairing')&&q.pairs.length>5)errs.push('أكثر من خمسة أزواج');
  if(errs.length){issues.push(`سؤال ${i+1}: ${errs.join('، ')}`);continue;}
  valid.push(q);
 }
 if(!valid.length)throw Error('الأسئلة المولدة لم تجتز التحقق: '+issues.slice(0,3).join(' | '));
 const warnings=(Array.isArray(result.warnings)?result.warnings:[]).map(x=>trim(x,250)).filter(Boolean);
 return {questions:valid,issues,warnings,totalPoints:valid.reduce((s,q)=>s+q.points,0),allValid:issues.length===0};
}
root.NoorGemini={KINDS,makeRequest,parseResult};
})(typeof globalThis==='object'?globalThis:this);
