# Noor Unified Tools 2.8.34 — Gemini temporary overload reliability

- Official Google Gemini guidance: 503 means temporary backend overload. Retry with increasing backoff.
- Only HTTP 503 receives one delayed retry on the selected supported Flash-Lite model, followed by a bounded attempt on the alternate discovered Flash-Lite model. Do not retry other failures or ambiguous network/timeout errors.
- 429 quota, 400 request errors, 401/403 key errors and other HTTP errors stop without auto-retry.
- Same source and structured output are sent for each bounded generation attempt.
- No publishing or saving to Noor occurs in this helper. Existing per-teacher pipeline pauses and resumes at the generate stage after persistent errors.
- Teacher private API key remains only in browser.storage.local, not in the page or logs.
- Tests use mocked HTTP responses (no teacher key or real remote service is required). Live Noor / Google service availability cannot be guaranteed.
