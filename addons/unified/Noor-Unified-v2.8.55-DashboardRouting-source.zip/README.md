# Noor Unified Firefox Extension — 2.8.55

Activities and SCORM accept any whole question count from 1 to 30. For activities, Gemini can fill the remaining slots after validation, and a generation-only interruption can be retried at the current lesson. Activity generation started in the Digital Library opens the selected class’s homework page. Unit-wide generation retains its settings across that navigation and reads lessons for the verified class.

## Choose a lesson by position

Under **Class and content**, choose the class and semester, enter the unit's position in the semester and the lesson's position in the unit, then select **Check selection in Noor**. Noor Tools opens only that class's preparation tree and shows the official unit and lesson titles. The teacher's choice is saved locally and reused across preparation, activities, and SCORM until the teacher changes it. Generating a preparation or activity returns to the teacher dashboard and opens the saved class before continuing, regardless of which teacher page was open.

## Import an interactive lesson

1. Select **مساق تفاعلي SCORM** and import one or more individual SCORM ZIPs.
2. Choose a verified class and specify the unit and lesson. If several ZIPs were selected, choose which package to use.
3. Click **تعبئة الدرس التفاعلي تلقائيًا**. The extension follows **المكتبة الرقمية ← الدروس التفاعلية ← إضافة الدرس**.
4. Review the draft in Noor and save it. The existing automatic-save setting remains available. Use **استكمال تعبئة SCORM** when prompted after selecting or verifying the lesson in Noor.

## Teacher-facing additions

- On mobile, a narrower panel (max 66dvh) divided into **الصف والمحتوى** and **المهمة والإعدادات** tabs. Form input values remain mounted while switching tabs.
- Minimize/restore button directly next to Close, plus original drag handle and reset-position control.
- Compact generation and import buttons.
- For Activities and SCORM, **الدرس المحدد فقط** / **جميع دروس الوحدة المختارة في نور**.
- Publish-date fields and opt-in unit-wide automatic save toggles (checked by default only after the teacher chooses the unit-wide scope).
- One unit-wide activity run creates independent activities for each lesson and starts the existing Noor automator only once per lesson. The next lesson starts only after an exact completed Noor run record is observed.
- One SCORM ZIP is created per verified official lesson (one variant per lesson) and downloaded as a backup. Automatic upload is serialized. The subsequent file is not sent until the previous entry appears uniquely in Noor's list with the batch-specific STN reference attached to its title. Ambiguous or unconfirmed save pauses the unit queue.
- A cancel control stops future batch steps but cannot undo a form submission already sent to Noor.
- Existing individual-lesson generation and the existing image fallback modes are retained.

## Safety and compatibility

- Batch lessons must come from the current Noor lesson selector or from a teacher- and class-scoped official curriculum snapshot. No invented lesson numbers, API endpoints, or class IDs.
- Same subject, course label, teacher identity, and numeric course ID are verified before each batch step.
- The batch state persists in browser.storage.local across page navigation, but **does not automatically retry** uncertain submissions.
- When Noor shows a SCORM upload form without a tree, a teacher-approved *whole-unit* selection from Noor's actual lesson selector can be accepted, tied to its observed form option; an unrelated class cannot be used.
- Real account acceptance, successful backend publication, and automatic save in every Noor form variant require an end-to-end live Noor test. Successful local tests do not imply server-side validation.
- The extension must be signed by Mozilla with the existing GitHub workflow before ordinary Firefox installation. Never repack the original signed XPI.
