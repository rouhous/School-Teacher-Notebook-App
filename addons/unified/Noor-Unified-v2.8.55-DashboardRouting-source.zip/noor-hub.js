/* Noor independent teacher services hub; no secrets or student data in page DOM.
   All actions require a click. Class/cid binding is based on visible Noor evidence,
   not guessing a grade from opaque course IDs. */
(function(){'use strict';
 if(window.top!==window||document.getElementById('stnNoorHub'))return;
 const teacherArea=/^\/teacher(?:\/|$)/i.test(location.pathname);
 const hasTeacherHome=[...document.querySelectorAll('a[href]')].some(link=>
  link.origin===location.origin&&/^\/teacher\/?$/i.test(link.pathname));
 if(!teacherArea&&!hasTeacherHome)return;
 const root=document.createElement('div');root.id='stnNoorHub';root.dir='rtl';
 root.innerHTML=`<button id="stnHubOpen" type="button" title="اضغط للفتح، واسحب لنقل الزر">🧩 أدوات نور</button>
 <section id="stnHubPanel" class="stnHubPanel" hidden role="dialog" aria-label="أدوات نور الموحدة">
  <header class="stnHead" id="stnHubDragHandle" title="اسحب الشريط لتغيير مكان النافذة">
  <span>أدوات نور · دفتر المعلم <small style="display:block;font-size:10px;font-weight:400">اسحب هنا لتحريك النافذة</small></span>
  <span class="stnHeadButtons"><button id="stnHubMinimize" type="button" title="تصغير أو توسيع" aria-label="تصغير الإضافة" aria-expanded="true">−</button><button id="stnHubResetPosition" type="button" title="إعادة الموضع الافتراضي" aria-label="إعادة موضع النافذة">⟲</button><button id="stnHubClose" type="button" aria-label="إغلاق">×</button></span></header>
  <label for="stnHubSubject">المادة المكتشفة من نور</label><input id="stnHubSubject" type="text" readonly placeholder="اختر صفًا من بطاقة المادة أولًا" aria-label="المادة المكتشفة من نور">
  <label for="stnHubClass">الصف / الفصل</label><select id="stnHubClass"><option value="">اختر الفصل الظاهر في نور</option></select>
  <label for="stnHubSemester">الفصل الدراسي</label><select id="stnHubSemester"><option value="1">الأول</option><option value="2">الثاني</option></select>
  <div id="stnHubAssessmentRow" hidden><label for="stnHubAssessment">التقييم</label><select id="stnHubAssessment"></select></div>
  <div id="stnHubCsvFields" hidden class="stnCsvFields">
    <p class="stnNote">درجات CSV: اختر تقييم الملف وحقل نور. مطابقة الطلاب تسبق التعبئة دائمًا، ولا يُضغط حفظ.</p>
    <label for="stnHubCsvColumn">التقييم في ملف CSV</label><select id="stnHubCsvColumn"></select>
    <label for="stnHubCsvTarget">الحقل الذي سيُعبأ في نور</label><select id="stnHubCsvTarget"><option value="">افتح جدول الدرجات وانقر فحص</option></select>
    <label class="stnCsvCheckbox"><input type="checkbox" id="stnHubCsvOverwrite"> السماح باستبدال الدرجات الموجودة (اختياري)</label>
    <pre id="stnHubCsvPreview" class="stnPreview" hidden></pre>
  </div>
  <div id="stnHubLessonChoiceBox" class="stnTeacherTree">
    <div class="stnRow">
      <div><label for="stnHubUnit">ترتيب الوحدة في الفصل</label><input id="stnHubUnit" type="text" inputmode="numeric" pattern="[0-9٠-٩۰-۹]+" placeholder="مثال 3"></div>
      <div><label for="stnHubLesson">ترتيب الدرس في الوحدة</label><input id="stnHubLesson" type="text" inputmode="numeric" pattern="[0-9٠-٩۰-۹]+" placeholder="مثال 2"></div>
    </div>
    <button type="button" class="stnBtn outline" id="stnHubRefreshTree">تحقّق من الاختيار في نور</button>
    <button type="button" id="stnHubStopCurriculum" class="stnBtn outline" hidden>إيقاف قراءة الشجرة</button>
    <p id="stnHubCurriculumStatus" class="stnNote" aria-live="polite" hidden></p>
    <div id="stnHubLessonPreview" class="stnNote" aria-live="polite" hidden>
      <strong>الاختيار من شجرة نور</strong>
      <p><span>عنوان الوحدة</span> <bdi id="stnHubUnitTitle"></bdi></p>
      <p><span>عنوان الدرس</span> <bdi id="stnHubLessonTitle"></bdi></p>
    </div>
  </div>
  <label for="stnHubService">الخدمة</label><select id="stnHubService"><option value="preparation">📚 تحضير درس</option><option value="activities">📝 نشاط / اختبار</option><option value="grades">📊 نقل الدرجات</option><option value="scorm">🎮 مساق تفاعلي SCORM</option></select>
  <div id="stnHubCountArea"><label for="stnHubCount">عدد الأسئلة لكل نشاط / درس</label><input id="stnHubCount" type="number" inputmode="numeric" min="1" max="30" step="1" value="6" aria-describedby="stnHubCountHint"><p id="stnHubCountHint" class="stnNote">اكتب أي عدد صحيح من 1 إلى 30.</p></div>
  <div id="stnHubPrepOptions" hidden>
    <label for="stnHubPrepScope">نطاق التحضير من ملف</label><select id="stnHubPrepScope"><option value="lesson">الدرس الحالي فقط</option><option value="unit">جميع دروس الوحدة</option><option value="semester">جميع دروس الفصل المتاحة في الملف</option></select>
    <div class="stnRow"><div><label for="stnHubPrepDate">تاريخ بداية التحضير</label><input id="stnHubPrepDate" type="date"></div><div><label for="stnHubPeriods">الحصص لكل درس</label><input id="stnHubPeriods" type="number" min="1" max="12" value="2"></div></div>
    <label id="stnHubPrepModeLabel">طريقة الحفظ بعد إنشاء التحضير</label>
    <div id="stnHubPrepSaveMode" class="stnHubChecks" role="radiogroup" aria-labelledby="stnHubPrepModeLabel">
      <label><input type="radio" name="stnHubPrepSaveMode" value="review" checked> 🔎 مراجعة قبل الحفظ</label>
      <label><input type="radio" name="stnHubPrepSaveMode" value="auto"> 💾 حفظ تلقائي بعد التوليد</label>
    </div>
    <p class="stnNote" id="stnHubPrepModeNote">سيُعبأ التحضير أولًا، ثم تظهر معاينته قبل الضغط على «اعتماد وحفظ». حدد طريقة الحفظ الآن، قبل إرسال طلب Gemini.</p>
    <div id="stnHubPrepPostActions" class="stnActions" hidden><button type="button" id="stnHubPrepReview" class="stnBtn outline" disabled>🔎 عرض التحضير للمراجعة</button><button type="button" id="stnHubPrepAutoSave" class="stnBtn" disabled>💾 اعتماد وحفظ التحضير</button></div>
    <pre id="stnHubPrepPreview" class="stnPreview" hidden aria-live="polite" style="white-space:pre-wrap;overflow-wrap:anywhere;max-height:260px;overflow:auto"></pre>
  </div>
  <div id="stnHubActivityOptions" hidden>
    <button type="button" id="stnHubActivityResumeDate" class="stnBtn" hidden>استكمال النشاط المتوقف</button>
    <label for="stnHubActivityScope">نطاق إنشاء الأنشطة</label><select id="stnHubActivityScope"><option value="lesson">الدرس المحدد فقط</option><option value="unit">جميع دروس الوحدة المختارة في نور</option></select>
    <div id="stnHubActivityUnitOptions" hidden><label class="stnBatchCheck"><input id="stnHubActivityUnitAuto" type="checkbox" checked> حفظ كل نشاط تلقائيًا بعد تأكيد نور حفظ السابق</label><p class="stnNote">يُحفظ نشاط مستقل لكل درس؛ يتوقف التسلسل عند أي نتيجة حفظ غير مؤكدة دون تكرار.</p></div>
    <label for="stnHubActivityPublishDate">تاريخ نشر الأنشطة (اختياري)</label><input id="stnHubActivityPublishDate" type="date"><p class="stnNote">اترك الحقل فارغًا لاستخدام تاريخ نور.</p>
    <label for="stnHubActivityQuantity">عدد الأنشطة/الاختبارات</label><input type="number" id="stnHubActivityQuantity" min="1" max="8" value="1">
    <label>أنواع الأسئلة المطلوبة</label><div id="stnHubActivityTypes" class="stnHubChecks">
     <label><input type="checkbox" value="mcq" checked> اختيار من متعدد</label><label><input type="checkbox" value="true_false" checked> صح / خطأ</label>
     <label><input type="checkbox" value="matching"> توصيل</label><label><input type="checkbox" value="fill_blanks"> ملء فراغات</label>
     <label><input type="checkbox" value="multi_select"> متعدد الإجابات</label><label><input type="checkbox" value="short_text"> إجابة قصيرة</label>
    </div>
  </div>
  <div id="stnHubScormOptions" hidden>
    <label for="stnHubScormScope">نطاق إنشاء SCORM</label><select id="stnHubScormScope"><option value="lesson">الدرس المحدد فقط</option><option value="unit">ملف SCORM مستقل لجميع دروس الوحدة</option></select>
    <div id="stnHubScormUnitOptions" hidden><label class="stnBatchCheck"><input id="stnHubScormUnitAuto" type="checkbox" checked> رفع وحفظ كل درس تلقائيًا بعد تأكيد نور حفظ السابق</label><p class="stnNote">تُحمّل ملفات ZIP الاحتياطية لكل درس. لن يبدأ رفع الدرس التالي إذا كان حفظ السابق غير مؤكد.</p></div>
    <label for="stnHubScormPublishDate">تاريخ نشر الدروس التفاعلية</label><input id="stnHubScormPublishDate" type="date">
    <label for="stnHubScormQuantity">عدد الدروس التفاعلية</label><input type="number" id="stnHubScormQuantity" min="1" max="10" value="1">
    <label for="stnHubScormImageMode">الصورة المصاحبة للنشاط</label>
    <select id="stnHubScormImageMode">
      <option value="gemini_svg">صورة Gemini ثلاثية الأبعاد؛ عند تعذرها استخدم SVG</option>
      <option value="gemini_none">صورة Gemini ثلاثية الأبعاد؛ عند تعذرها بدون صورة</option>
      <option value="svg">رسم SVG تعليمي دون استدعاء Gemini للصور</option>
      <option value="none">بدون صورة (مباشرة)</option>
    </select>
    <p class="stnNote">عند نفاد رصيد صور Gemini أو رفض الخطة (مثل 429)، يستمر إنشاء SCORM بالخيار المحدد. SVG رسم متجهي محلي، وليس صورة ثلاثية الأبعاد من Gemini.</p>
    <label id="stnHubScormModeLabel">الإجراء بعد تجهيز ملف SCORM</label>
    <div class="stnHubChecks" id="stnHubScormMode" role="radiogroup" aria-labelledby="stnHubScormModeLabel">
     <label><input type="radio" name="stnHubScormSaveMode" value="review" checked> 🔎 رفع الملف وعرضه للمراجعة</label>
     <label><input type="radio" name="stnHubScormSaveMode" value="auto"> 💾 حفظ تلقائي إذا تحقق كل شرط</label>
    </div>
    <p class="stnNote">مسار التعبئة في نور هو المكتبة الرقمية ← الدروس التفاعلية ← إضافة الدرس. تختار الإضافة الصف وتتحقق من الدرس ثم ترفق ملف ZIP.</p>
    <div class="stnActions"><button id="stnHubScormResume" type="button" class="stnBtn outline">↻ استكمال تعبئة SCORM</button><button id="stnHubScormCancel" type="button" class="stnBtn outline">إلغاء النشر المعلّق</button></div>
   </div>
  <div id="stnHubUnitBatchControls" class="stnActions"><button type="button" id="stnHubBatchRetry" class="stnBtn" hidden>إعادة محاولة توليد الدرس المتوقف</button><button type="button" id="stnHubBatchCancel" class="stnBtn outline">■ إيقاف وإلغاء كل العمليات</button></div>
  <div id="stnHubImportChoices" hidden><label>الأنشطة المستوردة: اختر بعضها أو الكل</label><div id="stnHubImportedItems" class="stnHubImported"></div><button id="stnHubImportPublish" type="button" class="stnBtn outline">نشر الأنشطة المحددة</button></div>
  <div id="stnHubKeyBox" hidden><p class="stnNote">لا يوجد مفتاح Gemini مرتبط بهذا المعلم بعد. يحتاج التحضير والتوليد إلى ربط المفتاح مرة واحدة.</p>
   <div class="stnActions"><button type="button" id="stnHubCreateKey" class="stnBtn outline">إنشاء مفتاح</button><button type="button" id="stnHubSaveKey" class="stnBtn">لصق وحفظ المفتاح</button></div>
   <input type="password" autocomplete="off" id="stnHubKey" class="stnKeyInput" placeholder="AQ. / AIza" aria-label="Gemini API key"></div>
  <div id="stnHubLegacyActions" class="stnActions"><button id="stnHubGenerate" type="button" class="stnBtn stnGenerateMini">✨ توليد باستخدام Gemini</button><button id="stnHubImport" type="button" class="stnBtn outline">📁 استيراد ملف</button></div>
  <div id="stnHubScormImport" hidden>
   <label for="stnHubScormPackage">حزمة SCORM المستوردة</label>
   <select id="stnHubScormPackage"></select>
   <button id="stnHubScormFill" type="button" class="stnBtn" disabled>تعبئة الدرس التفاعلي تلقائيًا</button>
  </div>
  <input id="stnHubFile" type="file" accept=".json,.pdf,.docx,.txt,.zip,.html" multiple hidden>
  <p id="stnHubStatus" class="stnStatus" role="status" aria-live="polite">اختر الخدمة والصف والوحدة والدرس. لن تختار الإضافة فصلًا آخر بالخطأ.</p>
  <pre id="stnHubPreview" class="stnPreview" hidden></pre>
 </section>`;
 // Compact two-tab phone interface. The same inputs remain mounted and retain their values/listeners.
 const panelRoot=root.querySelector('#stnHubPanel'),header=panelRoot.querySelector('.stnHead');
 const tabs=document.createElement('nav');tabs.id='stnHubTabs';tabs.className='stnHubTabs';tabs.setAttribute('aria-label','أقسام إضافة نور');
 tabs.innerHTML='<button id="stnHubTabContent" type="button" class="active" aria-selected="true">📘 الصف والمحتوى</button><button id="stnHubTabTask" type="button" aria-selected="false">⚙️ المهمة والإعدادات</button>';
 const contentPane=document.createElement('div');contentPane.id='stnHubContentPane';contentPane.className='stnHubTabPane';
 const taskPane=document.createElement('div');taskPane.id='stnHubTaskPane';taskPane.className='stnHubTabPane';taskPane.hidden=true;
 const first=panelRoot.querySelector('label[for="stnHubSubject"]'),split=panelRoot.querySelector('label[for="stnHubService"]'),statusNode=panelRoot.querySelector('#stnHubStatus');
 let part=first;while(part&&part!==split){const next=part.nextSibling;contentPane.append(part);part=next;}
 part=split;while(part&&part!==statusNode){const next=part.nextSibling;taskPane.append(part);part=next;}
 const language=document.createElement('div');language.className='stnHubLanguage';
 language.innerHTML='<label for="stnHubLanguage">العربية / English</label><select id="stnHubLanguage" aria-label="لغة الإضافة / Extension language"><option value="ar">العربية</option><option value="en">English</option></select>';
 header.after(language,tabs,contentPane,taskPane);
 function selectHubTab(which){const target=which==='task'?'task':'content';
  contentPane.hidden=target!=='content';taskPane.hidden=target!=='task';
  for(const [id,on] of [['stnHubTabContent',target==='content'],['stnHubTabTask',target==='task']]){
   const button=panelRoot.querySelector('#'+id);button.classList.toggle('active',on);button.setAttribute('aria-selected',String(on));
  }
 }
 const $=id=>root.querySelector('#'+id),norm=t=>String(t||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const clean=t=>String(t||'').replace(/\s+/g,' ').trim().slice(0,180);
 const status=message=>{$('stnHubStatus').textContent=String(message||'');};
 const getCid=()=>decodeURIComponent(location.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
 const routetype=()=>/\/teacher\/courses\/(?:add_preparation|preparations_index)/i.test(location.pathname)?'preparation':/\/teacher\/(?:homeworks|questions)(?:\/|$)/i.test(location.pathname)?'activities':/\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(location.pathname)?'scorm':/\/teacher\/(?:grades|marks|scores|gradebook|performance|assessment|evaluations)/i.test(location.pathname)?'grades':'home';
 let keyReady=false,busy=false,courseCandidates=[];
 let csvFileInfo=null,gradePreviewReady=false,gradePreviewMode=null;
 let importedScorm=[];
 let stagedPreparation=null; // In-memory review approval only; never auto-submit from a page reload.
 function prepSaveMode(){return $('stnHubPrepSaveMode').querySelector('input:checked')?.value==='auto'?'auto':'review'}
 function updatePrepModeChoice(){
  const auto=prepSaveMode();
  $('stnHubPrepModeNote').textContent=auto?'بعد اكتمال التوليد والتعبئة، تتحقق الإضافة من الصف والوحدة والدرس والمستوى والتواريخ، ثم تضغط حفظ مرة واحدة دون خطوة مراجعة. إذا فشل التحقق تتوقف دون حفظ.':'ستعبئ الإضافة التحضير دون حفظ، وتعرض معاينته ثم تنتظر موافقتك على «اعتماد وحفظ». أجرِ هذا الاختيار قبل إرسال الطلب إلى Gemini.';
  if($('stnHubService').value==='preparation')$('stnHubGenerate').textContent=auto?'✨ توليد التحضير وحفظه تلقائيًا':'✨ توليد التحضير للمراجعة';
 }
 function resetPreparationReview(){
  stagedPreparation=null;
  $('stnHubPrepPostActions').hidden=true;
  $('stnHubPrepReview').disabled=true;
  $('stnHubPrepAutoSave').disabled=true;
  $('stnHubPrepPreview').hidden=true;
  $('stnHubPrepPreview').textContent='';
 }

 // A native select is a browser-controlled popup: replacing options while it is
 // focused closes the menu immediately. Reconcile options only when needed, and
 // never during selection. The class catalog is the sole source of remembered rows.
 let classOptionsSignature='',classRefreshPending=false,classSelectionUntil=0,classTeacherId='';
 const classSelect=$('stnHubClass');
 // Per-tab navigation transaction, never deleted until confirmed handoff.
 const TRANSFER_KEY='stnHubTransfer:v2', PREP_TRANSFER_KEY='stnHubPrepTransfer:v3', TRANSFER_MAX_AGE=15*60*1000;
 const STOP_KEY='stnNoorStopAll:v1';
 let operationEpoch=0;
 const ensureOperation=epoch=>{if(epoch!==operationEpoch)throw Error('أُلغيت العملية بواسطة المعلم.');};
 const SERVICE_KEY='stnNoorSelectedService:v2';
 const serviceStorageKey=()=>SERVICE_KEY+':'+(classTeacherId||'unverified');
 const lookup=globalThis.NoorCurriculumDiscovery;
 const position=lookup.position;
 const selectionKey=teacher=>'stnNoorTeacherSelection:v1:'+teacher;
 let savedSelection=null,selectionReady=Promise.resolve(),selectionRevision=0;
 function inputs(){return {semester:$('stnHubSemester').value,unitNo:position($('stnHubUnit').value),lessonNo:position($('stnHubLesson').value)};}
 function samePositions(a,b){return ['semester','unitNo','lessonNo'].every(key=>a?.[key]===b?.[key]);}
 function isPinnedCourse(course){
  const pinned=savedSelection?.course;
  return Boolean(pinned&&course&&Number(course.grade)===Number(pinned.grade)&&
   (pinned.cid?course.cid===pinned.cid:norm(course.label)===norm(pinned.label)));
 }
 function persistSelection({course=selectedClass(),proof=null}={}){
  if(!classTeacherId)return;
  selectionRevision++;
  savedSelection={...inputs(),course:course?{cid:course.cid,label:course.label,grade:course.grade}:null,proof};
  browser.storage.local.set({[selectionKey(classTeacherId)]:savedSelection}).catch(()=>status('تعذر حفظ اختيار المعلم في الإضافة.'));
 }
 function displayLessonTitles(info){
  $('stnHubLessonPreview').hidden=!info;
  $('stnHubUnitTitle').textContent=info?.unit||'';
  $('stnHubLessonTitle').textContent=info?.title||'';
 }
 function clearPreview(){displayLessonTitles(null);$('stnHubCurriculumStatus').hidden=true;}
 async function orderedBranch(opts){
  if(!classTeacherId||!opts.course?.verified||!opts.unitNo)return null;
  const key=lookup.snapshotKey(classTeacherId,opts.course.cid,opts.semester,opts.unitNo);
  return (await browser.storage.local.get(key))[key]||null;
 }
 function lessonProof(branch,lesson){return {termId:branch.termId,unitId:branch.unitId,lessonId:lesson?.id||null};}
 function unitMatchesProof(branch,proof){return Boolean(branch&&proof&&branch.termId===proof.termId&&branch.unitId===proof.unitId);}
 async function resolveVerifiedLesson(opts,{required=false,refresh=false}={}){
  let branch=await orderedBranch(opts);
  if(branch&&refresh&&hasPreparationCourseProof(opts.course)){
   const live=await globalThis.NoorPrepBridge2828.orderedUnit(opts);
   const savedTitle=lookup.lessonAt(branch,opts.lessonNo)?.title;
   branch=live?.unit===branch.unit&&lookup.lessonAt(live,opts.lessonNo)?.title===savedTitle?live:null;
  }
  const lesson=lookup.lessonAt(branch,opts.lessonNo);
  if(lookup.matchIds(branch,lesson,opts.proof)){
   return {ok:true,...opts.proof,unit:branch.unit,title:lesson.title,semester:opts.semester,source:'tree'};
  }
  if(required)throw Error('تحقّق من ترتيب الوحدة والدرس في تبويب الصف والمحتوى قبل المتابعة.');
  return null;
 }
 async function previewNumberSelection({useCache=false}={}){
  if($('stnHubService').value==='grades')return;
  const opts=selected(),revision=selectionRevision,teacher=classTeacherId;
  if(!opts.course?.verified||!opts.unitNo){displayLessonTitles(null);return;}
  const branch=await orderedBranch(opts);
  if(teacher!==classTeacherId||revision!==selectionRevision)return;
  const lesson=lookup.lessonAt(branch,opts.lessonNo);
  const valid=opts.lessonNo?lookup.matchIds(branch,lesson,opts.proof):unitMatchesProof(branch,opts.proof);
  if(branch&&(valid||useCache)){
   if(opts.lessonNo&&!lesson){
    clearPreview();curriculumStatus('عدد الدروس في هذه الوحدة '+branch.lessons.length+'.');return;
   }
   if(useCache&&!valid)persistSelection({proof:lessonProof(branch,lesson)});
   displayLessonTitles({unit:branch.unit,title:lesson?.title});
  }else displayLessonTitles(null);
 }
 async function restoreSelection(id){
  const next=String(id||'');
  if(classTeacherId===next)return;
  classTeacherId=next;const revision=++selectionRevision;
  savedSelection=null;classOptionsSignature='';clearPreview();
  const key=selectionKey(next),prefs=next?(await browser.storage.local.get(key))[key]:null;
  if(next!==classTeacherId||revision!==selectionRevision)return;
  savedSelection=prefs||null;
  $('stnHubSemester').value=prefs?.semester||'1';
  $('stnHubUnit').value=prefs?.unitNo??'';
  $('stnHubLesson').value=prefs?.lessonNo??'';
  classSelect.value='';
  try{
   const service=sessionStorage.getItem(serviceStorageKey());
   if(['preparation','activities','grades','scorm'].includes(service))$('stnHubService').value=service;
  }catch(_){}
  discover();
  showStatus();
 }

 function transferKey(service){return service==='preparation'?PREP_TRANSFER_KEY:TRANSFER_KEY}
 function readTransfer(service){
  for(const key of service==='preparation'?[PREP_TRANSFER_KEY,TRANSFER_KEY]:[TRANSFER_KEY]){
   try{
    const p=JSON.parse(sessionStorage.getItem(key)||'null');if(!p)continue;
    if(Date.now()-p.createdAt>TRANSFER_MAX_AGE){sessionStorage.removeItem(key);continue;}
    if(p.service!==service)continue;
    if(service==='preparation'&&key===TRANSFER_KEY){writeTransfer(p);sessionStorage.removeItem(key);}
    return p;
   }catch(_){}
  }
  return null;
 }
 function writeTransfer(p){if(p.service==='activities')readTransfer('preparation');sessionStorage.setItem(transferKey(p.service),JSON.stringify(p));}
 function clearTransfer(service){sessionStorage.removeItem(transferKey(service));}
 function sameCourse(a,b){return !!(a&&b&&/^\d+$/.test(String(a.cid||''))&&String(a.cid)===String(b.cid)&&Number(a.grade)===Number(b.grade)&&norm(a.label)===norm(b.label))}

 const scormSaveMode=()=>root.querySelector('input[name="stnHubScormSaveMode"]:checked')?.value==='auto'?'auto':'review';
 const classValue=c=>(c.cid||'pending')+'|'+c.label;
 const classFocusHeld=()=>document.activeElement===classSelect||Date.now()<classSelectionUntil;
 function courseChoices(discovered=[]){
  const rows=[];
  for(const c of globalThis.NoorCourseCatalog?.all?.()||[]){
   const grade=Number(c.grade)||globalThis.NoorCourseCatalog?.gradeOf?.(c.label);
   if(!grade||!c.label||!globalThis.NoorCourseCatalog?.classLabel?.(c.label))continue;
   const numeric=/^\d+$/.test(String(c.cidNumeric||''))?String(c.cidNumeric):'';
   rows.push({label:clean(c.label),cid:numeric,grade,subject:globalThis.NoorCourseCatalog?.subjectOf?.(c.label)||'',verified:!!numeric});
  }
  for(const c of discovered){if(c.label&&c.grade&&/^\d+$/.test(String(c.cid||''))&&globalThis.NoorCourseCatalog?.classLabel?.(c.label))rows.push({...c,subject:globalThis.NoorCourseCatalog?.subjectOf?.(c.label)||''})}
  const unique=new Map();
  for(const c of rows){const key=(c.cid||'pending')+'|'+norm(c.label);
   const old=unique.get(key);if(!old||(!old.verified&&c.verified))unique.set(key,c);
  }
  // Where a dashboard-only placeholder has since gained a single verified URL,
  // remove the placeholder. Never conflate two different classes of one grade.
  const list=[...unique.values()];
  return list.filter(c=>c.cid || list.filter(x=>x.cid&&norm(x.label)===norm(c.label)).length!==1)
   .sort((a,b)=>a.grade-b.grade||a.label.localeCompare(b.label,'ar')||a.cid.localeCompare(b.cid));
 }
 function syncClassOptions(discovered=[]){
  courseCandidates=courseChoices(discovered);
  const select=classSelect;
  if(classFocusHeld()){classRefreshPending=true;return}
  const routeCid=getCid();
  const signature=JSON.stringify([routeCid,courseCandidates.map(c=>[c.cid,c.label,c.grade])]);
  if(signature===classOptionsSignature)return;
  const matching=courseCandidates.filter(isPinnedCourse);
  const verified=matching.filter(c=>c.verified);
  const keep=verified.length===1?verified[0]:matching.length===1?matching[0]:null;
  select.replaceChildren(new Option('اختر صفك من نور',''));
  for(const c of courseCandidates)select.append(new Option(c.label,classValue(c)));
  if(keep)select.value=classValue(keep);
  else if(savedSelection?.course){
   const placeholder={...savedSelection.course,verified:false};
   if(!courseCandidates.some(c=>classValue(c)===classValue(placeholder)))
    select.append(new Option(placeholder.label,classValue(placeholder)));
   select.value=classValue(placeholder);
  }
  classOptionsSignature=signature;
  classRefreshPending=false;
  updateSubject();
 }
 // Called by the curriculum pipeline after new course-card links appear.
 globalThis.NoorHubClassUI=Object.freeze({
  refresh:()=>syncClassOptions(),
  selected:()=>courseCandidates.find(c=>classValue(c)===classSelect.value)||null,
  list:()=>courseCandidates.map(c=>({...c}))
 });
 const safeRoute=(u)=>{try{const url=new URL(u,location.href);return url.origin===location.origin&&url.pathname.startsWith('/teacher/')?url:null}catch(_){return null}};
 function hasPreparationCourseProof(course){
  if(!course?.verified||!globalThis.NoorPrepBridge2828?.onAddPage?.())return false;
  if(getCid()===course.cid)return true;
  try{
   const proof=JSON.parse(sessionStorage.getItem('stnNoorVerifiedAddNavigation:v1')||'null');
   return proof?.numericCid===course.cid&&proof.teacherId===classTeacherId&&proof.addURL===location.href&&Date.now()-proof.at<15*60*1000;
  }catch(_){return false;}
 }
 function discover(){
  // Refresh the live dashboard even when the first render missed its course tiles.
  globalThis.NoorCourseCatalog?.scan?.();
  // Do not scan every cid: link on preparation/activities pages: many links
  // belong to lessons, assessment rows, or different classes. The teacher's
  // dashboard catalog is the only source of verified course links.
  syncClassOptions();
 }
 function selectedClass(){return globalThis.NoorHubClassUI?.selected?.()||null}
 function updateSubject(){const c=selectedClass();$('stnHubSubject').value=c?.subject||'';if(!c?.subject&&c)status('تم اكتشاف الصف ولكن لم تتأكد المادة من بطاقته؛ لا يمكن بدء التوليد قبل فتح بطاقة المادة الصحيحة.');}
 function selected(){
  const course=selectedClass(),coordinates=inputs();
  const proof=isPinnedCourse(course)&&samePositions(coordinates,savedSelection)?savedSelection.proof:null;
  return {subject:course?.subject||'',service:$('stnHubService').value,...coordinates,unit:$('stnHubUnit').value,lesson:$('stnHubLesson').value,
   proof,manualSelection:proof,count:Number($('stnHubCount').value),course};
 }
 function checkQuestionCount(opts){
  if(['activities','scorm'].includes(opts.service)&&(!Number.isInteger(opts.count)||opts.count<1||opts.count>30))
   throw Error('أدخل عددًا صحيحًا من 1 إلى 30 سؤالًا.');
 }
 function checkContext(opts,needsLesson=true){
  if(opts.service!=='grades'&&(!opts.subject||!opts.course||!opts.course.subject||norm(opts.subject)!==norm(opts.course.subject)))throw Error('المادة غير مؤكدة من بطاقة الصف في نور. لن أرسل Gemini طلبًا لمادة مختلفة.');
  if(!opts.course||!opts.course.verified)throw Error('اختر أحد صفوفك من القائمة. إذا ظهر بجانبه «افتح بطاقة الصف»، افتح بطاقة هذا الصف في نور لاكتشاف معرّفه الرسمي أولًا.');
  // Activities are bound on their own homework page after navigation. The
  // library's SCORM token says nothing about the class chosen for activities.
  if(needsLesson&&(!opts.unitNo||!opts.lessonNo||!opts.proof?.lessonId))
   throw Error('تحقّق من ترتيب الوحدة والدرس في تبويب الصف والمحتوى قبل المتابعة.');
 }
 function openTarget(opts){
  const url=opts.service==='activities'?'/teacher/homeworks/index/cid:':opts.service==='preparation'?'/teacher/courses/preparations_index/cid:':null;
  if(!url||!opts.course||!/^[0-9]+$/.test(opts.course.cid))return null;
  return location.origin+url+encodeURIComponent(opts.course.cid);
 }
 function isActivityCoursePage(course){
  return /^\/teacher\/homeworks(?:\/|$)/i.test(location.pathname)&&
   /^\d+$/.test(getCid())&&getCid()===String(course?.cid||'');
 }
 function captureTaskSettings(service){
  if(service==='preparation')return {prepSaveMode:prepSaveMode(),prepDate:$('stnHubPrepDate').value,
   prepPeriods:Number($('stnHubPeriods').value)};
  return {activityPublishDate:$('stnHubActivityPublishDate').value,activityScope:$('stnHubActivityScope').value,
   activityQuantity:$('stnHubActivityQuantity').value,activityAuto:$('stnHubActivityUnitAuto').checked,
   activityKinds:[...$('stnHubActivityTypes').querySelectorAll('input:checked')].map(input=>input.value)};
 }
 function restoreTaskSettings(p){
  $('stnHubCount').value=String(p.count);
  if(p.service==='activities'){
   $('stnHubActivityPublishDate').value=p.activityPublishDate||'';
   if(p.activityScope)$('stnHubActivityScope').value=p.activityScope;
   if(p.activityQuantity)$('stnHubActivityQuantity').value=p.activityQuantity;
   if(typeof p.activityAuto==='boolean')$('stnHubActivityUnitAuto').checked=p.activityAuto;
   if(Array.isArray(p.activityKinds))for(const input of $('stnHubActivityTypes').querySelectorAll('input'))
    input.checked=p.activityKinds.includes(input.value);
   updateBatchScope();
  }else{
   if(['review','auto'].includes(p.prepSaveMode)){
    const radio=$('stnHubPrepSaveMode').querySelector('input[value="'+p.prepSaveMode+'"]');
    if(radio)radio.checked=true;
   }
   if(/^\d{4}-\d{2}-\d{2}$/.test(String(p.prepDate||'')))$('stnHubPrepDate').value=p.prepDate;
   if(Number.isInteger(p.prepPeriods)&&p.prepPeriods>=1&&p.prepPeriods<=12)$('stnHubPeriods').value=String(p.prepPeriods);
   updatePrepModeChoice();
  }
 }
 function matchesTransfer(opts,p){
  return opts.service===p.service&&sameCourse(opts.course,p.course)&&opts.semester===p.semester&&opts.unit===p.unit&&opts.lesson===p.lesson&&
   opts.proof&&['termId','unitId','lessonId'].every(key=>opts.proof[key]===p.manualSelection?.[key]);
 }
 async function startFromDashboard(opts,epoch){
  const existing=readTransfer(opts.service);
  if(['dashboard','navigate','running','handed_off','submitting','submitted','auto_saving'].includes(existing?.phase))
   throw Error('توجد عملية سابقة لهذه الخدمة. استكملها أو اضغط «إيقاف وإلغاء كل العمليات».');
  const other=readTransfer(opts.service==='activities'?'preparation':'activities');
  if(['dashboard','navigate','running','submitting','auto_saving'].includes(other?.phase))
   throw Error('توجد عملية جارية في نور. أوقفها أو انتظر حتى تكتمل.');
  const run=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  if(run?.active)throw Error('يوجد نشاط قيد التنفيذ. أوقفه أو انتظر حتى يكتمل.');
  ensureOperation(epoch);
  if(!matchesTransfer(selected(),opts))throw Error('تغيّر اختيار المعلم. اضغط التوليد مجددًا.');
  const p={id:crypto.randomUUID(),version:3,teacherId:classTeacherId,service:opts.service,
   semester:opts.semester,unit:opts.unit,lesson:opts.lesson,manualSelection:opts.proof,count:opts.count,
   ...captureTaskSettings(opts.service),course:opts.course,targetPath:'/teacher',phase:'dashboard',createdAt:Date.now()};
  writeTransfer(p);
  status('جارٍ الرجوع إلى صفحة المعلم وفتح الصف المحدد في الإضافة…');
  if(lookup.dashboardPage()){
   // Run after generate releases its busy flag.
   setTimeout(()=>continueTransfer(opts.service).catch(error=>pauseTransfer(opts.service,error)),0);
  }else location.assign(location.origin+'/teacher');
 }
 async function routeIfNeeded(opts){
  if(opts.service!=='grades'||csvFileInfo||routetype()==='grades'&&(!/^\d+$/.test(getCid())||getCid()===opts.course.cid))return false;
  const target=safeRoute(globalThis.NoorCourseCatalog?.get?.(opts.course?.cid)?.routes?.grades);
  if(!target)throw Error('افتح رابط درجات الصف من بطاقة الصف في نور مرة واحدة حتى تكتشف الإضافة الرابط الرسمي.');
  if(target.pathname===location.pathname)return false;
  location.assign(target.href);return true;
 }
 async function keyStatus(){
  const res=await browser.runtime.sendMessage({type:'NOOR_HUB_KEY_STATUS'}).catch(()=>({ok:false}));
  keyReady=Boolean(res?.ok&&res.ready);
  $('stnHubKeyBox').hidden=keyReady||$('stnHubService').value==='grades';
  $('stnHubGenerate').disabled=curriculumScanning()||!keyReady&&$('stnHubService').value!=='grades';
  if(!res?.ok&&$('stnHubService').value!=='scorm')status(res?.error||'افتح دفتر المعلم المدرسي بحساب Google أولًا لربط المفتاح.');
 }
 function invalidateGradePreview(){
  gradePreviewReady=false;gradePreviewMode=null;
  $('stnHubGenerate').textContent='📊 مطابقة الطلاب ومعاينة الدرجات';
  $('stnHubCsvPreview').hidden=true;
 }
 function gradePageScan(){
  const result=globalThis.NoorCSVGrades?.scan();
  if(!result)throw Error('محرك الدرجات CSV غير متاح في هذا الإصدار.');
  const sel=$('stnHubCsvTarget');const old=sel.value;
  sel.replaceChildren(new Option('اختر حقل الدرجة في نور',''));
  result.slots.forEach(slot=>sel.append(new Option(slot.label, String(slot.index))));
  if([...sel.options].some(x=>x.value===old))sel.value=old;
  else if(result.slots.length===1)sel.value=String(result.slots[0].index);
  return result;
 }
 function setCsvFields(info){
  csvFileInfo=info;
  const sel=$('stnHubCsvColumn');sel.replaceChildren(new Option('اختر تقييم CSV',''));
  const found=info.scoreColumns.filter(c=>c.category);
  if(found.length===7&&new Set(found.map(x=>x.category)).size===7)sel.append(new Option('جميع التقييمات السبعة — تطابق تلقائي للعناوين','all'));
  for(const col of info.scoreColumns)sel.append(new Option(col.title,String(col.index)));
  if(info.scoreColumns.length===1)sel.value=String(info.scoreColumns[0].index);
  $('stnHubCsvFields').hidden=false;$('stnHubAssessmentRow').hidden=true;
  invalidateGradePreview();
  try{const scanned=gradePageScan();status('تم استيراد '+info.rows+' طالبًا من CSV. صفحة نور تحتوي '+scanned.students+' صفًا. اختر التقييم وحقل الدرجة ثم عاين المطابقة.');}
  catch(e){status('تم استيراد '+info.rows+' طالبًا من CSV. افتح صفحة رصد الدرجات ثم اختر التقييم المستهدف. '+String(e.message||e));}
 }
 async function gradesTransfer(opts){
  if(csvFileInfo&&globalThis.NoorCSVGrades?.ready){
   if(!gradePreviewReady){
    const selected=$('stnHubCsvColumn').value;
    if(!selected)throw Error('اختر التقييم من ملف CSV أولًا');
    const all=selected==='all',target=$('stnHubCsvTarget').value;
    if(!all&&target==='')throw Error('اختر حقل الدرجات الصحيح من جدول نور أولًا');
    // Read the current Noor table and require explicit selection before any changes.
    gradePageScan();
    const data=globalThis.NoorCSVGrades.planTransfer({columnIndex:selected,targetIndex:target,all,overwrite:$('stnHubCsvOverwrite').checked});
    $('stnHubCsvPreview').textContent=data.sample.join('\n');$('stnHubCsvPreview').hidden=!data.sample.length;
    const m=data.metrics;
    status('مطابقة CSV: '+data.count+' درجة جاهزة. طلاب متطابقون: '+m.matched+'/'+m.total+'، غير مطابقين: '+m.unmatched+'، متشابهون: '+m.ambiguous+'، غير صالح: '+m.invalid+'، خانات موجودة: '+m.existing+'.\nراجع أسماء الطلاب والتقييم وحقل نور قبل التعبئة. لا يحدث حفظ آلي.');
    gradePreviewReady=data.ready;gradePreviewMode='csv';
    if(data.ready)$('stnHubGenerate').textContent='📊 تعبئة الدرجات التي راجعتها — دون حفظ';
    return;
   }
   if(gradePreviewMode!=='csv')throw Error('أعد المعاينة أولًا');
   if(!confirm('هل تأكدت من الصف نفسه والتقييم وعمود نور؟ ستُعبأ الحقول التي ظهرت في المعاينة فقط، دون حفظ نهائي.'))return;
   const result=globalThis.NoorCSVGrades.apply();
   invalidateGradePreview();status('تمت تعبئة '+result.filled+' درجة، وتجاوز '+result.skipped+' خانة تغيرت أو تعذر الوصول إليها. راجع النتائج واحفظ يدويًا في نور.');
   return;
  }
  if(!globalThis.NoorGradeTool)throw Error('لم يصل تصدير درجات دفتر المعلم ولم يُستورد ملف CSV.');
  const assessmentId=$('stnHubAssessment').value;
  if(!assessmentId)throw Error('اختر التقييم من دفتر المعلم أولًا.');
  if(!gradePreviewReady){
   const res=await globalThis.NoorGradeTool.preview(assessmentId,opts.course.label);
   status(res?.message||'تم فحص المطابقة؛ راجع التفاصيل قبل التعبئة.');
   gradePreviewReady=Boolean(res?.ready);gradePreviewMode='notebook';
   if(gradePreviewReady)$('stnHubGenerate').textContent='📊 تعبئة الدرجات التي راجعتها — دون حفظ';
   return;
  }
  if(gradePreviewMode!=='notebook')throw Error('أعد فحص المطابقة أولًا');
  const filled=await globalThis.NoorGradeTool.apply(assessmentId,opts.course.label);
  invalidateGradePreview();status(filled?.message||'تمت التعبئة دون حفظ؛ راجع درجات نور.');
 }
 function updateBatchScope(){
  $('stnHubActivityUnitOptions').hidden=$('stnHubActivityScope').value!=='unit';
  $('stnHubScormUnitOptions').hidden=$('stnHubScormScope').value!=='unit';
  const bulk=['activities','scorm'].includes($('stnHubService').value)&&($('stnHubService').value==='activities'?$('stnHubActivityScope'):$('stnHubScormScope')).value==='unit';
  $('stnHubLesson').required=!bulk;
 }
 async function showStatus(){const s=$('stnHubService').value;updateBatchScope();
  $('stnHubCountArea').hidden=s==='preparation'||s==='grades';
  $('stnHubPrepOptions').hidden=s!=='preparation';
  $('stnHubActivityOptions').hidden=s!=='activities';
  if(s==='activities')updateActivityResume().catch(()=>{});
  $('stnHubScormOptions').hidden=s!=='scorm';
  syncScormImport();
  getUnitJob().then(showUnitRetry).catch(()=>{});
  $('stnHubImportChoices').hidden=true;
  $('stnHubImport').textContent=s==='grades'?'📁 استيراد الدرجات':'📁 استيراد ملف جاهز';
  $('stnHubAssessmentRow').hidden=s!=='grades'||Boolean(csvFileInfo);
  $('stnHubCsvFields').hidden=s!=='grades'||!csvFileInfo;
  $('stnHubLessonChoiceBox').hidden=s==='grades';
  if(s==='grades'&&globalThis.NoorGradeTool){try{const list=await globalThis.NoorGradeTool.assessments();const box=$('stnHubAssessment');box.replaceChildren(new Option(list.length===1?'التقييم الحالي':'اختر التقييم',''));for(const item of list)box.append(new Option(item.name+' / '+item.max,item.id));if(list.length===1)box.value=String(list[0].id);}catch(_){}}
  invalidateGradePreview();
  if(s!=='grades')$('stnHubGenerate').textContent=s==='preparation'?(prepSaveMode()==='auto'?'✨ توليد التحضير وحفظه تلقائيًا':'✨ توليد التحضير للمراجعة'):'✨ توليد باستخدام Gemini';
  if(s!=='preparation')resetPreparationReview();
  if(s!=='grades')previewNumberSelection().catch(()=>{});
  $('stnHubImport').textContent=s==='grades'?'📁 استيراد الدرجات':'📁 استيراد ملف';
  $('stnHubFile').accept=s==='scorm'?'.zip,.json':s==='preparation'?'.pdf,.docx,.txt,.json':s==='grades'?'.json,.csv':'.json,.pdf';
  $('stnHubFile').multiple=s==='scorm'||s==='activities';
  keyStatus();
 }
 async function prep(opts){
  const epoch=operationEpoch;
  const bridge=globalThis.NoorPrepBridge2828;
  if(!bridge?.onAddPage?.())throw Error('لم يفتح نموذج «إضافة تحضير» الرسمي بعد.');
  if(!hasPreparationCourseProof(opts.course))
   throw Error('لم يتأكد رابط التحضير للصف المختار. افتح فهرس الصف ثم ابدأ منه.');
  const previousPrep=readTransfer('preparation');
  if(previousPrep&&['submitting','submitted','auto_saving'].includes(previousPrep.phase))
   throw Error('يوجد تحضير سابق قيد الحفظ. تحقق من نور قبل بدء تحضير جديد.');
  // Recheck the official IDs at the saved positions before staging.
  const mapped=await resolveVerifiedLesson(opts,{required:true,refresh:true});
  ensureOperation(epoch);
  const matches=[{...mapped}];
  opts.unit=mapped.unit;opts.lesson=mapped.title;
  const date=$('stnHubPrepDate').value,periods=Number($('stnHubPeriods').value),saveMode=prepSaveMode();
  if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isInteger(periods)||periods<1||periods>12)
   throw Error('راجع تاريخ البداية وعدد الحصص.');
  status('جارٍ إعداد تحضير مادة '+opts.subject+' للدرس '+opts.lesson+' بواسطة Gemini...');
  const result=await browser.runtime.sendMessage({type:'NOOR_PREP_GENERATE',subject:opts.subject,grade:'Grade '+opts.course.grade,
    unit:(opts.semester==='1'?'الفصل الأول':'الفصل الثاني')+' — '+opts.unit,lesson:opts.lesson,
    fields:['objectives','concepts','warmUp','procedures','formative','closing','details'],
    lessonText:(document.querySelector('main')||document.body).innerText.slice(0,4000)});
  ensureOperation(epoch);
  if(!result?.ok)throw Error(result?.error||'لم يُرجع Gemini تحضيرًا صالحًا');
  const fields=result.fields||{};
  if(['objectives','procedures','formative','closing'].some(k=>!String(fields[k]||'').trim()))throw Error('تحضير Gemini ناقص ولن يُحفظ.');
  ensureOperation(epoch);
  const staged=await bridge.stagePreparation(matches[0],fields,{startDate:date,periods});
  ensureOperation(epoch);
  if(!staged?.ok||!staged?.scheduledDate)throw Error('لم تكتمل تعبئة التحضير والتواريخ؛ لن أتيح الحفظ.');
  // Explicit split: generate/stage -> teacher review -> single auto-save click.
  stagedPreparation={
    teacherId:classTeacherId,cid:opts.course.cid,subject:opts.subject,grade:opts.course.grade,
    semester:opts.semester,unitNo:$('stnHubUnit').value,lessonNo:$('stnHubLesson').value,
    unit:opts.unit,lesson:opts.lesson,lessonNodeId:String(matches[0].lessonId),
    pageURL:location.href,startDate:date,periods,scheduledDate:staged.scheduledDate,
    fields:{...fields},saveMode,status:'staged',reviewed:false,createdAt:Date.now()
  };
  $('stnHubPrepReview').disabled=saveMode==='auto';
  $('stnHubPrepAutoSave').disabled=true;
  $('stnHubPrepPostActions').hidden=saveMode==='auto';
  $('stnHubPrepPreview').hidden=true;
  const previous=readTransfer('preparation')||{};
  writeTransfer({...previous,service:'preparation',course:opts.course,phase:saveMode==='auto'?'auto_saving':'review_ready',stagedAt:Date.now(),
    createdAt:previous.createdAt||Date.now(),teacherId:classTeacherId,targetPath:location.pathname,prepSaveMode:saveMode});
  if(saveMode==='auto'){
    // The teacher explicitly chose auto-save before Gemini. All existing live Noor
    // checks, single-submit guard and fail-closed behavior are still enforced.
    status('✓ اكتمل التحضير؛ جارٍ التحقق من المستوى والصف ثم حفظه تلقائيًا مرة واحدة...');
    await saveReviewedPreparation({automatic:true});
  }else status('✓ اكتمل توليد التحضير دون حفظ. اضغط «عرض التحضير للمراجعة» ثم «اعتماد وحفظ التحضير».');
  return true;
 }
 function assertStagedPreparation(){
   const staged=stagedPreparation,opts=selected();
   if(!staged||staged.status!=='staged')throw Error('لم يُجهز تحضير غير محفوظ. اضغط التوليد أولًا.');
   if(opts.service!=='preparation'||opts.course?.cid!==staged.cid||classTeacherId!==staged.teacherId||
      opts.subject!==staged.subject||opts.semester!==staged.semester||
      $('stnHubUnit').value!==staged.unitNo||$('stnHubLesson').value!==staged.lessonNo||
      location.href!==staged.pageURL||$('stnHubPrepDate').value!==staged.startDate||
      Number($('stnHubPeriods').value)!==staged.periods||prepSaveMode()!==staged.saveMode)
    throw Error('تغيّر الصف أو المادة أو الفصل أو الوحدة أو الدرس أو التواريخ منذ التجهيز. أعد المراجعة والتوليد قبل الحفظ.');
   if(Date.now()-staged.createdAt>15*60*1000)throw Error('انتهت صلاحية التحضير المجهز (15 دقيقة). أعد التوليد ثم المراجعة.');
   return staged;
 }
 async function reviewStagedPreparation(){
   const staged=assertStagedPreparation();
   const verification=await globalThis.NoorPrepBridge2828?.verifyPreparationBeforeSave?.(staged.lessonNodeId);
   if(!verification?.ok)throw Error('لم أتحقق من اختيار الدرس والمستوى في نور: '+(verification?.reason||'غير معروف'));
   const fieldLabels={objectives:'الأهداف',concepts:'المفاهيم',warmUp:'التمهيد',procedures:'الإجراءات والأنشطة',formative:'التقويم التكويني',closing:'التقويم الختامي',details:'ملاحظات'};
   const lines=['مراجعة التحضير قبل الحفظ — لم يُرسل إلى نور بعد','',
      'المادة: '+staged.subject,'الصف: '+staged.grade,'الفصل الدراسي: '+staged.semester,
      'الوحدة: '+staged.unit,'الدرس: '+staged.lesson,
      'تاريخ أول حصة: '+staged.scheduledDate,'عدد الحصص: '+staged.periods,
      'العنوان في نموذج نور: '+verification.title,
      'المستوى في نور: '+verification.levels.join('، '),''];
   for(const [key,label] of Object.entries(fieldLabels))lines.push(label+'\n'+String(staged.fields[key]||'—')+'\n');
   $('stnHubPrepPreview').textContent=lines.join('\n');
   $('stnHubPrepPreview').hidden=false;
   staged.reviewed=true;
   $('stnHubPrepAutoSave').disabled=false;
   status('تم عرض التحضير للمراجعة. يمكنك تعديل حقول نور يدويًا، ثم اضغط «حفظ تلقائي» مرة واحدة عند الموافقة.');
 }
 async function saveReviewedPreparation({automatic=false}={}){
  const epoch=operationEpoch;
   const staged=assertStagedPreparation();
   if(automatic && staged.saveMode!=='auto')throw Error('الحفظ التلقائي لم يختره المعلم قبل التوليد.');
   if(!automatic && (staged.saveMode!=='review'||!staged.reviewed))throw Error('راجع التحضير ووافق عليه قبل الحفظ.');
   const bridge=globalThis.NoorPrepBridge2828;
   const verification=await bridge.verifyPreparationBeforeSave(staged.lessonNodeId);
   ensureOperation(epoch);
   if(!verification?.ok)throw Error('تغيرت بيانات النموذج بعد المعاينة: '+(verification?.reason||'غير معروف'));
   if(!hasPreparationCourseProof({verified:true,cid:staged.cid}))
    throw Error('انتهت صلاحية رابط التحضير الرسمي. لن أحفظ دون تحقق جديد من الصف.');
   // Commit only once, even if Noor navigates or the server response is uncertain.
   staged.status='submitting';$('stnHubPrepAutoSave').disabled=true;
   $('stnHubPrepReview').disabled=true;
   const previous=readTransfer('preparation')||{};
   writeTransfer({...previous,service:'preparation',course:{cid:staged.cid,label:staged.grade,grade:staged.grade},
      phase:'submitting',requestedAt:Date.now(),teacherId:staged.teacherId,targetPath:location.pathname});
   ensureOperation(epoch);
   const result=await bridge.submitPreparation();
   ensureOperation(epoch);
   if(!result?.scheduled)throw Error('لم يقبل نموذج نور جدولة عملية حفظ التحضير؛ لا تعاد المحاولة آليًا.');
   writeTransfer({...readTransfer('preparation'),service:'preparation',phase:'submitted',submittedAt:Date.now()});
   staged.status='save_scheduled';
   status('أُرسل أمر الحفظ مرة واحدة إلى نموذج نور. بانتظار إثبات نجاحه من الموقع؛ لن تعاد المحاولة تلقائيًا.');
 }
 async function updateActivityResume(job){
  if(!job)job=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  const engine=globalThis.NoorSmartAutomator;
  $('stnHubActivityResumeDate').hidden=!(engine?.isPausedActivityDate?.(job)&&job.pausedPath===location.pathname);
 }
 async function activity(opts){
  const epoch=operationEpoch;
  const resolved=await resolveVerifiedLesson(opts,{required:true});opts.unit=resolved.unit;opts.lesson=resolved.title;
  if(!globalThis.NoorSmartHub)throw Error('محرك الأنشطة لا يعمل في هذه الصفحة. افتح صفحة المهام الإلكترونية في نور.');
  const prior=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  if(prior?.active)throw Error('هناك نشاط سابق ما زال قيد التنفيذ في نور. افتحه أو أوقفه قبل إنشاء نشاط آخر حتى لا تتكرر الأسئلة.');
  status('جارٍ توليد نشاط الدرس باستخدام مفتاح المعلم...');
  const verified=globalThis.NoorCourseCatalog?.get?.(opts.course.cid);
  if(!verified?.cidNumeric||!sameCourse({cid:verified.cidNumeric,label:verified.label,grade:verified.grade},opts.course))
   throw Error('فُقد دليل ارتباط الصف ببطاقة نور الرسمية، ولن أنشر نشاطًا في فصل غير مؤكد.');
  const courseProof={cid:opts.course.cid,label:opts.course.label,grade:opts.course.grade,subject:opts.subject};
  const count=Number($('stnHubActivityQuantity').value);
  if(!Number.isInteger(count)||count<1||count>8)throw Error('عدد الأنشطة يجب أن يكون بين 1 و8');
  const kinds=[...$('stnHubActivityTypes').querySelectorAll('input:checked')].map(x=>x.value);
  if(!kinds.length)throw Error('اختر نوع نشاط واحدًا على الأقل');
  const ids=[];
  for(let i=0;i<count;i++){
   status('يُنشأ نشاط '+(i+1)+' من '+count+' لمادة '+opts.subject+' ...');
   const next=await globalThis.NoorSmartHub.generate({unit:opts.unit,lesson:opts.lesson,count:opts.count,courseProof,kinds});
   if(!next?.ok||!next.assessment?.id)throw Error(next?.error||'تعذر إنشاء نشاط رقم '+(i+1));
   if(next?.issues?.length)throw Error('تحتاج الأسئلة إلى مراجعة قبل النشر: '+next.issues.slice(0,3).join(' | '));
   ids.push(next.assessment.id);
  }
  const result={ok:true,ids};
  if(!result?.ok)throw Error(result?.error||'تعذر إنشاء الأنشطة');
  status('أُنشئت الأسئلة. جارٍ اختيار الفصل والمفردات في نور...');
  const before=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1?.id||'';
  ensureOperation(epoch);
  const msg=await globalThis.NoorSmartHub.publishSelection({unit:opts.unit,lesson:opts.lesson,courseProof,lessonNodeId:resolved.lessonId,ids:result.ids,publishDate:$('stnHubActivityPublishDate').value});
  const after=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  if(!after?.id||after.id===before||!after.active||String(after.cid)!==String(courseProof.cid)||
     Number(after.grade)!==Number(courseProof.grade))
    throw Error('لم يبدأ محرك نقل الأسئلة بصف جديد مؤكد. أُنشئت الأسئلة في المكتبة ولم يُحفظ واجب في نور. '+(msg||''));
  status('✓ احتفظت الإضافة بالصف والوحدة والدرس. بدأ نقل النشاط إلى نور وسيستكمل عبر الصفحات. '+(msg||''));
 }
 // Render a genuine Gemini illustration before ZIP packaging (offline after export).
 // Images are compressed locally and never uploaded to the Notebook backend.
 async function generateScormImage(opts,variant=1){
  status('🎨 جاري توليد صورة كرتونية ثلاثية الأبعاد بطابع عُماني مرتبطة بمادة '+opts.subject+' ودرس '+opts.lesson+'...');
  const r=await browser.runtime.sendMessage({type:'NOOR_GEMINI_SCORM_IMAGE',subject:opts.subject,
    grade:opts.course.grade,unit:opts.unit,lesson:opts.lesson,variant});
  if(!r?.ok||!r.image?.base64)throw Error('فشل توليد صورة النشاط باستخدام Gemini: '+(r?.error||'لم يتم إرجاع صورة فعلية')+'. لم أستبدلها برسم SVG.');
  const src='data:'+r.image.mime+';base64,'+r.image.base64;
  const img=new Image();img.src=src;
  try{await img.decode()}catch(e){throw Error('لم أستطع فتح صورة Gemini للتحقق من جودتها: '+String(e?.message||e))}
  if(!img.naturalWidth||!img.naturalHeight)throw Error('صورة Gemini فارغة.');
  const canvas=document.createElement('canvas');
  const scale=Math.min(1,1400/img.naturalWidth,850/img.naturalHeight);
  canvas.width=Math.max(1,Math.round(img.naturalWidth*scale));canvas.height=Math.max(1,Math.round(img.naturalHeight*scale));
  const ctx=canvas.getContext('2d');if(!ctx)throw Error('المتصفح لم يوفر معالجة صور Canvas.');
  ctx.drawImage(img,0,0,canvas.width,canvas.height);
  const blob=await new Promise(resolve=>canvas.toBlob(resolve,'image/jpeg',0.82));
  if(!blob||blob.size<400||blob.size>2*1024*1024)throw Error('الصورة المولدة غير قابلة لضغط آمن لحزمة SCORM.');
  const data=await blob.arrayBuffer(),bytes=new Uint8Array(data);
  let bin='',chunks=[];
  for(let i=0;i<bytes.length;i++){bin+=String.fromCharCode(bytes[i]);if(bin.length===8192){chunks.push(bin);bin='';}}
  if(bin)chunks.push(bin);
  return {mime:'image/jpeg',base64:btoa(chunks.join('')),alt:'3D Omani scene — '+opts.subject+' — '+opts.lesson};
 }
 function scormImageMode(){
  const mode=$('stnHubScormImageMode').value;
  return ['gemini_svg','gemini_none','svg','none'].includes(mode)?mode:'gemini_svg';
 }
 async function resolveScormImage(opts,variant){
  const mode=scormImageMode();
  if(mode==='none'){status('متابعة إنشاء SCORM دون صورة حسب اختيار المعلم.');return null;}
  if(mode==='svg'){status('استخدام رسم SVG تعليمي محلي بدلاً من استهلاك حصة توليد صور Gemini.');return {kind:'svg-fallback'};}
  try{return await generateScormImage(opts,variant)}catch(e){
   // This opt-in fallback concerns the optional image only. Text/question failures still stop.
   const reason=String(e?.message||e);
   if(mode==='gemini_none'){
    status('تعذر توليد صورة Gemini ('+reason.slice(0,125)+'). سأكمل الدرس دون صورة كما اخترت.');
    return null;
   }
   status('تعذر توليد صورة Gemini ('+reason.slice(0,125)+'). سأكمل الدرس برسم SVG تعليمي، وليس صورة AI ثلاثية الأبعاد.');
   return {kind:'svg-fallback'};
  }
 }
 async function scorm(opts){
  const epoch=operationEpoch;
  const resolved=await resolveVerifiedLesson(opts,{required:true});opts.unit=resolved.unit;opts.lesson=resolved.title;
  status('جارٍ إنشاء مغامرة SCORM عمانية تفاعلية للوحدة والدرس المحددين (اختيار، ترتيب، توصيل، صح/خطأ)...');
  const quantity=Number($('stnHubScormQuantity').value);
  if(!Number.isInteger(quantity)||quantity<1||quantity>10)throw Error('عدد الدروس التفاعلية يجب أن يكون من 1 إلى 10');
  let started=0;
  for(let i=0;i<quantity;i++){
   status('جارٍ إنشاء درس SCORM '+(i+1)+' من '+quantity+' لمادة '+opts.subject+'...');
   const result=await browser.runtime.sendMessage({type:'NOOR_GEMINI_SCORM_GENERATE',count:opts.count,
     subject:opts.subject,grade:opts.course.grade,unit:opts.unit,lesson:opts.lesson,semester:opts.semester,variant:i+1});
   if(!result?.ok)throw Error('تعذر إنشاء الدرس التفاعلي '+(i+1)+': '+(result?.error||'استجابة Gemini غير صالحة'));
   const title=(opts.subject+' — '+opts.unit+' — '+opts.lesson+(quantity>1?' ('+(i+1)+')':'')).slice(0,160);
   const image=await resolveScormImage(opts,i+1);
   ensureOperation(epoch);
   const blob=globalThis.NoorScorm.create(title,{...result.data,image},{subject:opts.subject,grade:opts.course.grade,unit:opts.unit,lesson:opts.lesson});
   const file=new File([blob],('Noor-SCORM-G'+opts.course.grade+'-U'+opts.unitNo+'-L'+opts.lessonNo+'-'+(i+1)+'.zip'),{type:'application/zip'});
   await download(file); // user always receives a portable backup
   if(quantity===1){
    if(!globalThis.NoorScormPublisher)throw Error('محرك استكمال النشر غير جاهز؛ الملف تم تنزيله احتياطيًا.');
    await globalThis.NoorScormPublisher.start(file,{...opts,positionProof:opts.proof,mode:scormSaveMode(),teacherId:classTeacherId,publishDate:$('stnHubScormPublishDate').value});
    started++;
   }
  }
  if(quantity>1)status('تم إنشاء '+quantity+' ملفات SCORM وتنزيلها. اختر ملفًا واحدًا عند نشر كل درس حتى لا يستبدل مساق سابقًا.');
  else if(started)status('✓ ملف SCORM جاهز. بدأت عملية فتح المكتبة الرقمية ثم مكتبة الدروس التفاعلية ونقل الملف تلقائيًا؛ سيظهر توقف واضح إذا لم يتعرف على أحد عناصر نور.');
 }
 function uniqueInputFile(){
  const els=[...document.querySelectorAll('input[type="file"]')]
   .filter(el=>!el.disabled&&!root.contains(el)&&!el.closest('#noor-prep-panel'));
  const descriptor=el=>{
    const own=[el.accept,el.name,el.id,el.getAttribute('aria-label')].filter(Boolean).join(' ');
    let parent=el.parentElement,near='';
    for(let i=0;parent&&i<3;i++,parent=parent.parentElement){
      const label=parent.querySelector('label');
      const txt=(label?.textContent||parent.textContent||'').trim();
      if(txt.length<150){near=txt;break;}
    }
    return {own,near};
  };
  const valid=els.filter(el=>{
    const d=descriptor(el),all=(d.own+' '+d.near);
    // Never write a SCORM ZIP into the optional cover-image input.
    if(/cover|poster|image|thumbnail|غلاف|صورة|png|jpe?g|gif|webp/i.test(all))return false;
    return /\.zip|scorm|attachment|رفع\s*ملف|اختر\s*ملف|drop a file|upload/i.test(all);
  });
  if(valid.length===1)return valid[0];
  // If Noor provides only one input, verify it is not an image-only field.
  if(els.length===1&&!/image\/|\.png|\.jpe?g|غلاف/i.test(Object.values(descriptor(els[0])).join(' ')))return els[0];
  return null;
 }
 async function attachScorm(file,opts){
  const input=uniqueInputFile();if(!input)return false;
  const official=opts.course?.cid&&globalThis.NoorCourseCatalog?.get?.(opts.course.cid)?.routes?.scorm;
  const officialCid=official?new URL(official).pathname.match(/cid:([^/]+)/)?.[1]:'';
  const verified=globalThis.NoorScormClassEvidence?.ensureSelected?.(opts.course);
  if(!opts.course||!verified?.ok)
   throw Error('لم أتحقق من الكتاب والصف وخانة «نشر لفصول» الخاصة بمساق SCORM: '+(verified?.reason||'unconfirmed')+'. لن أرفع الملف قبل التأكد.');
  try{
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  }catch(_){return false}
  const inputs=[...document.querySelectorAll('input[type="text"],textarea')].filter(el=>!el.closest('#noor-prep-panel')&&!root.contains(el));
  const titleFields=inputs.filter(el=>/title|name|العنوان|اسم\s*المساق/i.test([el.name,el.id,el.placeholder,el.getAttribute('aria-label')].join(' ')));
  if(titleFields.length===1){const el=titleFields[0];el.value=opts.unit+' — '+opts.lesson;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
  // Never submit an ambiguous Noor SCORM form. Screenshots alone do not prove the save selector.
  return true;
 }
 async function download(file){const url=URL.createObjectURL(file);const a=document.createElement('a');a.href=url;a.download=file.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}
 async function grades(opts){
  if(routetype()!=='grades'){
   if(!csvFileInfo)throw Error('افتح صفحة رصد الدرجات للفصل المحدد في نور قبل النقل.');
   // Some Noor releases use different grade routes. A real editable student table is the requirement.
   gradePageScan();
  }
  await gradesTransfer(opts);
 }
 // Durable, teacher-approved one-unit queue: no second submission without Noor success evidence.
 const UNIT_JOB='stnNoorUnitBatch:v1',UNIT_NAV='stnNoorUnitActivityNav:v1';let unitBatchBusy=false;
 const getUnitJob=async()=>{const j=(await browser.storage.local.get(UNIT_JOB))[UNIT_JOB];return j&&Date.now()-j.createdAt<4*3600*1000?j:null};
 const setUnitJob=async j=>browser.storage.local.set({[UNIT_JOB]:{...j,updatedAt:Date.now()}});
 async function confirmedUnitLessons(opts){
  const branch=await orderedBranch(opts);
  if(!unitMatchesProof(branch,opts.proof))throw Error('تحقّق من ترتيب الوحدة في شجرة الصف قبل إنشاء أنشطتها.');
  const entries=branch.lessons.map((lesson,index)=>({unit:branch.unit,lesson:lesson.title,source:'tree',
   termId:branch.termId,unitId:branch.unitId,lessonId:lesson.id,unitNo:opts.unitNo,lessonNo:index+1}));
  if(!entries.length||entries.length>35)throw Error('تعذر إنشاء سلسلة لهذه الوحدة. النطاق المتاح من درس واحد إلى 35 درسًا.');
  return entries;
 }
 async function beginUnitBatch(opts){
  const epoch=operationEpoch;
  if(unitBatchBusy)throw Error('عملية الوحدة قيد التشغيل.');
  checkContext(opts,false);checkQuestionCount(opts);
  if(!keyReady||!classTeacherId)throw Error('يجب ربط حساب المعلم ومفتاح Gemini قبل إنشاء أنشطة الوحدة.');
  if(!opts.proof?.unitId)throw Error('تحقّق من ترتيب الوحدة في شجرة الصف أولًا.');
  const old=await getUnitJob();if(old&&!['complete','cancelled','needs_lessons'].includes(old.phase))throw Error('هناك عملية وحدة سابقة غير مكتملة. راجع حالتها أو ألغها قبل البدء مجددًا.');
  const needsActivityPage=opts.service==='activities'&&!isActivityCoursePage(opts.course);
  const target=needsActivityPage?openTarget(opts):null;
  if(needsActivityPage&&!target)throw Error('تعذر تحديد رابط المهام الإلكترونية للصف المختار.');
  const auto=opts.service==='activities'?$('stnHubActivityUnitAuto').checked:$('stnHubScormUnitAuto').checked;
  const publishDate=opts.service==='activities'?$('stnHubActivityPublishDate').value:$('stnHubScormPublishDate').value;
  if(publishDate&&!/^\d{4}-\d{2}-\d{2}$/.test(publishDate))throw Error('تاريخ النشر غير صحيح.');
  const kinds=[...$('stnHubActivityTypes').querySelectorAll('input:checked')].map(x=>x.value);
  if(opts.service==='activities'&&!kinds.length)throw Error('اختر نوع سؤال واحدًا على الأقل.');
  const quantity=Number((opts.service==='activities'?$('stnHubActivityQuantity'):$('stnHubScormQuantity')).value);
  if(!Number.isInteger(quantity)||quantity<1||quantity>8)throw Error('اختر عددًا صالحًا من الأنشطة لكل درس (1–8).');
  if(opts.service==='scorm'&&quantity!==1)throw Error('في وضع جميع دروس الوحدة: اختر درس SCORM واحدًا لكل درس رسمي. يمكن توليد نسخ إضافية من وضع الدرس الواحد.');
  const entries=needsActivityPage?[]:await confirmedUnitLessons(opts);
  const batch={id:crypto.randomUUID(),createdAt:Date.now(),teacherId:classTeacherId,service:opts.service,course:{...opts.course},subject:opts.subject,
   semester:opts.semester,unit:opts.unit,unitNo:opts.unitNo,proof:opts.proof,entries,index:0,count:opts.count,quantity,kinds,auto,publishDate,imageMode:scormImageMode(),
   phase:needsActivityPage?'collecting':'ready', lastRunId:'',completed:[],generationIds:[],stagedIds:[],scormAwaitingId:'',status:'سلسلة وحدة جديدة'};
  ensureOperation(epoch);
  await setUnitJob(batch);
  if(needsActivityPage){
   sessionStorage.setItem(UNIT_NAV,batch.id);
   status('جارٍ فتح المهام الإلكترونية للصف المختار للتحقق من دروس الوحدة واستكمال توليد الأنشطة.');
   location.assign(target);
   return;
  }
  status('تم التحقق من '+entries.length+' دروس رسمية في الوحدة. سيتم التعامل مع كل درس على حدة.');
  await advanceUnitBatch();
 }
 function canRetryActivityGeneration(j){
  return j?.service==='activities'&&(j.phase==='retry_generation'||
   (j.phase==='paused'&&/^فشل التحقق من أسئلة الدرس/.test(j.status||'')));
 }
 function showUnitRetry(j){
  $('stnHubBatchRetry').hidden=$('stnHubService').value!=='activities'||!classTeacherId||
   j?.teacherId!==classTeacherId||!canRetryActivityGeneration(j);
 }
 async function retryActivityGeneration(){
  if(unitBatchBusy||busy)return;
  const j=await getUnitJob();
  if(!canRetryActivityGeneration(j)||j.teacherId!==classTeacherId)return;
  const run=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  if(run?.active)throw Error('يوجد نشاط قيد الحفظ في نور. استكمله أولًا.');
  j.phase='ready';await setUnitJob(j);showUnitRetry(j);
  await advanceUnitBatch();
 }
 async function advanceUnitBatch(){
  const epoch=operationEpoch;
  if(unitBatchBusy)return;
  unitBatchBusy=true;
  try{
   let j=await getUnitJob();if(!j||!['collecting','ready','awaiting','publishing'].includes(j.phase))return;
   if(j.phase==='collecting'&&(sessionStorage.getItem(UNIT_NAV)!==j.id||!isActivityCoursePage(j.course)))return;
   const active=await globalThis.NOOR_TEACHER_PROFILE?.active?.();
   if(!active||String(active)!==String(j.teacherId))throw Error('تغيّر حساب المعلم؛ توقفت سلسلة الوحدة.');
   globalThis.NoorCourseCatalog?.scan?.();const record=globalThis.NoorCourseCatalog?.get?.(j.course.cid);
   if(!sameCourse({cid:record?.cidNumeric,grade:record?.grade,label:record?.label},j.course)||
      norm(globalThis.NoorCourseCatalog.subjectOf(record.label))!==norm(j.subject))
    throw Error('لم أجد إثبات الصف والمادة المختارين في سجل نور الحالي.');
   if(j.phase==='collecting'){
    $('stnHubPanel').hidden=false;
    syncClassOptions();
    if(!isPinnedCourse(j.course))throw Error('اختيار المعلم لا يطابق الصف الذي بدأت منه السلسلة.');
    $('stnHubService').value='activities';showStatus();
    $('stnHubActivityScope').value='unit';updateBatchScope();
    $('stnHubActivityUnitAuto').checked=j.auto;
    $('stnHubActivityPublishDate').value=j.publishDate;
    $('stnHubActivityQuantity').value=String(j.quantity);
    $('stnHubCount').value=String(j.count);
    for(const checkbox of $('stnHubActivityTypes').querySelectorAll('input'))checkbox.checked=j.kinds.includes(checkbox.value);
    selectHubTab('task');
    status('وصلت إلى صفحة المهام الإلكترونية. جارٍ مطابقة دروس الوحدة المختارة.');
    ensureOperation(epoch);
    j.entries=await confirmedUnitLessons(j);
    const currentJob=await getUnitJob();
    if(currentJob?.id!==j.id||currentJob.phase!=='collecting')return;
    j.phase='ready';await setUnitJob(j);
    sessionStorage.removeItem(UNIT_NAV);
   }
   if(j.phase==='publishing'){
    if(j.service==='activities'){
     const run=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
     if(!run?.id||String(run.cid)!==String(j.course.cid)||!j.stagedIds.every(id=>run.items?.some(x=>x.id===id))){
      if(Date.now()-(j.publishStartedAt||j.updatedAt)>17000)throw Error('لم يتأكد بدء حفظ الأنشطة بعد تغيير الصفحة؛ لن أكرر التوليد أو الحفظ.');return;}
     j.lastRunId=run.id;
    }else{
     const publish=globalThis.NoorScormPublisher?.inspect?.();
     if(!publish?.id||publish.batchTag!==j.id.slice(0,8)+'-'+(j.index+1)){
      if(Date.now()-(j.publishStartedAt||j.updatedAt)>17000)throw Error('لم يتأكد بدء رفع SCORM بعد تغيير الصفحة؛ لن أكرر إرسال الملف.');return;}
     j.scormAwaitingId=publish.id;
    }
    j.phase='awaiting';await setUnitJob(j);
   }
   if(j.phase==='awaiting'){
    if(j.service==='activities'){
     const run=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
     if(run?.id!==j.lastRunId)throw Error('تغيرت معاملة الأنشطة في نور؛ لن أنتقل للدرس التالي.');
     if(run.stage==='paused'){status(run.message||'توقف حفظ النشاط في نور. ستتابع السلسلة بعد التأكد من حفظه.');return;}
     if(run.stage!=='done'||run.active)return;
    }else{
     const publish=globalThis.NoorScormPublisher?.inspect?.();
     if(!publish||publish.id!==j.scormAwaitingId||publish.phase!=='done')return;
    }
    j.completed.push({unit:j.entries[j.index].unit,lesson:j.entries[j.index].lesson,at:Date.now()});j.index++;j.generationIds=[];j.phase='ready';await setUnitJob(j);
   }
   if(j.index>=j.entries.length){j.phase='complete';j.status=j.auto?'اكتمل حفظ جميع دروس الوحدة التي أكد نور حفظها':'اكتمل توليد جميع دروس الوحدة؛ احفظ الأنشطة يدويًا من المكتبة أو ارفع ملفات SCORM المنزلة';await setUnitJob(j);status('✓ '+j.status+' ('+j.completed.length+' دروس).');return;}
   const entry=j.entries[j.index];
   if(j.service==='activities'&&!isActivityCoursePage(j.course)){
    const path=openTarget({service:'activities',course:j.course});if(!path)throw Error('لا يوجد مسار أنشطة مؤكد للصف.');
    // Only the teacher's verified numeric CID is used, never a guessed lesson URL.
    status('جارٍ العودة إلى أنشطة الصف المؤكد لإكمال الدرس '+(j.index+1));location.assign(path);return;
   }
   j.phase='generating';await setUnitJob(j);
   const courseProof={cid:j.course.cid,label:j.course.label,grade:j.course.grade,subject:j.subject};
   const opts={subject:j.subject,service:j.service,semester:j.semester,course:j.course,unit:entry.unit,lesson:entry.lesson,count:j.count};
   if(j.service==='activities'){
    const ids=[...(j.generationIds||[])];
    for(let i=ids.length;i<j.quantity;i++){
     status('إنشاء نشاط '+(i+1)+' من '+j.quantity+' — درس '+(j.index+1)+' من '+j.entries.length+': '+entry.lesson);
     const r=await globalThis.NoorSmartHub?.generate?.({...opts,courseProof,kinds:j.kinds});
     const latest=await getUnitJob();
     if(latest?.id!==j.id||latest.phase!=='generating')return;
     if(!r?.ok||!r.assessment?.id||r.issues?.length)
      throw Error('الدرس «'+entry.lesson+'». '+(r?.error||r?.issues?.slice(0,3).join(' | ')||'تعذّر تجهيز الأسئلة.'));
     ids.push(r.assessment.id);j.generationIds=[...ids];await setUnitJob(j);
    }
    if(!j.auto){j.completed.push({lesson:entry.lesson,ids,storedOnly:true});j.index++;j.generationIds=[];j.phase='ready';await setUnitJob(j);return;}
    const prior=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
    if(prior?.active)throw Error('يوجد نشاط آخر قيد الحفظ في نور. استكمله ثم تابع هذه الوحدة.');
    if((await getUnitJob())?.phase!=='generating')return;
    j.phase='publishing';j.stagedIds=ids;j.publishStartedAt=Date.now();await setUnitJob(j);
    ensureOperation(epoch);
    await globalThis.NoorSmartHub.publishSelection({...opts,courseProof,ids,lessonNodeId:entry.lessonId,publishDate:j.publishDate});
    const run=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
    if(!run?.id||run.id===prior?.id||String(run.cid)!==String(j.course.cid)||
       !ids.every(id=>run.items?.some(item=>item.id===id)))throw Error('لم يؤكد محرك نور بدء حفظ الأنشطة المحددة.');
    if((await getUnitJob())?.phase!=='publishing')return;
    j.lastRunId=run.id;j.phase='awaiting';await setUnitJob(j);
    status('بدأ حفظ نشاط '+entry.lesson+'؛ لن أنتقل للدرس التالي قبل تأكيد نور.');
   }else{
    const made=await browser.runtime.sendMessage({type:'NOOR_GEMINI_SCORM_GENERATE',count:j.count,subject:j.subject,
     grade:j.course.grade,unit:entry.unit,lesson:entry.lesson,semester:j.semester,variant:j.index+1});
    if(!made?.ok)throw Error('تعذر توليد أسئلة SCORM للدرس '+entry.lesson+': '+(made?.error||''));
    ensureOperation(epoch);
    const image=await resolveScormImageWithMode(opts,j.index+1,j.imageMode);
    const title=(j.subject+' — '+entry.unit+' — '+entry.lesson).slice(0,160);
    const zip=globalThis.NoorScorm.create(title,{...made.data,image},{subject:j.subject,grade:j.course.grade,unit:entry.unit,lesson:entry.lesson});
    const filename='Noor-SCORM-G'+j.course.grade+'-batch-'+(j.index+1)+'.zip';
    const file=new File([zip],filename,{type:'application/zip'});
    ensureOperation(epoch);
    await download(file);
    if(!j.auto){j.completed.push({lesson:entry.lesson,downloadedOnly:true});j.index++;j.phase='ready';await setUnitJob(j);return;}
    if(!globalThis.NoorScormPublisher)throw Error('محرك رفع SCORM غير متاح.');
    const lessonEvidence=entry.source==='form'?{source:'unit_batch',teacherApproved:true,unit:entry.unit,title:entry.lesson,
      observedAt:j.createdAt,control:entry.control,optionValue:entry.optionValue}:null;
    j.phase='publishing';j.publishStartedAt=Date.now();await setUnitJob(j);
    ensureOperation(epoch);
    const started=await globalThis.NoorScormPublisher.start(file,{...opts,teacherId:j.teacherId,mode:'auto',publishDate:j.publishDate,
     batchTag:j.id.slice(0,8)+'-'+(j.index+1),lessonEvidence,positionProof:entry.lessonId?entry:null});
    ensureOperation(epoch);
    if(!started?.ok)throw Error('لم يبدأ رفع SCORM.');
    j.scormAwaitingId=started.id;j.phase='awaiting';await setUnitJob(j);
   }
  }catch(e){
   if(epoch!==operationEpoch)return;
   const j=await getUnitJob(),reason=String(e.message||e);
   if(j&&!['complete','cancelled'].includes(j.phase)){
    j.phase=j.phase==='collecting'?'needs_lessons':j.phase==='generating'&&j.service==='activities'?'retry_generation':'paused';
    j.status=reason;await setUnitJob(j);showUnitRetry(j);
    if(sessionStorage.getItem(UNIT_NAV)===j.id)sessionStorage.removeItem(UNIT_NAV);
   }
   status('توقف تسلسل الوحدة. '+reason);
  }
  finally{
   if(epoch===operationEpoch){
    unitBatchBusy=false;
    const cur=await getUnitJob();
    if(cur?.phase==='ready'||cur?.phase==='awaiting'&&cur.service==='activities'&&(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1?.stage==='done')
     setTimeout(()=>checkUnitBatch().catch(()=>{}),180);
   }
  }
 }
 async function resolveScormImageWithMode(opts,variant,mode){
  if(mode==='none')return null;if(mode==='svg')return {kind:'svg-fallback'};
  try{return await generateScormImage(opts,variant)}catch(e){status('تعذر Gemini للصور، جارٍ الاستمرار حسب الإعداد المحدد.');return mode==='gemini_none'?null:{kind:'svg-fallback'};}
 }
 async function checkUnitBatch(){const j=await getUnitJob();showUnitRetry(j);if(!j)return;
  if(j.service!==$('stnHubService').value&&!(j.phase==='collecting'&&sessionStorage.getItem(UNIT_NAV)===j.id))return;
  if(['collecting','awaiting','ready','publishing'].includes(j.phase))await advanceUnitBatch();
  else if(j.phase==='paused'||j.phase==='retry_generation')status('توقف تسلسل دروس الوحدة عند '+(j.index+1)+' من '+j.entries.length+': '+j.status+' — لن يعاد النشر دون مراجعة.');
 }
 async function generate(resumeId){
  const epoch=operationEpoch;
  if(busy||stoppingAll||curriculumScanning())return;discover();const opts=selected();
  const bulk=(opts.service==='activities'&&$('stnHubActivityScope').value==='unit')||
   (opts.service==='scorm'&&$('stnHubScormScope').value==='unit');
  busy=true;$('stnHubGenerate').disabled=true;
  try{
   checkContext(opts,opts.service!=='grades'&&!bulk);checkQuestionCount(opts);
   if(opts.service!=='grades'&&!keyReady)throw Error('اربط مفتاح Gemini الخاص بك أولًا.');
   if(['activities','preparation'].includes(opts.service)){
    if(!opts.proof?.unitId)throw Error('تحقّق من ترتيب الوحدة في شجرة الصف أولًا.');
    if(!resumeId){await startFromDashboard(opts,epoch);return 'navigating';}
    const p=readTransfer(opts.service);
    const confirmed=opts.service==='preparation'?hasPreparationCourseProof(opts.course):isActivityCoursePage(opts.course);
    if(p?.id!==resumeId||p.phase!=='running'||!matchesTransfer(opts,p)||!confirmed)
     throw Error('لم يُفتح المسار المؤكّد للصف المختار.');
   }
   if(bulk){await beginUnitBatch(opts);return true;}
   if(opts.service==='grades'&&await routeIfNeeded(opts))return 'navigating';
   if(opts.service==='preparation'){resetPreparationReview();await prep(opts);}
   else if(opts.service==='activities')await activity(opts);
   else if(opts.service==='scorm')await scorm(opts);
   else await grades(opts);
   return true;
  }catch(e){if(epoch===operationEpoch)status('توقف: '+String(e.message||e));return false;}
  finally{if(epoch===operationEpoch){busy=false;$('stnHubGenerate').disabled=!keyReady&&$('stnHubService').value!=='grades';}}
 }
 function syncScormImport(){
  $('stnHubScormImport').hidden=$('stnHubService').value!=='scorm'||!importedScorm.length;
  $('stnHubScormFill').disabled=busy||$('stnHubScormPackage').value==='';
 }
 async function importScorm(files){
  const packages=[];
  for(const file of files){
   if(/\.zip$/i.test(file.name)&&globalThis.NoorScorm?.hasManifest(await file.arrayBuffer()))packages.push(file);
   else if(files.length===1&&/\.json$/i.test(file.name)){JSON.parse(await file.text());packages.push(file);}
   else throw Error('اختر حزم SCORM بصيغة ZIP تحتوي على imsmanifest.xml. الملف غير المطابق هو '+file.name+'. إذا كان أرشيفًا يجمع الاختبارات، فك ضغطه ثم اختر الحزم الداخلية.');
  }
  importedScorm=packages;
  const picker=$('stnHubScormPackage');
  picker.replaceChildren(new Option('اختر حزمة للتعبئة',''),...packages.map((file,i)=>new Option(file.name,String(i))));
  picker.value=packages.length===1?'0':'';
  syncScormImport();
  selectHubTab('task');
  status(packages.length===1?'تم استيراد '+packages[0].name+'. اضغط «تعبئة الدرس التفاعلي تلقائيًا».':
   'تم استيراد '+packages.length+' حزم SCORM. اختر حزمة ثم اضغط «تعبئة الدرس التفاعلي تلقائيًا».');
 }
 async function fillImportedScorm(file){
  const epoch=operationEpoch;
  discover();
  const opts=selected();
  checkContext(opts,false);
  const resolved=await resolveVerifiedLesson(opts,{required:true});
  opts.unit=resolved.unit;opts.lesson=resolved.title;
  if(!opts.unit||!opts.lesson){
   selectHubTab('content');
   throw Error('حدد الوحدة والدرس في «الصف والمحتوى»، ثم ارجع واضغط زر التعبئة.');
  }
  let zip=file;
  if(/\.json$/i.test(file.name)){
   const raw=JSON.parse(await file.text());
   const image=await resolveScormImage(opts,1);
   const blob=globalThis.NoorScorm.create(opts.subject+' — '+opts.unit+' — '+opts.lesson,{...(raw.data||raw),image},
    {subject:opts.subject,grade:opts.course.grade,unit:opts.unit,lesson:opts.lesson});
   zip=new File([blob],'Noor-SCORM-'+Date.now()+'.zip',{type:'application/zip'});
   await download(zip);
  }
  if(!globalThis.NoorScormPublisher)throw Error('محرك تعبئة SCORM غير جاهز.');
  ensureOperation(epoch);
  await globalThis.NoorScormPublisher.start(zip,{...opts,positionProof:opts.proof,
   mode:scormSaveMode(),teacherId:classTeacherId,publishDate:$('stnHubScormPublishDate').value});
 }
 async function importFile(file){
  const epoch=operationEpoch;
  discover();const opts=selected();
  if(opts.service!=='grades'){
   checkContext(opts,true);
   const lesson=await resolveVerifiedLesson(opts,{required:true});
   opts.unit=lesson.unit;opts.lesson=lesson.title;
  }
  if(opts.service==='activities'){
   if(!isActivityCoursePage(opts.course))throw Error('افتح صفحة المهام الإلكترونية للصف المختار أولًا.');
   const res=await globalThis.NoorSmartHub?.importFile(file,{...opts,courseProof:{cid:opts.course.cid,label:opts.course.label,grade:opts.course.grade,subject:opts.subject}});if(!res)throw Error('أداة استيراد الأنشطة غير جاهزة');
   const items=await globalThis.NoorSmartHub.list(opts);
   const container=$('stnHubImportedItems');container.replaceChildren();
   for(const item of items){const label=document.createElement('label'),check=document.createElement('input');check.type='checkbox';check.value=item.id;check.checked=items.length===1;
    label.append(check,document.createTextNode(' '+item.title+' ('+item.questionCount+' أسئلة)'));container.append(label);}
   $('stnHubImportChoices').hidden=!items.length;
   status('تم استيراد '+items.length+' نشاط لهذه الوحدة والدرس. اختر ما تريد نشره، أو حدد الكل. لن يُنشر نشاط لم تختره.');
  }else if(opts.service==='preparation'){
   const panel=document.querySelector('#noor-prep-panel');const input=panel?.querySelector('#noor-file');
   if(!input)throw Error('افتح صفحة تحضير الدروس لهذا الصف أولًا. يجب قراءة شجرة نور قبل الحفظ التلقائي.');
   if(!/\.(?:pdf|docx|txt)$/i.test(file.name))throw Error('استيراد التحضير القديم يدعم PDF وDOCX وTXT؛ لن تُنشر ملفات غير معروفة.');
   const date=$('stnHubPrepDate').value,periods=Number($('stnHubPeriods').value),scope=$('stnHubPrepScope').value;
   if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||!Number.isInteger(periods)||periods<1||periods>12)throw Error('حدد التاريخ وعدد الحصص أولًا.');
   if(scope==='semester')throw Error('تحضير فصل دراسي كامل من ملف متعدد الوحدات يحتاج مطابقة جميع دروس شجرة نور أولًا. لم أبدأ حفظًا قد يكرر الدروس؛ اختر وحدة واحدة أو قسم الملف إلى وحدات.');
   for(const [id,value] of [['noor-start-date',date],['noor-periods',String(periods)]]){const el=panel.querySelector('#'+id);if(!el)throw Error('لم أجد حقل '+id+' داخل محرك التحضير');el.value=value;el.dispatchEvent(new Event('change',{bubbles:true}));}
   const oldUnit=panel.querySelector('#noor-unit');oldUnit?.replaceChildren();
   const legacyStatus=panel.querySelector('.status');if(legacyStatus)legacyStatus.textContent='';
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
   status('جارٍ قراءة تحاضير الملف ومطابقة الوحدة والدرس مع نور...');
   for(let t=0;t<55;t++){
    if((legacyStatus?.textContent||'').startsWith('Loaded '))break;
    if((legacyStatus?.textContent||'').startsWith('Error:'))throw Error(legacyStatus.textContent);
    await new Promise(resolve=>setTimeout(resolve,200));
   }
   if(!(legacyStatus?.textContent||'').startsWith('Loaded '))throw Error('لم تكتمل قراءة الملف خلال مهلة الانتظار.');
   const gradeSel=panel.querySelector('#noor-grade'),unitSel=panel.querySelector('#noor-unit'),lessonSel=panel.querySelector('#noor-lesson');
   if(!gradeSel||!unitSel||!lessonSel||!unitSel.options.length)throw Error('لم تجهز قائمة دروس الملف بعد. انتظر حتى تكتمل القراءة ثم حاول مجددًا.');
   const equal=(a,b)=>norm(a)===norm(b);
   const declaredGrade=gradeSel.value;
   if(declaredGrade!=='From file'&&declaredGrade!=='Grade '+opts.course.grade)
    throw Error('الصف الموجود في الملف '+declaredGrade+' يختلف عن صف نور '+opts.course.grade+'. لن تُحفظ الدروس.');
   const matchingUnit=[...unitSel.options].filter(o=>equal(o.value,opts.unit)||equal(o.textContent,opts.unit));
   if(matchingUnit.length!==1)throw Error('الوحدة المحددة ليست مطابقة لوحدة واحدة في الملف. راجع اسم الوحدة قبل الحفظ.');
   unitSel.value=matchingUnit[0].value;unitSel.dispatchEvent(new Event('change',{bubbles:true}));
   if(scope==='lesson'){
    const matching=[...lessonSel.options].filter(o=>equal(o.textContent,opts.lesson));
    if(matching.length!==1)throw Error('الدرس المحدد ليس مطابقًا لدرس واحد في الملف. لن أبدأ حفظ درس خاطئ.');
    lessonSel.value=matching[0].value;lessonSel.dispatchEvent(new Event('change',{bubbles:true}));
   }
   const btn=panel.querySelector(scope==='unit'?'#noor-batch-btn':'#noor-fill-btn');
   if(!btn)throw Error('لم أجد زر التحضير الأصلي.');
   if(!confirm('الصف: '+opts.course.label+'\nالمادة: '+opts.subject+'\nالوحدة: '+opts.unit+'\n'+(scope==='lesson'?'الدرس: '+opts.lesson:'جميع دروس الوحدة')+'\nمن '+date+'، '+periods+' حصة لكل درس.\n\nبدء التعبئة والحفظ التلقائي؟'))return;
   ensureOperation(epoch);
   btn.click();status('بدأ محرك التحضير الأصلي بالحفظ التلقائي. راقب رسائله؛ ستتوقف العملية عند تعذر مطابقة شجرة نور.');
  }else if(opts.service==='grades'){
   if(/\.csv$/i.test(file.name)){
    if(file.size>4*1024*1024)throw Error('ملف CSV أكبر من 4 ميغابايت.');
    if(!globalThis.NoorCSVGrades)throw Error('محرك CSV مفقود من الإضافة.');
    setCsvFields(globalThis.NoorCSVGrades.parse(await file.text()));
    return;
   }
   if(!/\.json$/i.test(file.name))throw Error('استيراد الدرجات يقبل CSV أو JSON من دفتر المعلم.');
   csvFileInfo=null;globalThis.NoorCSVGrades?.reset();invalidateGradePreview();
   $('stnHubCsvFields').hidden=true;
   const bank=JSON.parse(await file.text());if(bank?.schema!=='teacher-notebook-noor-v1'||!Array.isArray(bank.students)||!Array.isArray(bank.assessments)||bank.students.length>300)throw Error('ملف الدرجات غير مطابق لتنسيق دفتر المعلم.');
   const id=(await browser.storage.local.get('stnActiveTeacherId')).stnActiveTeacherId;if(!id)throw Error('اربط حساب المعلم من الدفتر أولًا.');
   await browser.storage.local.set({['stnGrades:'+id]:bank});await showStatus();status('حُفظت بيانات الدرجات لهذا المعلم فقط. افتح صفحة الدرجات في نور ثم اضغط المطابقة والتعبئة.');
  }
 }
 const POSITION_KEY='stnNoorHubPosition:v1';
 let panelPosition=null,draggedOpener=false;
 const bound=(v,lo,hi)=>Math.min(Math.max(v,lo),Math.max(lo,hi));
 function readPosition(){try{const p=JSON.parse(localStorage.getItem(POSITION_KEY)||'null');return p&&typeof p==='object'?p:null}catch(_){return null}}
 function savePosition(){try{localStorage.setItem(POSITION_KEY,JSON.stringify({buttonX:root.getBoundingClientRect().left,buttonY:root.getBoundingClientRect().top,panel:panelPosition}))}catch(_){}}
 function placeButton(x,y){const b=$('stnHubOpen');root.style.left=bound(x,6,innerWidth-b.offsetWidth-6)+'px';root.style.top=bound(y,6,innerHeight-b.offsetHeight-6)+'px';root.style.bottom='auto';}
 function placePanel(x,y,remember=false){const panel=$('stnHubPanel');const w=panel.offsetWidth||Math.min(405,innerWidth-24),h=panel.offsetHeight||Math.min(innerHeight*.8,650);
  x=bound(x,6,innerWidth-w-6);y=bound(y,6,innerHeight-h-6);panel.style.left=x+'px';panel.style.top=y+'px';panelPosition={x,y};if(remember)savePosition();
 }
 const curriculumScanning=()=>Boolean(globalThis.NoorCurriculumDiscovery.load());
 async function curriculumAllowed(){
  if(busy||stoppingAll||stagedPreparation||$('stnHubService').value==='grades')return false;
  if(['activities','preparation'].some(service=>['dashboard','navigate','running','submitting','auto_saving'].includes(readTransfer(service)?.phase))||
     ['noor_batch','noor_batch_pending','stnNoorUnitActivityNav:v1'].some(key=>sessionStorage.getItem(key)))return false;
  const scorm=globalThis.NoorScormPublisher?.inspect?.();
  if(scorm&&!['done','paused'].includes(scorm.phase))return false;
  const [unit,storage]=await Promise.all([getUnitJob(),browser.storage.local.get('noorSmartRunV1')]);
  return (!unit||['complete','cancelled','paused','retry_generation'].includes(unit.phase))&&!storage.noorSmartRunV1?.active;
 }
 function curriculumStatus(message){
  const note=$('stnHubCurriculumStatus');note.hidden=false;note.textContent=message;
 }
 const curriculum=lookup.create({
  teacher:async()=>String(await globalThis.NOOR_TEACHER_PROFILE?.active?.()||''),
  allowed:curriculumAllowed,
  proof:cid=>hasPreparationCourseProof({cid,verified:true}),
  onProgress(){
   showPanel();selectHubTab('content');
   $('stnHubStopCurriculum').hidden=false;
   $('stnHubRefreshTree').disabled=true;
   $('stnHubGenerate').disabled=true;
   curriculumStatus('جارٍ قراءة الموضع المختار من شجرة نور…');
  },
  onFinish(job,result){
   showPanel();selectHubTab('content');
   $('stnHubRefreshTree').disabled=false;
   $('stnHubStopCurriculum').hidden=true;
   const course=selectedClass();
   if(!samePositions(inputs(),job)||!isPinnedCourse(course)||norm(course?.label)!==norm(job.label)){
    curriculumStatus('تغيّر الاختيار. تحقّق من الموضع الجديد.');return;
   }
   if(result.error){
    curriculumStatus(result.error==='unit'?'عدد الوحدات في هذا الفصل '+result.limit+'.':
     result.error==='semester'?'الفصل الدراسي المختار غير موجود في الشجرة.':
     result.error==='class'?'تعذّر التحقق من بطاقة الصف المختار في نور.':
     'تعذّرت قراءة الموضع من شجرة هذا الصف. حاول مرة أخرى.');
    return;
   }
   if(course.cid!==job.cid){curriculumStatus('تعذّر التحقق من بطاقة الصف المختار في نور.');return;}
   const branch=result.branch,lesson=lookup.lessonAt(branch,job.lessonNo);
   if(job.lessonNo&&!lesson){curriculumStatus('عدد الدروس في هذه الوحدة '+branch.lessons.length+'.');return;}
   persistSelection({course,proof:lessonProof(branch,lesson)});
   $('stnHubCurriculumStatus').hidden=true;
   displayLessonTitles({unit:branch.unit,title:lesson?.title});
  }
 });
 function showPanel(){const panel=$('stnHubPanel');panel.hidden=false;globalThis.NoorCourseCatalog?.scan?.();requestAnimationFrame(()=>{if(panelPosition)placePanel(panelPosition.x,panelPosition.y);else{const b=$('stnHubOpen').getBoundingClientRect(),h=panel.offsetHeight||Math.min(innerHeight*.8,650);placePanel(b.left,b.top-h-8)}});discover();keyStatus();if(!curriculumScanning())previewNumberSelection().catch(()=>{});}
 function enableDrag(target,onMove,onFinish){let state=null,moved=false;
  target.style.touchAction='none';
  target.addEventListener('pointerdown',event=>{if(event.button!==0||event.target.closest('button:not(#stnHubOpen)'))return;
   const rect=onMove===moveWindow?$('stnHubPanel').getBoundingClientRect():root.getBoundingClientRect();
   state={id:event.pointerId,startX:event.clientX,startY:event.clientY,x:rect.left,y:rect.top};moved=false;target.setPointerCapture?.(event.pointerId);event.preventDefault();});
  target.addEventListener('pointermove',event=>{if(!state||event.pointerId!==state.id)return;
   const dx=event.clientX-state.startX,dy=event.clientY-state.startY;if(Math.hypot(dx,dy)<5&&!moved)return;
   moved=true;onMove(state.x+dx,state.y+dy);event.preventDefault();});
  function finish(event){if(!state||event.pointerId!==state.id)return;state=null;if(moved){onFinish?.();if(target===$('stnHubOpen')){draggedOpener=true;setTimeout(()=>draggedOpener=false,350)}}}
  target.addEventListener('pointerup',finish);target.addEventListener('pointercancel',finish);
 }
 function moveWindow(x,y){placePanel(x,y)}
 function clearPendingOperationsLocally(){
  operationEpoch++;busy=false;unitBatchBusy=false;
  globalThis.NoorCurriculumDiscovery.cancel();
  $('stnHubCurriculumStatus').hidden=true;
  $('stnHubStopCurriculum').hidden=true;
  $('stnHubRefreshTree').disabled=false;
  $('stnHubGenerate').disabled=curriculumScanning()||!keyReady&&$('stnHubService').value!=='grades';
  sessionStorage.setItem(STOP_KEY,crypto.randomUUID());
  for(const key of [TRANSFER_KEY,PREP_TRANSFER_KEY,UNIT_NAV,'stnNoorVerifiedAddNavigation:v1',
   'stnNoorPrepSubmitReceipt:v1','noor_batch','noor_batch_pending','noor_hw_draft','stnScormPublishJob:v1'])
   sessionStorage.removeItem(key);
  resetPreparationReview();
  $('stnHubActivityResumeDate').hidden=true;$('stnHubBatchRetry').hidden=true;
 }
 let stoppingAll=false;
 async function cancelAllOperations(){
  if(stoppingAll)return;
  stoppingAll=true;
  try{
   clearPendingOperationsLocally();
   $('stnHubGenerate').disabled=true;
   await browser.storage.local.set({[STOP_KEY]:crypto.randomUUID()});
   const area=browser.storage.local;
   const keys=(area.getKeys?await area.getKeys():Object.keys(await area.get(null))).filter(key=>
    key==='noorSmartRunV1'||key===UNIT_JOB||key.startsWith('stnScormTempZip:v1:')||key.startsWith('stnPendingGrades:'));
   if(keys.length)await area.remove(keys);
   status('أُوقفت العمليات المعلّقة. يمكنك بدء عملية جديدة. ما أُرسل بالفعل إلى نور يبقى في نور.');
  }finally{
   stoppingAll=false;
   $('stnHubGenerate').disabled=curriculumScanning()||!keyReady&&$('stnHubService').value!=='grades';
  }
 }
 const continuingTransfers=new Set();
 async function continueTransfer(service){
  if(continuingTransfers.has(service)||curriculumScanning())return;
  continuingTransfers.add(service);
  try{await resumeTransfer(service);}finally{continuingTransfers.delete(service);}
 }
  async function resumeTransfer(service){
   await selectionReady;
   const p=readTransfer(service);if(!p)return;
   const epoch=operationEpoch;
   // Preparation submits may navigate away before a content-script reply survives.
   // Never interpret a lost reply as a failed save or automatically click again.
   if(p.service==='preparation'&&['submitted','submitting'].includes(p.phase)){
    let receipt=null;try{receipt=JSON.parse(sessionStorage.getItem('stnNoorPrepSubmitReceipt:v1')||'null')}catch(_){}
    const recent=receipt?.phase==='clicked'&&receipt?.teacherId===p.teacherId&&
      String(receipt?.cid||'')===String(p.course?.cid||'')&&Date.now()-receipt.at<15*60*1000;
    const alerts=[...document.querySelectorAll('.alert-success,.toast-success,.swal2-success,[role="alert"].success')]
      .map(el=>el.textContent||'').join(' ').toLowerCase();
    const serverSuccess=recent&&/(?:تحضير|preparation|saved|حفظ|اضاف|نجاح)/i.test(alerts);
    if(serverSuccess){writeTransfer({...p,phase:'confirmed',confirmedAt:Date.now()});
     status('✓ عرض نور رسالة نجاح لحفظ التحضير. لم يتكرر الضغط على الحفظ.');}
    else if(recent)status('تم الضغط على زر حفظ التحضير مرة واحدة في نور، لكن لم تظهر رسالة نجاح يمكن التحقق منها. راجع قائمة التحاضير قبل إنشاء نسخة أخرى.');
    else status('تم تسجيل محاولة الحفظ، ولكن لم يصل تأكيد الضغط من نموذج نور. راجع قائمة التحاضير قبل أي محاولة جديدة.');
    return;
   }
   if(p.phase!=='dashboard'&&p.phase!=='navigate')return;
   if(p.phase==='dashboard'?!lookup.dashboardPage():p.targetPath!==location.pathname)return;
   if(!p.teacherId||p.teacherId!==classTeacherId)throw Error('تغيّر حساب المعلم.');
   const catalog=globalThis.NoorCourseCatalog;
   await catalog.init();
   ensureOperation(epoch);
   if(readTransfer(service)?.id!==p.id) return;
   discover();
   $('stnHubPanel').hidden=false;
   if(!matchesTransfer(selected(),p))throw Error('تغيّر اختيار المعلم منذ بدء الطلب.');
   if(p.phase==='dashboard'){
    for(let attempt=0;attempt<24;attempt++){
     ensureOperation(epoch);
     if(!matchesTransfer(selected(),p))throw Error('تغيّر اختيار المعلم منذ بدء الطلب.');
     const cards=catalog.cards().filter(card=>norm(card.label)===norm(p.course.label));
     const record=catalog.get(p.course.cid);
     if(cards.length===1&&sameCourse({cid:record?.cidNumeric,label:record?.label,grade:record?.grade},p.course)){
      const link=openTarget(p);
      if(!link)break;
      writeTransfer({...p,phase:'navigate',targetPath:new URL(link).pathname});
      status('جارٍ فتح مسار الصف المختار في نور…');location.assign(link);return;
     }
     await new Promise(resolve=>setTimeout(resolve,250));
    }
    throw Error('لم أجد بطاقة الصف المختار في صفحة المعلم.');
   }
   if(service==='preparation'&&/\/teacher\/courses\/preparations_index\//i.test(location.pathname)&&getCid()===p.course.cid){
    let links=[];
    for(let attempt=0;attempt<20&&!links.length;attempt++){
     ensureOperation(epoch);
     links=lookup.addLinks();
     if(!links.length)await new Promise(resolve=>setTimeout(resolve,250));
    }
    if(!matchesTransfer(selected(),p))throw Error('تغيّر اختيار المعلم منذ بدء الطلب.');
    if(links.length!==1)throw Error('تعذّر تأكيد رابط إضافة التحضير للصف المختار.');
    const target=new URL(links[0]);
    const targetCid=target.pathname.match(/\/cid:(\d+)(?:\/|$)/)?.[1];
    if(targetCid&&targetCid!==p.course.cid)throw Error('رابط التحضير يعود إلى صف آخر.');
    sessionStorage.setItem('stnNoorVerifiedAddNavigation:v1',JSON.stringify({
     teacherId:classTeacherId,numericCid:p.course.cid,addURL:target.href,at:Date.now()}));
    writeTransfer({...p,targetPath:target.pathname});location.assign(target.href);return;
   }
   const addProof=(()=>{try{return JSON.parse(sessionStorage.getItem('stnNoorVerifiedAddNavigation:v1')||'null')}catch(_){return null}})();
   const verifiedAdd=p.service==='preparation'&&/\/teacher\/courses\/add_preparation\//i.test(location.pathname)&&
    addProof?.teacherId===p.teacherId&&addProof?.numericCid===p.course?.cid&&addProof?.addURL===location.href&&Date.now()-addProof.at<5*60*1000;
   if(getCid()!==p.course?.cid&&!verifiedAdd){
    writeTransfer({...p,phase:'paused',reason:'رابط الصف مختلف عن الصف الذي بدأت منه'});status('رابط الصف مختلف. لن أبدأ التوليد.');return;
   }
   $('stnHubPanel').hidden=false;
   status('استعادة الصف والوحدة والدرس من الطلب السابق؛ جارٍ التحقق من هوية الصف...');
   if(!matchesTransfer(selected(),p))throw Error('تغيّر اختيار المعلم منذ بدء الطلب.');
   restoreTaskSettings(p);
   await keyStatus();
   if(!keyReady){writeTransfer({...p,phase:'paused',reason:'مفتاح Gemini غير جاهز'});status('مفتاح Gemini غير جاهز. لم أفقد اختيار الصف أو الدرس، ولم أبدأ النشر.');return;}
   ensureOperation(epoch);
   writeTransfer({...p,phase:'running',startedAt:Date.now()});
   // Once running, a subsequent navigation must never restart generation.
   const ok=await generate(p.id);
   if(epoch!==operationEpoch||ok==='navigating')return;
   if(ok){
    const last=readTransfer(service);
    if(service==='activities'&&p.activityScope==='unit')clearTransfer(service);
    else if(!['submitted','review_ready','auto_saving'].includes(last?.phase))writeTransfer({...p,phase:'handed_off',startedAt:Date.now()});
   }
   else{const last=readTransfer(service);
    if(['submitting','submitted','auto_saving'].includes(last?.phase))status('حالة الحفظ غير مؤكدة؛ لا تعاد المحاولة تلقائيًا لتجنب التكرار. تحقق من سجل نور.');
    else writeTransfer({...p,phase:'paused',reason:$('stnHubStatus')?.textContent||'لم يبدأ التنفيذ'});
   }
  }
  function pauseTransfer(service,error){
   const p=readTransfer(service);
   if(!p||!['dashboard','navigate'].includes(p.phase))return;
   writeTransfer({...p,phase:'paused',reason:String(error.message||error)});
   status('توقف: '+String(error.message||error));
  }
 function bind(){
  globalThis.NoorUiLanguage?.bind(root,$('stnHubLanguage'));
  const saved=readPosition();if(saved){if(Number.isFinite(saved.buttonX)&&Number.isFinite(saved.buttonY))placeButton(saved.buttonX,saved.buttonY);if(Number.isFinite(saved.panel?.x)&&Number.isFinite(saved.panel?.y))panelPosition=saved.panel}
  enableDrag($('stnHubOpen'),placeButton,savePosition);
  enableDrag($('stnHubDragHandle'),moveWindow,savePosition);
  $('stnHubResetPosition').addEventListener('click',()=>{try{localStorage.removeItem(POSITION_KEY)}catch(_){}root.style.left='12px';root.style.top='auto';root.style.bottom='14px';panelPosition=null;if(!$('stnHubPanel').hidden)requestAnimationFrame(()=>{const b=$('stnHubOpen').getBoundingClientRect();placePanel(b.left,b.top-$('stnHubPanel').offsetHeight-8)})});
  window.addEventListener('resize',()=>{const r=$('stnHubOpen').getBoundingClientRect();if(root.style.top)placeButton(r.left,r.top);if(!$('stnHubPanel').hidden&&panelPosition)placePanel(panelPosition.x,panelPosition.y)});
  $('stnHubOpen').addEventListener('click',()=>{if(draggedOpener)return;const p=$('stnHubPanel');if(p.hidden)showPanel();else p.hidden=true});
  $('stnHubClose').addEventListener('click',()=>$('stnHubPanel').hidden=true);
  $('stnHubMinimize').addEventListener('click',()=>{const pane=$('stnHubPanel'),mini=pane.classList.toggle('stnHubMinimized');
   $('stnHubMinimize').textContent=mini?'▢':'−';$('stnHubMinimize').setAttribute('aria-expanded',String(!mini));
   if(!mini)requestAnimationFrame(()=>{if(panelPosition)placePanel(panelPosition.x,panelPosition.y)});
  });
  $('stnHubTabContent').addEventListener('click',()=>selectHubTab('content'));
  $('stnHubTabTask').addEventListener('click',()=>selectHubTab('task'));
  for(const [control,children] of [['stnHubActivityScope','stnHubActivityUnitOptions'],['stnHubScormScope','stnHubScormUnitOptions']])
   $(control).addEventListener('change',updateBatchScope);
  const batchDates=[new Date().getFullYear(),String(new Date().getMonth()+1).padStart(2,'0'),String(new Date().getDate()).padStart(2,'0')].join('-');
  $('stnHubScormPublishDate').value=batchDates;

  $('stnHubService').addEventListener('change',()=>{try{sessionStorage.setItem(serviceStorageKey(),$('stnHubService').value)}catch(_){}showStatus()});
  {const d=new Date();$('stnHubPrepDate').value=[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
  // The Firefox native dropdown is destroyed if options are rewritten mid-click.
  // Do not touch its children from MutationObservers until the user finishes.
  classSelect.addEventListener('pointerdown',()=>{classSelectionUntil=Date.now()+1800;});
  classSelect.addEventListener('keydown',()=>{classSelectionUntil=Date.now()+1800;});
  function changeSelection({useCache=false}={}){
   if(curriculumScanning()){
    lookup.cancel();$('stnHubStopCurriculum').hidden=true;$('stnHubRefreshTree').disabled=false;keyStatus();
   }
   persistSelection();
   clearPreview();resetPreparationReview();invalidateGradePreview();
   if(useCache)previewNumberSelection({useCache:true}).catch(()=>{});
  }
  classSelect.addEventListener('change',()=>{
   classSelectionUntil=Date.now()+750;
   updateSubject();
   changeSelection();
  });
  classSelect.addEventListener('blur',()=>{setTimeout(()=>{if(classRefreshPending)discover();},950);});
  for(const id of ['stnHubAssessment','stnHubCsvColumn','stnHubCsvTarget','stnHubCsvOverwrite'])$(id).addEventListener('change',invalidateGradePreview);
  for(const id of ['stnHubUnit','stnHubLesson','stnHubSemester'])$(id).addEventListener('change',()=>{
   const field=$(id),number=position(field.value);
   if(number)field.value=String(number);
   changeSelection({useCache:true});
  });
  $('stnHubStopCurriculum').addEventListener('click',()=>{
   lookup.cancel();
   $('stnHubStopCurriculum').hidden=true;
   $('stnHubRefreshTree').disabled=false;
   keyStatus();curriculumStatus('توقفت قراءة شجرة الصف.');
  });
  $('stnHubRefreshTree').addEventListener('click',async()=>{
   const course=selectedClass(),coordinates=inputs();
   if(!course){curriculumStatus('اختر صفًا من قائمة نور أولًا.');return;}
   if(!coordinates.unitNo||($('stnHubLesson').value&&!coordinates.lessonNo)){
    curriculumStatus('أدخل أرقام الترتيب من 1 فصاعدًا.');return;
   }
   if(!await curriculumAllowed()){curriculumStatus('أنه العملية الجارية قبل قراءة شجرة الصف.');return;}
   if(classValue(course)!==classSelect.value||!samePositions(coordinates,inputs()))return;
   clearPreview();persistSelection({course});resetPreparationReview();
   await curriculum.start({...coordinates,cid:course.cid,label:course.label});
  });
  $('stnHubScormImageMode').addEventListener('change',()=>{try{sessionStorage.setItem('stnNoorScormImageMode:v1',scormImageMode())}catch(_){}});
  try{const mode=sessionStorage.getItem('stnNoorScormImageMode:v1');if(['gemini_svg','gemini_none','svg','none'].includes(mode))$('stnHubScormImageMode').value=mode}catch(_){}
  $('stnHubScormResume').addEventListener('click',()=>globalThis.NoorScormPublisher?.resume?.());
  $('stnHubScormCancel').addEventListener('click',()=>globalThis.NoorScormPublisher?.cancel?.());
  for(const el of $('stnHubScormMode').querySelectorAll('input'))el.addEventListener('change',()=>{try{sessionStorage.setItem('stnNoorScormSaveMode:v1',scormSaveMode())}catch(_){}});
  try{const mode=sessionStorage.getItem('stnNoorScormSaveMode:v1');if(['review','auto'].includes(mode))$('stnHubScormMode').querySelector('input[value="'+mode+'"]').checked=true}catch(_){}
  $('stnHubActivityResumeDate').addEventListener('click',async()=>{
   try{await globalThis.NoorSmartAutomator?.resumeActivityDate?.();await updateActivityResume();}
   catch(e){status(String(e.message||e));}
  });
  $('stnHubGenerate').addEventListener('click',()=>{selectHubTab('task');generate()});
  $('stnHubBatchRetry').addEventListener('click',()=>retryActivityGeneration().catch(e=>status(String(e.message||e))));
  $('stnHubBatchCancel').addEventListener('click',()=>cancelAllOperations().catch(e=>status('تعذر إلغاء العمليات. '+String(e.message||e))));
  for(const radio of $('stnHubPrepSaveMode').querySelectorAll('input'))radio.addEventListener('change',()=>{resetPreparationReview();updatePrepModeChoice()});
  updatePrepModeChoice();
  $('stnHubPrepReview').addEventListener('click',async()=>{
   if(busy)return;
   try{busy=true;await reviewStagedPreparation()}catch(e){$('stnHubPrepAutoSave').disabled=true;status('تعذرت المراجعة: '+String(e.message||e))}finally{busy=false}
  });
  $('stnHubPrepAutoSave').addEventListener('click',async()=>{
   if(busy)return;
   try{busy=true;await saveReviewedPreparation()}catch(e){status('الحفظ غير مؤكد: '+String(e.message||e)+'. لن أعيد الضغط على حفظ لتجنب التكرار.')}finally{busy=false}
  });
  for(const id of ['stnHubClass','stnHubSemester','stnHubUnit','stnHubLesson','stnHubPrepDate','stnHubPeriods'])
   $(id).addEventListener('change',resetPreparationReview);

  $('stnHubImport').addEventListener('click',()=>$('stnHubFile').click());
  $('stnHubImportPublish').addEventListener('click',async()=>{
   if(busy||curriculumScanning())return;
   try{busy=true;const opts=selected();checkContext(opts,true);
    if(opts.service!=='activities'||!isActivityCoursePage(opts.course))throw Error('افتح صفحة المهام الإلكترونية للصف المختار لنشر الأنشطة.');
    const ids=[...$('stnHubImportedItems').querySelectorAll('input:checked')].map(x=>x.value);
    if(!ids.length)throw Error('اختر نشاطًا واحدًا على الأقل.');
    const courseProof={cid:opts.course.cid,label:opts.course.label,grade:opts.course.grade,subject:opts.subject};
    const resolved=await resolveVerifiedLesson(opts,{required:true});
    const info=await globalThis.NoorSmartHub.publishSelection({...opts,unit:resolved.unit,lesson:resolved.title,courseProof,ids,lessonNodeId:resolved.lessonId});status('بدأ إدراج '+ids.length+' نشاطًا محددًا فقط في نور. '+info);
   }catch(e){status('توقف النشر: '+String(e.message||e));}finally{busy=false;}
  });
  $('stnHubScormPackage').addEventListener('change',syncScormImport);
  $('stnHubScormFill').addEventListener('click',async()=>{
   const choice=$('stnHubScormPackage').value;
   if(busy||curriculumScanning()||choice===''||!importedScorm[Number(choice)])return;
   busy=true;syncScormImport();
   try{await fillImportedScorm(importedScorm[Number(choice)]);}
   catch(e){status('تعذرت تعبئة SCORM. '+String(e.message||e));}
   finally{busy=false;syncScormImport();}
  });
  $('stnHubFile').addEventListener('change',async()=>{
   const files=[...($('stnHubFile').files||[])];$('stnHubFile').value='';
   if(busy||curriculumScanning()||!files.length)return;
   const service=$('stnHubService').value;
   try{
    busy=true;
    if(service==='scorm'){
     await importScorm(files);
     return;
    }
    if((service==='grades'||service==='preparation')&&files.length!==1)throw Error('اختر ملفًا واحدًا للدرجات أو التحضير في كل عملية');
    for(const file of files){status('جارٍ استيراد '+file.name+' ...');await importFile(file);}
   }catch(e){status('تعذر الاستيراد: '+String(e.message||e));}
   finally{busy=false;syncScormImport();}
  });
  $('stnHubCreateKey').addEventListener('click',()=>window.open('https://aistudio.google.com/api-keys','_blank','noopener,noreferrer'));
  $('stnHubSaveKey').addEventListener('click',async()=>{
   let text=$('stnHubKey').value.trim();if(!text){try{text=await navigator.clipboard.readText()}catch(_){}}
   if(!text){status('ألصق المفتاح في الحقل ثم اضغط «لصق وحفظ».');return}
   status('جارٍ اختبار مفتاح Gemini مباشرة مع Google...');
   const res=await browser.runtime.sendMessage({type:'NOOR_HUB_SAVE_KEY',apiKey:text});$('stnHubKey').value='';
   if(!res?.ok){status(res?.error||'فشل اختبار المفتاح');return}
   keyReady=true;$('stnHubKeyBox').hidden=true;$('stnHubGenerate').disabled=false;status('✓ مفتاح Gemini محفوظ لهذا المعلم، ويعمل للتحضير والأنشطة وSCORM.');
  });
  window.addEventListener('stnCourseCatalogChanged',()=>{if(classFocusHeld())classRefreshPending=true;else syncClassOptions();});
  const observer=new MutationObserver(ms=>{
   if(ms.every(m=>root.contains(m.target)))return;
   clearTimeout(observer.timer);observer.timer=setTimeout(()=>discover(),450);
  });observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','aria-selected']});
  let last=location.href;setInterval(()=>{if(last!==location.href){last=location.href;discover();}},{interval:1500}.interval);
  selectionReady=Promise.resolve(globalThis.NOOR_TEACHER_PROFILE?.active?.())
   .then(restoreSelection).then(()=>curriculum.resume()).catch(()=>{});
  discover();showStatus();
  setTimeout(()=>{if(curriculumScanning())return;checkUnitBatch().catch(e=>status('تعذر استئناف الوحدة: '+String(e.message||e)))},1750);
  setTimeout(()=>{
   if(curriculumScanning())return;
   for(const service of ['activities','preparation'])continueTransfer(service).catch(error=>pauseTransfer(service,error));
  },350);
  window.addEventListener('stnNoorScormConfirmed',()=>checkUnitBatch().catch(()=>{}));
  browser.storage.onChanged.addListener((change,area)=>{
   if(area==='local'&&change[STOP_KEY]?.newValue&&!stoppingAll)clearPendingOperationsLocally();
   if(area==='local'&&classTeacherId&&change['stnGrades:'+classTeacherId]?.newValue){
     const bank=change['stnGrades:'+classTeacherId].newValue;
     $('stnHubService').value='grades';try{sessionStorage.setItem(serviceStorageKey(),'grades')}catch(_){}showStatus();
     status('وصلت درجات دفتر المعلم للصف '+(bank.className||'غير معروف')+'. جاري التحقق من رابط درجات هذا الصف قبل التعبئة؛ الحفظ النهائي يتطلب مراجعة.');
   }
   if(area==='local'&&change.noorSmartRunV1?.newValue){const job=change.noorSmartRunV1.newValue;if(job?.message)status(job.message);updateActivityResume(job).catch(()=>{});
    if(job?.stage==='done'||job?.stage==='paused')setTimeout(()=>checkUnitBatch().catch(()=>{}),550);
    const p=readTransfer('activities');if(p?.phase==='handed_off'&&job?.stage==='done'&&String(job.cid)===String(p.course.cid))clearTransfer('activities');
   }
   if(area==='local'&&change.stnActiveTeacherId){lookup.cancel();keyReady=false;selectionReady=restoreSelection(change.stnActiveTeacherId.newValue).catch(()=>{});}
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{document.body.append(root);bind()},{once:true});else{document.body.append(root);bind()}
})();
