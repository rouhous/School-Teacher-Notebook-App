/* Noor Unified Pipeline 2.8.28.
 * Explicitly requested three-in-one / unit / term automation with persisted
 * per-teacher stages. Never guesses a course ID or retries a save after click.
 * Fails closed until Noor confirms the previous operation. */
(function(root){'use strict';
 if(window.top!==window || !/^\/teacher(?:\/|$)/i.test(location.pathname))return;
 const $=id=>document.getElementById(id);
 const path=()=>location.pathname;
 const clean=(v,max=200)=>String(v??'').replace(/\s+/g,' ').trim().slice(0,max);
 const norm=v=>clean(v).normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[إأآ]/g,'ا').toLowerCase();
 const delay=t=>new Promise(r=>setTimeout(r,t));
 const cid=()=>decodeURIComponent(path().match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
 const dateOK=s=>/^\d{4}-\d{2}-\d{2}$/.test(s)&&!Number.isNaN(Date.parse(s+'T12:00:00'));
 const today=()=>{const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-')};
 const schoolDays=(start,count)=>{const a=[],d=new Date(start+'T12:00:00');for(let k=0;a.length<count&&k<400;k++){const dt=new Date(d);dt.setDate(d.getDate()+k);if(![5,6].includes(dt.getDay()))a.push([dt.getFullYear(),String(dt.getMonth()+1).padStart(2,'0'),String(dt.getDate()).padStart(2,'0')].join('-'))}return a};
 const jobKey=id=>'stnPipelineJob:'+id,treeKey=(id,c)=>'stnCurriculum:'+id+':'+c;
 let teacher='',job=null,busy=false,files=[],catalog=[],awaitingSelection=false;
 function status(t){const node=$('stnHubStatus');if(node)node.textContent=String(t||'');}
 function findClass(){const h=$('stnHubClass');if(!h)return null;const value=h.value;const found=catalog.find(x=>value===x.cidNumeric+'|'+x.label||value===x.label||value===x.cidNumeric+'|'+x.label);
  const opt=[...h.options].find(o=>o.value===value);if(found)return found;
  if(opt){const grade=root.NoorCourseCatalog?.gradeOf(opt.textContent);const numeric=value.split('|')[0];if(/^\d+$/.test(numeric)&&grade)return {label:clean(opt.textContent),grade,cidNumeric:numeric,routes:{preparation:location.origin+'/teacher/courses/preparations_index/cid:'+encodeURIComponent(numeric)}};}
  return null;
 }
 function refreshCourses(){catalog=root.NoorCourseCatalog?.all?.()||[];
  const sel=$('stnHubClass');if(!sel)return;
  const original=sel.value;
  for(const c of catalog){const val=c.cidNumeric?c.cidNumeric+'|'+c.label:'pending|'+c.label;
   if(![...sel.options].some(o=>o.value===val))sel.append(new Option(c.cidNumeric?c.label:c.label+' — افتح بطاقة الصف في نور',val));}
  if(original&&[...sel.options].some(o=>o.value===original))sel.value=original;
  else if(cid()&&[...sel.options].some(o=>o.value.startsWith(cid()+'|')))sel.value=[...sel.options].find(o=>o.value.startsWith(cid()+'|')).value;
 }
 function currentCourse(){const h=findClass();if(!h?.cidNumeric||!/^\d+$/.test(h.cidNumeric)||!h.grade)throw Error('تم عرض الصف من الصفحة الرئيسية لكن لم يظهر رابط الصف الرسمي بعد. اضغط بطاقة الصف في نور، ثم اختر «تحضير الدروس» مرة واحدة لاكتشاف معرّفه.');return h}
 function sourceTree(c){return root.NoorPrepBridge2828?.curriculum?.()}
 function selectLessons(tree,opts){
  const termOf=u=>/الثاني|second|term\s*2|semester\s*2/i.test(u.term||'')?'2':/الأول|الاول|first|term\s*1|semester\s*1/i.test(u.term||'')?'1':'';
  const units=(tree||[]).filter(x=>!termOf(x)||termOf(x)===opts.semester);
  const u=opts.unit?units.filter(x=>norm(x.unit)===norm(opts.unit)):units;
  if(opts.scope==='lesson'&&u.length!==1)throw Error('اختر وحدة واحدة معروفة من شجرة نور.');
  if(opts.scope==='unit'&&u.length!==1)throw Error('لم أجد وحدة واحدة مطابقة بالضبط؛ اختر اسم الوحدة من القائمة.');
  if(opts.scope==='semester'&&u.length===0)throw Error('شجرة نور لا تحتوي دروس الفصل المحدد.');
  const rows=[];
  for(const unit of u){
   const sem=/الثاني|second|term\s*2|semester\s*2/i.test(unit.term)?'2':/الأول|الاول|first|term\s*1|semester\s*1/i.test(unit.term)?'1':'';
   if(opts.scope==='semester'&&sem&&opts.semester!==sem)continue;
   for(const l of (unit.lessons||[])){
    if(opts.scope==='lesson'&&norm(l.title)!==norm(opts.lesson))continue;
    if(!unit.termId||!unit.unitId||!l.id||!String(l.title||'').trim())throw Error('شجرة نور تحتوي درسًا دون معرف أصلي، أوقفت العملية.');
    rows.push({termId:unit.termId,unitId:unit.unitId,lessonId:l.id,unit:unit.unit,title:l.title,semester:sem||opts.semester});
   }
  }
  if(!rows.length)throw Error('لم أعثر على دروس مطابقة للنطاق المختار في شجرة نور.');
  if(rows.length>80)throw Error('الدفعة أكثر من 80 درسًا. قسّم الفصل إلى وحدات أصغر.');
  if(new Set(rows.map(l=>l.lessonId)).size!==rows.length)throw Error('معرّفات الدروس مكررة في الشجرة، أوقف التشغيل.');
  return rows;
 }
 async function storedTree(c){const v=(await browser.storage.local.get(treeKey(teacher,c.cidNumeric)))[treeKey(teacher,c.cidNumeric)];return Array.isArray(v?.units)&&Date.now()-v.capturedAt<7*86400000?v.units:null}
 function setCurriculumUI(units){
  const u=$('stnHubUnitList'),l=$('stnHubLessonList');if(!u||!l)return;
  const names=[...new Set(units.map(x=>x.unit).filter(Boolean))];u.replaceChildren(...names.map(s=>new Option(s,s)));
  function update(){const selected=norm($('stnHubUnit')?.value);let lessons=units.filter(x=>norm(x.unit)===selected).flatMap(x=>x.lessons||[]).map(x=>x.title);
   if(!selected)lessons=units.flatMap(x=>x.lessons||[]).map(x=>x.title);
   l.replaceChildren(...[...new Set(lessons)].map(s=>new Option(s,s)));
  }
  update();
 }
 async function refreshCurriculum(){const c=findClass();if(!c?.cidNumeric)return;
  const units=await storedTree(c);if(units)setCurriculumUI(units);
 }
 async function loadCurriculum(){
  const c=currentCourse();
  if(!root.NoorPrepBridge2828?.onAddPage?.() || cid()!==c.cidNumeric){
   if(!confirm('سنفتح محرر تحضير الصف المختار لقراءة الوحدات والدروس الرسمية من شجرة نور. متابعة؟'))return;
   sessionStorage.setItem('stnPipelineOpenCatalog',JSON.stringify({cid:c.cidNumeric,time:Date.now()}));
   location.assign(location.origin+'/teacher/courses/preparations_index/cid:'+encodeURIComponent(c.cidNumeric));return;
  }
  status('أقرأ وحدات ودروس الصف من شجرة نور الرسمية...');
  const units=await sourceTree(c);
  await browser.storage.local.set({[treeKey(teacher,c.cidNumeric)]:{capturedAt:Date.now(),units}});
  setCurriculumUI(units);status('تم اكتشاف '+units.length+' وحدات من الصف '+c.label+'. اختر الوحدة والدرس أو نطاق الوحدة/الفصل.');
 }
 const keyReady=async()=>{const r=await browser.runtime.sendMessage({type:'NOOR_HUB_KEY_STATUS'});return Boolean(r?.ok&&r.ready)};
 async function parseFiles(incoming){
  const imported={preparations:[],activities:[],scorm:[]};
  for(const file of incoming){
   if(file.size>12*1024*1024)throw Error('ملف أكبر من 12 ميغابايت؛ قسّمه إلى ملفات أصغر.');
   const name=file.name.toLowerCase();
   if(/\.(pdf|docx|txt)$/.test(name)){
    const parsed=await root.NoorPrepBridge2828?.parseFile?.(file);
    if(!parsed?.length)throw Error('تعذر قراءة دروس الملف: '+file.name);
    imported.preparations.push(...parsed);
   }else if(name.endsWith('.json')){
    const raw=JSON.parse(await file.text());
    if(raw?.preparation&&raw?.activity&&raw?.scorm){imported.preparations.push({unit:raw.unit, name:raw.lesson,...raw.preparation});imported.activities.push({unit:raw.unit,lesson:raw.lesson,...raw.activity});imported.scorm.push({unit:raw.unit,lesson:raw.lesson,...raw.scorm})}
    else if(Array.isArray(raw.lessons))for(const item of raw.lessons){
      if(item.preparation)imported.preparations.push({unit:item.unit,name:item.lesson,...item.preparation});
      if(item.activity)imported.activities.push({unit:item.unit,lesson:item.lesson,...item.activity});
      if(item.scorm)imported.scorm.push({unit:item.unit,lesson:item.lesson,...item.scorm});
    }else if(Array.isArray(raw.questions)){
      imported.activities.push({...raw,unit:raw.unit||$('stnHubUnit').value,lesson:raw.lesson||$('stnHubLesson').value});
    }else throw Error('JSON غير معروف. استخدم سجل الدروس أو الأنشطة أو حزمة ثلاثية.');
   }else if(name.endsWith('.zip')){
    const data=new Uint8Array(await file.arrayBuffer());if(data.length>1_500_000||!root.NoorScorm?.hasManifest(data.buffer))throw Error('SCORM غير صالح أو حجمه كبير.');
    // Retain the uploaded SCORM archive in teacher-scoped browser storage across navigation.
    let data64='';for(let i=0;i<data.length;i+=8192)data64+=String.fromCharCode(...data.subarray(i,i+8192));
    imported.scorm.push({unit:$('stnHubUnit').value,lesson:$('stnHubLesson').value,name:file.name,zipBase64:btoa(data64)});
   }else throw Error('نوع الملف غير مدعوم: '+file.name);
  }
  files=imported;status('تم تحليل '+imported.preparations.length+' تحضير، '+imported.activities.length+' نشاط، '+imported.scorm.length+' ملف SCORM. اختر النطاق ثم ابدأ.');
 }
 function optionsFromUI(){const course=currentCourse();const scope=$('stnPipeScope').value,semester=$('stnHubSemester').value,unit=clean($('stnHubUnit').value,160),lesson=clean($('stnHubLesson').value,160);
  if(!['lesson','unit','semester'].includes(scope))throw Error('نطاق غير صحيح.');
  if(scope!=='semester'&&!unit)throw Error('اختر الوحدة من شجرة نور أولًا.');
  if(scope==='lesson'&&!lesson)throw Error('اختر الدرس من شجرة نور.');
  const date=$('stnPipeStartDate').value;
  if(!dateOK(date))throw Error('اختر تاريخ نشر صالحًا.');
  const periods=Number($('stnPipePeriods').value);
  if(!Number.isInteger(periods)||periods<1||periods>12)throw Error('عدد الحصص لكل درس يجب أن يكون 1 إلى 12.');
  return {course,scope,semester,unit,lesson,date,periods,count:Number($('stnHubCount')?.value)||6};
 }
 async function saveJob(next){if(!teacher||next.teacherId!==teacher)throw Error('تغيّر حساب المعلم.');next.updatedAt=Date.now();job=next;await browser.storage.local.set({[jobKey(teacher)]:job});status(`${job.index+1}/${job.lessons.length} · ${job.stage}: ${job.message||''}`);return job}
 async function pause(reason){if(!job)return;await saveJob({...job,stage:'paused',pausedFrom:job.stage,message:String(reason).slice(0,400)});status('توقفت العملية بأمان: '+reason+'\nيمكن استئنافها من المرحلة نفسها بعد تصحيح المشكلة.');}
 function locationCourseVerified(c,service){if(!c||!c.cidNumeric)return false;
  if(service==='preparation'||service==='activities')return cid()===c.cidNumeric;
  const official=c.routes?.scorm;return service==='scorm'&&official&&new URL(official).pathname.match(/cid:([^/]+)/)?.[1]===cid();
 }
 function urlFor(course,service){const numeric=course.cidNumeric;if(!/^\d+$/.test(numeric||''))return null;
  if(service==='preparation')return location.origin+'/teacher/courses/preparations_index/cid:'+encodeURIComponent(numeric);
  if(service==='activities')return location.origin+'/teacher/homeworks/index/cid:'+encodeURIComponent(numeric);
  if(service==='scorm'){const u=course.routes?.scorm;try{const v=new URL(u);if(v.origin===location.origin&&/\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(v.pathname))return v.href}catch(_){ }return null}
  return null;
 }
 function checkCourse(){const c=job.course;
  if(!c?.cidNumeric||!c.grade||!/^\d+$/.test(c.cidNumeric))throw Error('الصف غير متحقق من نور.');
  if(teacher!==job.teacherId)throw Error('تغيّر حساب المعلم منذ بدء الدفعة.');
 }
 function item(){return job.lessons[job.index]}
 function normalizedDateForItem(i){const slots=schoolDays(job.date,Math.max((i+1)*job.periods,1));return slots[i*job.periods]||'';}
 function importedFor(l){const same=(a,b)=>norm(a)===norm(b);
  const lessonNumber=s=>clean(s).match(/(?:lesson|درس|plan|^)(?:\s*plan)?\s*[:#-]?\s*(\d{1,2})(?:\b|\s|$)/i)?.[1]||'';
  const one=(list,lessonKeys)=>list.filter(r=>same(r.unit,l.unit)&&lessonKeys.some(k=>same(r[k],l.title)||(lessonNumber(r[k])&&lessonNumber(r[k])===lessonNumber(l.title))));
  const prep=one(job.imported.preparations,['name','lesson','title']);const activity=one(job.imported.activities,['lesson','name']);const scorm=one(job.imported.scorm,['lesson','name']);
  if([prep,activity,scorm].some(a=>a.length>1))throw Error('الملف يحتوي أكثر من عنصر للدرس '+l.title+'؛ لا أختار أحدها عشوائيًا.');
  return {prep:prep[0]||null,activity:activity[0]||null,scorm:scorm[0]||null};
 }
 async function begin(source){if(job&&job.stage!=='done'&&job.stage!=='cancelled')throw Error('هناك عملية غير مكتملة. استأنفها أو ألغِها أولًا.');
  const o=optionsFromUI();let units=await storedTree(o.course);
  if(!units&&root.NoorPrepBridge2828?.onAddPage?.()&&cid()===o.course.cidNumeric){units=await sourceTree(o.course);await browser.storage.local.set({[treeKey(teacher,o.course.cidNumeric)]:{units,capturedAt:Date.now()}})}
  if(!units?.length)throw Error('حمّل شجرة نور الرسمية للصف بالزر «اكتشاف الوحدات والدروس» أولًا.');
  const lessons=selectLessons(units,o);
  if(source==='gemini'&&!(await keyReady()))throw Error('مفتاح Gemini الشخصي غير محفوظ.');
  if(source==='file'&&!files.preparations?.length&&!files.activities?.length&&!files.scorm?.length)throw Error('استورد محتوياتك أولًا.');
  // Do not let an abandoned legacy preparation batch run concurrently.
  for(const old of ['noor_batch','noor_batch_pending'])try{if(sessionStorage.getItem(old))throw Error('هناك دفعة تحضير قديمة لم تُنهَ في نفس التبويب. أكملها أو ألغِها قبل البدء.')}catch(e){if(e?.message?.includes('دفعة'))throw e}
  if(!confirm(`سيبدأ إعداد ونشر ${lessons.length} درسًا ضمن الصف ${o.course.label}، مع التحضير والأنشطة وSCORM.\nالتاريخ: ${o.date} والحصص لكل درس: ${o.periods}.\nستُنقر أزرار الحفظ الرسمية آليًا بعد التحقق من الصفحة. المتابعة؟`))return;
  const state={id:crypto.randomUUID(),teacherId:teacher,course:o.course,scope:o.scope,semester:o.semester,unit:o.unit,lesson:o.lesson,
    date:o.date,periods:o.periods,count:o.count,source,imported:source==='file'?files:{preparations:[],activities:[],scorm:[]},
    lessons,index:0,stage:'generate',message:'جارٍ إنشاء موارد الدرس الأول',bundle:null,results:[],createdAt:Date.now(),updatedAt:Date.now()};
  await saveJob(state);await step();
 }
 async function runGenerate(){const l=item();const found=importedFor(l);
  const needGemini=job.source==='gemini'||!found.prep||!found.activity||!found.scorm;
  if(needGemini&&!(await keyReady()))throw Error('هناك موارد ناقصة في الملفات؛ مطلوب Gemini لإنشائها، لكن المفتاح غير محفوظ.');
  let generated=null;
  if(needGemini){status('Gemini: إنشاء تحضير ونشاط وSCORM للدرس '+l.title+' ...');
    const res=await browser.runtime.sendMessage({type:'NOOR_PIPELINE_GENERATE_BUNDLE',teacherId:teacher,grade:job.course.grade,semester:job.semester,unit:l.unit,lesson:l.title,count:job.count});
    if(!res?.ok)throw Error(res?.error||'فشل Gemini');generated=res.bundle;
  }
  const bundle={preparation:found.prep||generated?.preparation,activity:found.activity||generated?.activity,scorm:found.scorm||generated?.scorm};
  if(!bundle.preparation||!bundle.activity||!bundle.scorm)throw Error('بعض موارد الدرس الثلاثة غير متوفرة.');
  await saveJob({...job,bundle,stage:'open_preparation',message:'تم تجهيز الموارد الثلاثة. جارٍ فتح التحضير.'});
 }
 async function openPreparation(){checkCourse();
  const target=urlFor(job.course,'preparation');if(!target)throw Error('رابط التحضير غير معروف.');
  if(!locationCourseVerified(job.course,'preparation')){location.assign(target);return}
  const bridge=root.NoorPrepBridge2828;
  if(!bridge?.onAddPage?.()){const found=bridge?.findAddPage?.();
    if(found){const u=new URL(found,location.href);if(u.origin!==location.origin||!u.pathname.includes('add_preparation'))throw Error('رابط إضافة التحضير غير معتمد.');location.assign(u.href);return}
    const go=await bridge?.openAddPage?.();if(!go)throw Error('لم أعثر على نموذج إضافة التحضير لهذا الصف.');return;
  }
  const l=item();const current=await bridge.curriculum();const matching=current.filter(u=>String(u.unitId)===String(l.unitId)&&String(u.termId)===String(l.termId));
  if(matching.length!==1||!matching[0].lessons.some(z=>String(z.id)===String(l.lessonId)&&norm(z.title)===norm(l.title)))throw Error('شجرة نور الحالية لا تطابق درس الخطة؛ لا يمكن الحفظ.');
  const staged=await bridge.stagePreparation(l,job.bundle.preparation,{startDate:normalizedDateForItem(job.index),periods:job.periods});
  await saveJob({...job,currentDate:staged.scheduledDate,stage:'verify_preparation',submittedAt:Date.now(),message:'أرسلت التحضير لنور، جارٍ التحقق من نجاح الحفظ'});
  await bridge.submitPreparation();
 }
 const validationText=()=>clean((document.querySelector('main')||document.body).textContent,15000);
 function saveAcknowledged(name){const text=validationText();
  const success=/تم\s*(?:الحفظ|الإضافة|النشر|التعديل)\s*بنجاح|saved\s+successfully|successfully\s+saved/i.test(text);
  const row=[...document.querySelectorAll('table tbody tr,.preparation-list li')].some(x=>norm(x.textContent).includes(norm(name)));
  const error=/خطأ\s*في\s*الحفظ|حدث\s*خطأ|validation\s+error/i.test(text);
  return !error&&(success||row);
 }
 async function verifyPreparation(){if(saveAcknowledged(item().title)){
   await saveJob({...job,stage:'open_activities',message:'تحضير الدرس محفوظ ومؤكد. جارٍ إنشاء النشاط.'});return;
  }
  if(Date.now()-(job.submittedAt||0)<15000)return;
  throw Error('لم أجد دليلًا على نجاح حفظ التحضير في نور. لن أعيد الضغط منعًا للتكرار.');
 }
 async function openActivities(){const target=urlFor(job.course,'activities');if(!target)throw Error('رابط الأنشطة للصف غير موجود.');
  if(!locationCourseVerified(job.course,'activities')){location.assign(target);return}
  if(!/^\/teacher\/homeworks(?:\/|$)/i.test(path()))throw Error('هذه ليست صفحة المهام الإلكترونية للصف المحدد.');
  if(!root.NoorSmartHub?.importFile||!root.NoorSmartHub?.publish)throw Error('محرك أنشطة نور لم يكتمل تحميله.');
  const l=item();const questions=job.bundle.activity.questions;
  if(!Array.isArray(questions)||!questions.length)throw Error('نشاط الدرس دون مفردات.');
  const json={title:job.bundle.activity.title+' — '+l.title,grade:String(job.course.grade),subject:'English',unit:l.unit,lesson:l.title,questions};
  const file=new File([JSON.stringify(json)],'noor-pipeline-'+job.id+'-'+job.index+'.json',{type:'application/json'});
  const currentActivity=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  if(currentActivity?.active)throw Error('يوجد نشاط آخر جارٍ في نور. أوقفه أو أكمله أولًا.');
  const outcome=await root.NoorSmartHub.importFile(file,{unit:l.unit,lesson:l.title,count:job.count});
  if(!outcome||outcome.items!==1)throw Error('توقع نشاط واحد لهذا الدرس؛ وجدت '+outcome?.items+'.');
  await saveJob({...job,stage:'await_activities',activityStartedAt:Date.now(),message:'بدأ إدراج مفردات النشاط والحفظ في نور'});
  await root.NoorSmartHub.publish({unit:l.unit,lesson:l.title,publishDate:job.currentDate||normalizedDateForItem(job.index)});
 }
 async function waitActivities(){const j=(await browser.storage.local.get('noorSmartRunV1')).noorSmartRunV1;
  if(!j||j.stage==='paused'||!j.active&&j.stage!=='done')throw Error('محرك الأنشطة لم يؤكد النشر: '+(j?.message||'لم يبدأ'));
  if(j.stage==='done'&&!j.active){await saveJob({...job,stage:'open_scorm',message:'تم نشر النشاط. جارٍ رفع الدرس التفاعلي.'});return}
  if(Date.now()-(job.activityStartedAt||0)>20*60000)throw Error('لم يؤكد نور إكمال النشاط خلال 20 دقيقة. يمكن الاستئناف بعد التحقق.');
 }
 async function openScorm(){
  const target=urlFor(job.course,'scorm');
  if(!target)throw Error('لم يُكتشف رابط SCORM لهذا الصف من قائمة المواد في نور. افتح «المكتبة الرقمية ← الدروس التفاعلية» لهذا الصف مرة واحدة، ثم استأنف العملية. لا يمكن اختراع معرفات CID/TID.');
  if(!locationCourseVerified(job.course,'scorm')){location.assign(target);return}
  if(!/\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(path()))throw Error('صفحة SCORM الحالية ليست صفحة الصف المؤكد.');
  if(!/\/upload\/Scorm/i.test(path())){
   const actions=[...document.querySelectorAll('a[href],button')].filter(e=>/رفع درس تفاعلي جديد|رفع\s*درس\s*تفاعلي|New\s*interactive\s*lesson/i.test(clean(e.textContent)));
   if(actions.length!==1)throw Error('لم أعثر على زر واحد لرفع درس تفاعلي جديد.');
   await saveJob({...job,stage:'open_scorm',message:'فتح نموذج SCORM الرسمي'});
   actions[0].click();return;
  }
  await fillScorm();
 }
 function uniqueByHint(selector,hints){const fields=[...document.querySelectorAll(selector)].filter(x=>!x.disabled&&!x.closest('#stnNoorHub'));const re=new RegExp(hints,'i');const filtered=fields.filter(el=>re.test([el.id,el.name,el.placeholder,el.getAttribute('aria-label'),el.closest('.form-group,.row,.input')?.querySelector('label')?.textContent].join(' ')));
  return filtered.length===1?filtered[0]:null;
 }
 function setInput(input,value){const proto=input instanceof HTMLTextAreaElement?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
  if(setter)setter.call(input,value);else input.value=value;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
 }
 async function fillScorm(){const l=item(),bundle=job.bundle.scorm;
  const verified=urlFor(job.course,'scorm');if(!verified||!locationCourseVerified(job.course,'scorm'))throw Error('لا يمكن ربط نموذج SCORM بالصف بدون معرفه الرسمي.');
  const title=uniqueByHint('input[type=text],input:not([type]),textarea','العنوان|title');
  if(!title)throw Error('حقل عنوان SCORM غير مؤكد.');
  const name=clean(bundle.title||l.title,130);setInput(title,name);
  if(!bundle.zipBase64&&!Array.isArray(bundle.questions))throw Error('لا يوجد ملف SCORM صالح.');
  let archive;
  if(bundle.zipBase64){const str=atob(bundle.zipBase64);const data=Uint8Array.from(str,c=>c.charCodeAt(0));archive=new Blob([data],{type:'application/zip'});}
  else archive=root.NoorScorm?.create(name,bundle.questions);
  if(!archive||archive.size<350)throw Error('فشل إنشاء حزمة SCORM.');
  const input=uniqueByHint('input[type=file]','scorm|zip|upload|ارفاق\s*ملف|اختر\s*ملفا')||(()=>{const all=[...document.querySelectorAll('input[type=file]')].filter(el=>!el.disabled);return all.length===1?all[0]:null})();
  if(!input)throw Error('حقل رفع SCORM غير محدد؛ ربما توجد حقول أخرى لصورة الغلاف.');
  const file=new File([archive],'Noor-'+job.id.slice(0,8)+'-Lesson-'+(job.index+1)+'.zip',{type:'application/zip'});
  const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));
  if(!input.files?.length)throw Error('لم يقبل المتصفح إرفاق ملف SCORM.');
  const type=[...document.querySelectorAll('input[type=radio]')].filter(e=>/scorm/i.test([e.value,e.name,e.closest('label')?.textContent,e.parentElement?.textContent].join(' ')));
  if(type.length!==1)throw Error('خيار نوع الدرس SCORM غير مؤكد.');type[0].click();
  const date=uniqueByHint('input[type=date],input[type=text]','publish|date|تاريخ\s*النشر');
  if(!date)throw Error('لم أتعرف على تاريخ نشر SCORM.');const publishDate=job.currentDate||normalizedDateForItem(job.index);setInput(date,publishDate);
  if(date.value!==publishDate)throw Error('رفض نور تاريخ نشر SCORM.');
  // Class publishing is required. Never publish to all students without a verified class choice.
  const classMode=[...document.querySelectorAll('input[type=radio],button')].filter(e=>/نشر\s*لفصول|نشر\s*للفصول/i.test(clean([e.getAttribute('aria-label'),e.parentElement?.textContent].join(' '))));
  if(classMode.length!==1)throw Error('خيار «نشر لفصول» لم يُحدّد بدقة.');classMode[0].click();await delay(300);
  const classCheckboxes=[...document.querySelectorAll('input[type=checkbox]')].filter(x=>!x.disabled&&x.offsetParent!==null);
  const desired=norm(job.course.label),matched=classCheckboxes.filter(x=>{const label=norm(x.closest('label')?.textContent||x.parentElement?.textContent||'');return label===desired||desired.includes(label)&&label.length>6;});
  if(matched.length!==1)throw Error('لا يمكن تأكيد خانة فصل SCORM (يجب أن تتطابق مع الصف المختار دون تخمين).');
  matched[0].checked=true;matched[0].dispatchEvent(new Event('change',{bubbles:true}));
  const upload=[...document.querySelectorAll('button,input[type=submit]')].filter(x=>!x.disabled&&/^(?:رفع|upload|publish)$/i.test(clean(x.textContent||x.value)));
  if(upload.length!==1)throw Error('لم أجد زر رفع واحدًا مؤكدًا في SCORM.');
  await saveJob({...job,stage:'verify_scorm',submittedAt:Date.now(),scormTitle:name,message:'ملف SCORM مرفق ونُقر زر الرفع الرسمي؛ جارٍ التحقق'});
  upload[0].click();
 }
 async function verifyScorm(){if(saveAcknowledged(job.scormTitle||item().title)){
   const results=job.results.slice();results.push({lesson:item().title,unit:item().unit,date:job.currentDate||normalizedDateForItem(job.index),services:['preparation','activities','scorm'],status:'confirmed'});
   const next=job.index+1,done=next>=job.lessons.length;
   await saveJob({...job,results,index:next,stage:done?'done':'generate',bundle:null,currentDate:null,message:done?'اكتمل نشر الموارد الثلاثة لجميع الدروس':'تم تأكيد SCORM، جارٍ تجهيز الدرس التالي'});
   return;
  }
  if(Date.now()-(job.submittedAt||0)<16000)return;
  throw Error('لم تظهر رسالة نجاح أو سجل المساق التفاعلي بعد الرفع. لن أكرر الإرسال.');
 }
 async function step(){if(busy||!job||['paused','cancelled','done'].includes(job.stage))return;
  busy=true;
  try{if(teacher!==job.teacherId)throw Error('حساب المعلم تغيّر.');
   switch(job.stage){
    case 'generate':await runGenerate();break;
    case 'open_preparation':await openPreparation();break;
    case 'verify_preparation':await verifyPreparation();break;
    case 'open_activities':await openActivities();break;
    case 'await_activities':await waitActivities();break;
    case 'open_scorm':await openScorm();break;
    case 'verify_scorm':await verifyScorm();break;
    default:throw Error('مرحلة العملية غير معروفة: '+job.stage);
   }
  }catch(e){await pause(e?.message||String(e))}
  finally{busy=false}
 }
 async function resume(){if(!job||job.stage!=='paused')return;const previous=job.pausedFrom;
  if(!previous)throw Error('لا يوجد مسار استئناف واضح.');
  // Saves are NOT re-issued after a click; resume verification only.
  if(['verify_preparation','verify_scorm'].includes(previous)||previous==='await_activities'){
   await saveJob({...job,stage:previous,submittedAt:previous==='verify_preparation'||previous==='verify_scorm'?Date.now():job.submittedAt});
  }else if(['generate','open_preparation','open_activities','open_scorm'].includes(previous))await saveJob({...job,stage:previous});
  else throw Error('لا يمكن استئناف مرحلة غير معروفة.');
  step();
 }
 async function cancel(){if(!job)return;if(!confirm('هل تريد إيقاف الدفعة؟ المحتوى المنشور سابقًا لن يُحذف.'))return;
  await saveJob({...job,stage:'cancelled',message:'توقفت بطلب المعلم. تفاصيل المنجزات محفوظة.'});
 }
 function ui(){const panel=$('stnHubPanel');if(!panel||$('stnPipeSection'))return;
  const service=$('stnHubService');if(![...service.options].some(x=>x.value==='bundle'))service.prepend(new Option('✨ التحضير + النشاط + SCORM معًا','bundle'));
  service.value='bundle';
  const oldActions=$('stnHubLegacyActions');if(oldActions)oldActions.hidden=true;
  const wrap=document.createElement('div');wrap.id='stnPipeSection';wrap.innerHTML=`<div class="stnPipeBox">
    <label for="stnPipeScope">نطاق الإنشاء والنشر</label><select id="stnPipeScope"><option value="lesson">الدرس المحدد</option><option value="unit">جميع دروس الوحدة</option><option value="semester">جميع دروس الفصل الدراسي</option></select>
    <div class="stnRow"><div><label for="stnPipeStartDate">تاريخ البداية / النشر</label><input type="date" id="stnPipeStartDate"></div>
    <div><label for="stnPipePeriods">الحصص لكل درس</label><select id="stnPipePeriods">${Array.from({length:10},(_,i)=>`<option value="${i+1}"${i===1?' selected':''}>${i+1}</option>`).join('')}</select></div></div>
    <button type="button" class="stnBtn outline" id="stnPipeReadTree" style="width:100%;margin-top:8px">📚 اكتشاف الوحدات والدروس من صف نور</button>
    <p class="stnNote">ينشئ التحضير والأنشطة والدرس التفاعلي معًا، ثم ينشرها بالتاريخ المحدد. إذا غاب دليل نجاح الحفظ يتوقف بدل التكرار.</p>
    <div class="stnActions"><button class="stnBtn" type="button" id="stnPipeStart">✨ إنشاء ونشر الموارد الثلاثة</button><button class="stnBtn outline" type="button" id="stnPipeImport">📁 استيراد ملفاتك</button></div>
    <input type="file" id="stnPipeFile" multiple hidden accept=".pdf,.docx,.txt,.json,.zip">
    <div class="stnActions"><button type="button" class="stnBtn outline" id="stnPipeResume">▶ استئناف</button><button type="button" class="stnBtn outline" id="stnPipeStop">■ إيقاف</button></div>
    <pre id="stnPipeProgress" class="stnPreview" aria-live="polite"></pre></div>`;
  panel.insertBefore(wrap,$('stnHubStatus'));
  $('stnPipeStartDate').value=today();
  service.addEventListener('change',()=>{wrap.hidden=service.value!=='bundle';if(oldActions)oldActions.hidden=service.value==='bundle';});
  $('stnPipeReadTree').addEventListener('click',()=>loadCurriculum().catch(e=>status('تعذر اكتشاف الدروس: '+e.message)));
  $('stnPipeStart').addEventListener('click',()=>begin(files?.preparations?.length||files?.activities?.length||files?.scorm?.length?'file':'gemini').catch(e=>status('تعذر بدء الدفعة: '+e.message)));
  $('stnPipeImport').addEventListener('click',()=>$('stnPipeFile').click());
  $('stnPipeFile').addEventListener('change',async()=>{const f=[...$('stnPipeFile').files];$('stnPipeFile').value='';if(f.length)try{await parseFiles(f)}catch(e){status('تعذر الاستيراد: '+e.message)}});
  $('stnPipeResume').addEventListener('click',()=>resume().catch(e=>status(e.message)));
  $('stnPipeStop').addEventListener('click',()=>cancel().catch(e=>status(e.message)));
  $('stnHubClass').addEventListener('change',refreshCurriculum);
  $('stnHubUnit').addEventListener('change',refreshCurriculum);
  window.addEventListener('stnCourseCatalogChanged',refreshCourses);
  refreshCourses();refreshCurriculum();
 }
 async function init(){teacher=await root.NOOR_TEACHER_PROFILE?.active?.()||'';
  if(!teacher)return;const data=await browser.storage.local.get(jobKey(teacher));job=data[jobKey(teacher)]||null;
  for(let k=0;k<12&&!$('stnHubPanel');k++)await delay(200);
  ui();
  const open=sessionStorage.getItem('stnPipelineOpenCatalog');if(open){
   try{const d=JSON.parse(open);if(d.cid===cid()&&Date.now()-d.time<180000){
    if(!root.NoorPrepBridge2828?.onAddPage?.())await root.NoorPrepBridge2828?.openAddPage?.();
    else{sessionStorage.removeItem('stnPipelineOpenCatalog');await loadCurriculum();$('stnHubPanel').hidden=false;}
   }}catch(e){status('تعذر تحميل دروس الصف: '+e.message)}
  }
  if(job){const t=$('stnPipeProgress');if(t)t.textContent=job.message||job.stage;
   if(!['done','cancelled','paused'].includes(job.stage))setTimeout(step,1200);
  }
  setInterval(async()=>{if(!job||['done','cancelled','paused'].includes(job.stage))return;await step();},2500);
  browser.storage.onChanged.addListener((changes,area)=>{
   if(area!=='local')return;
   if(changes.stnActiveTeacherId && changes.stnActiveTeacherId.newValue!==teacher){job=null;status('تغيّر حساب المعلم؛ أوقفت الدفعة القديمة.');return}
   const c=changes[jobKey(teacher)];if(c?.newValue){job=c.newValue;const p=$('stnPipeProgress');if(p)p.textContent=job.stage+' — '+(job.message||'')+'\nالمنجز: '+job.results.length+' / '+job.lessons.length;}
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
 root.NoorPipeline2828=Object.freeze({selectLessons,schoolDays,normalize:norm});
})(typeof globalThis==='object'?globalThis:this);
