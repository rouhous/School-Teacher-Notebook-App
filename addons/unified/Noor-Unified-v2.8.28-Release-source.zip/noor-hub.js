/* Noor unified teacher hub 2.8.27; no secrets or student data in page DOM.
   All actions require a click. Class/cid binding is based on visible Noor evidence,
   not guessing a grade from opaque course IDs. */
(function(){'use strict';
 if(window.top!==window||!/^\/teacher(?:\/|$)/.test(location.pathname)||document.getElementById('stnNoorHub'))return;
 const root=document.createElement('div');root.id='stnNoorHub';root.dir='rtl';
 root.innerHTML=`<button id="stnHubOpen" type="button">🧩 أدوات نور</button>
 <section id="stnHubPanel" class="stnHubPanel" hidden role="dialog" aria-label="أدوات نور الموحدة">
  <header class="stnHead">أدوات نور · دفتر المعلم <button id="stnHubClose" type="button" aria-label="إغلاق">×</button></header>
  <label for="stnHubService">الخدمة</label><select id="stnHubService"><option value="preparation">📚 تحضير درس</option><option value="activities">📝 نشاط / اختبار</option><option value="grades">📊 نقل الدرجات</option><option value="scorm">🎮 مساق تفاعلي SCORM</option></select>
  <label for="stnHubClass">الصف / الفصل</label><select id="stnHubClass"><option value="">اختر الفصل الظاهر في نور</option></select>
  <div class="stnRow"><div><label for="stnHubSemester">الفصل الدراسي</label><select id="stnHubSemester"><option value="1">الأول</option><option value="2">الثاني</option></select></div><div><label for="stnHubCount">عدد الأسئلة</label><select id="stnHubCount"><option value="5">5</option><option value="6" selected>6</option><option value="10">10</option><option value="15">15</option><option value="20">20</option></select></div></div>
  <div id="stnHubAssessmentRow" hidden><label for="stnHubAssessment">التقييم</label><select id="stnHubAssessment"></select></div>
  <div id="stnHubCsvFields" hidden class="stnCsvFields">
    <p class="stnNote">درجات CSV: اختر تقييم الملف وحقل نور. مطابقة الطلاب تسبق التعبئة دائمًا، ولا يُضغط حفظ.</p>
    <label for="stnHubCsvColumn">التقييم في ملف CSV</label><select id="stnHubCsvColumn"></select>
    <label for="stnHubCsvTarget">الحقل الذي سيُعبأ في نور</label><select id="stnHubCsvTarget"><option value="">افتح جدول الدرجات وانقر فحص</option></select>
    <label class="stnCsvCheckbox"><input type="checkbox" id="stnHubCsvOverwrite"> السماح باستبدال الدرجات الموجودة (اختياري)</label>
    <pre id="stnHubCsvPreview" class="stnPreview" hidden></pre>
  </div>
  <label for="stnHubUnit">الوحدة / Theme</label><input id="stnHubUnit" list="stnHubUnitList" placeholder="اختر أو اكتب اسم الوحدة"><datalist id="stnHubUnitList"></datalist>
  <label for="stnHubLesson">الدرس</label><input id="stnHubLesson" list="stnHubLessonList" placeholder="الدرس المحدد في شجرة نور"><datalist id="stnHubLessonList"></datalist>
  <div id="stnHubKeyBox" hidden><p class="stnNote">لا يوجد مفتاح Gemini مرتبط بهذا المعلم بعد. يحتاج التحضير والتوليد إلى ربط المفتاح مرة واحدة.</p>
   <div class="stnActions"><button type="button" id="stnHubCreateKey" class="stnBtn outline">إنشاء مفتاح</button><button type="button" id="stnHubSaveKey" class="stnBtn">لصق وحفظ المفتاح</button></div>
   <input type="password" autocomplete="off" id="stnHubKey" class="stnKeyInput" placeholder="AQ. / AIza" aria-label="Gemini API key"></div>
  <div id="stnHubLegacyActions" class="stnActions"><button id="stnHubGenerate" type="button" class="stnBtn">✨ توليد باستخدام Gemini</button><button id="stnHubImport" type="button" class="stnBtn outline">📁 استيراد ملف</button></div>
  <input id="stnHubFile" type="file" accept=".json,.pdf,.docx,.txt,.zip,.html" hidden>
  <p id="stnHubStatus" class="stnStatus" role="status" aria-live="polite">اختر الخدمة والصف والوحدة والدرس. لن تختار الإضافة فصلًا آخر بالخطأ.</p>
  <pre id="stnHubPreview" class="stnPreview" hidden></pre>
 </section>`;
 const $=id=>root.querySelector('#'+id),norm=t=>String(t||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const clean=t=>String(t||'').replace(/\s+/g,' ').trim().slice(0,180);
 const status=message=>{$('stnHubStatus').textContent=String(message||'');};
 const getCid=()=>decodeURIComponent(location.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
 const routetype=()=>/\/teacher\/courses\/(?:add_preparation|preparations_index)/i.test(location.pathname)?'preparation':/\/teacher\/(?:homeworks|questions)(?:\/|$)/i.test(location.pathname)?'activities':/\/teacher\/attachments\/index\/Scorm/i.test(location.pathname)?'scorm':/\/teacher\/(?:grades|marks|scores|gradebook)/i.test(location.pathname)?'grades':'home';
 const current={cid:'',className:'',grade:null,verified:false};let lastSelection='',keyReady=false,busy=false,autoApplied=false,courseCandidates=[];
 let csvFileInfo=null,gradePreviewReady=false,gradePreviewMode=null;
 const safeRoute=(u)=>{try{const url=new URL(u,location.href);return url.origin===location.origin&&url.pathname.startsWith('/teacher/')?url:null}catch(_){return null}};
 function lessonTree(){
  const selectors='.jstree-clicked,.jstree-anchor[aria-selected="true"],[role="treeitem"][aria-selected="true"],.jstree-node.jstree-selected,.tree-node.selected,[data-selected="true"]';
  const nodes=[...document.querySelectorAll(selectors)].filter(n=>!root.contains(n));
  const lessonRE=/(?:\bLesson\s*\d+\b|(?:^|\s)\d+\s*[-–.]\s*\d+|(?:درس\s*\d+)|\bStarter\b)/i;
  const unitRE=/(?:^|\b)(?:Unit|Theme|الوحدة|وحدة|ثيم)\s*\d*/i;
  let candidate=null;
  for(const n of nodes){
   const holder=n.closest('li,[role="treeitem"],.jstree-node,.tree-node')||n;
   const direct=n.closest('a,.jstree-anchor')||n;
   const name=clean(direct.textContent||'');
   const badge=holder.querySelector('.lesson-badge,[data-type="lesson"]')||[...holder.querySelectorAll('span,small,b')].find(x=>/^(?:درس|Lesson)$/i.test(clean(x.textContent)));
   if(!name||name.length>160||(!lessonRE.test(name)&&!badge)||/^(?:Unit|Theme|وحدة|الفصل الدراسي)/i.test(name))continue;
   let unit='',semester='';let parent=holder;
   for(let depth=0;depth<8;depth++){
    parent=parent.parentElement?.closest('li,[role="treeitem"],.jstree-node,.tree-node');if(!parent)break;
    const title=clean(parent.querySelector(':scope > a,:scope > .jstree-anchor,:scope > .tree-label')?.textContent||'');
    if(!unit&&unitRE.test(title))unit=title;
    if(!semester&&/الفصل\s*(?:الدراسي\s*)?(?:الاول|الأول|الثاني)/.test(title))semester=/الثاني/.test(title)?'2':'1';
   }
   candidate={name,unit,semester};break;
  }
  return candidate;
 }
 function discover(){
  const routeCid=getCid();const ctx=globalThis.__NoorSmartReadContext?.()||{};
  current.cid=routeCid;current.className=ctx.className||'';current.grade=ctx.grade||null;current.verified=Boolean(ctx.gradeVerified);
  const choices=[];
  if(routeCid&&ctx.gradeVerified&&ctx.className)choices.push({label:ctx.className,cid:routeCid,grade:ctx.grade,verified:true});
  if(routeCid&&!ctx.gradeVerified){
    const headings=[...document.querySelectorAll('h1,h2,.breadcrumb a,.breadcrumb span,.course-name,.course-title')].filter(n=>!root.contains(n)).map(n=>clean(n.textContent)).filter(t=>globalThis.NoorContext?.isClassLabel?.(t));
    const unique=[...new Set(headings.map(norm))];
    if(unique.length===1){const label=headings[0];choices.push({label,cid:routeCid,grade:globalThis.NoorContext.parseGrade(label),verified:true});}
  }
  for(const a of document.querySelectorAll('a[href*="cid:"]')){
   if(root.contains(a))continue;
   const url=safeRoute(a.href);if(!url)continue;
   const cid=decodeURIComponent(url.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
   if(!cid)continue;
   const courseContainer=a.closest('article,li,tr,.card,[class*="course"],[class*="subject"],[class*="item"]') || a.parentElement;
   const texts=[a.textContent,
     courseContainer?.querySelector('h2,h3,h4,strong,.class-name,.course-name')?.textContent,
     courseContainer?.textContent?.slice(0,180)];
   for(const t of texts){const label=clean(t);if(!label||label.length>80)continue;
    const grade=globalThis.NoorContext?.parseGrade?.(label)||null;
    if(grade&&globalThis.NoorContext?.isClassLabel?.(label)){choices.push({label,cid,grade,verified:true});break;}
   }
  }
  courseCandidates=[...new Map(choices.map(c=>[c.cid+'|'+norm(c.label),c])).values()];
  const select=$('stnHubClass'),old=select.value;
  select.replaceChildren(new Option('اختر الفصل الظاهر في نور',''));
  for(const c of courseCandidates){const o=new Option(c.label,c.cid+'|'+c.label);select.append(o)}
  if([...select.options].some(o=>o.value===old))select.value=old;
  else if(routeCid&&courseCandidates.filter(c=>c.cid===routeCid).length===1)select.value=routeCid+'|'+courseCandidates.find(c=>c.cid===routeCid).label;
  else if(courseCandidates.length===1)select.value=courseCandidates[0].cid+'|'+courseCandidates[0].label;
  const units=new Set(),lessons=new Set();
  for(const n of document.querySelectorAll('.jstree-anchor,[role="treeitem"],select option,.tree-label')){
   if(root.contains(n))continue;const text=clean(n.textContent);
   if(text.length<3||text.length>120)continue;
   if(/^(Unit|Theme|وحدة|الوحدة)\b/i.test(text))units.add(text);
   if(/\bLesson\s*\d+\b|(?:^|\s)\d+\s*[-–.]\s*\d+|^درس\s*\d+/i.test(text))lessons.add(text);
  }
  for(const [id,items] of [['stnHubUnitList',units],['stnHubLessonList',lessons]]){$(id).replaceChildren(...[...items].slice(0,80).map(x=>new Option(x,x)))}
  const tree=lessonTree();
  const signature=tree?[tree.name,tree.unit,tree.semester].join('|'):'';
  if(tree&&signature!==lastSelection){
   lastSelection=signature;if(tree.unit)$('stnHubUnit').value=tree.unit;
   if(tree.name)$('stnHubLesson').value=tree.name;
   if(tree.semester)$('stnHubSemester').value=tree.semester;
  }
  if(!root.contains(document.activeElement) && routetype()==='preparation'){
   const p=document.getElementById('noor-prep-panel');
   if(p){if(!$('stnHubUnit').value)$('stnHubUnit').value=clean(p.querySelector('#noor-context-unit')?.value);
    if(!$('stnHubLesson').value)$('stnHubLesson').value=clean(p.querySelector('#noor-context-lesson')?.value)}
  }
 }
 function selectedClass(){const option=$('stnHubClass').value;return courseCandidates.find(c=>option===c.cid+'|'+c.label)||null}
 function selected(){return {service:$('stnHubService').value,semester:$('stnHubSemester').value,unit:clean($('stnHubUnit').value),lesson:clean($('stnHubLesson').value),count:Number($('stnHubCount').value),course:selectedClass()}}
 function checkContext(opts,needsLesson=true){
  if(!opts.course||!opts.course.verified)throw Error('لا يوجد فصل مؤكد من نور. اختر الفصل أولًا من الصفحة الرسمية في نور ثم افتح الإضافة.');
  if(current.cid && opts.course.cid!==current.cid)throw Error('الفصل المحدد يختلف عن صفحة نور الحالية؛ افتح الصفحة الخاصة بالفصل المطلوب.');
  if(needsLesson&&(!opts.unit||!opts.lesson))throw Error('اختر الوحدة والدرس أولًا أو حددهما من شجرة نور.');
 }
 function openTarget(opts){
  const url=opts.service==='activities'?'/teacher/homeworks/index/cid:':opts.service==='preparation'?'/teacher/courses/preparations_index/cid:':null;
  if(!url||!opts.course||!/^[0-9]+$/.test(opts.course.cid))return null;
  return location.origin+url+encodeURIComponent(opts.course.cid);
 }
 async function routeIfNeeded(opts){
  if(routetype()===opts.service)return false;
  if(opts.service==='grades'&&csvFileInfo){gradePageScan();return false;}
  if(['scorm','grades'].includes(opts.service))throw Error('افتح خدمة '+(opts.service==='scorm'?'المساقات التفاعلية SCORM':'رصد الدرجات')+' من صفحة الفصل في نور. لا يمكن استنتاج رابطها بأمان من رقم CID وحده.');
  const link=openTarget(opts);if(!link)throw Error('افتح رابط الخدمة من صفحة الفصل في نور؛ رابط الفصل الحالي ليس رقمًا مطابقًا لرابط الفهرس.');
  if(!confirm('سنفتح صفحة '+(opts.service==='activities'?'الأنشطة':'التحضير')+' الخاصة بالفصل المحدد. متابعة؟'))return true;
  sessionStorage.setItem('stnHubPending',JSON.stringify({service:opts.service,semester:opts.semester,unit:opts.unit,lesson:opts.lesson,count:opts.count,cid:opts.course.cid,execute:'generate'}));
  location.assign(link);return true;
 }
 async function keyStatus(){
  const res=await browser.runtime.sendMessage({type:'NOOR_HUB_KEY_STATUS'}).catch(()=>({ok:false}));
  keyReady=Boolean(res?.ok&&res.ready);
  $('stnHubKeyBox').hidden=keyReady||$('stnHubService').value==='grades';
  $('stnHubGenerate').disabled=!keyReady&&$('stnHubService').value!=='grades';
  if(!res?.ok)status(res?.error||'افتح دفتر المعلم المدرسي بحساب Google أولًا لربط المفتاح.');
 }
 function invalidateGradePreview(){
  gradePreviewReady=false;gradePreviewMode=null;
  $('stnHubGenerate').textContent='📊 مطابقة الطلاب ومعاينة الدرجات';
  $('stnHubCsvPreview').hidden=true;
 }
 function gradePageScan(){
  const result=globalThis.NoorCSVGrades?.scan();
  if(!result)throw Error('محرك الدرجات CSV غير متاح في هذا الإصدار.');
  const sel=$('stnHubCsvTarget');const old=sel.value;
  sel.replaceChildren(new Option('اختر حقل الدرجة في نور',''));
  result.slots.forEach(slot=>sel.append(new Option(slot.label, String(slot.index))));
  if([...sel.options].some(x=>x.value===old))sel.value=old;
  else if(result.slots.length===1)sel.value=String(result.slots[0].index);
  return result;
 }
 function setCsvFields(info){
  csvFileInfo=info;
  const sel=$('stnHubCsvColumn');sel.replaceChildren(new Option('اختر تقييم CSV',''));
  const found=info.scoreColumns.filter(c=>c.category);
  if(found.length===7&&new Set(found.map(x=>x.category)).size===7)sel.append(new Option('جميع التقييمات السبعة — تطابق تلقائي للعناوين','all'));
  for(const col of info.scoreColumns)sel.append(new Option(col.title,String(col.index)));
  if(info.scoreColumns.length===1)sel.value=String(info.scoreColumns[0].index);
  $('stnHubCsvFields').hidden=false;$('stnHubAssessmentRow').hidden=true;
  invalidateGradePreview();
  try{const scanned=gradePageScan();status('تم استيراد '+info.rows+' طالبًا من CSV. صفحة نور تحتوي '+scanned.students+' صفًا. اختر التقييم وحقل الدرجة ثم عاين المطابقة.');}
  catch(e){status('تم استيراد '+info.rows+' طالبًا من CSV. افتح صفحة رصد الدرجات ثم اختر التقييم المستهدف. '+String(e.message||e));}
 }
 async function gradesTransfer(opts){
  if(csvFileInfo&&globalThis.NoorCSVGrades?.ready){
   if(!gradePreviewReady){
    const selected=$('stnHubCsvColumn').value;
    if(!selected)throw Error('اختر التقييم من ملف CSV أولًا');
    const all=selected==='all',target=$('stnHubCsvTarget').value;
    if(!all&&target==='')throw Error('اختر حقل الدرجات الصحيح من جدول نور أولًا');
    // Read the current Noor table and require explicit selection before any changes.
    gradePageScan();
    const data=globalThis.NoorCSVGrades.planTransfer({columnIndex:selected,targetIndex:target,all,overwrite:$('stnHubCsvOverwrite').checked});
    $('stnHubCsvPreview').textContent=data.sample.join('\n');$('stnHubCsvPreview').hidden=!data.sample.length;
    const m=data.metrics;
    status('مطابقة CSV: '+data.count+' درجة جاهزة. طلاب متطابقون: '+m.matched+'/'+m.total+'، غير مطابقين: '+m.unmatched+'، متشابهون: '+m.ambiguous+'، غير صالح: '+m.invalid+'، خانات موجودة: '+m.existing+'.\nراجع أسماء الطلاب والتقييم وحقل نور قبل التعبئة. لا يحدث حفظ آلي.');
    gradePreviewReady=data.ready;gradePreviewMode='csv';
    if(data.ready)$('stnHubGenerate').textContent='📊 تعبئة الدرجات التي راجعتها — دون حفظ';
    return;
   }
   if(gradePreviewMode!=='csv')throw Error('أعد المعاينة أولًا');
   if(!confirm('هل تأكدت من الصف نفسه والتقييم وعمود نور؟ ستُعبأ الحقول التي ظهرت في المعاينة فقط، دون حفظ نهائي.'))return;
   const result=globalThis.NoorCSVGrades.apply();
   invalidateGradePreview();status('تمت تعبئة '+result.filled+' درجة، وتجاوز '+result.skipped+' خانة تغيرت أو تعذر الوصول إليها. راجع النتائج واحفظ يدويًا في نور.');
   return;
  }
  if(!globalThis.NoorGradeTool)throw Error('لم يصل تصدير درجات دفتر المعلم ولم يُستورد ملف CSV.');
  const assessmentId=$('stnHubAssessment').value;
  if(!assessmentId)throw Error('اختر التقييم من دفتر المعلم أولًا.');
  if(!gradePreviewReady){
   const res=await globalThis.NoorGradeTool.preview(assessmentId,opts.course.label);
   status(res?.message||'تم فحص المطابقة؛ راجع التفاصيل قبل التعبئة.');
   gradePreviewReady=Boolean(res?.ready);gradePreviewMode='notebook';
   if(gradePreviewReady)$('stnHubGenerate').textContent='📊 تعبئة الدرجات التي راجعتها — دون حفظ';
   return;
  }
  if(gradePreviewMode!=='notebook')throw Error('أعد فحص المطابقة أولًا');
  const filled=await globalThis.NoorGradeTool.apply(assessmentId,opts.course.label);
  invalidateGradePreview();status(filled?.message||'تمت التعبئة دون حفظ؛ راجع درجات نور.');
 }
 async function showStatus(){const s=$('stnHubService').value;
  $('stnHubCount').parentElement.hidden=s==='preparation'||s==='grades';
  $('stnHubAssessmentRow').hidden=s!=='grades'||Boolean(csvFileInfo);
  $('stnHubCsvFields').hidden=s!=='grades'||!csvFileInfo;
  for(const id of ['stnHubUnit','stnHubLesson']){const item=$(id);item.hidden=s==='grades';root.querySelector('label[for="'+id+'"]').hidden=s==='grades';}
  if(s==='grades'&&globalThis.NoorGradeTool){try{const list=await globalThis.NoorGradeTool.assessments();const box=$('stnHubAssessment');box.replaceChildren(new Option(list.length===1?'التقييم الحالي':'اختر التقييم',''));for(const item of list)box.append(new Option(item.name+' / '+item.max,item.id));if(list.length===1)box.value=String(list[0].id);}catch(_){}}
  invalidateGradePreview();
  if(s!=='grades')$('stnHubGenerate').textContent='✨ توليد باستخدام Gemini';
  $('stnHubImport').textContent=s==='grades'?'📁 استيراد الدرجات':'📁 استيراد ملف';
  $('stnHubFile').accept=s==='scorm'?'.zip,.json':s==='preparation'?'.pdf,.docx,.txt':s==='grades'?'.json,.csv':'.json,.pdf';
  keyStatus();
 }
 async function prep(opts){
  const panel=document.getElementById('noor-prep-panel');if(!panel)throw Error('افتح درس التحضير في نور أولًا؛ لم يُفتح محرر التحضير بعد.');
  const fields={'noor-context-grade':String(opts.course.grade),'noor-context-semester':opts.semester,'noor-context-unit':opts.unit,'noor-context-lesson':opts.lesson};
  for(const [id,v] of Object.entries(fields)){const el=panel.querySelector('#'+id);if(el){el.value=v;el.dispatchEvent(new Event('change',{bubbles:true}));}}
  if(panel.querySelector('#noor-subject')&&!panel.querySelector('#noor-subject').value)panel.querySelector('#noor-subject').value='English';
  const btn=panel.querySelector('#noor-generate-prep');if(!btn)throw Error('زر التحضير الأصلي غير موجود.');
  btn.click();status('جارٍ توليد التحضير عبر Gemini...');
  for(let t=0;t<110;t++){
   await new Promise(r=>setTimeout(r,700));
   const output=panel.querySelector('#noor-generated-preview')?.value||'';
   const info=panel.querySelector('#noor-prep-ai-status')?.textContent||'';
   if(/خطأ:|تعذر|فشل/.test(info))throw Error(info);
   if(output && !panel.querySelector('#noor-apply-prep')?.disabled){
    $('stnHubPreview').textContent=output.slice(0,2000);$('stnHubPreview').hidden=false;
    if(/\/add_preparation/i.test(location.pathname)){
     status('تم إنشاء التحضير. ستُطلب موافقتك على تعبئة الحقول في نور دون الحفظ النهائي.');
     panel.querySelector('#noor-apply-prep').click();
    }else{
     status('تم إنشاء التحضير. افتح صفحة «إضافة تحضير» في نور لتعبئة الحقول أو استخدم زر نسخ التحضير.');
     await navigator.clipboard?.writeText?.(output).catch(()=>{});
    }
    return;
   }
  }
  throw Error('انتهت مهلة انتظار التحضير. تحقق من رسالة Gemini في نور.');
 }
 async function activity(opts){
  if(!globalThis.NoorSmartHub)throw Error('محرك الأنشطة لا يعمل في هذه الصفحة. افتح صفحة المهام الإلكترونية في نور.');
  status('جارٍ توليد نشاط الدرس باستخدام مفتاح المعلم...');
  const result=await globalThis.NoorSmartHub.generate({unit:opts.unit,lesson:opts.lesson,count:opts.count});
  if(!result?.ok)throw Error(result?.error||'تعذر إنشاء النشاط');
  if(result?.issues?.length)throw Error('تم إنشاء الأسئلة ولكن بعضها يحتاج مراجعة: '+result.issues.slice(0,3).join(' | '));
  status('أُنشئت الأسئلة. جارٍ اختيار الفصل والمفردات في نور...');
  const msg=await globalThis.NoorSmartHub.publish({unit:opts.unit,lesson:opts.lesson});
  status(msg||'أرسلت مفردات النشاط لمحرك نور. تابع حالة الإرسال هنا.');
 }
 async function scorm(opts){
  status('جارٍ توليد أسئلة SCORM من Gemini...');
  const prompt='Produce an interactive MCQ course for Omani Grade '+opts.course.grade+', '+opts.unit+', lesson '+opts.lesson+', semester '+opts.semester+'. Use age-appropriate original English questions with explanations, do not fabricate textbook page numbers.';
  const result=await browser.runtime.sendMessage({type:'NOOR_GEMINI_GENERATE',count:opts.count,prompt});
  if(!result?.ok)throw Error(result?.error||'تعذر إنشاء أسئلة SCORM');
  const title=(opts.unit+' — '+opts.lesson).slice(0,160);
  const blob=globalThis.NoorScorm.create(title,result.data.questions);
  const file=new File([blob],('Noor-SCORM-'+Date.now()+'.zip'),{type:'application/zip'});
  await download(file);
  if(routetype()!=='scorm'){status('تم إنشاء وتنزيل SCORM 1.2. افتح المساقات التفاعلية من نفس الفصل في نور لإرفاق الملف.');return}
  const attached=await attachScorm(file,opts);
  status(attached?'تم ملء ملف SCORM والبيانات المؤكدة. راجع النموذج ثم اضغط حفظ داخل نور.':'تم إنشاء SCORM وتنزيله. لم تظهر خانة رفع ملف SCORM واضحة، لذا أرفقه يدويًا من نور.');
 }
 function uniqueInputFile(){
  const els=[...document.querySelectorAll('input[type="file"]')].filter(el=>!root.contains(el)&&!el.closest('#noor-prep-panel'));
  const valid=els.filter(el=>!el.disabled && (/\.zip|scorm|upload|attachment/i.test([el.accept,el.name,el.id].join(' '))||els.length===1));
  return valid.length===1?valid[0]:null;
 }
 async function attachScorm(file,opts){
  const input=uniqueInputFile();if(!input)return false;
  if(!opts.course||!current.cid||opts.course.cid!==current.cid)throw Error('لم أتحقق من أن المساق ينتمي للفصل المحدد، لذلك لم أرفع الملف.');
  try{
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  }catch(_){return false}
  const inputs=[...document.querySelectorAll('input[type="text"],textarea')].filter(el=>!el.closest('#noor-prep-panel')&&!root.contains(el));
  const titleFields=inputs.filter(el=>/title|name|العنوان|اسم\s*المساق/i.test([el.name,el.id,el.placeholder,el.getAttribute('aria-label')].join(' ')));
  if(titleFields.length===1){const el=titleFields[0];el.value=opts.unit+' — '+opts.lesson;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
  // Never submit an ambiguous Noor SCORM form. Screenshots alone do not prove the save selector.
  return true;
 }
 async function download(file){const url=URL.createObjectURL(file);const a=document.createElement('a');a.href=url;a.download=file.name;document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000)}
 async function grades(opts){
  if(routetype()!=='grades'){
   if(!csvFileInfo)throw Error('افتح صفحة رصد الدرجات للفصل المحدد في نور قبل النقل.');
   // Some Noor releases use different grade routes. A real editable student table is the requirement.
   gradePageScan();
  }
  await gradesTransfer(opts);
 }
 async function generate(){
  if(busy)return;discover();const opts=selected();
  try{
   checkContext(opts,opts.service!=='grades');
   if(opts.service!=='grades'&&!keyReady)throw Error('اربط مفتاح Gemini الخاص بك أولًا.');
   if(await routeIfNeeded(opts))return;
   busy=true;$('stnHubGenerate').disabled=true;
   if(opts.service==='preparation')await prep(opts);
   else if(opts.service==='activities')await activity(opts);
   else if(opts.service==='scorm')await scorm(opts);
   else await grades(opts);
  }catch(e){status('توقف: '+String(e.message||e));}
  finally{busy=false;$('stnHubGenerate').disabled=!keyReady&&$('stnHubService').value!=='grades';}
 }
 async function importFile(file){
  discover();const opts=selected();if(opts.service!=='grades')checkContext(opts,true);
  if(opts.service==='activities'){
   if(routetype()!=='activities')throw Error('افتح صفحة المهام الإلكترونية لهذا الفصل أولًا.');
   const res=await globalThis.NoorSmartHub?.importFile(file,opts);if(!res)throw Error('أداة استيراد الأنشطة غير جاهزة');
   status(res.status||'تم استيراد الأنشطة.');
   if(res.items===1){status('تم الاستيراد؛ جارٍ إدراج النشاط في نور...');status(await globalThis.NoorSmartHub.publish(opts))}
   else status('تم استيراد '+res.items+' نشاط. اختر النشاط المطلوب إن كان أكثر من واحد.');
  }else if(opts.service==='preparation'){
   const input=document.querySelector('#noor-prep-panel #noor-file');if(!input)throw Error('افتح صفحة تحضير الدروس في نور أولًا.');
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;input.dispatchEvent(new Event('change',{bubbles:true}));status('تم إرسال الملف إلى محرك استيراد التحضير. راجع نتيجة التحليل.');
  }else if(opts.service==='grades'){
   if(/\.csv$/i.test(file.name)){
    if(file.size>4*1024*1024)throw Error('ملف CSV أكبر من 4 ميغابايت.');
    if(!globalThis.NoorCSVGrades)throw Error('محرك CSV مفقود من الإضافة.');
    setCsvFields(globalThis.NoorCSVGrades.parse(await file.text()));
    return;
   }
   if(!/\.json$/i.test(file.name))throw Error('استيراد الدرجات يقبل CSV أو JSON من دفتر المعلم.');
   csvFileInfo=null;globalThis.NoorCSVGrades?.reset();invalidateGradePreview();
   $('stnHubCsvFields').hidden=true;
   const bank=JSON.parse(await file.text());if(bank?.schema!=='teacher-notebook-noor-v1'||!Array.isArray(bank.students)||!Array.isArray(bank.assessments)||bank.students.length>300)throw Error('ملف الدرجات غير مطابق لتنسيق دفتر المعلم.');
   const id=(await browser.storage.local.get('stnActiveTeacherId')).stnActiveTeacherId;if(!id)throw Error('اربط حساب المعلم من الدفتر أولًا.');
   await browser.storage.local.set({['stnGrades:'+id]:bank});await showStatus();status('حُفظت بيانات الدرجات لهذا المعلم فقط. افتح صفحة الدرجات في نور ثم اضغط المطابقة والتعبئة.');
  }else{
   let zip=file;
   if(/\.json$/i.test(file.name)){const raw=JSON.parse(await file.text());const blob=globalThis.NoorScorm.create(opts.unit+' — '+opts.lesson,raw.questions||raw.data?.questions);zip=new File([blob],'Noor-SCORM-'+Date.now()+'.zip',{type:'application/zip'});}
   if(!/\.zip$/i.test(zip.name)||!globalThis.NoorScorm.hasManifest(await zip.arrayBuffer()))throw Error('ملف SCORM ZIP يجب أن يحتوي على imsmanifest.xml.');
   const attached=routetype()==='scorm'&&await attachScorm(zip,opts);
   if(!attached)await download(zip);
   status(attached?'تم تجهيز ملف SCORM في نموذج نور. راجع وحدته ودرسه ثم اضغط حفظ.':'تم تنزيل SCORM. افتح مساقات نور التفاعلية في الفصل المحدد لإرفاقه.');
  }
 }
 function bind(){
  $('stnHubOpen').addEventListener('click',()=>{const p=$('stnHubPanel');p.hidden=!p.hidden;if(!p.hidden){discover();keyStatus()}});
  $('stnHubClose').addEventListener('click',()=>$('stnHubPanel').hidden=true);
  $('stnHubService').addEventListener('change',showStatus);
  for(const id of ['stnHubClass','stnHubAssessment','stnHubCsvColumn','stnHubCsvTarget','stnHubCsvOverwrite'])$(id).addEventListener('change',invalidateGradePreview);
  $('stnHubGenerate').addEventListener('click',generate);
  $('stnHubImport').addEventListener('click',()=>$('stnHubFile').click());
  $('stnHubFile').addEventListener('change',async()=>{const f=$('stnHubFile').files?.[0];$('stnHubFile').value='';if(!f)return;try{busy=true;status('جارٍ استيراد '+f.name+' ...');await importFile(f)}catch(e){status('تعذر الاستيراد: '+String(e.message||e))}finally{busy=false}});
  $('stnHubCreateKey').addEventListener('click',()=>window.open('https://aistudio.google.com/api-keys','_blank','noopener,noreferrer'));
  $('stnHubSaveKey').addEventListener('click',async()=>{
   let text=$('stnHubKey').value.trim();if(!text){try{text=await navigator.clipboard.readText()}catch(_){}}
   if(!text){status('ألصق المفتاح في الحقل ثم اضغط «لصق وحفظ».');return}
   status('جارٍ اختبار مفتاح Gemini مباشرة مع Google...');
   const res=await browser.runtime.sendMessage({type:'NOOR_HUB_SAVE_KEY',apiKey:text});$('stnHubKey').value='';
   if(!res?.ok){status(res?.error||'فشل اختبار المفتاح');return}
   keyReady=true;$('stnHubKeyBox').hidden=true;$('stnHubGenerate').disabled=false;status('✓ مفتاح Gemini محفوظ لهذا المعلم، ويعمل للتحضير والأنشطة وSCORM.');
  });
  const observer=new MutationObserver(ms=>{
   if(ms.every(m=>root.contains(m.target)))return;
   clearTimeout(observer.timer);observer.timer=setTimeout(()=>discover(),450);
  });observer.observe(document.documentElement,{subtree:true,childList:true,attributes:true,attributeFilter:['class','aria-selected']});
  let last=location.href;setInterval(()=>{if(last!==location.href){last=location.href;discover();}},{interval:1500}.interval);
  discover();const type=routetype();$('stnHubService').value=type==='home'?'preparation':type;showStatus();
  const pending=sessionStorage.getItem('stnHubPending');if(pending){
   try{const p=JSON.parse(pending);sessionStorage.removeItem('stnHubPending');
    if(p.cid===getCid()&&p.execute==='generate'){
     $('stnHubService').value=p.service;$('stnHubSemester').value=p.semester;$('stnHubUnit').value=p.unit;$('stnHubLesson').value=p.lesson;$('stnHubCount').value=String(p.count);
     $('stnHubPanel').hidden=false;
     setTimeout(async()=>{await keyStatus();if(p.service==='activities'&&!globalThis.NoorSmartHub){status('محرك الأنشطة لم يجهز بعد؛ اضغط توليد مجددًا.');return;}await generate()},1600);
    }
   }catch(_){}
  }
  browser.storage.onChanged.addListener((change,area)=>{
   if(area==='local'&&change.noorSmartRunV1?.newValue){const job=change.noorSmartRunV1.newValue;if(job?.message)status(job.message)}
   if(area==='local'&&change.stnActiveTeacherId){keyReady=false;keyStatus();}
  });
 }
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{document.body.append(root);bind()},{once:true});else{document.body.append(root);bind()}
})();
