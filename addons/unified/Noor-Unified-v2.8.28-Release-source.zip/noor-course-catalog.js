/* Noor course catalog 2.8.28. Captures only official course and service URLs seen
 * in the logged-in teacher's DOM. Never infers a CID, TID or target grade from an ID. */
(function(root){'use strict';
 if(!/^\/teacher(?:\/|$)/i.test(location.pathname))return;
 const MAX=40;
 const clean=s=>String(s||'').replace(/\s+/g,' ').trim().slice(0,130);
 const key='stnCourseCatalog:';
 const ai=/الاول|الأول|الثاني|الثالث|الرابع|الخامس|السادس|السابع|الثامن|التاسع|العاشر|الحادي\s+عشر|الثاني\s+عشر/;
 const arabic=['','الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر','الحادي عشر','الثاني عشر'];
 let cache=[],teacher='',lastCard='',lastTime=0,started=false;
 const norm=s=>clean(s).normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[إأآ]/g,'ا').toLowerCase();
 function gradeOf(s){
  const a=clean(s);let g=root.NoorContext?.parseGrade?.(a);
  if(g)return g;
  const m=a.match(/(?:^|[/|\-]\s*)(?:الصف\s*)?(الحادي\s+عشر|الثاني\s+عشر|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول)(?:\s|$|[-(])/);
  if(m){const i=arabic.findIndex(x=>norm(x)===norm(m[1]));return i>0?i:null}
  const n=a.match(/(?:^|\s)(?:Grade|Class)\s*(1[0-2]|[1-9])\b/i);
  return n?Number(n[1]):null;
 }
 function classLabel(text){
  const t=clean(text);if(!t||t.length>130||!gradeOf(t))return '';
  const matches=t.match(/(?:اللغة\s*الإنجليزية|اللغة\s*الانجليزية|English|مادة[^\n]{2,30})\s*[/|\-:]\s*(?:الصف\s*)?(الحادي\s+عشر|الثاني\s+عشر|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول|\d{1,2})(?:\s*[-(]\s*\d{1,3})?/i);
  if(matches)return clean(matches[0]);
  const pieces=t.split(/\s{2,}|\n|\r/).map(clean).filter(Boolean);
  const strong=pieces.find(p=>p.length<95&&gradeOf(p));
  return strong||t;
 }
 function readUrl(value){try{
  const u=new URL(value,location.href);
  if(u.origin!==location.origin||!u.pathname.startsWith('/teacher/'))return null;
  if(!u.pathname.includes('cid:'))return null;
  return u;
 }catch(_){return null}}
 function serviceOf(u){const p=u.pathname;
  if(/\/teacher\/courses\/(?:preparations_index|add_preparation)/i.test(p))return 'preparation';
  if(/\/teacher\/homeworks\//i.test(p))return 'activities';
  if(/\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(p))return 'scorm';
  if(/\/teacher\/(?:grades|marks|scores|gradebook|assessments)/i.test(p))return 'grades';
  return 'course';
 }
 const idOf=u=>decodeURIComponent(u.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
 const courseID=record=>record.cidNumeric||record.cidOpaque||record.identity||'';
 function merge(record){
  const label=classLabel(record.label);const grade=gradeOf(label);
  if(!label||!grade)return false;
  const numeric=/^\d+$/.test(record.cid||'')?record.cid:'';
  const rawCid=record.cid||'';
  const labelMatches=cache.filter(x=>norm(x.label)===norm(label)&&x.grade===grade);
  if(!numeric&&record.service==='scorm'&&labelMatches.length>1&&!labelMatches.some(x=>x.cidOpaque===rawCid))return false;
  const exists=(numeric?cache.find(x=>x.cidNumeric===numeric):null)||
    (!numeric?labelMatches.find(x=>x.cidOpaque===rawCid)||labelMatches[0]:cache.find(x=>norm(x.label)===norm(label)&&x.grade===grade&&!x.cidNumeric));
  const item=exists||{label,grade,cidNumeric:'',cidOpaque:'',routes:{},observed:Date.now()};
  const changed=!exists||(numeric&&item.cidNumeric!==numeric)||(rawCid&&record.service==='scorm'&&item.cidOpaque!==rawCid)||(record.service&&record.url&&item.routes[record.service]!==record.url);
  if(numeric)item.cidNumeric=numeric;
  else if(rawCid && record.service==='scorm')item.cidOpaque=rawCid;
  if(record.service&&record.url){item.routes[record.service]=record.url;}
  if(changed)item.observed=Date.now();
  if(!exists)cache.push(item);
  if(cache.length>MAX)cache=cache.slice(-MAX);
  return Boolean(changed);
 }
 function closestClass(el){
  for(let p=el,i=0;p&&i<7;i++,p=p.parentElement){
   const nodes=[p.querySelector?.('.course-title,.course-name,.class-name,.panel-heading,header,h2,h3,h4,strong'),p];
   for(const n of nodes){if(!n)continue;const txt=clean(n.textContent);if(txt.length>130)continue;const label=classLabel(txt);if(label)return label;}
  }
  return '';
 }
 function scan(){let changed=false;
  for(const a of document.querySelectorAll('a[href*="cid:"], [data-href*="cid:"], [onclick*="cid:"]')){
   let candidate=a.href||a.getAttribute('data-href')||'';
   if(!candidate){const oc=a.getAttribute('onclick')||'';candidate=oc.match(/['"]([^'"]*cid:[^'"]*)['"]/)?.[1]||'';}
   const u=readUrl(candidate);if(!u)continue;
   let label=closestClass(a);
   if(!label && Date.now()-lastTime<6500)label=lastCard;
   if(!label){const heading=[...document.querySelectorAll('.breadcrumb,header h1,main h1,.course-title')].map(el=>classLabel(el.textContent)).find(Boolean);label=heading||'';}
   if(label)changed=merge({label,cid:idOf(u),url:u.href,service:serviceOf(u)})||changed;
  }
  // Cards are shown on the teacher dashboard before their popover links are loaded.
  if(/^\/teacher\/?$/i.test(location.pathname)){
   for(const el of document.querySelectorAll('main article,main .card,main [class*="course"],main [class*="subject"]')){
    if(!el.offsetParent && getComputedStyle(el).position!=='fixed')continue;
    const label=classLabel(el.querySelector('h2,h3,h4,strong,.title')?.textContent||el.textContent?.slice(0,115));
    if(label)changed=merge({label})||changed;
   }
  }
  if(changed){persist();window.dispatchEvent(new CustomEvent('stnCourseCatalogChanged'));}
 }
 async function persist(){if(!teacher)return;try{await browser.storage.local.set({[key+teacher]:cache.map(c=>({label:c.label,grade:c.grade,cidNumeric:c.cidNumeric,cidOpaque:c.cidOpaque,routes:c.routes,observed:c.observed}))})}catch(_){}}
 async function init(){if(started)return;started=true;teacher=await root.NOOR_TEACHER_PROFILE?.active?.()||'';
  if(teacher){const saved=(await browser.storage.local.get(key+teacher))[key+teacher];if(Array.isArray(saved))cache=saved.slice(-MAX).filter(c=>c&&typeof c.label==='string'&&c.routes&&typeof c.routes==='object');}
  document.addEventListener('click',e=>{let label=closestClass(e.target);if(label){lastCard=label;lastTime=Date.now()}setTimeout(scan,280)},{capture:true});
  const obs=new MutationObserver(()=>{clearTimeout(obs.tick);obs.tick=setTimeout(scan,400)});
  obs.observe(document.documentElement,{childList:true,subtree:true});scan();
 }
 root.NoorCourseCatalog=Object.freeze({init,scan,all:()=>cache.map(c=>({...c,routes:{...c.routes}})),get:(c)=>cache.find(x=>x.cidNumeric===String(c)||norm(x.label)===norm(c))||null,gradeOf});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(typeof globalThis==='object'?globalThis:this);
