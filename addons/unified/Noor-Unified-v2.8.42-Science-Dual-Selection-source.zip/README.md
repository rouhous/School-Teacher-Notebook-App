# Noor Unified 2.8.42 — Science tree + dual teacher selection

Based on the user-supplied 2.8.38 Mozilla-signed extension and the tested 2.8.40 source. Preserve teacher membership, preparations, quizzes, grade transfer, Gemini key storage, offline SCORM 1.2 and Mozilla update identity.

## Changes in 2.8.42

- **Keep default automatic selection**: when a teacher clicks a Noor lesson item, the extension continues detecting its term/unit/lesson and filling the existing number inputs.
- **Add optional explicit teacher selection**: a separate mode presents the verified curriculum's term/unit and a lesson dropdown. A selected lesson is matched by the official `termId`, `unitId` and `lessonId`; automatic selection is not removed.
- **Science numbering**: "4 الخلايا والكائنات الحية" is unit 4, "4-1 خصائص الكائنات الحية" is lesson 1, and "4-2" is lesson 2. The teacher may use number fields `4` + `1` or choose "الوحدة الرابعة — الدرس الأول (4-1)" from the manual list.
- **Safety**: no ambiguity across semesters, unit/lesson prefixes or subjects. An explicit `5-1` cannot resolve to `4-1`. A manual choice must correspond to a verified official node ID before generation, preparation or SCORM publication.
- The existing SCORM upload, Gemini 3D scene generation, class verification and review/auto-save modes remain unchanged.

## Previous 2.8.41 changes

- Align SCORM publication navigation with Noor screenshots: exact class course card → its paginated **إدارة المحتوى** menu → **المكتبة الرقمية** → **مكتبة الدروس التفاعلية** tab → **رفع درس تفاعلي جديد**.
- Recognize the real create form using a heading, SCORM control and attachment input even when Noor changes the URL. Follow DOM changes in the same tab; do not invent service paths or write to opaque APIs.
- Prefill SCORM type, title, description, appropriate language, publication date when a native date input exists, preparation and lesson details where identifiable. Verify the textbook/subject/grade/section and a unique official lesson tree selection before attaching the ZIP. Never put a ZIP in the separate cover-image file input.
- Carry a generated or imported ZIP through navigation in teacher-specific browser storage, with a standalone downloadable backup. Review mode never submits. Auto-save mode clicks the final save button once only if all safety checks pass; final acceptance by Noor is never assumed.
- Native Gemini image generation (`NOOR_GEMINI_SCORM_IMAGE`) requests a relevant 16:9 3D Omani educational cartoon for the actual selected subject, unit and lesson. Compress to JPEG and include the image in SCORM ZIP and `imsmanifest.xml` (offline). No static SVG/CSS illustration substitute. Model availability, paid quotas and API key permission may affect image creation; report failure explicitly.
- The originally fixed Firefox typed-array cross-compartment transfer issue remains repaired, no `.subarray` on file bytes.

## Safety & limitations

An authenticated Noor end-to-end portal test is not available in this environment. Screenshot-based navigation and browser DOM simulation passed, but dynamic Noor form widget semantics (especially non-native datepicker and lesson tree) could differ. The publisher fails closed and preserves its ZIP if controls are ambiguous. A wrong grade or section must never be silently selected. For more than one generated lesson, use each ZIP separately instead of repeatedly submitting the same form. A pre-existing imported ZIP is not regenerated (or visually restyled).

Source ZIP does not carry a valid Mozilla signature. The signed XPI must be obtained by the automated GitHub Actions → Mozilla process using the original extension ID and update URL. Do not manually copy signature metadata from a different version.

## Local QA (2026-11-18)

- All custom JS passes `node --check`.
- Browser DOM mock: verified 6-step route, SCORM radio, title, description, unique lesson, ZIP attachment (cover input untouched).
- Review mode: staged without Save; auto mode: one Save click and result marked unknown.
- Mismatched class proof: safely stops before file attachment or Save.
- SCORM zip includes a real raster JPEG and a reference in `imsmanifest.xml`; no legacy inline SVG.
- Live Noor and live Gemini-key API testing not performed.

## QA additions (2.8.42)

- `node tests/test_science_tree.js` passed 17+ resolver assertions (Science, Arabic ordinal names, teacher-selected IDs, ambiguity and English regression).
- All custom JavaScript syntax checks passed.
- No authenticated Noor end-to-end test was possible. Manual tree lists require a teacher-scoped verified curriculum captured from Noor; unknown trees stop rather than guess.
