# Noor Unified 2.8.41 — SCORM Digital Repository + Gemini image

Based on the user-supplied 2.8.38 Mozilla-signed extension and the tested 2.8.40 source. Preserve teacher membership, preparations, quizzes, grade transfer, Gemini key storage, offline SCORM 1.2 and Mozilla update identity.

## Changes in 2.8.41

- Align SCORM publication navigation with Noor screenshots: exact class course card → its paginated **إدارة المحتوى** menu → **المكتبة الرقمية** → **مكتبة الدروس التفاعلية** tab → **رفع درس تفاعلي جديد**.
- Recognize the real create form using a heading, SCORM control and attachment input even when Noor changes the URL. Follow DOM changes in the same tab; do not invent service paths or write to opaque APIs.
- Prefill SCORM type, title, description, appropriate language, publication date when a native date input exists, preparation and lesson details where identifiable. Verify the textbook/subject/grade/section and a unique official lesson tree selection before attaching the ZIP. Never put a ZIP in the separate cover-image file input.
- Carry a generated or imported ZIP through navigation in teacher-specific browser storage, with a standalone downloadable backup. Review mode never submits. Auto-save mode clicks the final save button once only if all safety checks pass; final acceptance by Noor is never assumed.
- Native Gemini image generation (`NOOR_GEMINI_SCORM_IMAGE`) requests a relevant 16:9 3D Omani educational cartoon for the actual selected subject, unit and lesson. Compress to JPEG and include the image in SCORM ZIP and `imsmanifest.xml` (offline). No static SVG/CSS illustration substitute. Model availability, paid quotas and API key permission may affect image creation; report failure explicitly.
- The originally fixed Firefox typed-array cross-compartment transfer issue remains repaired, no `.subarray` on file bytes.

## Safety & limitations

An authenticated Noor end-to-end portal test is not available in this environment. Screenshot-based navigation and browser DOM simulation passed, but dynamic Noor form widget semantics (especially non-native datepicker and lesson tree) could differ. The publisher fails closed and preserves its ZIP if controls are ambiguous. A wrong grade or section must never be silently selected. For more than one generated lesson, use each ZIP separately instead of repeatedly submitting the same form. A pre-existing imported ZIP is not regenerated (or visually restyled).

Source ZIP does not carry a valid Mozilla signature. The signed XPI must be obtained by the automated GitHub Actions → Mozilla process using the original extension ID and update URL. Do not manually copy signature metadata from a different version.

## Local QA (2026-11-18)

- All custom JS passes `node --check`.
- Browser DOM mock: verified 6-step route, SCORM radio, title, description, unique lesson, ZIP attachment (cover input untouched).
- Review mode: staged without Save; auto mode: one Save click and result marked unknown.
- Mismatched class proof: safely stops before file attachment or Save.
- SCORM zip includes a real raster JPEG and a reference in `imsmanifest.xml`; no legacy inline SVG.
- Live Noor and live Gemini-key API testing not performed.
