/* Noor unit/lesson number resolver 2.8.36. Uses verified curriculum titles and node IDs.
 * No guess based on a raw number: ambiguity stops publishing. */
(function(root){'use strict';
 const norm=v=>String(v||'').normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/\s+/g,' ').trim().toLowerCase();
 const digit=v=>{const converted=String(v||'').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776));return converted};
 function number(v,kind){const str=digit(v).trim();if(/^\d{1,2}$/.test(str))return Number(str);
   const p=kind==='unit'?/(?:^|\s)(?:Unit|Theme|الوحدة|وحدة|ثيم)\s*[:#.-]?\s*(\d{1,2})(?!\d)/i:
     /(?:^|\s)(?:Lesson|الدرس|درس)\s*[:#.-]?\s*(\d{1,2})(?!\d)/i;
   const match=p.exec(str);
   if(match)return Number(match[1]);
   if(kind==='lesson'){
     const nested=/(?:^|\s)(?:Unit|الوحدة|وحدة)\s*[:#.-]?\s*(\d{1,2})(?!\d)/i.exec(str);
     if(nested)return Number(nested[1]);
     const xy=/(?:^|\s)\d{1,2}\s*[-.]\s*(\d{1,2})(?!\d)/.exec(str);
     if(xy)return Number(xy[1]);
   }
   return null;
 }
 function term(v){const text=norm(v);if(/الثاني|second|semester\s*2|term\s*2|الفصل\s*2/.test(text))return '2';
  if(/الاول|first|semester\s*1|term\s*1|الفصل\s*1/.test(text))return '1';return ''}
 function same(value,input,kind){if(!String(input||'').trim())return false;
  if(norm(value)===norm(input))return true;
  const wanted=digit(input).trim();const n=number(value,kind);
  // Only a number-only input can match by number; two descriptive labels must match exactly.
  return /^\d{1,2}$/.test(wanted)&&n===Number(wanted);
 }
 function resolve(units,{semester,unit,lesson}){
   const trees=Array.isArray(units)?units:[];
   let matches=[];
   for(const u of trees){
    if(!same(u.unit,unit,'unit'))continue;
    const t=term(u.term);
    if(t&&semester&&t!==String(semester))continue;
    for(const l of u.lessons||[]){
     if(!same(l.title,lesson,'lesson'))continue;
     if(!u.termId||!u.unitId||!l.id)continue;
     matches.push({termId:String(u.termId),unitId:String(u.unitId),lessonId:String(l.id),unit:String(u.unit),title:String(l.title),semester:t||String(semester||'')});
    }
   }
   if(matches.length!==1)return {ok:false,reason:matches.length===0?'not_found':'ambiguous',count:matches.length};
   return {ok:true,...matches[0]};
 }
 root.NoorLessonNumbers=Object.freeze({number,term,resolve});
})(typeof globalThis==='object'?globalThis:this);
