/* Only extension controls are gated; Noor LMS itself always stays usable. */
(()=>{'use strict';
if(!/^\/teacher(?:\/|$)/.test(location.pathname)||window!==top)return;
const api=typeof browser!=='undefined'?browser:chrome;
const style=document.createElement('style');
style.textContent=`body.stn-noor-membership-locked #stnNoorHub,body.stn-noor-membership-locked #stnNoorToggle,body.stn-noor-membership-locked #noor-smart-activities-root,body.stn-noor-membership-locked #noor-prep-panel {display:none!important}`;
(document.head||document.documentElement).appendChild(style);
document.body?.classList.add('stn-noor-membership-locked');
const widget=document.createElement('aside');widget.id='stnMembershipNotice';widget.dir='rtl';
widget.style.cssText='position:fixed;z-index:2147483646;bottom:16px;right:12px;max-width:min(360px,calc(100vw - 24px));background:#fffef7;color:#164438;border:1px solid #bca576;border-radius:14px;padding:12px;font:13px/1.8 Tahoma,Arial;box-shadow:0 8px 25px #153c3840';
widget.innerHTML='<strong>🧩 أدوات نور | دفتر المعلم</strong><p style="margin:5px 0 8px" id="stnMembershipMessage">جارٍ التحقق من العضوية...</p><a href="https://rouhous.github.io/School-Teacher-Notebook-App/school-edition/school-notebook.html" target="_blank" rel="noopener noreferrer" style="color:#087a5b">فتح دفتر المعلم للتحقق</a>　<button type="button" id="stnMembershipRetry" style="cursor:pointer;border:1px solid #087a5b;border-radius:7px;color:#087a5b;background:#fff;padding:4px 8px">إعادة الفحص</button>';
(document.body||document.documentElement).appendChild(widget);
let busy=false;
async function refresh(){
 if(busy)return;busy=true;
 try{
  const result=await api.runtime.sendMessage({type:'STN_LICENSE_STATUS'});
  const allowed=result?.ok===true;
  document.body?.classList.toggle('stn-noor-membership-locked',!allowed);
  widget.hidden=allowed;
  if(!allowed)widget.querySelector('#stnMembershipMessage').textContent='هذه الخدمات مخصصة للمعلمين المعتمدين. افتح دفتر المعلم وسجل الدخول، ثم اضغط إعادة الفحص.';
 }catch(_){widget.hidden=false;document.body?.classList.add('stn-noor-membership-locked');}
 finally{busy=false}
}
widget.querySelector('#stnMembershipRetry').addEventListener('click',refresh);
api.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&(changes['stnNoorEntitlement:v1']||changes.stnActiveTeacherId))void refresh();});
void refresh();
})();
