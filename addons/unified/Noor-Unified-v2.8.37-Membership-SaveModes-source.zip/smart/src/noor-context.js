/* Extract class/grade only from Noor's visible course or selected class UI. No CID-to-grade guessing. */
(function(root){'use strict';
 const arabic=['','الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر','الحادي عشر','الثاني عشر'];
 const english=['','first','second','third','fourth','fifth','sixth','seventh','eighth','ninth','tenth','eleventh','twelfth'];
 const clean=s=>String(s??'').replace(/\s+/g,' ').trim().slice(0,200);
 function parseGrade(source){
  const s=clean(source).toLowerCase();
  if(!s||/الصفوف\s*\(?\s*1\s*[-–]\s*12|grades\s*1\s*[-–]\s*12/.test(s))return null;
  let m=s.match(/(?:^|[^\w])(?:grade|class|الصف|صف)\s*[:\-]?\s*(1[0-2]|[1-9])(?:\b|\s|[-_])/i);
  if(m)return Number(m[1]);
  for(let i=12;i>=1;i--){
   if(new RegExp('(?:الصف|صف)\\s+(?:ال)?'+arabic[i].replace(/^ال/,'')).test(s))return i;
   if(new RegExp('(?:^|[^a-z])'+english[i]+'(?:\\s*[-–]\\s*\\d+|\\s+(?:class|grade)|\\s*$)','i').test(s))return i;
  }
  return null;
 }
 // Only a short, stand-alone course/class label can identify a published class.
 // Generic announcements, navigation, and a school's grade range are not class labels.
 function isClassLabel(value){
  const s=clean(value);
  if(!s || s.length>90 || !parseGrade(s))return false;
  const grades=english.slice(1).join('|');
  const englishPattern=new RegExp('^(?:(?:grade|class)\\s+)?(?:'+grades+')(?:(?:\\s*[-–]\\s*\\d{1,3})|(?:\\s+section\\s+\\d{1,3}))?$', 'i');
  const numberPattern=/^(?:(?:grade|class|الصف|صف)\s*)\d{1,2}(?:\s*[-–]\s*\d{1,3})?$/i;
  const arabicPattern=/^(?:(?:الصف|صف)\s+)?(?:الأول|الثاني|الثالث|الرابع|الخامس|السادس|السابع|الثامن|التاسع|العاشر|الحادي عشر|الثاني عشر)(?:\s*[-–]\s*\d{1,3})?$/;
  return englishPattern.test(s)||numberPattern.test(s)||arabicPattern.test(s);
 }
 const sourceRank={selectedClass:7,selectedCourse:6,classOption:5,selectedOption:1,breadcrumb:3,courseTitle:3,heading:2};
 function choose(candidates){
  const found=[];
  for(const c of candidates||[]){
   const label=clean(c.text);const grade=parseGrade(label);
   if(!grade)continue;
   found.push({label,grade,source:c.source,rank:sourceRank[c.source]||0});
  }
  found.sort((a,b)=>b.rank-a.rank);
  if(!found.length)return {verified:false,grade:null,className:'',evidence:'No displayed class found'};
  const peak=found.filter(x=>x.rank===found[0].rank);
  if(new Set(peak.map(x=>x.grade)).size!==1)return {verified:false,grade:null,className:'',evidence:'Conflicting displayed grades'};
  // Two sections of the same grade are different classes. Don't choose one at random.
  const distinct=new Set(peak.map(x=>x.label.toLowerCase().replace(/\s+/g,' ').replace(/[–—]/g,'-')));
  if(distinct.size>1)return {verified:false,grade:null,className:'',evidence:'Multiple classes shown; select the intended one in Noor'};
  return {verified:peak[0].rank>=3,grade:peak[0].grade,className:peak[0].label,evidence:peak[0].source};
 }
 root.NoorContext={parseGrade,isClassLabel,choose};
})(typeof globalThis==='object'?globalThis:this);
