/* Strict two-column matching table resolver for Noor. Resolves columns by their
   visible Arabic headers and rows by on-screen geometry, not DOM input order.
   Never writes to the page; caller commits only after the entire plan validates. */
(function(root){'use strict';
 const clean=v=>String(v??'').replace(/\s+/g,' ').trim();
 const norm=v=>clean(v).toLowerCase().replace(/[^\p{L}\p{N}]+/gu,'');
 function rect(el){return el.getBoundingClientRect()}
 const centerX=r=>r.left+r.width/2;
 const centerY=r=>r.top+r.height/2;
 function locateHeader(doc,variants,visible){
  const candidates=[...doc.querySelectorAll('th,label,span,div,strong,b,td,p')].filter(x=>visible(x)&&variants.some(v=>norm(x.textContent)===norm(v))&&rect(x).width>0);
  // An outer wrapper and a nested label may duplicate the same text/position.
  // Prefer the innermost leaf containing the caption.
  return candidates.filter(x=>!candidates.some(other=>other!==x&&x.contains?.(other)));
 }
 function plan(doc,pairs,visible,{editorBottom=0,scoreTop=Infinity}={}){
  if(!Array.isArray(pairs)||!pairs.length||pairs.some(p=>!clean(p?.left)||!clean(p?.right)))throw Error('أزواج التوصيل ناقصة في ملف الأسئلة');
  const choices=locateHeader(doc,['خيار','الخيارات','Choice'],visible),answers=locateHeader(doc,['جواب','الإجابة','Answer'],visible);
  const valid=[];
  for(const choice of choices)for(const answer of answers){
   const c=rect(choice),a=rect(answer);
   if(Math.abs(centerY(c)-centerY(a))>55||Math.abs(centerX(c)-centerX(a))<65)continue;
   if(Math.min(c.top,a.top)<editorBottom-40||Math.max(c.bottom,a.bottom)>scoreTop)continue;
   valid.push({choice,answer,c,a,y:Math.max(c.bottom,a.bottom)});
  }
  if(valid.length!==1)throw Error('لم أتعرف على عمودي «خيار» و«جواب» بصورة واحدة مؤكدة في نور');
  const headers=valid[0];
  const candidates=[...doc.querySelectorAll('input[type="text"],input:not([type])')].filter(el=>{
   if(!visible(el)||el.disabled||el.readOnly)return false;
   const r=rect(el);
   return r.width>55&&r.height>12&&r.top>=headers.y-15&&r.bottom<=scoreTop+8;
  });
  const sorted=candidates.sort((a,b)=>centerY(rect(a))-centerY(rect(b)));
  const groups=[];
  for(const el of sorted){const y=centerY(rect(el));const last=groups[groups.length-1];if(last&&Math.abs(last.y-y)<=14){last.inputs.push(el);last.y=(last.y*(last.inputs.length-1)+y)/last.inputs.length;}else groups.push({y,inputs:[el]});}
  const rows=[];
  for(const group of groups){
   // A lone score or unrelated search field must not be treated as a matching row.
   if(group.inputs.length===1)continue;
   if(group.inputs.length!==2)throw Error('صف توصيل غير واضح: عدد الحقول في الصف ليس اثنين');
   const [one,two]=group.inputs;const x1=centerX(rect(one)),x2=centerX(rect(two));
   const hChoice=centerX(headers.c),hAnswer=centerX(headers.a);
   const costDirect=Math.abs(x1-hChoice)+Math.abs(x2-hAnswer);
   const costReverse=Math.abs(x2-hChoice)+Math.abs(x1-hAnswer);
   const option=costDirect<costReverse?one:two;
   const response=costDirect<costReverse?two:one;
   if(Math.abs(centerX(rect(option))-hChoice)>180||Math.abs(centerX(rect(response))-hAnswer)>180||Math.abs(x1-x2)<65)throw Error('تعذر ربط خانتي «خيار» و«جواب» بالعمودين الصحيحين');
   rows.push({option,response});
  }
  if(rows.length<pairs.length)throw Error('نور يعرض '+rows.length+' صفوف توصيل فقط، والسؤال يحتاج '+pairs.length);
  // It is common for Noor to display five rows by default, while an exercise
  // contains fewer pairs. Extra rows MUST stay empty so the answer key is exact.
  for(const extra of rows.slice(pairs.length))if(clean(extra.option.value)||clean(extra.response.value))throw Error('هناك صف توصيل إضافي غير فارغ؛ لا أعدّل بيانات المعلم');
  const assignments=[];
  for(let i=0;i<pairs.length;i++){
   const p=pairs[i],r=rows[i];
   for(const [el,value] of [[r.option,p.left],[r.response,p.right]]){
    if(clean(el.value)&&clean(el.value)!==clean(value))throw Error('حقل توصيل يحتوي على نص مختلف مسبقًا؛ لا أكتب فوقه');
    assignments.push({el,value});
   }
  }
  return {assignments,numberOfRows:rows.length,extraRows:rows.length-pairs.length};
 }
 root.NoorMatching={plan};
})(typeof globalThis!=='undefined'?globalThis:this);
