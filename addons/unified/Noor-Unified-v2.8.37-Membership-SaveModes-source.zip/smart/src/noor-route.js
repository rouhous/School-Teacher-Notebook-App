/* Noor route reader. The cid is an opaque course/session token, NOT a grade. */
(function (root) {
  'use strict';
  function parse(url) {
    try {
      const u = new URL(String(url));
      if (u.protocol !== 'https:' || u.hostname.toLowerCase() !== 'lms.moe.gov.om')
        return {isNoor: false, cid: null, cidKind: null, pageType: 'unsupported', path: ''};
      const path = u.pathname;
      // Noor uses both numeric ids on the index and opaque ids on create pages.
      // Never convert the token to a number or infer the grade from its contents.
      const token = path.match(/(?:^|\/)cid:([^/?#]+)(?:\/|$)/i)?.[1] || null;
      let cid = null;
      if (token) {
        const decoded = decodeURIComponent(token);
        if (/^[A-Za-z0-9_.~-]{1,160}$/.test(decoded)) cid = decoded;
      }
      const cidKind = cid ? (/^\d+$/.test(cid) ? 'numeric' : 'opaque') : null;
      let pageType = 'other';
      if (/^\/teacher\/homeworks\/create(?:\/|$)/i.test(path)) pageType = 'homework_create';
      else if (/^\/teacher\/homeworks(?:\/|$)/i.test(path)) pageType = 'homework';
      return {isNoor: true, cid, cidKind, pageType, path};
    } catch {
      return {isNoor: false, cid: null, cidKind: null, pageType: 'unsupported', path: ''};
    }
  }
  function validateBinding(binding, current) {
    const errors = [];
    if (!current?.isNoor) errors.push('الصفحة الحالية ليست من منصة نور المعتمدة');
    if (!binding?.cid) errors.push('لا يوجد معرّف سياق مرتبط؛ افتح مهمة من الصف المقصود');
    if (!current?.cid) errors.push('لا يظهر معرّف السياق في رابط الصفحة الحالية؛ التحقق مطلوب قبل النشر');
    if (binding?.cid && current?.cid && binding.cid !== current.cid)
      errors.push('اختلف معرّف السياق بين الصفحتين؛ أعِد الربط وتحقق من الصف قبل النشر');
    if (!binding?.verifiedGrade || !binding?.verifiedSubject)
      errors.push('لم يتم التحقق بعد من الصف والمادة داخل نور');
    if (!binding?.verifiedLesson)
      errors.push('لم يتم التحقق بعد من الدرس/الوحدة المختارين');
    return {valid: errors.length === 0, errors};
  }
  root.NoorRoute = {parse, validateBinding};
})(typeof globalThis === 'object' ? globalThis : this);
