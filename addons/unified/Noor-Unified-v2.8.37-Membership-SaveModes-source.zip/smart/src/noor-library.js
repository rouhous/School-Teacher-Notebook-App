/* One library, organised by UNIT and LESSON, regardless of how many JSON files the teacher adds.
   No cloud round trip for JSON. Unknown unit/lesson is retained under "غير محدد". */
(function(root){'use strict';
const trim=v=>String(v??'').trim();
const norm=v=>trim(v).toLowerCase().replace(/\s+/g,' ').replace(/[\u0660-\u0669]/g,d=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(d)));
function unitOf(v){let s=trim(v);if(!s)return '';const m=s.match(/(?:\bunit|\bunits|الوحدة|وحدة)\s*[:#-]?\s*(\d{1,2})\b/i);return m?'Unit '+Number(m[1]):/^\d{1,2}$/.test(s)?'Unit '+Number(s):s;}
function lessonOf(v){let s=trim(v);if(!s)return '';const m=s.match(/(?:\blesson|\bperiod|الدرس|درس)\s*[:#-]?\s*(\d{1,2})\b/i);return m?'Lesson '+Number(m[1]):/^\d{1,2}$/.test(s)?'Lesson '+Number(s):s;}
function derive(source,fallback={}){
 const tag=[source.unit,source.lesson,source.stem,source.question,source.title,source.name,fallback.title,fallback.fileName].filter(Boolean).join(' ');
 const name=trim(source.unit||source.unitName||source.الوحدة||'');
 const level=trim(source.lesson||source.lessonName||source.الدرس||'');
 let unit=unitOf(name),lesson=lessonOf(level);
 if(!unit)unit=unitOf((tag.match(/\bUnits?\s*\d{1,2}/i)||tag.match(/الوحدة\s*\d{1,2}/)||[])[0]);
 if(!lesson)lesson=lessonOf((tag.match(/\bLesson\s*\d{1,2}/i)||tag.match(/الدرس\s*\d{1,2}/)||[])[0]);
 return {unit:unit||unitOf(fallback.unit)||'',lesson:lesson||lessonOf(fallback.lesson)||''};
}
const qKeys=['questions','items','questionsList','الأسئلة','أسئلة'];
function entries(payload,fileName='assessment.json'){
 const out=[];
 const visited=new Set();
 function seek(obj,meta={},depth=0){
   if(depth>8||!obj||typeof obj!=='object'||visited.has(obj))return;
   visited.add(obj);
   if(Array.isArray(obj)){for(const node of obj)seek(node,meta,depth+1);return;}
   const merged={...meta,...derive(obj,meta),title:trim(obj.title||obj.name||meta.title)};
   for(const key of qKeys){if(Array.isArray(obj[key])){
     for(const q of obj[key])out.push({q,meta:{...merged,...derive(q,merged)}});
     return;
   }}
   if(typeof obj.stem==='string'||typeof obj.question==='string'||typeof obj['نص السؤال']==='string'){
     out.push({q:obj,meta:merged});return;
   }
   const includes=['assessment','quiz','exam','test','activity','data','units','lessons','activities','assessments','quizzes','اختبارات','أنشطة','الوحدات','الدروس'];
   for(const key of includes)if(obj[key])seek(obj[key],merged,depth+1);
   if(!includes.some(k=>obj[k]))for(const [k,v] of Object.entries(obj)){
      if(!v||typeof v!=='object')continue;
      const ref=/^(?:unit|lesson|الوحدة|الدرس)\s*\d+/i.test(k)?derive({title:k},merged):merged;
      seek(v,{...merged,...ref},depth+1);
   }
 }
 seek(payload,{fileName,title:trim(payload?.title)||fileName.replace(/\.json$/i,'')});
 if(!out.length)throw Error('لم يعثر على أسئلة في الملف. استخدم قائمة questions أو بنك وحدات ودروس.');
 const groups=new Map();const warnings=[];
 for(const {q,meta} of out){
   let parsed;try{parsed=root.NoorImporter.parse({title:meta.title||fileName,unit:meta.unit,lesson:meta.lesson,questions:[q]},{fileName});}
   catch(e){warnings.push(String(e.message));continue;}
   if(!parsed.questions.length)continue;
   const key=norm(meta.unit)+'|'+norm(meta.lesson)+'|'+norm(meta.title||fileName);
   if(!groups.has(key))groups.set(key,{id:'',title:meta.title||fileName.replace(/\.json$/i,''),unit:meta.unit||'',lesson:meta.lesson||'',fileName,questions:[],grade:trim(q.grade||payload?.grade||''),warnings:[]});
   groups.get(key).questions.push(...parsed.questions);
   groups.get(key).warnings.push(...parsed.warnings);
 }
 const result=[...groups.values()];if(!result.length)throw Error('الأسئلة غير صالحة أو أنواعها غير مدعومة.');
 return {assessments:result,warnings};
}
const categories=assessments=>[...new Set(assessments.map(x=>x.unit).filter(Boolean))].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
const lessons=(assessments,u)=>[...new Set(assessments.filter(x=>norm(x.unit)===norm(u)).map(x=>x.lesson).filter(Boolean))].sort((a,b)=>a.localeCompare(b,undefined,{numeric:true}));
root.NoorLibrary={entries,unitOf,lessonOf,derive,categories,lessons,norm};
})(typeof globalThis==='object'?globalThis:this);
