/* Screenshot-grounded Noor question vocabulary. No live DOM mappings are assumed. */
(function (root) {
  'use strict';
  const kinds = ['mcq','multi_select','true_false','short_text','essay','matching','pairing','fill_blanks','image_click','content','attachment','ordering'];
  const label = {mcq:'اختيار من متعدد',multi_select:'متعدد الأجوبة',true_false:'صح/خطأ',short_text:'إجابة قصيرة',essay:'سؤال إنشائي',matching:'توصيل بين عمودين',pairing:'اقتران',fill_blanks:'ملء الفراغات',image_click:'نقر على صورة',content:'مفردة محتوى مع أسئلة فرعية',attachment:'إجابة بمرفق',ordering:'ترتيب (بانتظار إثبات الدعم في نور)'};
  const clean = (v,max=4000)=>String(v??'').trim().slice(0,max);
  const arr = (v,max=12)=>Array.isArray(v)?v.slice(0,max):[];
  function normalizeQuestion(raw,meta={}) {
    if (!raw || typeof raw!=='object') return null;
    const kind=clean(raw.kind||raw.type||'mcq',40).toLowerCase();
    if(!kinds.includes(kind))return null;
    const options=arr(raw.options).map(v=>clean(v,500)).filter(Boolean);
    const answer=kind==='true_false' ? (raw.answer===true || raw.answer==='true' || raw.answer==='True' ? true : raw.answer===false || raw.answer==='false' || raw.answer==='False' ? false : null) : (raw.answer??null);
    return {
      id:clean(raw.id||crypto.randomUUID(),100),kind,
      stem:clean(raw.stem||raw.question),options,answer,
      answers:arr(raw.answers,12).map(v=>clean(v,500)),
      blanks:arr(raw.blanks,12).map(v=>clean(v,500)),
      pairs:arr(raw.pairs,20).map(p=>({left:clean(p?.left,800),right:clean(p?.right,800),leftImage:clean(p?.leftImage,240),rightImage:clean(p?.rightImage,240)})),
      items:arr(raw.items,20).map(v=>clean(v,500)),
      content:clean(raw.content,16000),mediaType:clean(raw.mediaType,20),mediaName:clean(raw.mediaName,240),
      subquestions:arr(raw.subquestions,40).map(v=>normalizeQuestion(v,meta)).filter(Boolean),
      allowedExtensions:arr(raw.allowedExtensions,15).map(v=>clean(v,15).toLowerCase()),
      points:Number(raw.points??1),explanation:clean(raw.explanation,2500),
      source:clean(raw.source||meta.source||'manual',60),
      grade:clean(meta.grade||raw.grade,30),subject:clean(meta.subject||raw.subject,100),
      unit:clean(meta.unit||raw.unit,160),lesson:clean(meta.lesson||raw.lesson,180),
      needsReview:true,createdAt:new Date().toISOString()
    };
  }
  function validateQuestion(q) {
    const e=[];
    if(!q||typeof q!=='object')return ['سؤال غير صالح'];
    if(!kinds.includes(q.kind))e.push('نوع السؤال غير مدعوم');
    if(!q.stem||q.stem.trim().length<3)e.push('نص السؤال ناقص');
    if(!(Number.isFinite(q.points)&&q.points>0&&q.points<=100))e.push('درجة السؤال غير صحيحة');
    if(q.kind==='mcq'||q.kind==='multi_select'){
      if(!Array.isArray(q.options)||q.options.length<2)e.push('يلزم خياران على الأقل');
      if(new Set(q.options||[]).size!==(q.options||[]).length)e.push('اختيارات مكررة');
      if(q.kind==='mcq'&&!q.options?.includes(String(q.answer)))e.push('الإجابة الصحيحة ليست بين الاختيارات');
      if(q.kind==='multi_select'){
        if(!Array.isArray(q.answers)||q.answers.length<2)e.push('يلزم جوابان صحيحان على الأقل');
        if(new Set(q.answers||[]).size!==(q.answers||[]).length)e.push('إجابات صحيحة مكررة');
        if((q.answers||[]).some(v=>!q.options?.includes(v)))e.push('بعض الإجابات الصحيحة ليست بين الاختيارات');
      }
    }
    if(q.kind==='true_false'&&typeof q.answer!=='boolean')e.push('إجابة صح/خطأ غير محددة');
    if(q.kind==='short_text'&&(typeof q.answer!=='string'||!q.answer.trim()))e.push('إجابة نموذجية غير موجودة');
    if(q.kind==='essay'&&q.answer!==null&&typeof q.answer!=='string')e.push('نموذج الإجابة يجب أن يكون نصًا');
    if(['matching','pairing'].includes(q.kind)){
      const pairs=q.pairs||[];
      if(pairs.length<2||pairs.some(p=>!(p.left||p.leftImage)||!(p.right||p.rightImage)))e.push('أزواج المطابقة ناقصة');
      if(q.kind==='pairing'&&pairs.length>5)e.push('الاقتران في الصور يدعم حتى خمسة أزواج؛ يلزم التحقق من نور قبل الزيادة');
    }
    if(q.kind==='fill_blanks'&&(!q.blanks?.length||q.blanks.some(x=>!x)))e.push('إجابات الفراغات ناقصة');
    if(q.kind==='image_click'&&!q.mediaName)e.push('صورة السؤال غير مرفقة؛ لا يمكن إكمال سؤال النقر قبل تحديدها');
    if(q.kind==='content'){
      if(!['paragraph','image','video','audio'].includes(q.mediaType))e.push('نوع المحتوى غير محدد');
      if(q.mediaType==='paragraph'&&!q.content)e.push('نص المحتوى غير موجود');
      if(['image','video','audio'].includes(q.mediaType)&&!q.mediaName)e.push('ملف المحتوى غير محدد');
      if(!q.subquestions?.length)e.push('لم تُضف الأسئلة الفرعية للمحتوى');
      else q.subquestions.forEach((sq,i)=>validateQuestion(sq).forEach(x=>e.push(`سؤال فرعي ${i+1}: ${x}`)));
    }
    if(q.kind==='attachment'&&(!Array.isArray(q.allowedExtensions)||!q.allowedExtensions.length))e.push('لم تحدد امتدادات ملفات الإجابة');
    if(q.kind==='ordering'&&(!q.items?.length||q.items.length<2||q.items.some(x=>!x)))e.push('عناصر الترتيب ناقصة');
    return e;
  }
  function validateAssessment(a,supportedKinds=kinds) {
    const errors=[];
    if(!a?.title?.trim())errors.push('عنوان النشاط مطلوب');
    for(const field of ['grade','subject','unit','lesson'])if(!String(a?.[field]||'').trim())errors.push('الحقل مطلوب: '+field);
    if(!['quiz','assignment','activity'].includes(a?.activityType))errors.push('نوع النشاط غير معروف');
    if(!Array.isArray(a?.questions)||!a.questions.length)errors.push('لا توجد أسئلة');
    (a?.questions||[]).forEach((q,i)=>{
      if(!supportedKinds.includes(q.kind))errors.push(`سؤال ${i+1}: لا تدعم صفحة نور هذا النوع بعد`);
      validateQuestion(q).forEach(err=>errors.push(`سؤال ${i+1}: ${err}`));
    });
    return {valid:!errors.length,errors,totalPoints:(a?.questions||[]).reduce((s,q)=>s+(Number(q.points)||0),0)};
  }

  // Noor may present a two-stage content editor that cannot be verified in every teacher account.
  // Instead of dropping a reading passage, convert a paragraph-content item into the existing
  // individually gradable Noor question types. Original bank data is NOT changed.
  function prepareForNoor(questions) {
    const out=[],notes=[];
    for(const q of questions){
      if(q.kind==='content' && q.mediaType==='paragraph'){
        const problems=validateQuestion(q);
        if(problems.length)throw Error('سؤال الفقرة: '+problems.join('، '));
        const subs=q.subquestions||[];
        const sum=subs.reduce((n,s)=>n+Number(s.points||0),0);
        if(Math.abs(sum-q.points)>0.001)throw Error('درجات الأسئلة الفرعية لا تساوي درجة الفقرة');
        if(subs.some(s=>['content','attachment','image_click','ordering'].includes(s.kind)))
          throw Error('تحتوي الفقرة على نوع سؤال فرعي لا يمكن نقله دون محرر مخصص');
        subs.forEach((s,i)=>out.push({...s,id:(s.id||q.id+'-'+(i+1)),stem:[q.stem,q.content,s.stem].filter(Boolean).join('\n\n'),source:'json-content-paragraph'}));
        notes.push('حوّلت فقرة القراءة إلى '+subs.length+' أسئلة مستقلة مع تكرار نص الفقرة حفاظًا على السياق والدرجات.');
      }else out.push(q);
    }
    return {questions:out,notes};
  }

  root.NoorSchema={kinds,label,normalizeQuestion,validateQuestion,validateAssessment,prepareForNoor};
})(typeof globalThis==='object'?globalThis:this);
