/* Safe adaptation for Noor's Number Of Blanks control and dynamically rendered answers. */
(function(root){'use strict';
const norm=s=>String(s??'').normalize('NFKC').toLowerCase().replace(/[^\p{L}\p{N}]+/gu,'');
const NUM_LABELS=['number of blanks','number of blank','عدد الفراغات','عدد الإجابات','عدد الاجابات'];
const ANSWERS=['الإجابات','الاجابات','answers','answers list'];
function isRelevant(el){return el&&!el.closest?.('#noor-smart-activities-root')&&!el.disabled;}
function groupsFor(label,query,document){
 const a=[...document.querySelectorAll('label,.control-label,.field-label,span,p,div')]
   .filter(el=>isRelevant(el)&&NUM_LABELS.concat(ANSWERS).some(t=>norm(el.textContent)===norm(t)))
   .filter(el=>label.some(t=>norm(el.textContent)===norm(t)));
 const out=[];
 for(const el of a){const direct=el.control||document.getElementById(el.getAttribute?.('for')||'');
  if(direct?.matches?.(query)&&isRelevant(direct)){out.push([direct]);continue;}
  let parent=el;
  for(let depth=0;depth<5&&parent;depth++,parent=parent.parentElement){
   const candidates=[...parent.querySelectorAll(query)].filter(isRelevant);
   if(candidates.length){out.push(candidates);break;}
  }
 }
 return out;
}
function countSelect(document){
 const selectors=[...document.querySelectorAll('select')].filter(isRelevant);
 const byIdentity=selectors.filter(el=>/blank|فراغ|numberofblanks/i.test([el.id,el.name,el.getAttribute('aria-label')].join(' ')));
 if(byIdentity.length===1)return byIdentity[0];
 const byLabel=groupsFor(NUM_LABELS,'select',document).filter(c=>c.length===1).map(c=>c[0]);
 const distinct=[...new Set(byLabel)];if(distinct.length===1)return distinct[0];
 const numeric=selectors.filter(el=>{
  const vals=[...el.options].map(o=>String(o.value||o.textContent).trim()).filter(Boolean);
  return vals.length>=2&&vals.length<=7&&vals.includes('1')&&vals.includes('2')&&vals.includes('3')&&vals.every(v=>/^\d+$/.test(v));
 });
 return numeric.length===1?numeric[0]:null;
}
function setCount(select,n){
 const matches=[...select.options].filter(o=>String(o.value).trim()===String(n)||String(o.textContent).trim()===String(n));
 // Some Noor templates render duplicate labels, but exactly one distinct value is safe.
 const values=[...new Set(matches.map(o=>o.value))];
 if(values.length!==1||!matches.length)throw Error('تعذر إيجاد عدد الفراغات «'+n+'» في قائمة نور.');
 if(select.value!==values[0]){
  select.value=values[0];
  select.dispatchEvent(new Event('input',{bubbles:true}));
  select.dispatchEvent(new Event('change',{bubbles:true}));
 }
 if(String(select.value)!==String(values[0]))throw Error('لم يؤكد نور اختيار '+n+' فراغات.');
}
function answerFields(document,count){
 const all=[...document.querySelectorAll('input')].filter(el=>isRelevant(el)&&!['hidden','submit','button','radio','checkbox','file','date','datetime-local','number'].includes(el.type));
 const named=all.filter(el=>/answer|blank|اجابة|إجابة|فراغ/i.test([el.name,el.id,el.getAttribute('aria-label'),el.placeholder].join(' ')));
 if(named.length===count)return named;
 const boxes=groupsFor(ANSWERS,'input',document).map(group=>group.filter(el=>all.includes(el))).filter(group=>group.length===count);
 if(boxes.length){const seen=[...new Set(boxes.map(x=>x.map(y=>all.indexOf(y)).join(',')))];if(seen.length===1)return boxes[0];}
 // Fallback: answers are the only text fields between Number Of Blanks and the score.
 // Don't read values from other fields and don't assume when there are ambiguities.
 const counter=countSelect(document);if(!counter)return [];
 const order=[...document.querySelectorAll('input,select,label,span,p,div')];const i=order.indexOf(counter);
 const scoreLabels=order.filter(e=>/^(?:درجة المفردة|درجة السؤال|question score|score)$/i.test(String(e.textContent||'').trim()));
 const stop=scoreLabels.map(e=>order.indexOf(e)).filter(x=>x>i).sort((a,b)=>a-b)[0]??order.length;
 const possible=all.filter(el=>{const idx=order.indexOf(el);return idx>i&&idx<stop;});
 return possible.length===count?possible:[];
}
async function fill(document,answers,setText,sleep=ms=>new Promise(r=>setTimeout(r,ms))){
 if(!Array.isArray(answers)||answers.length<1||answers.length>5||answers.some(v=>!String(v||'').trim()))throw Error('عدد إجابات الفراغات يجب أن يكون بين 1 و5.');
 const select=countSelect(document);if(!select)throw Error('لم أتعرف على قائمة Number Of Blanks في نور.');
 setCount(select,answers.length);
 let fields=[];
 for(let i=0;i<24;i++){fields=answerFields(document,answers.length);if(fields.length===answers.length)break;await sleep(200)}
 if(fields.length!==answers.length)throw Error('لم تظهر حقول الإجابات '+answers.length+' بعد اختيار عدد الفراغات.');
 for(let i=0;i<answers.length;i++)setText(fields[i],String(answers[i]));
 for(let i=0;i<fields.length;i++)if(String(fields[i].value).trim()!==String(answers[i]).trim())throw Error('لم يؤكد نور إدخال إجابة الفراغ رقم '+(i+1));
 return true;
}
root.NoorBlanks={countSelect,setCount,answerFields,fill};
})(typeof globalThis==='object'?globalThis:this);
