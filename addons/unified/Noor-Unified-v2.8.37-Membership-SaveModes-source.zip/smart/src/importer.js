/* Ready-made assessment files -> Noor's normalized assessment contract.
   JSON conversion never contacts Gemini or the network. */
(function(root){
 'use strict';
 const str=(x)=>String(x??'').trim();
 const value=(v,keys)=>{for(const key of keys) if(v?.[key]!==undefined && v?.[key]!==null)return v[key];return undefined};
 const first=(v,keys)=>value(v,keys);
 const list=x=>Array.isArray(x)?x:typeof x==='string'?x.split(/\s*[\n;|]\s*/).filter(Boolean):[];
 function kind(x){
  const s=str(x).toLowerCase().replace(/[_\-\s/]/g,'');
  const m={mcq:'mcq',multiplechoice:'mcq',singlechoice:'mcq',choice:'mcq',اختيارمنمتعدد:'mcq',اختيارمتعدد:'mcq',
    multiselect:'multi_select',msq:'multi_select',multipleanswer:'multi_select',multipleanswers:'multi_select',متعددالأجوبة:'multi_select',اختياراتمتعددة:'multi_select',
    tf:'true_false',tfq:'true_false',truefalse:'true_false',صحخطأ:'true_false',صحأوخطأ:'true_false',boolean:'true_false',
    essay:'essay',مفردةمقالية:'essay',written:'essay',paragraph:'essay',إنشائي:'essay',مقالي:'essay',
    fill:'fill_blanks',fillblanks:'fill_blanks',gapfill:'fill_blanks',fillintheblanks:'fill_blanks',ملءالفراغات:'fill_blanks',إكمالالفراغات:'fill_blanks',
    matching:'matching',match:'matching',توصيل:'matching',توصيلبينعمودين:'matching',pairing:'pairing',اقتران:'pairing',
    shorttext:'short_text',shortanswer:'short_text',إجابةقصيرة:'short_text',
    imageclick:'image_click',النقرعلىصورة:'image_click',attachment:'attachment',مرفق:'attachment',content:'content',محتوى:'content'};
  return m[s]||null;
 }
 function answerMap(a,options){
  if(a===true||a===false)return a;
  if(typeof a==='number'&&Number.isInteger(a)&&options.length){return (a>=1?options[a-1]:options[0])??String(a);}
  let text=str(a);
  if(options.includes(text))return text;
  if(/^[a-z]$/i.test(text)&&options.length)return options[text.toUpperCase().charCodeAt(0)-65]||text;
  if(/^\d+$/.test(text)&&options.length)return options[Number(text)-1]||text;
  if(/^(true|correct|صح|صحيح|نعم)$/i.test(text))return true;
  if(/^(false|incorrect|خطأ|خاطئ|لا)$/i.test(text))return false;
  return text;
 }
 function unwrap(body){
  if(Array.isArray(body))return {questions:body};
  const candidates=[body,body?.assessment,body?.quiz,body?.test,body?.activity,body?.exam,body?.data,body?.الاختبار];
  for(const a of candidates){if(!a||typeof a!=='object')continue;
    for(const key of ['questions','items','أسئلة','الأسئلة','questionsList'])if(Array.isArray(a[key]))return {...a,questions:a[key]};
  }
  throw Error('ملف JSON لا يحتوي قائمة أسئلة. المطلوب مصفوفة questions أو items.');
 }
 function parse(body,{fileName='assessment.json'}={}){
  const data=unwrap(body),warnings=[],results=[];
  const raw=data.questions||[];
  raw.forEach((q,i)=>{
   if(!q||typeof q!=='object'){warnings.push(`سؤال ${i+1}: عنصر غير صالح`);return;}
   const options0=first(q,['options','choices','alternatives','الاختيارات','الخيارات','الإختيارات']);
   let options=(options0&&!Array.isArray(options0)&&typeof options0==='object'?Object.values(options0):list(options0)).map(x=>typeof x==='object'?str(x.text??x.label??x.value??x.option):str(x)).filter(Boolean);
   const k=kind(first(q,['kind','type','question_type','questionType','نوع','نوع السؤال']))||(options.length?'mcq':null);
   if(!k){warnings.push(`سؤال ${i+1}: لم يُحدّد نوع سؤال معرّف`);return;}
   let rawAns=first(q,['answer','correctAnswer','correct_answer','correct','الإجابة','الإجابة الصحيحة','الجواب الصحيح']);
   let answers0=first(q,['answers','correctAnswers','correct_answers','الإجابات الصحيحة']);
   if(rawAns==null&&Array.isArray(options0)){
    const marked=options0.filter(x=>typeof x==='object'&&(x.correct===true||x.isCorrect===true));
    if(marked.length===1)rawAns=marked[0].text??marked[0].label??marked[0].value;
    if(marked.length>1)answers0=marked.map(x=>x.text??x.label??x.value);
   }
   const ans=answerMap(rawAns,options);
   const answers=list(answers0).map(x=>answerMap(x,options));
   const pairs=list(first(q,['pairs','matches','الأزواج','المطابقة'])).map(p=>Array.isArray(p)?{left:str(p[0]),right:str(p[1])}:{left:str(p.left??p.question??p.الطرف_الأول),right:str(p.right??p.answer??p.الطرف_الثاني)});
   const stem=str(first(q,['stem','question','text','prompt','السؤال','نص السؤال','نص المفردة']));
   const points=Number(first(q,['points','point','grade','mark','marks','score','degree','الدرجة','درجة المفردة'])??1);
   const subRaw=list(first(q,['subquestions','subQuestions','children','الأسئلة الفرعية']));
   const subquestions=[];
   for(const sub of subRaw){
     try{const parsed=parse({questions:[sub]},{fileName});subquestions.push(...parsed.questions);}
     catch(e){warnings.push(`سؤال ${i+1}: سؤال فرعي غير قابل للاستيراد: ${String(e.message||e)}`);}
   }
   const question={
    id:str(q.id||''),kind:k,stem,points,options,answer:k==='true_false'?ans:rawAns==null?null:ans,
    answers,blanks:list(first(q,['blanks','gaps','الفراغات','إجابات الفراغات'])),pairs,
    mediaType:str(first(q,['mediaType','media_type','نوع المحتوى'])),
    mediaName:str(first(q,['mediaName','media_name','media','filename','ملف'])),
    content:str(first(q,['content','passage','readingText','textContent','محتوى'])),
    subquestions,allowedExtensions:list(first(q,['allowedExtensions','allowed_extensions','fileTypes','امتدادات الملفات'])),
    explanation:str(first(q,['explanation','reason','الشرح'])),source:'json'
   };
   if(k==='multi_select'&&answers.length===0 && ans!=null)question.answers=[ans];
   if(['essay','short_text'].includes(k)&&rawAns==null)question.answer=k==='essay'?null:'';
   results.push(question);
  });
  if(!results.length)throw Error('لم أتعرف على أي سؤال صالح في الملف');
  const cleanFile=fileName.replace(/\.[^.]+$/,'').replace(/[_-]+/g,' ').trim();
  return {title:str(first(data,['title','name','quiz_title','عنوان','عنوان الاختبار','عنوان النشاط']))||cleanFile,
    unit:str(first(data,['unit','unitName','الوحدة'])),lesson:str(first(data,['lesson','lessonName','الدرس'])),
    questions:results,warnings,received:raw.length};
 }
 root.NoorImporter={parse,kind,answerMap};
})(typeof globalThis==='object'?globalThis:this);
