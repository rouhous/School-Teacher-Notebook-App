// Gemini is billed/limited against each linked teacher's own API project.
// The key stays in Firefox extension storage and is sent directly to Google
// Gemini only; it never passes through the Notebook or Supabase backend.
const STN_TEACHER_KEY='stnActiveTeacherId';
const STN_KEY_PREFIX='stnGeminiKey:';
const STN_NOTEBOOK_URL='https://rouhous.github.io/School-Teacher-Notebook-App/school-edition/school-notebook.html';
const STN_NOOR_ORIGIN='https://lms.moe.gov.om/';
const keyPattern=/^(?:AIza[A-Za-z0-9_-]{20,}|AQ\.[A-Za-z0-9._~=-]{20,})$/;
async function teacherContext(){
  await globalThis.STN_NOOR_LICENSE.authorized();
  const {stnActiveTeacherId}=await browser.storage.local.get(STN_TEACHER_KEY);
  const id=String(stnActiveTeacherId||'');
  if(!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))throw Error('افتح دفتر المعلم بحساب Google المعتمد، ثم ارجع إلى نور.');
  const {['stnGeminiKey:'+id]:key}=await browser.storage.local.get(STN_KEY_PREFIX+id);
  if(!keyPattern.test(String(key||'')))throw Error('لم يتم حفظ مفتاح Gemini لهذا المعلم.');
  return {id,key};
}
const fromNotebook=sender=>String(sender?.url||'').startsWith(STN_NOTEBOOK_URL);
const fromNoor=sender=>String(sender?.url||'').startsWith(STN_NOOR_ORIGIN);
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!msg||!fromNotebook(sender))return false;
 if(msg.type==='STN_STORE_GRADES')return (async()=>{
   await globalThis.STN_NOOR_LICENSE.authorized();
   const p=msg.payload;
   const id=(await browser.storage.local.get(STN_TEACHER_KEY)).stnActiveTeacherId;
   if(!id||msg.teacherId!==id||p?.schema!=='teacher-notebook-noor-v1' ||
      !Array.isArray(p.students)||!Array.isArray(p.assessments)||
      p.students.length>300||p.assessments.length>120||JSON.stringify(p).length>500000)
     return {ok:false,error:'invalid_payload'};
   const safe={schema:p.schema,exportedAt:String(p.exportedAt||''),className:String(p.className||'').slice(0,120),
     assessments:p.assessments.map(a=>({id:String(a.id||''),name:String(a.name||'').slice(0,100),max:Number(a.max)||0})),
     students:p.students.map(st=>({name:String(st.name||'').slice(0,180),studentNumber:String(st.studentNumber||'').slice(0,40),
       grades:Object.fromEntries(Object.entries(st.grades||{}).slice(0,120).map(([k,v])=>[String(k).slice(0,80),String(v??'').slice(0,30)]))}))};
   await browser.storage.local.set({['stnGrades:'+id]:safe});
   let navigation='awaiting_course';
   const catalog=(await browser.storage.local.get('stnCourseCatalog:v4:'+id))['stnCourseCatalog:v4:'+id];
   const norm=v=>String(v||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/\s+/g,' ').trim().toLowerCase();
   const exact=Array.isArray(catalog)?catalog.filter(c=>norm(c.label)===norm(safe.className)&&c.cidNumeric&&/^\d+$/.test(c.cidNumeric)):[];
   // Never invent Noor grade routes. The link must come from the selected class card.
   if(exact.length===1){
     const candidate=exact[0],raw=candidate.routes?.grades;
     let target='';try{const u=new URL(raw);if(u.origin==='https://lms.moe.gov.om'&&u.pathname.startsWith('/teacher/')&&u.pathname.includes('cid:'))target=u.href}catch(_){}
     if(target){
       const tabs=await browser.tabs.query({url:'https://lms.moe.gov.om/*'}).catch(()=>[]);
       const tab=tabs.find(t=>t.active)||tabs[0];
       if(tab?.id)await browser.tabs.update(tab.id,{url:target,active:true});else await browser.tabs.create({url:target,active:true});
       navigation='opened_official_grades';
     }
   }
   await browser.storage.local.set({['stnPendingGrades:'+id]:{className:safe.className,receivedAt:Date.now(),navigation}});
   return {ok:true,count:safe.students.length,navigation};
 })();
 return false;
});
browser.runtime.onMessage.addListener((msg,sender) => {
 if (!msg || msg.type !== 'NOOR_GEMINI_GENERATE' || !fromNoor(sender)) return false;
 return (async()=>{
 let key; try {({key}=await teacherContext())}catch(e){return {ok:false,error:String(e.message||e)}}
 const count=Math.max(1,Math.min(40,Number(msg.count)||10));
 const prompt=String(msg.prompt||'').slice(0,6500)+`\nReturn ONLY JSON with exactly ${count} questions: {"title":"...","questions":[{"question":"...","options":["...","...","...","..."],"correct":0,"explanation":"..."}]}. Each question must have exactly 4 options, one correct index 0-3. No markdown. Do not invent specific textbook facts not in supplied context. If lesson details are missing, write broadly relevant questions and avoid unsupported curriculum claims.`;
 try {
    const generated=await globalThis.NoorGeminiModels.generate(key,{contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.6,maxOutputTokens:16000}},{timeoutMs:90000});
    const payload=generated.data;
    const raw=payload.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('')||'';
    const data=JSON.parse(raw);
    if(!Array.isArray(data.questions)||data.questions.length!==count)throw Error('عدد الأسئلة غير مطابق للمطلوب. حاول مرة أخرى.');
    for(const q of data.questions){if(typeof q.question!=='string'||!Array.isArray(q.options)||q.options.length!==4||!q.options.every(x=>typeof x==='string')||!Number.isInteger(q.correct)||q.correct<0||q.correct>3||typeof q.explanation!=='string')throw Error('صيغة سؤال غير صحيحة. حاول مجددًا.');}
    return {ok:true,modelUsed:generated.model,data:{title:String(data.title||'Interactive Activity').slice(0,150),questions:data.questions}};
  }catch(e){return {ok:false,error:String(e.message||e).slice(0,400)};}

})();
});
// Validate the current teacher's stored key against Google instead of guessing its
// validity from the prefix alone. Never send the credential to the web page or logs.
browser.runtime.onMessage.addListener((msg,sender) => {
  if (!msg || msg.type!=='NOOR_GEMINI_TEST_KEY' || !fromNoor(sender)) return false;
  return (async()=>{
    let key;
    try {({key}=await teacherContext());} catch(e) {return {ok:false,error:String(e.message||e)}}
    try {
      const response=await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1',{
        method:'GET',headers:{'x-goog-api-key':key},cache:'no-store',signal:AbortSignal.timeout(15000)
      });
      if(response.ok) return {ok:true};
      const payload=await response.json().catch(()=>({}));
      let reason=String(payload?.error?.message||'HTTP '+response.status);
      if(key) reason=reason.split(key).join('[hidden]');
      if(response.status===401 || response.status===403)
        return {ok:false,error:'Google رفض المفتاح أو صلاحيات مشروعه ('+response.status+'): '+reason.slice(0,150)};
      if(response.status===429)return {ok:false,error:'وصل مشروع Gemini إلى حد الطلبات (429).'};
      return {ok:false,error:'Google HTTP '+response.status+': '+reason.slice(0,150)};
    } catch(e){return {ok:false,error:'تعذر فحص اتصال Google: '+String(e.message||e).slice(0,120)}}
  })();
});

// Generate a lesson directly through the teacher's Google account API project.
// This deliberately avoids the older Supabase relay that only accepted AIza keys.
// It does not auto-save or publish any response in Noor.
browser.runtime.onMessage.addListener((msg,sender) => {
 if (!msg || msg.type!=='NOOR_PREP_GENERATE' || !fromNoor(sender)) return false;
 return (async()=>{
   let key;
   try {({key}=await teacherContext());} catch(e){return {ok:false,error:String(e.message||e)}}
   const subject=String(msg.subject||'').trim().slice(0,120);
   const grade=String(msg.grade||'').trim().slice(0,60);
   const unit=String(msg.unit||'').trim().slice(0,160);
   const lesson=String(msg.lesson||'').trim().slice(0,180);
   const lessonText=String(msg.lessonText||'').slice(0,5000);
   const fields=Array.isArray(msg.fields)?msg.fields.filter(v=>typeof v==='string'&&/^[A-Za-z][\w-]{1,79}$/.test(v)).slice(0,25):[];
   if(!subject||!grade||!lesson||!fields.length)return {ok:false,error:'حدّد المادة والصف والدرس وحقول التحضير أولًا.'};
   const prompt=`You are an experienced teacher preparing a professional lesson in Oman. Create detailed, actionable curriculum-aligned lesson preparation in the same language as the subject. Base it on the teacher-supplied textbook content when present. If specific lesson pages are not given, never claim to have read them or invent exact textbook page or exercise numbers. Include measurable objectives, learning vocabulary and concepts, a warm-up, clear procedures with teacher/student actions, guided and independent practice, differentiation, and formative and final assessment with actual ready-to-use questions and model answers. Avoid generic boilerplate and do not invent official policy. Reply with a single JSON object whose keys exactly match the requested fields and whose values are complete plain-text explanations, no Markdown tables.\nSubject: ${subject}\nGrade: ${grade}\nUnit: ${unit}\nLesson: ${lesson}\nAvailable lesson text: ${lessonText||'[Not supplied: provide suggested activities rather than fabricated textbook quotations]'}\nRequired Noor field names: ${JSON.stringify(fields)}`;
   const payload={contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.35,maxOutputTokens:5500}};
   try {
     const generated=await globalThis.NoorGeminiModels.generate(key,payload,{timeoutMs:60000});
     const raw=(generated.data?.candidates?.[0]?.content?.parts||[]).map(p=>String(p.text||'')).join('');
     let parsed;
     try{parsed=JSON.parse(raw)}catch{return {ok:false,error:'لم يرجع Gemini تحضيرًا بصيغة JSON صالحة، حاول مرة أخرى.'}}
     const prepared={};
     for(const f of fields){if(typeof parsed?.[f]==='string')prepared[f]=parsed[f].slice(0,3500);}
     if(!Object.keys(prepared).length)return {ok:false,error:'لم يُرجع Gemini حقول تحضير مطابقة لحقول نور.'};
     return {ok:true,fields:prepared,modelUsed:generated.model};
   }catch(e){return {ok:false,error:String(e?.message||e).slice(0,350)}}

 })();
});

// One Gemini key per Notebook teacher, shared by preparation, activities, and SCORM.
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!fromNoor(sender)||!msg||!['NOOR_HUB_KEY_STATUS','NOOR_HUB_SAVE_KEY'].includes(msg.type))return false;
 return (async()=>{
  await globalThis.STN_NOOR_LICENSE.authorized();
  const info=(await browser.storage.local.get(STN_TEACHER_KEY))[STN_TEACHER_KEY];
  const id=String(info||'');
  if(!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))return {ok:false,error:'افتح دفتر المعلم بحساب Google المعتمد أولًا.'};
  const storage='stnGeminiKey:'+id;
  if(msg.type==='NOOR_HUB_KEY_STATUS'){
   const obj=await browser.storage.local.get(storage);return {ok:true,ready:keyPattern.test(String(obj[storage]||''))};
  }
  const candidate=String(msg.apiKey||'').replace(/\s/g,'').slice(0,240);
  if(!keyPattern.test(candidate))return {ok:false,error:'تحقق من صحة مفتاح Gemini: يبدأ عادةً AQ. أو AIza.'};
  try {
   const resp=await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1',{
    method:'GET',headers:{'x-goog-api-key':candidate},cache:'no-store',signal:AbortSignal.timeout(20000)
   });
   if(!resp.ok)return {ok:false,error:'رفضت Google المفتاح (HTTP '+resp.status+'). تأكد من صلاحيات مشروعه.'};
   await browser.storage.local.set({[storage]:candidate});return {ok:true,ready:true};
  }catch(e){return {ok:false,error:'تعذر اختبار مفتاح Gemini: '+String(e.message||e).slice(0,110)};}
 })();
});
