# Noor Unified Tools 2.8.37 — teacher-only access and pre-generation save mode

- Uses server-verifiable, installation-bound membership permits issued only after the logged-in Notebook account is approved and active. No user quota, no old-version block.
- Teacher's Google or passkey credential stays between the Notebook page and the Supabase membership endpoint. The extension receives a signed 24-hour permit, never the credential or Gemini key.
- Firefox extension functions remain locked until the teacher confirms their Notebook session; refresh the Notebook login if a permit expires. A temporarily offline extension may rely on an unexpired cached permit.
- Before Gemini starts, the teacher chooses **review before saving** (default) or **automatic save**. Automatic mode fills, verifies lesson tree, objective level, dates and periods, and submits once without a second click. Review mode fills, shows a preview, and waits for explicit final approval.
- Keeps unit/lesson numeric selectors, independent services, grades preview, and fail-closed SCORM destination checks from 2.8.36.
- Live verification must be carried out with an approved teacher's Notebook account and an authenticated Noor lesson page before broad rollout.
