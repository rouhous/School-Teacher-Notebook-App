/* Noor course catalog 2.8.31. Learn course IDs from their real teacher-dashboard
 * cards and their own popover links, not from lesson/preparation/grade tables.
 * Only teacher-scoped, verified course IDs can be used for writing to Noor. */
(function(root){'use strict';
 if(!/^\/teacher(?:\/|$)/i.test(location.pathname))return;
 const KEY='stnCourseCatalog:v4:',MAX=40;
 const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
 const norm=s=>clean(s).normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[إأآ]/g,'ا').toLowerCase();
 const arabic=['','الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر','الحادي عشر','الثاني عشر'];
 const gradeWords='الحادي\\s+عشر|الثاني\\s+عشر|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول';
 const gradeRE=new RegExp('(?:^|[\\s\\/\\(\\)\\|:\\-])('+gradeWords+')(?=$|[\\s\\/\\(\\)\\|:\\-])','gi');
 const gradeNumeric=/(?:^|\s)(?:grade|class|الصف|صف)\s*[:\-]?\s*(1[0-2]|[1-9])(?:$|[\s\/-])/i;
 let teacher='',cache=[],lastCard='',lastCardAt=0,started=false,observer=null;
 function gradeOf(value){
  const s=clean(value);if(!s||s.length>210)return null;
  // A grade span, e.g. (12-11), is a school stage, never a class identity.
  const matches=[...s.matchAll(new RegExp(gradeRE.source,'gi'))];
  const words=matches.map(m=>arabic.findIndex(w=>norm(w)===norm(m[1]))).filter(n=>n>0);
  const numeric=gradeNumeric.exec(s);if(numeric)words.push(Number(numeric[1]));
  const unique=[...new Set(words)];return unique.length===1?unique[0]:null;
 }
 // Read the subject from the verified course tile only (no global defaults).
 const knownSubjects=[
  ['الأحياء',/\bBiology\b|الأحياء|احياء|أحياء/i],
  ['الفيزياء',/\bPhysics\b|الفيزياء/i],
  ['الكيمياء',/\bChemistry\b|الكيمياء/i],
  ['اللغة الإنجليزية',/اللغة\s*الإنجليزية|اللغة\s*الانجليزية|\bEnglish(?:\s+Language)?\b/i],
  ['اللغة العربية',/اللغة\s*العربية|\bArabic(?:\s+Language)?\b/i],
  ['الرياضيات',/الرياضيات|\bMathematics\b|\bMath\b/i],
  ['العلوم',/العلوم|\bScience\b/i],
  ['التربية الإسلامية',/التربية\s*(?:الإسلامية|الاسلامية)|\bIslamic\b/i],
  ['الجغرافيا',/الجغرافيا|\bGeography\b/i],
  ['التاريخ',/التاريخ|\bHistory\b/i],
  ['الدراسات الاجتماعية',/الدراسات\s*الاجتماعية|\bSocial\s+Studies\b/i],
  ['تقنية المعلومات',/تقنية\s*المعلومات|\bIT\b|\bInformation\s+Technology\b/i],
  ['الفنون التشكيلية',/الفنون\s*التشكيلية|\bArt\b/i],
  ['المهارات الموسيقية',/المهارات\s*الموسيقية|\bMusic\b/i],
  ['التربية الرياضية',/التربية\s*الرياضية|\bPhysical\s+Education\b/i],
  ['اللغة الفرنسية',/اللغة\s*الفرنسية|\bFrench\b/i]
 ];
 function subjectOf(value){
  const text=clean(value);
  const matches=knownSubjects.filter(([,pattern])=>pattern.test(text)).map(([name])=>name);
  // Reject multiple conflicting subjects rather than silently selecting English.
  return matches.length===1?matches[0]:'';
 }
 function classLabel(value){
  const s=clean(value);if(!s||s.length>190)return '';
  // Reject class-like text in preparation titles or activity rows.
  if(/(?:lesson|unit|theme|project|writing|grammar|vocabulary|reading|speaking|listening|review|overview|formative|assessment|تحضير|درس|وحدة|الاهداف|الأهداف|التقويم|الاختبار|انشطة|أنشطة|تاريخ|المراجعة|المهام|الطلبة|مفردات)/i.test(s))return '';
  if(/(?:^|\s)Grade\s*(?:1[0-2]|[1-9])\s*:/i.test(s))return '';
  const g=gradeOf(s);if(!g)return '';
  const subject=subjectOf(s);
  const isStandalone=norm(s)===norm(arabic[g]) || new RegExp('^(?:الصف|صف)\\s+'+gradeWords+'$','i').test(s) || /^(?:grade|class)\s*\d{1,2}(?:\s*[-–]\s*\d{1,2})?$/i.test(s);
  if(!subject&&!isStandalone)return '';
  // Permit one section number, not a school stage range or unrelated prose.
  const section=(s.match(/(?:الحادي عشر|الثاني عشر|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول)\s*[-–]\s*(\d{1,2})(?=$|\s)/)||[])[1]||'';
  const subjectClean=subject;
  return (subjectClean?subjectClean+' / ':'')+arabic[g]+(section?' - '+section:'');
 }
 function localURL(value){try{const u=new URL(value,location.href);return u.origin===location.origin&&/^\/teacher\//i.test(u.pathname)&&/\/cid:/.test(u.pathname)?u:null}catch(_){return null}}
 function idOf(url){return decodeURIComponent(url.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'')}
 function service(url){const p=url.pathname;
  if(/\/teacher\/courses\/(?:preparations_index|add_preparation)/i.test(p))return 'preparation';
  if(/\/teacher\/homeworks\//i.test(p))return 'activities';
  if(/\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(p))return 'scorm';
  if(/\/teacher\/(?:grades|marks|scores|gradebook|assessments)/i.test(p))return 'grades';return 'course';
 }
 function add(record){const label=classLabel(record.label);if(!label)return false;const grade=gradeOf(label);if(!grade)return false;
  const cid=String(record.cid||''),numeric=/^\d+$/.test(cid)?cid:'',opaque=cid&&!numeric?cid:'';
  let item=numeric?cache.find(x=>x.cidNumeric===numeric):null;
  if(!item){const matches=cache.filter(x=>norm(x.label)===norm(label));if(matches.length===1)item=matches[0];}
  // Do not merge two same-grade sections or multiple different official IDs.
  if(item&&numeric&&item.cidNumeric&&item.cidNumeric!==numeric)return false;
  if(item&&opaque&&record.service==='scorm'&&item.cidOpaque&&item.cidOpaque!==opaque)return false;
  const first=!item;
  if(!item)item={label,grade,cidNumeric:'',cidOpaque:'',routes:{},observed:Date.now()};
  let changed=first;
  if(numeric&&!item.cidNumeric){item.cidNumeric=numeric;changed=true}
  if(opaque&&record.service==='scorm'&&!item.cidOpaque){item.cidOpaque=opaque;changed=true}
  if(record.url&&record.service&&item.routes[record.service]!==record.url){item.routes[record.service]=record.url;changed=true}
  if(changed){item.observed=Date.now();if(first)cache.push(item);if(cache.length>MAX)cache=cache.slice(-MAX)}
  return changed;
 }
 // Noor's material tiles are not guaranteed to be <article> or .card.
 // Find isolated grade labels inside the visible "المواد" dashboard section,
 // then ascend only as far as the single matching subject/course tile.
 const isHome=()=>/^\/teacher\/?$/i.test(location.pathname);
 function displayed(el){if(!el||typeof el.getBoundingClientRect!=='function')return false;const r=el.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(el).visibility!=='hidden'}
 function materialTitle(){return [...document.querySelectorAll('h1,h2,h3,h4,header strong,[class*="section-title"]')]
   .find(el=>!el.closest('#stnNoorHub,nav,aside,table')&&displayed(el)&&norm(el.innerText||el.textContent)==='المواد')||null}
 function labelFromText(el){const text=clean(el?.innerText||el?.textContent||'');return text.length<=190?classLabel(text):''}
 function discoverCards(){
  if(!isHome())return [];
  const material=materialTitle(),heading=material?.getBoundingClientRect(),out=[],seen=new Set();
  function eligible(el){
   if(!el||seen.has(el)||el.closest('#stnNoorHub,nav,aside,table,tbody,footer'))return false;
   if(!displayed(el))return false;
   const r=el.getBoundingClientRect();
   if(r.width<130||r.height<42||r.width>Math.max(540,innerWidth*.55))return false;
   // Limit discovery to the visible materials area, not announcements or navigation.
   if(heading&&(r.top<heading.bottom-28||r.top>heading.bottom+840))return false;
   return true;
  }
  function addCard(el){if(!eligible(el))return;const label=labelFromText(el);if(!label)return;seen.add(el);out.push({element:el,label})}
  // Fast path for the known Noor card classes.
  for(const el of document.querySelectorAll('article,.card,[class*="course-card"],[class*="material-card"],[class*="subject-card"]'))addCard(el);
  // Semantic fallback: a course tile may use only Bootstrap's .col* wrappers.
  // The leaf itself must explicitly display the grade; this never looks at saved
  // preparation titles, arbitrary CID links, or hidden data tables.
  const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
  let leaf,count=0;
  while((leaf=walker.nextNode())&&++count<12000){
   const value=clean(leaf.nodeValue),el=leaf.parentElement;
   if(!el||value.length>65||!gradeOf(value)||!displayed(el)||el.closest('#stnNoorHub,nav,aside,table,tbody,footer'))continue;
   // Find the nearest whole tile containing both the subject and this grade.
   let chosen=null;
   for(let node=el,depth=0;node&&depth<9;node=node.parentElement,depth++){
    if(node===document.body||node===document.documentElement)break;
    const content=clean(node.innerText||node.textContent);
    if(content.length>230)break;
    if(!eligible(node))continue;
    if(classLabel(content)){chosen=node;break}
   }
   if(!chosen)continue;
   // Prefer the complete tile wrapper while it keeps one clear grade and a short label.
   for(let node=chosen.parentElement,depth=0;node&&depth<3;node=node.parentElement,depth++){
    if(node===document.body||!eligible(node))break;
    if(classLabel(clean(node.innerText||node.textContent))===classLabel(clean(chosen.innerText||chosen.textContent)))chosen=node;
    else break;
   }
   addCard(chosen);
  }
  // Nested tile candidates should result in one card, not repeated classes.
  return out.filter((c,i)=>!out.some((d,j)=>j!==i&&d.element.contains(c.element)&&d.label===c.label));
 }
 function courseCard(node){
  const cards=discoverCards();
  const direct=cards.find(c=>c.element===node||c.element.contains(node));
  return direct?.label||'';
 }
 function visibleHeaderLabel(){
  if(isHome())return '';
  const cid=idOf({pathname:location.pathname});if(!cid||!/^\d+$/.test(cid))return '';
  const labels=new Set();
  const selectors='h1,h2,h3,h4,h5,.breadcrumb,.page-title,.course-title,.class-name,.subject-name,[data-course-name],[class*="course-header"],[class*="subject-title"]';
  for(const el of document.querySelectorAll(selectors)){
   if(!displayed(el)||el.closest('#stnNoorHub,table,tbody,nav,aside,footer'))continue;
   const label=labelFromText(el);if(label)labels.add(label);
  }
  return labels.size===1?[...labels][0]:'';
 }
 function scan(){let changed=false;
  if(isHome()){
   const cards=discoverCards();
   for(const card of cards)changed=add({label:card.label})||changed;
   // A course popover can be appended outside its card; link it only to
   // the tile the teacher just clicked, not any other table or grade row.
   for(const a of document.querySelectorAll('a[href*="cid:"],[data-href*="cid:"]')){
    if(a.closest('table,tbody,tr,.preparation-list,.dataTables_wrapper,#stnNoorHub'))continue;
    const u=localURL(a.href||a.getAttribute('data-href'));if(!u)continue;
    const direct=cards.find(c=>c.element.contains(a))?.label||'';
    // Associate a detached menu link with the selected tile only when it is
    // in a true service popover/menu, or is an explicitly named service action.
    // Never assign an unrelated CID link just because a card was clicked.
    const menu=Boolean(a.closest('[role="menu"],[role="dialog"],.popover,.dropdown-menu,[id*="popover"],[class*="popover"],[class*="dropdown-menu"],[class*="course-actions"]'));
    const action=clean(a.innerText||a.textContent);
    const actionService=/رصد\s*(?:و\s*)?متابعة\s*الأداء|نقل\s*الدرجات|إدارة\s*الدرجات|grade|mark|score/i.test(action)?'grades':service(u);
    const serviceAction=actionService!=='course'&&/^(?:تحضير\s*(?:الدروس)?|المهام\s*الإلكترونية|الاختبارات|نقل\s*الدرجات|رصد\s*(?:و\s*)?متابعة\s*الأداء|إدارة\s*الدرجات|الدروس\s*التفاعلية|مكتبة\s*الدروس\s*التفاعلية|Add\s*preparation)$/i.test(action);
    const attached=Date.now()-lastCardAt<6000&&lastCard&&(menu||serviceAction);
    const label=direct||(attached?lastCard:'');
    if(label)changed=add({label,cid:idOf(u),url:u.href,service:actionService})||changed;
   }
  }else{
   // Page heading can directly prove the numeric course ID and grade.
   // Never infer grade or class from old preparation/activity table rows.
   const numeric=idOf({pathname:location.pathname});
   const heading=visibleHeaderLabel();
   if(heading&&/^\d+$/.test(numeric)){
    changed=add({label:heading,cid:numeric,url:location.origin+location.pathname,service:service({pathname:location.pathname})})||changed;
   }
   const item=cache.find(x=>x.cidNumeric===numeric);
   if(item&&/^\d+$/.test(numeric)){
    const type=service({pathname:location.pathname});if(type!=='course'){
     const safe=location.origin+location.pathname;
     if(item.routes[type]!==safe){item.routes[type]=safe;item.observed=Date.now();changed=true;}
    }
   }
  }
  if(changed){persist();window.dispatchEvent(new CustomEvent('stnCourseCatalogChanged'))}
 }
 async function persist(){if(!teacher)return;try{await browser.storage.local.set({[KEY+teacher]:cache})}catch(_){}}
 async function init(){if(started)return;started=true;try{teacher=String(await root.NOOR_TEACHER_PROFILE?.active?.()||'')}catch(_){teacher=''};
  // V3 discards unreliable cached entries gathered from lesson titles in V2.
  try{const r=await browser.storage.local.get(KEY+teacher);const saved=r[KEY+teacher];if(Array.isArray(saved))cache=saved.slice(-MAX).filter(x=>classLabel(x.label)&&x.grade===gradeOf(x.label)&&x.routes&&typeof x.routes==='object');}catch(_){ }
  if(cache.length)window.dispatchEvent(new CustomEvent('stnCourseCatalogChanged'));
  document.addEventListener('click',e=>{if(document.getElementById('stnNoorHub')?.contains(e.target))return;
   if(isHome()){const label=courseCard(e.target);if(label){lastCard=label;lastCardAt=Date.now()}}
   setTimeout(scan,320);
  },{capture:true});
  observer=new MutationObserver(records=>{
   // Ignore our own controls; replacing select options must not rescan Noor.
   if(records.every(r=>r.target?.closest?.('#stnNoorHub')))return;
   clearTimeout(observer.tick);observer.tick=setTimeout(scan,750)
  });
  observer.observe(document.documentElement,{childList:true,subtree:true,attributes:true,attributeFilter:['class','style','hidden']});scan();
  browser.storage?.onChanged?.addListener?.(async(changes,area)=>{
   if(area!=='local'||!changes.stnActiveTeacherId)return;
   const next=String(changes.stnActiveTeacherId.newValue||'');
   if(next===teacher)return;
   teacher=next;cache=[];lastCard='';lastCardAt=0;
   try{const data=await browser.storage.local.get(KEY+teacher);if(Array.isArray(data[KEY+teacher]))cache=data[KEY+teacher].filter(x=>classLabel(x.label)&&x.grade===gradeOf(x.label));}catch(_){}
   scan();window.dispatchEvent(new CustomEvent('stnCourseCatalogChanged'));
  });
  window.addEventListener('pageshow',()=>setTimeout(scan,300));
  window.addEventListener('focus',()=>setTimeout(scan,350));
 }
 root.NoorCourseCatalog=Object.freeze({init,scan,all:()=>cache.map(x=>({...x,routes:{...x.routes}})),get:c=>cache.find(x=>x.cidNumeric===String(c)||norm(x.label)===norm(c))||null,gradeOf,classLabel,subjectOf,cards:()=>discoverCards().map(c=>({element:c.element,label:c.label}))});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(typeof globalThis==='object'?globalThis:this);
