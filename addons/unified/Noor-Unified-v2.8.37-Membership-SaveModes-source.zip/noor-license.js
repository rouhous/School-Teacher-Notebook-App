/* Membership gate for Noor Tools: permit is issued after a verified Notebook login.
 * This script runs in the Firefox background, isolated from Noor's page JavaScript. */
(function(){'use strict';
const API='https://czljzhwmtqmtmlsbwgyz.supabase.co/functions/v1/noor-addon-license';
const NOTEBOOK='https://rouhous.github.io/School-Teacher-Notebook-App/school-edition/school-notebook.html';
const NOOR='https://lms.moe.gov.om/';
const KEY='stnNoorEntitlement:v1', INSTALL='stnNoorInstallId:v1', SUBJECT='stnActiveTeacherId';
let lastChecked=0;
const fromNotebook=s=>String(s?.url||'').split('?')[0].split('#')[0]===NOTEBOOK;
const fromNoor=s=>String(s?.url||'').startsWith(NOOR);
const validId=s=>typeof s==='string'&&/^[a-f\d]{32}$/.test(s);
async function installId(){
 const store=await browser.storage.local.get(INSTALL);
 if(validId(store[INSTALL]))return store[INSTALL];
 const bytes=new Uint8Array(16);crypto.getRandomValues(bytes);
 const id=Array.from(bytes,b=>b.toString(16).padStart(2,'0')).join('');
 await browser.storage.local.set({[INSTALL]:id});return id;
}
async function verifyRemote(data){
 const r=await fetch(API,{method:'POST',headers:{'content-type':'application/json'},cache:'no-store',
  body:JSON.stringify({action:'verify',permit:data.permit,installId:data.installId,subject:data.subject}),
  signal:AbortSignal.timeout(16000)});
 const payload=await r.json().catch(()=>({}));
 if(!r.ok||!payload.ok)return {ok:false,networkError:r.status>=500,reason:payload.reason||'MEMBERSHIP_NOT_VERIFIED'};
 if(payload.subject!==data.subject||!(Number(payload.expiresAt)*1000>Date.now()))return {ok:false,reason:'PERMIT_MISMATCH'};
 return {ok:true,expiresAt:payload.expiresAt};
}
async function status(){
 const saved=(await browser.storage.local.get([KEY,SUBJECT]))[KEY];
 if(!saved?.permit||!saved.subject||saved.installId!==await installId()||!saved.expiresAt||saved.expiresAt*1000<=Date.now())return {ok:false,reason:'OPEN_NOTEBOOK_TO_VERIFY'};
 const active=(await browser.storage.local.get(SUBJECT))[SUBJECT];
 if(saved.subject!==active)return {ok:false,reason:'TEACHER_CHANGED'};
 if(Date.now()-lastChecked<10*60*1000)return {ok:true,subject:saved.subject,expiresAt:saved.expiresAt};
 let remote;try{remote=await verifyRemote(saved)}catch(_){remote={ok:false,networkError:true}}
 if(remote.ok){lastChecked=Date.now();return {ok:true,subject:saved.subject,expiresAt:saved.expiresAt}}
 if(remote.networkError)return {ok:true,offline:true,subject:saved.subject,expiresAt:saved.expiresAt};
 await browser.storage.local.remove(KEY);return {ok:false,reason:remote.reason||'MEMBERSHIP_INACTIVE'};
}
async function authorized(){const result=await status();if(!result.ok)throw Error('خدمات نور حصرية للمعلمين المعتمدين في دفتر المعلم. افتح الدفتر بحسابك وحدّث التحقق قبل استخدام الإضافة.');return result;}
async function receive(msg){
 const id=await installId();if(!msg||msg.installId!==id||!msg.permit||typeof msg.teacherId!=='string'||!msg.teacherId)return {ok:false,error:'INVALID_MEMBERSHIP'};
 const auth=await verifyRemote({permit:msg.permit,installId:id,subject:msg.teacherId});
 if(!auth.ok)return {ok:false,error:auth.reason||'MEMBERSHIP_NOT_APPROVED'};
 const previous=(await browser.storage.local.get(SUBJECT))[SUBJECT];
 if(previous&&previous!==msg.teacherId)await browser.storage.local.remove(['noorSmartRunV1','noorSmartPanelOpen']);
 await browser.storage.local.set({[SUBJECT]:msg.teacherId,[KEY]:{permit:msg.permit,installId:id,subject:msg.teacherId,expiresAt:auth.expiresAt}});
 lastChecked=Date.now();return {ok:true,expiresAt:auth.expiresAt};
}
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!msg)return false;
 if(msg.type==='STN_LICENSE_CHALLENGE'&&fromNotebook(sender))return installId().then(id=>({ok:true,installId:id}));
 if(msg.type==='STN_SET_ACTIVE_TEACHER'&&fromNotebook(sender))return receive(msg).catch(e=>({ok:false,error:String(e.message||e).slice(0,120)}));
 if(msg.type==='STN_LICENSE_STATUS'&&(fromNoor(sender)||fromNotebook(sender)))return status();
 return false;
});
globalThis.STN_NOOR_LICENSE=Object.freeze({authorized,status});
})();
