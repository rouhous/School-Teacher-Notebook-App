/* Minimal self-contained, standards-oriented SCORM 1.2 MCQ package writer.
 * No remote dependencies; generated student content is escaped into a JSON script.
 * Upload and actual LMS reporting still require a real session test. */
(function(root){'use strict';
 function bytes32(n){return [n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255]}
 function bytes16(n){return [n&255,(n>>>8)&255]}
 function escXML(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));}
 function zip(entries){
  const encoder=new TextEncoder();let offset=0;const local=[],central=[];
  const t=Array.from({length:256},(_,i)=>{for(let j=0;j<8;j++)i=(i&1)?0xedb88320^(i>>>1):i>>>1;return i>>>0});
  const crc=data=>{let c=0xffffffff;for(const b of data)c=t[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0};
  for(const [name,body] of entries){
   const filename=encoder.encode(name),raw=encoder.encode(body),check=crc(raw),length=raw.length;
   const lh=new Uint8Array([...bytes32(0x04034b50),...bytes16(20),...bytes16(0x800),...bytes16(0),...bytes16(0),...bytes16(0),...bytes32(check),...bytes32(length),...bytes32(length),...bytes16(filename.length),...bytes16(0),...filename]);
   local.push(lh,raw);
   central.push(new Uint8Array([...bytes32(0x02014b50),...bytes16(20),...bytes16(20),...bytes16(0x800),...bytes16(0),...bytes16(0),...bytes16(0),...bytes32(check),...bytes32(length),...bytes32(length),...bytes16(filename.length),...bytes16(0),...bytes16(0),...bytes16(0),...bytes16(0),...bytes32(0),...bytes32(offset),...filename]));
   offset+=lh.length+length;
  }
  const centralSize=central.reduce((n,x)=>n+x.length,0);
  const end=new Uint8Array([...bytes32(0x06054b50),...bytes16(0),...bytes16(0),...bytes16(central.length),...bytes16(central.length),...bytes32(centralSize),...bytes32(offset),...bytes16(0)]);
  return new Blob([...local,...central,end],{type:'application/zip'});
 }
 function normalize(raw){
  const q=raw?.questions || raw?.data?.questions || [];
  if(!Array.isArray(q)||!q.length||q.length>50)throw Error('SCORM: يجب توفير 1 إلى 50 سؤالًا.');
  return q.map((x,i)=>{
   const prompt=String(x.question||x.stem||'').trim().slice(0,1200);
   const options=Array.isArray(x.options)?x.options.map(v=>String(v).trim().slice(0,350)):[];
   const correct=Number.isInteger(x.correct)?x.correct:options.indexOf(String(x.answer??''));
   if(!prompt||options.length!==4||options.some(v=>!v)||correct<0||correct>3)throw Error('السؤال '+(i+1)+' غير مناسب لمساق SCORM اختيار من متعدد.');
   return {question:prompt,options,correct,explanation:String(x.explanation||'').slice(0,600)};
  });
 }
 const runtime=String.raw`(function(){'use strict';const data=window.NOOR_SCORM_DATA;let i=0,score=0,done=false,answered=false,api=null;
 const $=id=>document.getElementById(id);
 for(let w=window,n=0;n<12;n++){try{if(w.API){api=w.API;break}if(w.parent===w)break;w=w.parent}catch(_){break}}
 try{if(api)api.LMSInitialize('')}catch(_){}
 function report(status){if(!api)return;try{api.LMSSetValue('cmi.core.score.raw',String(Math.round(100*score/data.questions.length)));api.LMSSetValue('cmi.core.score.min','0');api.LMSSetValue('cmi.core.score.max','100');api.LMSSetValue('cmi.core.lesson_status',status);api.LMSCommit('')}catch(_){}}
 function draw(){answered=false;$('next').hidden=true;$('feedback').textContent='';$('title').textContent=data.title;$('progress').textContent=(i+1)+' / '+data.questions.length;const q=data.questions[i];$('question').textContent=q.question;$('choices').replaceChildren();q.options.forEach((label,index)=>{const button=document.createElement('button');button.type='button';button.textContent=String.fromCharCode(65+index)+'. '+label;button.onclick=()=>{if(answered)return;answered=true;if(index===q.correct)score++;for(const b of $('choices').children)b.disabled=true;$('feedback').textContent=(index===q.correct?'Correct! ':'Correct: '+q.options[q.correct]+'. ')+q.explanation;$('next').hidden=false;};$('choices').append(button)})}
 $('next').onclick=()=>{if(!answered)return;i++;if(i<data.questions.length){draw();return}done=true;report('completed');$('question').textContent='Completed!';$('progress').textContent='Score: '+score+' / '+data.questions.length;$('feedback').textContent='Your score has been saved where the LMS provides a SCORM API.';$('choices').replaceChildren();$('next').hidden=true;try{if(api)api.LMSFinish('')}catch(_){}};
 window.addEventListener('pagehide',()=>{if(!done)report('incomplete');try{if(api)api.LMSFinish('')}catch(_){}});
 report('incomplete');draw();})();`;
 function create(title,questions){
  const data={title:String(title||'Interactive course').trim().slice(0,160),questions:normalize({questions})};
  const manifest=`<?xml version="1.0" encoding="UTF-8"?>\n<manifest identifier="NOOR_SCORM_1_2" version="1.0" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2" xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2"><metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata><organizations default="ORG"><organization identifier="ORG"><title>${escXML(data.title)}</title><item identifier="ITEM" identifierref="RESOURCE"><title>${escXML(data.title)}</title></item></organization></organizations><resources><resource identifier="RESOURCE" type="webcontent" adlcp:scormtype="sco" href="index.html"><file href="index.html"/><file href="questions.js"/><file href="runtime.js"/></resource></resources></manifest>`;
  const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${escXML(data.title)}</title><style>body{background:#edf6f3;color:#1a3b31;font:16px system-ui,sans-serif;margin:0;padding:16px}.app{max-width:720px;margin:auto;background:white;border:1px solid #b2d8c2;border-radius:16px;padding:20px}button{width:100%;text-align:left;background:#f5fbf7;border:1px solid #a7cdb6;border-radius:10px;padding:13px;margin:7px 0;font:inherit}button:disabled{opacity:.7}#next{background:#086c50;color:white;text-align:center}#feedback{margin-top:12px;line-height:1.8}h1{font-size:1.3rem}</style></head><body><main class="app"><h1 id="title"></h1><p id="progress"></p><h2 id="question"></h2><div id="choices"></div><p id="feedback" aria-live="polite"></p><button id="next" hidden>Next</button></main><script src="questions.js"></script><script src="runtime.js"></script></body></html>`;
  const js='window.NOOR_SCORM_DATA='+JSON.stringify(data).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028')+';';
  return zip([['imsmanifest.xml',manifest],['index.html',html],['questions.js',js],['runtime.js',runtime]]);
 }
 function hasManifest(data){const bytes=new Uint8Array(data);const marker=new TextEncoder().encode('imsmanifest.xml');for(let i=0;i<bytes.length-marker.length;i++){let match=true;for(let j=0;j<marker.length;j++)if(bytes[i+j]!==marker[j]){match=false;break}if(match)return true}return false}
 root.NoorScorm=Object.freeze({create,normalize,hasManifest});
})(typeof globalThis==='object'?globalThis:this);
