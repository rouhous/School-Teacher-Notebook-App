/* Noor Unified Grades: safe CSV scanner and exact-match transfer.
 * Adapted from Noor CSV Grade Assistant 1.3.2.
 * No extra launcher or popup, no network traffic, and NO automatic submission.
 * Imported student records are kept only in this page's memory. */
(function(){'use strict';
 if(globalThis.NoorCSVGrades)return;
 const visible=e=>!!e && (!e.getClientRects||e.getClientRects().length>0||e.offsetWidth>0||e.offsetHeight>0);
 const clean=s=>String(s??'').replace(/\s+/g,' ').trim();
 const norm=s=>clean(s).normalize('NFKC').toLowerCase()
  .replace(/[\u064b-\u065f\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/ة/g,'ه')
  .replace(/\s+/g,' ').trim();
 const normalizeId=s=>String(s??'').replace(/[^0-9٠-٩]/g,'').replace(/[٠-٩]/g,d=>String(d.charCodeAt(0)-1632));
 const columns=[
  {id:'presentation',aliases:['spk presentations','presentation','العروض الشفهية','التقديم الشفهي','speaking presentation'],max:10},
  {id:'interaction',aliases:['spk interaction','interaction','التفاعل الشفهي','التفاعل'],max:10},
  {id:'reading',aliases:['rdg texts','reading','القراءة','نصوص القراءة'],max:5},
  {id:'writing1',aliases:['wrt information','writing 1','الكتابة 1','writing information'],max:5},
  {id:'writing2',aliases:['wrt letters','writing 2','الكتابة 2','writing letters'],max:5},
  {id:'grammar',aliases:['g/v grammar','grammar','grammar vocabulary','القواعد','المفردات'],max:5},
  {id:'semester',aliases:['semester test','semester exam','اختبار الفصل','اختبار نهاية الفصل'],max:60}
 ];
 let csvSource=null,snapshot=null,plan=null;
 function parse(text){
  if(typeof text!=='string'||text.length>4*1024*1024)throw Error('ملف CSV فارغ أو كبير جدًا');
  const str=text.replace(/^\ufeff/,'');let first='',inside=false;
  for(let i=0;i<str.length;i++){const c=str[i];if(c==='"')inside=!inside;if((c==='\n'||c==='\r')&&!inside)break;first+=c;}
  const candidates=[',',';','\t'];const delim=candidates.sort((a,b)=>first.split(b).length-first.split(a).length)[0];
  let quoted=false,row=[],field='',rows=[];
  function push(){row.push(field);if(row.some(v=>clean(v)))rows.push(row);row=[];field='';}
  for(let i=0;i<str.length;i++){
   const c=str[i];if(c==='"'){if(quoted&&str[i+1]==='"'){field+='"';i++;}else quoted=!quoted;}
   else if(c===delim&&!quoted){row.push(field);field='';}
   else if((c==='\n'||c==='\r')&&!quoted){if(c==='\r'&&str[i+1]==='\n')i++;push();}
   else field+=c;
  }
  if(quoted)throw Error('علامة اقتباس غير مغلقة في CSV');
  push();if(rows.length<2||rows[0].length<2)throw Error('ملف CSV لا يتضمن رأس الأعمدة وبيانات الطلاب');
  if(rows.length>1501)throw Error('عدد سجلات CSV يتجاوز الحد الآمن 1500');
  const headers=rows[0].map(clean).slice(0,80);
  const indexOf=words=>headers.findIndex(h=>words.some(w=>norm(h)===norm(w)||norm(h).includes(norm(w))));
  const nameIndex=indexOf(['اسم الطالب','student name','name']);
  const idIndex=indexOf(['studentnumber','student number','student id','student_id','رقم الطالب','الرقم المدني']);
  const scoreColumns=headers.map((title,index)=>{
   if(index===nameIndex||index===idIndex)return null;
   let known=columns.find(c=>c.aliases.some(w=>norm(title)===norm(w)))||null;
   return {index,title:title||'عمود '+(index+1),known};
  }).filter(Boolean);
  if((nameIndex<0&&idIndex<0)||!scoreColumns.length)throw Error('تعذر تحديد اسم الطالب أو رقمه وعمود الدرجات');
  csvSource={headers,rows:rows.slice(1).map((r,i)=>({name:clean(r[nameIndex]||''),id:idIndex>=0?normalizeId(r[idIndex]):'',cells:r,line:i+2})).filter(x=>x.name||x.id),scoreColumns};
  snapshot=null;plan=null;
  return {headers,rows:csvSource.rows.length,scoreColumns:scoreColumns.map(c=>({index:c.index,title:c.title,category:c.known?.id||''}))};
 }
 const isNumericInput=e=>e&&e.matches?.('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]),textarea')
  &&!e.disabled&&!e.readOnly&&visible(e)&&(!e.type||['text','tel','number',''].includes(e.type));
 function scan(){
  snapshot=null;plan=null;
  let best=null;
  for(const table of document.querySelectorAll('table')){
   if(!visible(table)||table.closest?.('#stnNoorHub,#stnNoorWidget,#noor-prep-panel'))continue;
   const trs=[...table.querySelectorAll('tr')];if(trs.length<2)continue;
   const heads=[...table.querySelectorAll('thead th')].map(h=>clean(h.textContent));
   const rows=[];
   for(const tr of trs){
    if(!visible(tr)||tr.querySelector('th')&&tr.querySelectorAll('td').length===0)continue;
    const cells=[...tr.children].filter(e=>e.matches('th,td'));
    const fields=cells.flatMap((cell,cellIdx)=>[...cell.querySelectorAll('input,textarea')].filter(isNumericInput).map((input,within)=>({input,cellIdx,within,heading:heads[cellIdx]||''})));
    if(!fields.length)continue;
    const texts=cells.filter(c=>!c.querySelector('input,textarea,select')).map(c=>clean(c.textContent)).filter(Boolean);
    const ids=[...tr.querySelectorAll('[data-student-id],[data-student-number]')].map(n=>normalizeId(n.getAttribute('data-student-id')||n.getAttribute('data-student-number')));
    for(const t of texts)for(const m of t.matchAll(/\b\d{6,12}\b/g))ids.push(m[0]);
    const names=texts.filter(t=>!/^\d{6,12}$/.test(t)).slice(0,6);
    if(!names.length&&!ids.length)continue;
    rows.push({tr,names,ids,fields});
   }
   if(rows.length>0&&(!best||best.rows.length<rows.length))best={table,rows};
  }
  if(!best)throw Error('افتح صفحة درجات نور؛ لم أجد جدول طلاب مع حقول قابلة للتعبئة.');
  const maxSlots=Math.max(...best.rows.map(r=>r.fields.length));
  const slots=Array.from({length:maxSlots},(_,index)=>{
   const col=best.rows.find(r=>r.fields[index])?.fields[index];
   return {index,label:col?.heading||'حقل الدرجة '+(index+1)};
  });
  snapshot={...best,slots,location:location.href};
  return {students:best.rows.length,slots,headers:slots.map(s=>s.label)};
 }
 function matchStudent(source,rows,used){
  const available=rows.filter(r=>!used.has(r.tr));
  if(source.id){
   const byId=available.filter(r=>r.ids.some(x=>x===source.id));
   if(byId.length===1)return {row:byId[0],method:'رقم الطالب'};
   if(byId.length>1)return {ambiguous:true};
   // If Noor shows student identifiers, a conflicting identifier must NOT
   // be silently bypassed by a same-name match.
   if(rows.some(r=>r.ids.length))return {row:null};
  }
  if(source.name){const n=norm(source.name);const byName=available.filter(r=>r.names.some(x=>norm(x)===n));if(byName.length===1)return {row:byName[0],method:'الاسم الكامل'};if(byName.length>1)return {ambiguous:true};}
  return {row:null};
 }
 function planTransfer({columnIndex,targetIndex,overwrite=false,all=false,emptyZero=false}={}){
  if(!csvSource)throw Error('استورد ملف CSV أولًا');
  if(!snapshot||!snapshot.table.isConnected||snapshot.location!==location.href)scan();
  const index=Number(columnIndex),target=Number(targetIndex);
  if(!all&&(!csvSource.scoreColumns.some(c=>c.index===index)||!snapshot.slots.some(s=>s.index===target)))throw Error('اختر عمود درجة CSV وحقل نور بشكل صريح.');
  let mapping=[];
  if(all){
   // Batch seven-assessment transfer only when each heading has one unambiguous correspondence.
   for(const c of csvSource.scoreColumns.filter(c=>c.known)){
    const targets=snapshot.slots.filter(slot=>c.known.aliases.some(a=>norm(slot.label)===norm(a)||norm(slot.label).includes(norm(a))));
    if(targets.length!==1)throw Error('تعذر ربط حقل نور تلقائيًا بتقييم '+c.title+'؛ اختر تقييمًا وحقلًا يدويًا.');
    mapping.push({source:c,target:targets[0].index});
   }
   if(mapping.length!==7||new Set(mapping.map(m=>m.target)).size!==7)throw Error('التعبئة الجماعية تحتاج سبعة تقييمات متطابقة فريدة في CSV ونور.');
  }else mapping=[{source:csvSource.scoreColumns.find(c=>c.index===index),target}];
  const used=new Set(),planned=[],metrics={total:csvSource.rows.length,matched:0,unmatched:0,ambiguous:0,invalid:0,existing:0,empty:0};
  for(const student of csvSource.rows){
   const m=matchStudent(student,snapshot.rows,used);
   if(m.ambiguous){metrics.ambiguous++;continue;}
   if(!m.row){metrics.unmatched++;continue;}
   metrics.matched++;used.add(m.row.tr);
   for(const map of mapping){
    const field=m.row.fields[map.target]?.input;
    let raw=clean(student.cells[map.source.index]);
    if(raw===''&&!emptyZero){metrics.empty++;continue;}
    if(raw==='')raw='0';
    const num=Number(raw.replace(/[٠-٩]/g,d=>String(d.charCodeAt(0)-1632)));
    if(!Number.isFinite(num)||num<0||!/^\d+(?:\.\d+)?$/.test(String(raw))){metrics.invalid++;continue;}
    if(map.source.known&&num>map.source.known.max){metrics.invalid++;continue;}
    if(!field||!isNumericInput(field)||!m.row.tr.isConnected){metrics.invalid++;continue;}
    const minimum=field.min==null||field.min===''?null:Number(field.min);
    const maximum=field.max==null||field.max===''?null:Number(field.max);
    if((minimum!==null&&num<minimum)||(maximum!==null&&num>maximum)){metrics.invalid++;continue;}
    const old=field.value||'';
    if(old!==''&&!overwrite){metrics.existing++;continue;}
    planned.push({field,row:m.row.tr,name:student.name||student.id,num,old,category:map.source.title,method:m.method});
   }
  }
  const sample=planned.slice(0,12).map(p=>p.name+' | '+p.category+': '+(p.old||'فارغ')+' → '+p.num+' ('+p.method+')');
  plan={items:planned,table:snapshot.table,location:snapshot.location,created:Date.now(),mapping};
  return {ready:planned.length>0,count:planned.length,metrics,sample,batch:all};
 }
 function apply(){
  if(!plan||!plan.items.length)throw Error('نفّذ المطابقة والمعاينة قبل التعبئة.');
  if(plan.location!==location.href||!plan.table.isConnected)throw Error('تغيرت صفحة نور؛ أعد الفحص أولًا.');
  if(Date.now()-plan.created>5*60*1000)throw Error('انتهت صلاحية المعاينة؛ أعد الفحص.');
  let filled=0,skipped=0;
  for(const p of plan.items){
   if(!p.row.isConnected||!p.field.isConnected||!isNumericInput(p.field)||String(p.field.value||'')!==p.old){skipped++;continue;}
   const proto=p.field.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
   const setter=Object.getOwnPropertyDescriptor(proto,'value')?.set;
   if(setter)setter.call(p.field,String(p.num));else p.field.value=String(p.num);
   p.field.dispatchEvent(new Event('input',{bubbles:true}));p.field.dispatchEvent(new Event('change',{bubbles:true}));
   p.field.style.outline='2px solid #168a66';filled++;
  }
  plan=null;return {filled,skipped};
 }
 function reset(){csvSource=null;snapshot=null;plan=null;}
 globalThis.NoorCSVGrades=Object.freeze({parse,scan,planTransfer,apply,reset,
  get ready(){return!!csvSource},get rows(){return csvSource?.rows.length||0}});
})();
