# Noor Unified 2.8.43 — Named units and optional lesson tree

Based on 2.8.42. Preserves the same Mozilla extension ID, Firefox update URL, teacher accounts/licenses, Gemini services, Arabic-English learning activities, SCORM 1.2 and private notebook sync.

## What changed

1. **Automatic selection remains the default.** On a verified course's activity page, the add-on reads the lesson the teacher actually selected from the Noor **الدروس** form control. It accepts unit-lesson codes such as `4-4 الكائنات الدقيقة والغذاء` without demanding a separate lesson tree.
2. **Manual choice is additional.** Teachers can choose from a recognized Noor curriculum tree when available, or from the actual lesson options in Noor's form when that subject has no tree. The list is grouped under the unit names exposed by Noor; if the same course has a verified cached official unit name, that name is shown for numbered codes. Names are not fabricated.
3. **Named units.** Recognizes Arabic ordinal names (`الوحدة الأولى`, `الوحدة الثانية`, `الوحدة الثالثة: امتداد الإسلام ...`) plus official lesson titles. For uncoded lesson titles, the add-on requires an exact full lesson name rather than a numerical approximation.
4. **Science numbering.** `4-4` means **unit 4, lesson 4**. Choosing `4-3` cannot select `4-4`. Duplicate names/entries remain ambiguous and must be resolved manually.
5. **Homework publisher.** The existing assignment lesson picker now matches science unit-lesson codes and exact named lessons in Noor's actual `الدروس` dropdown. A choice among duplicates is no longer guessed.
6. **SCORM upload.** If the current SCORM form really lacks a tree, a recent teacher-confirmed lesson from Noor's form may stand in as lesson evidence; subject, grade, section, ZIP input and save conditions remain separately verified. It still never uploads into the cover image field. If there is a tree, it remains authoritative.
7. **No bypass of class verification.** A missing tree does not mean the wrong class may be used. Missing/ambiguous lesson lists still stop automation. For preparations where the original Noor preparation bridge requires a tree node ID, that bridge remains strict to prevent wrong lesson saves.

## Limitations

These checks use actual DOM forms rather than fabricated Noor APIs. Automated tests cover named units, Science `4-4`, exact selected options, duplicate/wrong-unit refusals and legacy English. A logged-in end-to-end Noor browser test has not been performed. Dynamic third-party Select2 widgets can differ; when the lesson cannot be verified, the extension leaves the submission unsaved.

For Mozilla signing, upload this archive to `addons/unified/` and run the repository's `release-noor-signed.yml` workflow for `2.8.43`. This source archive carries **no** valid Mozilla signature; sign using the existing GitHub workflow, not by copying an older signature.
