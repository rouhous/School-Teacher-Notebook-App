/* Noor course catalog 2.8.30. Learn course IDs from their real teacher-dashboard
 * cards and their own popover links, not from lesson/preparation/grade tables.
 * Only teacher-scoped, verified course IDs can be used for writing to Noor. */
(function(root){'use strict';
 if(!/^\/teacher(?:\/|$)/i.test(location.pathname))return;
 const KEY='stnCourseCatalog:v3:',MAX=40;
 const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
 const norm=s=>clean(s).normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[إأآ]/g,'ا').toLowerCase();
 const arabic=['','الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر','الحادي عشر','الثاني عشر'];
 const gradeWords='الحادي\\s+عشر|الثاني\\s+عشر|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول';
 const gradeRE=new RegExp('(?:^|[\\s\\/\\(\\)\\|:\\-])('+gradeWords+')(?=$|[\\s\\/\\(\\)\\|:\\-])','gi');
 const gradeNumeric=/(?:^|\s)(?:grade|class|الصف|صف)\s*[:\-]?\s*(1[0-2]|[1-9])(?:$|[\s\/-])/i;
 let teacher='',cache=[],lastCard='',lastCardAt=0,started=false,observer=null;
 function gradeOf(value){
  const s=clean(value);if(!s||s.length>210)return null;
  // A grade span, e.g. (12-11), is a school stage, never a class identity.
  const matches=[...s.matchAll(new RegExp(gradeRE.source,'gi'))];
  const words=matches.map(m=>arabic.findIndex(w=>norm(w)===norm(m[1]))).filter(n=>n>0);
  const numeric=gradeNumeric.exec(s);if(numeric)words.push(Number(numeric[1]));
  const unique=[...new Set(words)];return unique.length===1?unique[0]:null;
 }
 function classLabel(value){
  const s=clean(value);if(!s||s.length>190)return '';
  // Reject class-like text in preparation titles or activity rows.
  if(/(?:lesson|unit|theme|project|writing|grammar|vocabulary|reading|speaking|listening|review|overview|formative|assessment|تحضير|درس|وحدة|الاهداف|الأهداف|التقويم|الاختبار|انشطة|أنشطة|تاريخ|المراجعة|المهام|الطلبة|مفردات)/i.test(s))return '';
  if(/(?:^|\s)Grade\s*(?:1[0-2]|[1-9])\s*:/i.test(s))return '';
  const g=gradeOf(s);if(!g)return '';
  const subject=(s.match(/اللغة\s*الإنجليزية|اللغة\s*الانجليزية|اللغة\s*العربية|English|Mathematics|Science|الرياضيات|العلوم|التربية\s*الإسلامية/i)||[])[0]||'';
  const isStandalone=norm(s)===norm(arabic[g]) || new RegExp('^(?:الصف|صف)\\s+'+gradeWords+'$','i').test(s) || /^(?:grade|class)\s*\d{1,2}(?:\s*[-–]\s*\d{1,2})?$/i.test(s);
  if(!subject&&!isStandalone)return '';
  // Permit one section number, not a school stage range or unrelated prose.
  const section=(s.match(/(?:الحادي عشر|الثاني عشر|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول)\s*[-–]\s*(\d{1,2})(?=$|\s)/)||[])[1]||'';
  const subjectClean=subject?(/english/i.test(subject)?'English':norm(subject).includes('الانجليزي')?'اللغة الإنجليزية':subject):'';
  return (subjectClean?subjectClean+' / ':'')+arabic[g]+(section?' - '+section:'');
 }
 function localURL(value){try{const u=new URL(value,location.href);return u.origin===location.origin&&/^\/teacher\//i.test(u.pathname)&&/\/cid:/.test(u.pathname)?u:null}catch(_){return null}}
 function idOf(url){return decodeURIComponent(url.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'')}
 function service(url){const p=url.pathname;
  if(/\/teacher\/courses\/(?:preparations_index|add_preparation)/i.test(p))return 'preparation';
  if(/\/teacher\/homeworks\//i.test(p))return 'activities';
  if(/\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(p))return 'scorm';
  if(/\/teacher\/(?:grades|marks|scores|gradebook|assessments)/i.test(p))return 'grades';return 'course';
 }
 function add(record){const label=classLabel(record.label);if(!label)return false;const grade=gradeOf(label);if(!grade)return false;
  const cid=String(record.cid||''),numeric=/^\d+$/.test(cid)?cid:'',opaque=cid&&!numeric?cid:'';
  let item=numeric?cache.find(x=>x.cidNumeric===numeric):null;
  if(!item){const matches=cache.filter(x=>norm(x.label)===norm(label));if(matches.length===1)item=matches[0];}
  // Do not merge two same-grade sections or multiple different official IDs.
  if(item&&numeric&&item.cidNumeric&&item.cidNumeric!==numeric)return false;
  if(item&&opaque&&record.service==='scorm'&&item.cidOpaque&&item.cidOpaque!==opaque)return false;
  const first=!item;
  if(!item)item={label,grade,cidNumeric:'',cidOpaque:'',routes:{},observed:Date.now()};
  let changed=first;
  if(numeric&&!item.cidNumeric){item.cidNumeric=numeric;changed=true}
  if(opaque&&record.service==='scorm'&&!item.cidOpaque){item.cidOpaque=opaque;changed=true}
  if(record.url&&record.service&&item.routes[record.service]!==record.url){item.routes[record.service]=record.url;changed=true}
  if(changed){item.observed=Date.now();if(first)cache.push(item);if(cache.length>MAX)cache=cache.slice(-MAX)}
  return changed;
 }
 function courseCard(node){for(let p=node,n=0;p&&n<6;n++,p=p.parentElement){
  if(p.closest?.('#stnNoorHub'))return '';
  if(p.matches?.('tr,tbody,table,.preparation-list,.dataTables_wrapper'))return '';
  const type=String(p.className||'');
  if(!p.matches?.('article,.card,[class*="course"],[class*="subject"],[class*="material"],[class*="popover"],[class*="dropdown"]'))continue;
  const heading=p.querySelector('h2,h3,h4,.course-title,.course-name,.class-name,.title,strong');
  const text=clean(heading?.textContent||'');
  const h=classLabel(text);if(h)return h;
  if(clean(p.innerText||p.textContent).length<=220){const q=classLabel(p.innerText||p.textContent);if(q)return q;}
 }return ''}
 const isHome=()=>/^\/teacher\/?$/i.test(location.pathname);
 function scan(){let changed=false;
  if(isHome()){
   // Dashboard cards: show all teacher classes even if an ID requires opening a card.
   for(const c of document.querySelectorAll('article,.card,[class*="course-card"],[class*="material-card"],[class*="subject-card"]')){
    if(c.closest('#stnNoorHub'))continue;
    const label=courseCard(c)||classLabel(clean(c.innerText||c.textContent).slice(0,190));
    if(label)changed=add({label})||changed;
   }
   // Popover links can appear outside a card: associate them only with the
   // last course card the teacher explicitly clicked, never with a lesson row.
   for(const a of document.querySelectorAll('a[href*="cid:"],[data-href*="cid:"]')){
    const u=localURL(a.href||a.getAttribute('data-href'));if(!u)continue;
    const label=courseCard(a)||(Date.now()-lastCardAt<3500?lastCard:'');
    if(label)changed=add({label,cid:idOf(u),url:u.href,service:service(u)})||changed;
   }
  }else{
   // On other teacher pages tables contain dozens of Grade 10 lesson titles.
   // Never enumerate their links as if they were the teacher's classes.
   const numeric=idOf({pathname:location.pathname});
   const item=cache.find(x=>x.cidNumeric===numeric);
   if(item&&/^(?:\d+)$/.test(numeric)){
    const type=service({pathname:location.pathname});if(type!=='course'){
     const safe=location.origin+location.pathname;
     if(item.routes[type]!==safe){item.routes[type]=safe;item.observed=Date.now();changed=true;}
    }
   }
  }
  if(changed){persist();window.dispatchEvent(new CustomEvent('stnCourseCatalogChanged'))}
 }
 async function persist(){if(!teacher)return;try{await browser.storage.local.set({[KEY+teacher]:cache})}catch(_){}}
 async function init(){if(started)return;started=true;teacher=String(await root.NOOR_TEACHER_PROFILE?.active?.()||'');
  // V3 discards unreliable cached entries gathered from lesson titles in V2.
  try{const r=await browser.storage.local.get(KEY+teacher);const saved=r[KEY+teacher];if(Array.isArray(saved))cache=saved.slice(-MAX).filter(x=>classLabel(x.label)&&x.grade===gradeOf(x.label)&&x.routes&&typeof x.routes==='object');}catch(_){ }
  if(cache.length)window.dispatchEvent(new CustomEvent('stnCourseCatalogChanged'));
  document.addEventListener('click',e=>{if(document.getElementById('stnNoorHub')?.contains(e.target))return;
   if(isHome()){const label=courseCard(e.target);if(label){lastCard=label;lastCardAt=Date.now()}}
   setTimeout(scan,320);
  },{capture:true});
  observer=new MutationObserver(()=>{clearTimeout(observer.tick);observer.tick=setTimeout(scan,650)});
  observer.observe(document.documentElement,{childList:true,subtree:true});scan();
 }
 root.NoorCourseCatalog=Object.freeze({init,scan,all:()=>cache.map(x=>({...x,routes:{...x.routes}})),get:c=>cache.find(x=>x.cidNumeric===String(c)||norm(x.label)===norm(c))||null,gradeOf,classLabel});
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})(typeof globalThis==='object'?globalThis:this);
