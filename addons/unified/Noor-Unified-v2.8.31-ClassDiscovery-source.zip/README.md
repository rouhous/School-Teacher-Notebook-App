# Noor Unified Tools — 2.8.31 (dashboard class discovery)

- Fix: discover real teacher course tiles on the Noor dashboard even if Noor uses Bootstrap columns rather than `.card` elements.
- Preserve one teacher course label for each grade; collect the official course CID only from a clicked tile and its services popover.
- On course pages, use only the explicit class heading and numeric CID; never parse historic preparation or activity table rows as classes.
- Refresh on menu open, DOM changes, tab focus and page restoration.
- Clicking an unlinked class attempts to expose the official class-services popup; publication remains blocked until CID verification.
- Keep the same Firefox ID, existing Gemini keys, grades, pipeline and drag UI.
- Regression tests validate dashboards with bare columns, stage ranges, nested text, table-noise exclusion and class popover association.
- Tested locally on mock Noor structures; final acceptance requires testing on authenticated Noor.
