# Noor Unified Tools 2.8.38 — Omani gamified SCORM courses

- The teacher chooses the verified subject, class, semester, **unit and exact lesson** as before. The dedicated SCORM request asks Gemini for a **modern Omani learning adventure**, not plain multiple-choice questions.
- Gemini returns **strict structured educational content**: lesson-specific introduction, a narrative mission, learning objectives, hints, explanations, and four types of challenges: MCQ, true/false, sequence ordering, and matching. The validator rejects duplicated questions, malformed answers, or insufficient variety.
- A fixed and locally tested SCORM 1.2 renderer packages the generated activities into an **offline ZIP**, containing a responsive ocean/fort/dhow/mountains illustration, three progression stages, stars, helpful feedback, a progress bar, and final score. No AI-generated executable code or third-party runtime dependencies are injected.
- Student progress and scores are sent to Noor if its SCORM 1.2 runtime API is available. Generation and download continue even if the SCORM upload form lacks enough class evidence; **upload is still guarded** and is not claimed to be automatically saved unless Noor's official controls can be verified in a live session.
- Teacher authorization and Gemini-key separation from 2.8.37 remain unchanged. No user quota, no revocation of older versions.

## Testing

- JavaScript syntax checks for all bundled scripts.
- Structured Gemini-content generator tested with an authorized teacher-key mock; curriculum unit, lesson and Omani design instructions are included in the actual prompt.
- ZIP structure / SCORM 1.2 manifest validation / question data and runtime JS syntax tests.
- Chromium mobile-size browser test successfully navigated MCQ, true/false, ordering, matching and reached the final score, with no runtime errors.
- **Not yet verified:** complete authenticated Noor SCORM upload / final save and live Gemini output for all grades. Do not represent ZIP creation as successful publishing on Noor.
