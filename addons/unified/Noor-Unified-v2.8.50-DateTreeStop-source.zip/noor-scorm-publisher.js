/* Noor Unified 2.8.48 — SCORM page-to-page publisher (Firefox content script).
 * Never sends a file to an invented endpoint. Uses the teacher's visible Noor
 * navigation, selects only uniquely identified form controls, verifies class
 * before attaching, and never claims a submission succeeded from a click.
 * Unknown Noor UI => stop, preserve the package, explain the blocker.
 */
(function(root){'use strict';
 if(window.top!==window||!/^\/teacher(?:\/|$)/i.test(location.pathname)||root.NoorScormPublisher)return;
 const JOB='stnScormPublishJob:v1',FILE='stnScormTempZip:v1:',MAX=5*1024*1024,TTL=45*60*1000;
 const norm=s=>String(s||'').normalize('NFKC').replace(/[إأآ]/g,'ا').replace(/ة/g,'ه').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const tidy=s=>String(s||'').replace(/\s+/g,' ').trim();
 const sleep=t=>new Promise(r=>setTimeout(r,t));
 const inHub=el=>Boolean(el?.closest?.('#stnNoorHub,#noor-prep-panel'));
 const visible=el=>Boolean(el&&el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden');
 const UPLOAD_TITLE=/^(?:رفع درس تفاعلي جديد|انشاء درس تفاعلي(?: جديد)?|اضافه الدرس(?: التفاعلي)?|اضافه درس تفاعلي(?: جديد)?)$/;
 const LESSONS_ACTION=/^(?:مكتبه )?الدروس التفاعليه$/;
 const REPOSITORY_ACTION=/^(?:المكتبه الرقميه|المكتبه الالكترونيه|المستودع الرقمي)$/;
 const CREATE_ACTION=/^(?:رفع|انشاء|اضافه) (?:درس|مساق) تفاعلي(?: جديد)?$|^اضافه الدرس(?: التفاعلي)?$/;
 const pageHeaders=()=>[...document.querySelectorAll('h1,h2,h3,h4,h5,h6,[role="heading"],.page-title,.card-title')]
   .filter(e=>visible(e)&&!inHub(e)).map(e=>norm(e.innerText||e.textContent));
 const onUploadPage=()=>/\/teacher\/attachments\/upload\/scorm(?:\/|$)/i.test(location.pathname)
   ||pageHeaders().some(h=>UPLOAD_TITLE.test(h));
 const isScormForm=()=>onUploadPage()&&Boolean(optionOfRadio('SCORM'));
 const get=()=>{try{const j=JSON.parse(sessionStorage.getItem(JOB)||'null');if(!j)return null;if(Date.now()-j.at>TTL){sessionStorage.removeItem(JOB);return null}return j}catch(_){return null}};
 const set=j=>sessionStorage.setItem(JOB,JSON.stringify({...j,updated:Date.now()}));
 function confirmedSaved(j){
  if(!j?.batchTag||isScormForm())return false;
  // A batch-specific nonce is put in the uploaded *title* before submission.
  // A single actual Noor listing row bearing it is evidence of one new record.
  const expected=norm('STN-'+j.batchTag);
  const rows=[...document.querySelectorAll('table tbody tr,[role="row"]')].filter(e=>visible(e)&&!inHub(e));
  const found=rows.filter(e=>norm(e.textContent).includes(expected));
  if(found.length!==1)return false;
  j.phase='done';j.confirmedAt=Date.now();set(j);
  browser.storage.local.remove(fileKey(j)).catch(()=>{});
  root.dispatchEvent(new CustomEvent('stnNoorScormConfirmed',{detail:{id:j.id,batchTag:j.batchTag}}));
  return true;
 }
 function notice(message){
  const panel=document.getElementById('stnHubPanel'),s=document.getElementById('stnHubStatus');
  if(panel)panel.hidden=false;
  const svc=document.getElementById('stnHubService');if(svc&&svc.value!=='scorm'){svc.value='scorm';svc.dispatchEvent(new Event('change',{bubbles:true}));}
  if(s)s.textContent=String(message);
 }
 async function teacher(){try{return String(await root.NOOR_TEACHER_PROFILE?.active?.()||'')}catch(_){return ''}}
 const fileKey=j=>FILE+j.id;
 // Firefox content-script Xray wrappers can reject Uint8Array.subarray() with
 // "Permission denied to access property constructor" (Mozilla bug 1868675).
 // Access bytes only by index; do not use slice/subarray/apply on typed views.
 function encode(bytes){
  const parts=[];let block='';
  for(let i=0;i<bytes.length;i++){
   block+=String.fromCharCode(bytes[i]);
   if(block.length===8192){parts.push(block);block='';}
  }
  if(block)parts.push(block);
  return btoa(parts.join(''));
 }
 function decode(str){const s=atob(str);const a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return a}
 async function cleanup(j){if(!j)return;try{await browser.storage.local.remove(fileKey(j))}catch(_){}sessionStorage.removeItem(JOB)}
 async function cancel(){const j=get();await cleanup(j);notice(j?.phase==='submitted_unknown'?'ألغيت المتابعة في الإضافة؛ ربما وصل أمر الحفظ إلى نور بالفعل. تحقق من المكتبة قبل إنشاء درس جديد.':'ألغي النشر المعلّق دون إرسال أمر حفظ جديد. احتفظت بنسخة SCORM المنزلة.');}
 async function start(file,opts){
  const stopToken=sessionStorage.getItem('stnNoorStopAll:v1');
  if(!file||file.size<100||file.size>MAX)throw Error('الملف كبير جدًا للتنقل التلقائي (الحد 5 ميغابايت) أو فارغ. احتفظ بالنسخة المنزلة وارفعها يدويًا.');
  if(!/\.zip$/i.test(file.name)||!root.NoorScorm?.hasManifest?.(await file.arrayBuffer()))throw Error('حزمة SCORM ليست ZIP صالحًا بملف imsmanifest.xml.');
  if(get()&&get().phase!=='done')throw Error('هناك عملية SCORM قائمة أو غير مؤكدة؛ استكملها وتحقق من نتيجتها أو ألغ المتابعة بعد فحص نور، قبل بدء عملية جديدة.');
  const t=await teacher();
  if(!t||!opts.teacherId||t!==String(opts.teacherId))throw Error('لم تثبت هوية المعلم قبل نقل ملف SCORM.');
  const c=opts.course;
  if(!c?.verified||!/^\d+$/.test(String(c.cid||''))||!c.grade||!c.label||!c.subject||norm(c.subject)!==norm(opts.subject))throw Error('لم تثبت المادة والصف من بطاقة نور.');
  if(!opts.unit||!opts.lesson)throw Error('تحديد الوحدة والدرس في شجرة نور مطلوب.');
  const existing=get();if(existing)await cleanup(existing);
  const j={id:'s'+Date.now()+'-'+Math.random().toString(36).slice(2,9),at:Date.now(),teacherId:t,
   mode:opts.mode==='auto'?'auto':'review',phase:'route',step:'',navigation:[],
   cid:String(c.cid),grade:Number(c.grade),label:tidy(c.label),subject:tidy(opts.subject),
   semester:String(opts.semester),unit:tidy(opts.unit),lesson:tidy(opts.lesson),
   batchTag:/^[a-f0-9-]{1,24}$/i.test(String(opts.batchTag||''))?String(opts.batchTag):'',publishDate:String(opts.publishDate||''),
   filename:file.name,formPath:'',verifiedLesson:false,attached:false,lessonEvidence:opts.lessonEvidence||null};
  const bin=encode(new Uint8Array(await file.arrayBuffer()));
  try{await browser.storage.local.set({[fileKey(j)]:{at:j.at,teacherId:t,name:file.name,base64:bin}})}
  catch(e){throw Error('لم أستطع حفظ نسخة SCORM مؤقتًا أثناء التنقل: '+String(e?.message||e))}
  if(stopToken!==sessionStorage.getItem('stnNoorStopAll:v1')){
   await browser.storage.local.remove(fileKey(j));
   throw Error('أُلغيت تعبئة SCORM.');
  }
  waitingSince=0;
  set(j);notice('حُفظ ملف SCORM مؤقتًا؛ جارٍ فتح المكتبة الرقمية ثم الدروس التفاعلية للصف المحدد.');
  scheduleAdvance(j,250);
  return {ok:true,queued:true,id:j.id};
 }
 function actionText(e){
  return [e.innerText||e.textContent,e.value,e.getAttribute('aria-label'),e.title].map(norm)
   .map(value=>value.replace(/^[\s+＋]+|[\s+＋]+$/g,''));
 }
 function uniqueLink(regex,scope=document){
  const nodes=[...scope.querySelectorAll('a,button,[role="button"],[role="tab"],[onclick],input[type="button"],input[type="submit"]')]
   .filter(e=>visible(e)&&!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&!inHub(e))
   .filter(e=>actionText(e).some(v=>regex.test(v)));
  const actions=new Set(nodes.map(e=>e.closest('a,button,[role="tab"],[role="button"]')||e));
  return [...actions].filter(e=>![...actions].some(parent=>parent!==e&&parent.contains(e)));
 }
 function oneAction(regex,scope){const actions=uniqueLink(regex,scope);return actions.length===1?actions[0]:null}
 function visiblePopover(){return [...document.querySelectorAll('.popover,.dropdown-menu,[role="menu"],[role="dialog"],[class*="course-actions"]')]
    .filter(e=>visible(e)&&!inHub(e)&&tidy(e.textContent).length<1400)}
 function activeBookCourse(j){const known=root.NoorCourseCatalog?.get?.(j.cid);return Boolean(known&&Number(known.grade)===j.grade&&norm(known.label)===norm(j.label))}
 const isCourseHome=()=>/^\/teacher\/?$/i.test(location.pathname);
 const activityInUse=()=>{
  const choice=document.getElementById('stnHubService')?.value;
  return choice==='activities'||(choice!=='scorm'&&/^\/teacher\/(?:homeworks|questions)(?:\/|$)/i.test(location.pathname));
 };
 let advanceTimer, waitingSince=0, waitingURL='';
 function scheduleAdvance(j,delay=400){
  clearTimeout(advanceTimer);
  advanceTimer=setTimeout(()=>{const active=get();if(active?.id===j.id&&active.phase!=='paused')advance();},delay);
 }
 function takeNavigation(j,action,label){
  if(!action||!visible(action))return false;
  const target=action.closest('a')||action;
  if(target.tagName==='A'&&target.href&&!target.getAttribute('href')?.startsWith('#')&&
     !/^javascript:\s*(?:void\s*\(0\)|;?)\s*;?$/i.test(target.getAttribute('href')||'')){
   const u=new URL(target.href,location.href);
   if(u.origin!==location.origin||!/^\/teacher(?:\/|$)/i.test(u.pathname)||
      /\/teacher\/(?:homeworks|questions)(?:\/|$)/i.test(u.pathname))return false;
  }
  const key=location.href+'|'+label;
  if(j.navigation?.includes(key))return false;
  if((j.navigation?.length||0)>=10)throw Error('تعذر الوصول إلى نموذج إضافة الدرس بعد عدة خطوات.');
  j.navigation=[...(j.navigation||[]),key];j.phase='route';j.step=label;set(j);
  waitingSince=0;
  notice('جارٍ فتح «'+label+'»…');
  if(target.tagName==='A'&&target.target==='_blank')target.target='_self';
  target.click();
  scheduleAdvance(j);
  return true;
 }
 function pause(j,reason){if(!j)return;const reasonText=String(reason||'تعذر تحديد النموذج').slice(0,350);
  j.phase='paused';j.reason=reasonText;set(j);
  notice('توقفت تعبئة SCORM. '+reasonText+' الملف محفوظ مؤقتًا. بعد مراجعة الصفحة اضغط «استكمال تعبئة SCORM».');
 }
 function pickNav(j){
  const headings=pageHeaders();
  const lessonsTab=oneAction(LESSONS_ACTION);
  const inLessons=headings.some(h=>LESSONS_ACTION.test(h))||j.step==='الدروس التفاعلية'||
   /\/teacher\/attachments\/index\/scorm(?:\/|$)/i.test(location.pathname);
  if((inLessons||lessonsTab)&&takeNavigation(j,oneAction(CREATE_ACTION),'إضافة الدرس'))return true;
  if(inLessons||j.step==='إضافة الدرس')return false;
  if(takeNavigation(j,lessonsTab,'الدروس التفاعلية'))return true;
  if(j.step==='المكتبة الرقمية'||headings.some(h=>REPOSITORY_ACTION.test(h)))return false;
  const repository=oneAction(REPOSITORY_ACTION);
  if(takeNavigation(j,repository,'المكتبة الرقمية'))return true;
  if(takeNavigation(j,oneAction(/^اداره المحتوى$/),'إدارة المحتوى'))return true;
  const menu=visiblePopover().filter(p=>/تحضير الدروس|اداره المحتوى|المرفقات|المكتبه الرقميه/.test(norm(p.textContent)));
  if(menu.length===1&&takeNavigation(j,oneAction(/^(?:التالي|next|2|›|»)$/,menu[0]),'التالي في قائمة إدارة المحتوى'))return true;
  if(isCourseHome()&&menu.length===0){
   const matches=(root.NoorCourseCatalog?.cards?.()||[]).filter(c=>norm(c.label)===norm(j.label));
   if(matches.length>1)throw Error('ظهرت أكثر من بطاقة مطابقة للصف. اختر بطاقة الصف في نور.');
   if(matches.length===1){
    const card=matches[0].element;
    const button=card.querySelector('[data-toggle="popover"],[data-bs-toggle="popover"],button,[role="button"]')||card;
    if(takeNavigation(j,button,'قائمة مادة '+j.label))return true;
   }
  }
  return false;
 }
 function nearText(el){
  // Inspect only the *nearest* compact control group. Walking up to the full
  // form accidentally picks up the separate "صورة الغلاف" upload label.
  let node=el.parentElement;
  for(let depth=0;node&&depth<5;depth++,node=node.parentElement){
   if(node.tagName==='FORM'||node.tagName==='BODY')break;
   const direct=tidy(node.textContent);
   if(direct&&direct.length<135)return direct;
  }
  return '';
 }
 function fieldText(el){return norm([el.getAttribute('placeholder'),el.id,el.name,el.getAttribute('aria-label'),
  [...(el.labels||[])].map(x=>x.textContent).join(' '),el.closest('.form-group,.form-row,.form-control')?.querySelector('label')?.textContent,nearText(el)].join(' '))}
 function searchField(filter,selectors){
  const matches=[...document.querySelectorAll(selectors)].filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&filter(fieldText(e),e));
  if(matches.length===1)return matches[0];
  // Prefer an exact placeholder/name/id over a broad surrounding form-group.
  const direct=matches.filter(e=>filter(norm([e.placeholder,e.id,e.name,e.getAttribute('aria-label')].join(' ')),e));
  return direct.length===1?direct[0]:null;
 }
 function nativeValue(el,value){const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value')?.set?.call(el,String(value));el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
 function fileInput(){
  const inputs=[...document.querySelectorAll('input[type="file"]')].filter(e=>!e.disabled&&!inHub(e));
  const describe=e=>norm([e.id,e.name,e.accept,e.getAttribute('aria-label'),[...(e.labels||[])].map(l=>l.textContent).join(' '),nearText(e)].join(' '));
  const cover=/(?:غلاف|صوره|صورة|cover|image|jpe?g|png|webp|avatar)/;
  const zip=/(?:scorm|zip|ملف|file|رفع|drop|upload)/;
  const explicit=inputs.filter(e=>{const own=norm([e.accept,e.id,e.name].join(' '));return !cover.test(own)&&/zip|scorm|compressed/.test(own);});
  if(explicit.length===1)return explicit[0];
  const candidates=inputs.filter(e=>!cover.test(describe(e))&&zip.test(describe(e)));
  if(candidates.length===1)return candidates[0];

  return null;
 }
 function optionOfRadio(text){const want=norm(text);
  const radios=[...document.querySelectorAll('input[type="radio"]')].filter(e=>!e.disabled&&!inHub(e));
  const hits=radios.filter(e=>{const direct=norm([e.value,e.id,e.getAttribute('aria-label'),...[...(e.labels||[])].map(x=>x.textContent)].join(' '));
   const near=norm(e.closest('label,.form-check,.radio,.custom-control')?.textContent||'');
   return new RegExp('(?:^|[^a-z0-9])'+want+'(?:$|[^a-z0-9])').test(direct+' '+near);
  });
  return hits.length===1?hits[0]:null;
 }
 function treeNodes(){
  const selectors='.jstree-anchor,.fancytree-title,[role="treeitem"],.tree-node-title,.treeview a,.tree a,.ztree a,[data-lesson-id]';
  return [...document.querySelectorAll(selectors)].filter(e=>visible(e)&&!inHub(e)&&!e.closest('nav')&&
    (e.matches('[role="treeitem"]')?Boolean(e.closest('[aria-label*="دروس"],[aria-label*="lesson"],.lesson-tree,.curriculum-tree')):true));
 }
 function unitNodes(nodes,j){
  const exact=nodes.filter(e=>norm(e.textContent)===norm(j.unit));
  if(exact.length)return exact;
  const number=root.NoorLessonNumbers?.number,unitNumber=number?.(j.unit,'unit');
  return unitNumber?nodes.filter(e=>{
   const title=norm(e.textContent);
   return /^(?:unit|theme|الوحده|المحور|\d+\s+[^\d-])/i.test(title)&&
    !/(?:lesson|الدرس|درس)\s*[:#.-]?\s*\d/i.test(title)&&number?.(title,'unit')===unitNumber;
  }):[];
 }
 function treeCandidate(j){
  const nodes=treeNodes(),number=root.NoorLessonNumbers?.number;
  const unitNumber=number?.(j.unit,'unit');
  const units=unitNodes(nodes,j);
  if(units.length>1)return null;
  const branch=units[0]?.closest('li,[role="treeitem"]');
  const candidates=nodes.filter(e=>e!==units[0]&&(!branch||branch.contains(e)));
  const exact=candidates.filter(e=>{
   if(norm(e.textContent)!==norm(j.lesson))return false;
   const pair=root.NoorLessonEvidence?.code?.(e.textContent);
   return !pair||!unitNumber||pair.unit===unitNumber;
  });
  const n=number?.(j.lesson,'lesson');
  if(exact.length===1&&(!n||branch||!/^(?:lesson|الدرس|درس)?\s*\d+$/i.test(norm(j.lesson))))return exact[0];
  if(exact.length>1||!n)return null;
  const short=candidates.filter(e=>{
   const t=tidy(e.textContent);if(!t||t.length>=170)return false;
   const pair=root.NoorLessonEvidence?.code?.(t);
   if(pair)return pair.unit===unitNumber&&pair.lesson===n;
   return Boolean((branch||number?.(t,'unit')===unitNumber&&unitNumber)&&
    /(?:lesson|الدرس|درس)\s*[:#.-]?\s*\d/i.test(t)&&number?.(t,'lesson')===n);
  });
  return short.length===1?short[0]:null;
 }
 async function expandUnitIfPossible(j){
  const exact=unitNodes(treeNodes(),j);
  if(exact.length!==1)return false;
  const unit=exact[0],branch=unit.closest('li,[role="treeitem"]')||unit;
  const toggle=branch.querySelector('.jstree-ocl,.fancytree-expander,[aria-label*="expand"],button[aria-expanded="false"]');
  if(toggle&&visible(toggle)){toggle.click();await sleep(500);return true}
  if(unit.getAttribute('aria-expanded')==='false'){unit.click();await sleep(500);return true}
  return false;
 }
 function treeSelected(node){if(!node)return false;
  const scope=node.closest('li,[role="treeitem"]')||node;
  return Boolean(node.getAttribute('aria-selected')==='true'||scope.getAttribute('aria-selected')==='true'||
   node.classList.contains('jstree-clicked')||node.classList.contains('fancytree-selected')||
   scope.classList.contains('jstree-checked')||scope.classList.contains('jstree-clicked')||
   scope.classList.contains('selected')||scope.querySelector('input[type="checkbox"]:checked'));
 }
 function treeOpen(){return uniqueLink(/^(?:عرض الشجره|عرض الشجرة|شجره الدروس|شجرة الدروس)$/i)}
 function exactSaveButton(input){const scope=input.closest('form')||document;
  const els=[...scope.querySelectorAll('button,input[type="submit"],a.btn')]
  .filter(e=>visible(e)&&!e.disabled&&!inHub(e));
  const names=/^(?:حفظ|حفظ ونشر|نشر|اضافه|اضافه الدرس|رفع|save|publish|submit)$/i;
  const matches=els.filter(e=>names.test(norm(e.textContent||e.value||e.title)));
  return matches.length===1?matches[0]:null;
 }
 function requiredUnfilled(){return [...document.querySelectorAll('input[required],select[required],textarea[required]')]
  .filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&e.type!=='hidden'&&e.type!=='radio'&&e.type!=='checkbox'&&e.type!=='file')
  .filter(e=>!String(e.value||'').trim());}
 async function stage(j){
  if(!isScormForm())throw Error('نموذج رفع درس تفاعلي جديد في نور غير مفتوح أو لم يكتمل تحميله.');
  const c=root.NoorCourseCatalog?.get?.(j.cid);
  if(!c||norm(c.label)!==norm(j.label)||Number(c.grade)!==j.grade||norm(root.NoorCourseCatalog?.subjectOf?.(c.label)||'')!==norm(j.subject))throw Error('الصف أو المادة الحالية لا تطابق اختيارك.');
  const course={cid:j.cid,grade:j.grade,label:j.label,subject:j.subject,verified:true};
  const type=optionOfRadio('SCORM');
  if(!type.checked)type.click();
  if(!type.checked)throw Error('تعذر تحديد SCORM في نوع الدرس.');
  for(let attempt=0;attempt<20&&!fileInput();attempt++)await sleep(250);
  if(get()?.id!==j.id)return;
  const input=fileInput();if(!input)throw Error('لم تظهر خانة ZIP المميزة بعد اختيار SCORM.');
  const result=root.NoorScormClassEvidence?.ensureSelected?.(course);
  if(!result?.ok)throw Error('لم أتحقق من كتاب الصف والفصل المراد النشر له: '+(result?.reason||'not_found'));
  const helper=root.NoorLessonEvidence;
  const liveList=helper?.scan?.(document);
  const live=liveList&&helper.resolveFromList(liveList,j);
  const title=searchField(s=>/العنوان|\btitle\b/i.test(s),'input[type="text"],input:not([type]),textarea');
  if(!title)throw Error('لم أميز حقل عنوان الدرس عن باقي الحقول.');
  const wantedTitle=j.unit+' — '+j.lesson+(j.batchTag?' • STN-'+j.batchTag:'');
  if(!title.value||norm(title.value)!==norm(wantedTitle))nativeValue(title,wantedTitle);
  const desc=searchField(s=>/الوصف|\bdescription\b/i.test(s),'textarea,input[type="text"]');
  if(desc&&!desc.value)nativeValue(desc,'درس تفاعلي في '+j.subject+' — '+j.unit+' — '+j.lesson);
  const preparation=searchField(s=>/التحضير|preparation/i.test(s),'textarea,input[type="text"]');
  if(preparation&&!preparation.value)nativeValue(preparation,j.subject+' • '+j.unit+' • '+j.lesson);
  const languages=[...document.querySelectorAll('select')].filter(e=>visible(e)&&!inHub(e)&&/اللغة|language/.test(fieldText(e)));
  if(languages.length===1&&!languages[0].value){const matching=[...languages[0].options].filter(o=>/english|الانجليزيه/.test(norm(o.textContent)));if(matching.length===1)nativeValue(languages[0],matching[0].value)}
  const date=searchField(s=>/تاريخ النشر|publish.*date|publication.*date/.test(s),'input[type="date"],input[type="text"]');
  if(date&&date.type==='date'){
   const local=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
   if(!date.value)nativeValue(date,/^\d{4}-\d{2}-\d{2}$/.test(j.publishDate)?j.publishDate:local);
  }
  // Text-calendar widgets are not standardized and may require a picker. Never
  // submit a required publication date that Noor has not itself accepted.
  const dateConfirmed=Boolean(date&&String(date.value||'').trim());
  if(!treeCandidate(j)){
   const open=treeOpen();
   if(open.length===1&&j.phase!=='tree_opened'){
    j.phase='tree_opened';set(j);open[0].click();await sleep(800);
   }
  }
  if(get()?.id!==j.id)return;
  if(!treeCandidate(j))await expandUnitIfPossible(j);
  if(get()?.id!==j.id)return;
  const tree=treeCandidate(j);
  if(tree&&!treeSelected(tree)){
   j.phase='tree_selection';set(j);tree.click();await sleep(450);
  }
  const selected=treeSelected(treeCandidate(j));
  // Some Noor subjects have NO lesson tree on the SCORM form. Only if the tree
  // and tree opener are both absent, accept an earlier verified selection from
  // the *real Noor lesson dropdown* of the same teacher/class. Never synthesize
  // this evidence from the title we just inserted into the upload form.
  const e=j.lessonEvidence;
  const numbers=root.NoorLessonNumbers;
  const unitNumber=numbers?.number?.(j.unit,'unit');
  const sameUnit=(a,b)=>Boolean(a&&b&&(norm(a)===norm(b)||(unitNumber&&numbers?.number?.(a,'unit')===unitNumber)));
  const noTree=!treeNodes().length&&!treeOpen().length;
  const liveProof=Boolean(live?.ok&&sameUnit(live.unit,j.unit));
  const previousProof=['form','unit_batch'].includes(e?.source)&&
   (e.source!=='unit_batch'||(e.teacherApproved===true&&j.batchTag&&(e.control||e.optionValue)))&&
   (e.selected===true||e.teacherChosen===true||e.source==='unit_batch')&&Number.isFinite(Number(e.observedAt))&&
   Math.abs(Date.now()-Number(e.observedAt))<TTL&&norm(e.title)===norm(j.lesson)&&sameUnit(e.unit,j.unit);
  const formProof=noTree&&(liveProof||previousProof);
  if(!selected&&!formProof){
   throw Error('تعذر مطابقة الوحدة والدرس. اختر الدرس من شجرة نور أو قائمة «الدروس» في النموذج، ثم استكمل التعبئة.');
  }
  if(get()?.id!==j.id)return;
  j.verifiedLesson=true;
  if(!input.files?.length){const temp=(await browser.storage.local.get(fileKey(j)))[fileKey(j)];
   if(get()?.id!==j.id)return;
   if(!temp||temp.teacherId!==j.teacherId||temp.name!==j.filename)throw Error('اختفى الملف المؤقت أو اختلف حساب المعلم.');
   const bytes=decode(temp.base64),file=new File([bytes],temp.name,{type:'application/zip'});
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;
   input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  }
  if(!input.isConnected||input.files?.length!==1||input.files[0].name!==j.filename)throw Error('لم يتأكد إرفاق الملف إلى حقل SCORM الصحيح.');
  j.attached=true;j.formPath=location.pathname;j.phase='staged';set(j);
  const preview=document.getElementById('stnHubPreview');
  if(preview){preview.hidden=false;preview.textContent='معاينة الدرس التفاعلي قبل الحفظ\nالصف: '+j.label+'\nالمادة: '+j.subject+
   '\nالفصل: '+j.semester+'\nالوحدة: '+j.unit+'\nالدرس: '+j.lesson+'\nSCORM: '+j.filename+
   '\nحالة الرفع: ملف مرتبط بخانة ZIP\nتاريخ النشر: '+(dateConfirmed?date.value:'غير محدد');}
  notice('✓ تم تجهيز مسودة SCORM: الصف والدرس والملف ونوع SCORM مؤكدون. '+(j.mode==='auto'?'جارٍ فحص صلاحية الحفظ...':'ظهرت معاينة بيانات الدرس في لوحة الإضافة؛ راجعها واحفظ من نور. لم أضغط حفظ.'));
  if(j.mode!=='auto')return;
  await sleep(1500);
  if(!dateConfirmed)throw Error('تاريخ النشر لم يُؤكّد في نور. اختره من التقويم قبل الحفظ التلقائي.');
  // The portal may need time to finish processing ZIP after change event.
  if(get()?.id!==j.id)return;
  if(location.pathname!==j.formPath||!input.isConnected||input.files?.length!==1||!(treeSelected(treeCandidate(j))||formProof)||!type.checked)throw Error('تغيّر النموذج أثناء تجهيز الملف؛ أوقف الحفظ.');
  if(requiredUnfilled().length)throw Error('في نموذج نور حقول مطلوبة غير مكتملة؛ توقفت قبل الحفظ.');
  const button=exactSaveButton(input);
  if(!button)throw Error('زر الحفظ/النشر النهائي غير مميز بدقة في هذه النسخة من نور. لم يُضغط حفظ.');
  j.phase='submitted_unknown';j.submittedAt=Date.now();set(j);
  notice('تم الضغط على زر الحفظ مرة واحدة. التحقق من قبول نور جارٍ؛ لا تكرر الإرسال.');
  button.click();
 }
 let running=false;
 async function advance(){
  if(running)return;
  const j=get();if(!j||activityInUse()||!['route','tree_opened','tree_selection'].includes(j.phase))return;
  running=true;
  try{
   const t=await teacher();if(t!==j.teacherId)throw Error('تغيّر حساب المعلم؛ لن يُستخدم ملف معلم آخر.');
   root.NoorCourseCatalog?.scan?.();
   if(get()?.id!==j.id)return;
   if(!activeBookCourse(j)){
    if(waitForPage(j))return;
    throw Error('الصف المحدد لا يطابق بطاقة المادة المسجلة في نور.');
   }
   if(!isScormForm()){
    if(!onUploadPage()&&pickNav(j))return;
    if(waitForPage(j))return;
    if(onUploadPage())throw Error('ظهر نموذج إضافة الدرس، لكن لم يظهر خيار SCORM فيه.');
    throw Error('لم أجد الخطوة التالية في «المكتبة الرقمية ← الدروس التفاعلية ← إضافة الدرس».');
   }
   await stage(j);
  }catch(e){pause(get(),String(e?.message||e))}finally{running=false}
 }
 function waitForPage(j){
  if(waitingURL!==location.href||!waitingSince){waitingURL=location.href;waitingSince=Date.now();}
  if(Date.now()-waitingSince>=8500)return false;
  scheduleAdvance(j);
  return true;
 }
 async function resume(){
  if(running)return;
  const j=get();if(!j){notice('لا توجد عملية تعبئة SCORM معلقة. استورد حزمة ثم اضغط زر التعبئة.');return}
  if(j.phase==='done'){notice('✓ تأكد ظهور SCORM في القائمة.');return}
  if(j.phase==='submitted_unknown'){if(confirmedSaved(j)){notice('✓ تأكد ظهور SCORM في القائمة.');return;}notice('سبق الضغط على حفظ. افتح قائمة الدروس للتحقق، دون تكرار الإرسال.');return}
  if(j.phase==='staged'&&isScormForm()&&fileInput()?.files?.[0]?.name===j.filename){notice('المسودة جاهزة للمراجعة والحفظ من نموذج نور.');return}
  j.phase='route';j.navigation=[];j.step='';set(j);waitingSince=0;
  notice('جارٍ استكمال تعبئة SCORM من الصفحة الحالية...');advance();
 }
 root.NoorScormPublisher=Object.freeze({start,resume,cancel,onUploadPage,inspect:()=>{const j=get();return j?{id:j.id,phase:j.phase,grade:j.grade,lesson:j.lesson,mode:j.mode,reason:j.reason,batchTag:j.batchTag}:null}});
 setTimeout(()=>{const j=get();if(j&&!activityInUse()){
   if(j.phase==='submitted_unknown'){
    let checks=0;
    const verify=()=>{const active=get();if(!active||active.id!==j.id||active.phase!=='submitted_unknown')return;
     if(confirmedSaved(active)){notice('✓ تحقق ظهور الدرس التفاعلي في قائمة نور بعد الحفظ؛ يمكن الانتقال للدرس التالي.');return;}
     if(++checks<9)setTimeout(verify,1700);
     else notice('حالة حفظ SCORM غير مؤكدة. افتح قائمة نور للتحقق؛ لن يُرسل الدرس التالي أو يتكرر الحفظ دون إثبات.');
    };
    verify();return;
   }
   if(j.phase==='done'){root.dispatchEvent(new CustomEvent('stnNoorScormConfirmed',{detail:{id:j.id,batchTag:j.batchTag}}));return}
   if(j.phase==='staged'){notice('الدرس التفاعلي جاهز للمراجعة على هذه الصفحة. لن يتكرر الرفع بعد تحديث الصفحة.');return}
   if(j.phase==='route'||j.phase==='tree_opened'||j.phase==='tree_selection')advance();
   else if(j.phase==='paused')notice('عملية SCORM معلقة: '+j.reason+' — اضغط «استكمال تعبئة SCORM» بعد فتح صفحة نور الصحيحة.');
  }},950);
})(typeof globalThis==='object'?globalThis:this);
