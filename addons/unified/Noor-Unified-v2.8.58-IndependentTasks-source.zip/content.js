/* Noor Prep Filler v2.7.1 – homework form auto-fill on create page */
(function () {
  "use strict";

  // Render status messages without interpreting untrusted lesson/file names as HTML.
  // Only the extension's own <br> and <b> formatting tokens are supported.
  function setSafeStatusMarkup(node, markup) {
    if (!node) return;
    const parts = String(markup ?? "").split(/(<br\s*\/?>|<\/?b>)/gi);
    const fragment = document.createDocumentFragment();
    let bold = null;
    for (const part of parts) {
      if (/^<br\s*\/?>$/i.test(part)) {
        fragment.appendChild(document.createElement("br"));
      } else if (/^<b>$/i.test(part)) {
        bold = document.createElement("b");
        fragment.appendChild(bold);
      } else if (/^<\/b>$/i.test(part)) {
        bold = null;
      } else if (part) {
        (bold || fragment).appendChild(document.createTextNode(part));
      }
    }
    node.replaceChildren(fragment);
  }
  function getSafeStatusMarkup(node) {
    if (!node) return "";
    return Array.from(node.childNodes, n => n.nodeName === "BR" ? "<br>" : n.nodeName === "B" ? "<b>" + n.textContent + "</b>" : n.textContent).join("");
  }


  const api = typeof browser !== "undefined" ? browser : chrome;
  const pending = new Map();
  let msgSeq = 0;
  let pageReady = false;
  let fileLesson = null;
  let fileLessons = []; // all lessons imported from a local file
  // A clean add-on must not reuse preparation history saved under the Noor site origin.
  // All keys below were created by older versions of this extension, not by Noor itself.
  // Do not reset other teachers' live Noor data or any files they intentionally import.
  const OLD_PREP_KEYS = ['noor_prep_settings_v1', 'noor_prepared_titles_v1'];
  const OLD_PREP_SESSION_KEYS = ['noor_batch', 'noor_batch_pending', 'noor_hw_draft'];
  function wipeLegacyPrepState() {
    try {
      for (const key of OLD_PREP_KEYS) localStorage.removeItem(key);
      // Run once per tab/session: after this a teacher may start their OWN new batch.
      const stamp = 'stn_noor_clean_prep_session_v2823';
      if (sessionStorage.getItem(stamp) !== '1') {
        for (const key of OLD_PREP_SESSION_KEYS) sessionStorage.removeItem(key);
        sessionStorage.setItem(stamp, '1');
      }
    } catch (_) {}
  }
  wipeLegacyPrepState();
  // No shared Noor-origin settings or prepared-lesson tracking, across teacher accounts.
  function loadSettings() { return {}; }
  function saveSettings(_partial) { /* intentionally session-only */ }


  window.addEventListener("message", (ev) => {
    if (ev.source !== window || !ev.data) return;
    if (ev.data.__noor === "ready") { pageReady = true; return; }
    if (ev.data.__noor !== "res") return;
    const p = pending.get(ev.data.id);
    if (!p) return;
    pending.delete(ev.data.id);
    clearTimeout(p.timer);
    if (ev.data.ok) p.resolve(ev.data.result);
    else p.reject(new Error(ev.data.error || "helper_error"));
  });

  (function injectPageHelper() {
    try {
      const s = document.createElement("script");
      s.src = api.runtime.getURL("page-helper.js");
      s.onload = () => s.remove();
      (document.head || document.documentElement).appendChild(s);
    } catch (e) {
      console.warn("[Noor] helper inject failed", e);
    }
  })();

  function callPage(cmd, args = {}, timeoutMs = 15000) {
    return new Promise((resolve, reject) => {
      const id = "noor-" + Date.now() + "-" + (++msgSeq);
      const timer = setTimeout(() => {
        pending.delete(id);
        reject(new Error("helper_timeout"));
      }, timeoutMs);
      pending.set(id, { resolve, reject, timer });
      window.postMessage({ __noor: "req", id, cmd, args }, location.origin);
    });
  }

  async function waitHelper(ms = 8000) {
    for (let t = 0; t < ms && !pageReady; t += 100) {
      await new Promise(r => setTimeout(r, 100));
    }
    if (!pageReady) {
      try {
        const s = document.createElement("script");
        s.src = api.runtime.getURL("page-helper.js");
        (document.head || document.documentElement).appendChild(s);
        for (let t = 0; t < 3000 && !pageReady; t += 100) {
          await new Promise(r => setTimeout(r, 100));
        }
      } catch (_) {}
    }
    return pageReady;
  }

  function isAddPage() {
    return /\/add_preparation/i.test(location.pathname) &&
      !!(document.getElementById("add_preparation_form") || document.getElementById("PreparationObjective"));
  }
  function findAddPreparationUrl() {
    const anchors = [...document.querySelectorAll('a[href*="add_preparation"]')];
    for (const a of anchors) {
      const href = a.href || a.getAttribute("href") || "";
      if (/add_preparation/i.test(href)) return href;
    }
    for (const el of document.querySelectorAll("[onclick], button, a")) {
      const oc = el.getAttribute("onclick") || "";
      const m = oc.match(/['"]([^'"]*add_preparation[^'"]*)['"]/i);
      if (m) {
        try { return new URL(m[1], location.origin).href; } catch (_) {}
      }
    }
    try {
      const saved = sessionStorage.getItem("noor_add_url");
      if (saved && /add_preparation/i.test(saved)) return saved;
    } catch (_) {}
    return null;
  }
  function rememberAddUrl() {
    if (isAddPage()) {
      try { sessionStorage.setItem("noor_add_url", location.href); } catch (_) {}
    }
  }
  async function goToAddPreparation() {
    rememberAddUrl();
    if (isAddPage()) return true;
    const url = findAddPreparationUrl();
    if (url) {
      try { sessionStorage.setItem("noor_add_url", url); } catch (_) {}
      location.href = url;
      return true;
    }
    const labels = [
      "add preparation", "new preparation", "create preparation",
      "إضافة تحضير", "اضافة تحضير", "تحضير جديد", "إضافة", "اضافة",
      "أضف تحضيرا", "اضف تحضيرا", "تحضير"
    ];
    for (const el of document.querySelectorAll("a, button, input[type=button], input[type=submit]")) {
      const t = (el.textContent || el.value || "").trim().toLowerCase();
      if (labels.some(l => t.includes(l))) {
        el.click();
        await new Promise(r => setTimeout(r, 1500));
        if (isAddPage()) return true;
        const u2 = findAddPreparationUrl();
        if (u2) { location.href = u2; return true; }
      }
    }
    return false;
  }

  function toHtml(text) {
    if (!text) return "";
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\n/g, "<br>");
  }

  // ----- Section extraction from free text (Word/PDF/TXT) -----
  function normalizeText(t) {
    return String(t || "")
      .replace(/\r\n/g, "\n")
      .replace(/\r/g, "\n")
      .replace(/\u00a0/g, " ")
      .replace(/[ \t]+\n/g, "\n")
      .replace(/\n{3,}/g, "\n\n")
      .trim();
  }

  function extractBetween(text, startPatterns, endPatterns) {
    const lower = text.toLowerCase();
    let start = -1;
    let startLen = 0;
    for (const p of startPatterns) {
      const i = lower.indexOf(p.toLowerCase());
      if (i !== -1 && (start === -1 || i < start)) {
        start = i;
        startLen = p.length;
      }
    }
    if (start === -1) return "";
    let from = start + startLen;
    // skip colon / dashes after heading
    while (from < text.length && /[:\-\s]/.test(text[from])) from++;
    let end = text.length;
    for (const p of endPatterns) {
      const i = lower.indexOf(p.toLowerCase(), from);
      if (i !== -1 && i < end) end = i;
    }
    return text.slice(from, end).trim();
  }

  function parsePreparationText(raw, fileName) {
    const text = normalizeText(raw);
    if (!text || text.length < 20) return null;

    const objectives = extractBetween(text,
      ["Aims/ Learning outcomes", "Aims / Learning outcomes", "Aims/Learning outcomes",
       "Learning outcomes", "Aims:", "Objectives:", "OBJECTIVES", "By the end of the lesson"],
      ["To Start", "Warm up", "Warm-up", "Strategies", "Focus skill", "Target language",
       "Concepts", "Implementation", "Task 1", "Materials"]
    ) || extractBetween(text,
      ["To scan", "To use", "To express", "To identify", "To recognize"],
      ["To Start", "Warm up", "Strategies"]
    );

    const warmUp = extractBetween(text,
      ["To Start:", "To Start", "Warm up Activity", "Warm-up Activity", "Warm up:", "Warm-up:",
       "التهيئة", "التمهيد"],
      ["Strategies", "Implementation", "Task 1", "School Activities", "Lesson Procedures",
       "Materials", "Formative", "Activity 1"]
    );

    const procedures = extractBetween(text,
      ["School Activities / Lesson Procedures", "Lesson Procedures", "School Activities",
       "Implementation of Approaches", "Implementation of Approaches / Activities",
       "Task 1:", "Task 1", "إجراءات سير الدرس", "الأنشطة"],
      ["Formative Assessment", "Formative assessment", "Enrichment", "Finishing the lesson",
       "Closing Assessment", "Homework", "Teacher's Comments", "التقويم التكويني"]
    );

    const formative = extractBetween(text,
      ["Formative Assessment", "Formative assessment", "التقويم التكويني"],
      ["Closing Assessment", "Summative", "Finishing the lesson", "Enrichment",
       "Homework", "Teacher's Comments", "التقويم الختامي", "Closing"]
    );

    const closing = extractBetween(text,
      ["Closing Assessment", "Finishing the lesson", "Summative Assessment",
       "التقويم الختامي", "Closing:"],
      ["Homework", "Teacher's Comments", "Comments", "Enrichment", "Senior Teacher"]
    );

    const concepts = extractBetween(text,
      ["Focus skill", "Target language", "Concepts", "Key Vocabulary", "المفاهيم"],
      ["Aims", "Objectives", "To Start", "Warm up", "Strategies", "Learning outcomes"]
    );

    const homework = extractBetween(text,
      ["Homework:", "Homework", "الواجب"],
      ["Teacher's Comments", "Teacher’s Comments", "Comments", "Senior Teacher", "Supervisor"]
    );

    const comments = extractBetween(text,
      ["Teacher's Comments", "Teacher’s Comments", "Comments for the weekly", "Comments:"],
      ["Senior Teacher", "Supervisor", "Signature"]
    );

    // Title from filename or first line
    let title = (fileName || "").replace(/\.(pdf|docx?|txt)$/i, "").replace(/[_-]+/g, " ").trim();
    const firstLine = text.split("\n").map(l => l.trim()).find(l => l.length > 5 && l.length < 80);
    if (firstLine && /lesson|unit|grade|class/i.test(firstLine)) title = firstLine;
    // Try "Lesson/ Activity: L 1, P 1" style
    const lessonMatch = text.match(/Lesson\s*\/\s*Activity\s*:\s*([^\n]+)/i) ||
                        text.match(/Unit\s*:\s*([^\n]+)/i);
    if (lessonMatch) title = lessonMatch[1].trim().slice(0, 80);

    const lesson = {
      id: "file-" + Date.now(),
      unit: "From file",
      name: title || "Imported preparation",
      title: title || "Imported preparation",
      objectives: objectives || "",
      concepts: concepts || "",
      warmUp: warmUp || "",
      procedures: procedures || "",
      formative: formative || "",
      closing: (closing + (homework ? "\n\nHomework:\n" + homework : "")).trim(),
      details: comments || ""
    };

    // If almost nothing was extracted, put whole text into procedures
    const filled = [lesson.objectives, lesson.warmUp, lesson.procedures, lesson.formative, lesson.closing]
      .filter(s => s && s.length > 10).length;
    if (filled === 0 && text.length > 50) {
      lesson.procedures = text.slice(0, 8000);
      lesson.objectives = "See lesson procedures (imported from file).";
    }

    return lesson;
  }


  function splitIntoLessonBlocks(raw) {
    var text = normalizeText(raw);
    if (!text) return [];
    // Find all Lesson Plan N starts
    var re = /Lesson\s+Plan\s+(\d+)\s*[:\-–]?\s*([^\n\r]*)/gi;
    var matches = [];
    var m;
    while ((m = re.exec(text)) !== null) {
      matches.push({ index: m.index, num: m[1], title: (m[2] || "").trim(), full: m[0] });
    }
    if (matches.length < 1) {
      return text.length > 50 ? [{ text: text, num: "1", title: "" }] : [];
    }
    var blocks = [];
    for (var i = 0; i < matches.length; i++) {
      var start = matches[i].index;
      var end = i + 1 < matches.length ? matches[i + 1].index : text.length;
      blocks.push({
        text: text.slice(start, end).trim(),
        num: matches[i].num,
        title: matches[i].title,
        index: start
      });
    }
    return blocks;
  }

  function detectUnitFromBlock(blockText) {
    if (!blockText) return null;
    var m = blockText.match(/Theme\s*&\s*Unit\s*:\s*Theme\s*(\d+)\s*\(([^)]+)\)/i);
    if (m) return "Unit " + m[1] + ": " + m[2].trim();
    m = blockText.match(/Theme\s*(\d+)\s*\(([^)]+)\)/i);
    if (m) return "Unit " + m[1] + ": " + m[2].trim();
    m = blockText.match(/Theme\s*(\d+)\s*:\s*([A-Za-z][^\n\r]{2,40})/i);
    if (m) {
      var name = m[2].replace(/\s+from\s+.*/i, "").replace(/[–—-].*$/, "").trim();
      return "Unit " + m[1] + ": " + name;
    }
    m = blockText.match(/Theme\s*(\d+)/i);
    if (m) return "Unit " + m[1];
    return null;
  }

  // Known Grade 12 theme names for fallback by order
  var THEME_NAMES = {
    "1": "Retail Therapy",
    "2": "Starting University",
    "3": "Tourism and Hospitality",
    "4": "Travel and Transport"
  };

  function parseAllLessonsFromText(raw, fileName) {
    var blocks = splitIntoLessonBlocks(raw);
    var lessons = [];
    var lastUnit = null;
    var themeHits = [];
    // Pre-scan full text for theme headers in order
    var full = normalizeText(raw);
    var tre = /Theme\s*(\d+)\s*(?:\(([^)]+)\)|:\s*([A-Za-z][^.\n]{2,40}))?/gi;
    var tm;
    while ((tm = tre.exec(full)) !== null) {
      var n = tm[1];
      var nm = (tm[2] || tm[3] || THEME_NAMES[n] || "").trim().replace(/[–—-].*$/, "").trim();
      if (!nm) nm = THEME_NAMES[n] || "";
      themeHits.push({ index: tm.index, unit: "Unit " + n + (nm ? ": " + nm : "") });
    }

    function unitAt(pos) {
      var best = null;
      for (var k = 0; k < themeHits.length; k++) {
        if (themeHits[k].index <= pos) best = themeHits[k].unit;
      }
      return best;
    }

    for (var i = 0; i < blocks.length; i++) {
      var b = blocks[i];
      var blockText = typeof b === "string" ? b : b.text;
      var L = parsePreparationText(blockText, fileName);
      if (!L) continue;
      var u = detectUnitFromBlock(blockText);
      if (!u && typeof b === "object") u = unitAt(b.index || 0);
      if (!u) u = lastUnit;
      if (!u) {
        // fallback: group by 5
        var themeNum = String(Math.floor(lessons.length / 5) + 1);
        u = "Unit " + themeNum + (THEME_NAMES[themeNum] ? ": " + THEME_NAMES[themeNum] : "");
      }
      lastUnit = u;
      var num = (typeof b === "object" && b.num) ? b.num : String(lessons.length + 1);
      var title = (typeof b === "object" && b.title) ? b.title : "";
      if (!title) {
        var nm = blockText.match(/Lesson\s+Plan\s+\d+\s*[:\-–]?\s*([^\n\r]+)/i);
        title = nm ? nm[1].trim() : "";
      }
      L.id = "file-" + Date.now() + "-" + i;
      L.unit = u;
      L.name = ("Lesson " + num + (title ? " – " + title : "")).slice(0, 90);
      L.title = L.unit + " / " + L.name;
      L.grade = null; // set below from whole text
      lessons.push(L);
    }

    if (!lessons.length) {
      var one = parsePreparationText(raw, fileName);
      if (one) {
        one.unit = detectUnitFromBlock(raw) || "Unit 1";
        lessons.push(one);
      }
    }
    // Detect grade from document
    var gMatch = full.match(/Grade\s*(12|11|10|9)\b/i) ||
                 full.match(/صف\s*(الثاني\s*عشر|الحادي\s*عشر|العاشر|التاسع)/i);
    var detectedGrade = "From file";
    if (gMatch) {
      var g = gMatch[1].toLowerCase();
      if (g === "12" || g.indexOf("ثاني") >= 0) detectedGrade = "Grade 12";
      else if (g === "11" || g.indexOf("حادي") >= 0) detectedGrade = "Grade 11";
      else if (g === "10" || g.indexOf("عاشر") >= 0) detectedGrade = "Grade 10";
      else if (g === "9" || g.indexOf("تاسع") >= 0) detectedGrade = "Grade 9";
    }
    lessons.forEach(function (L) { L.grade = detectedGrade; });
    return lessons;
  }

  // ----- File loaders (content-script only, clean ArrayBuffer via base64) -----
  function readFileAsArrayBuffer(file) {
    return new Promise(function (resolve, reject) {
      var r = new FileReader();
      r.onload = function () { resolve(r.result); };
      r.onerror = function () { reject(r.error || new Error("FileReader failed")); };
      r.readAsArrayBuffer(file);
    });
  }

  function toCleanArrayBuffer(src) {
    var u8 = src instanceof Uint8Array ? src : new Uint8Array(src);
    var out = new Uint8Array(u8.byteLength);
    out.set(u8);
    return out.buffer;
  }

  function getMammoth() {
    if (typeof mammoth !== "undefined" && mammoth) return mammoth;
    if (typeof window !== "undefined" && window.mammoth) return window.mammoth;
    return null;
  }
  function getPdfJs() {
    if (typeof pdfjsLib !== "undefined" && pdfjsLib) return pdfjsLib;
    if (typeof window !== "undefined") {
      return window.pdfjsLib || window["pdfjs-dist/build/pdf"] || null;
    }
    return null;
  }

  async function extractTextFromDocx(arrayBuffer) {
    var m = getMammoth();
    if (!m || typeof m.extractRawText !== "function") {
      throw new Error("Word reader not loaded. Reinstall extension and reload (F5).");
    }
    var clean = toCleanArrayBuffer(arrayBuffer);
    var result = await m.extractRawText({ arrayBuffer: clean });
    return (result && result.value) || "";
  }

  async function extractTextFromPdf(arrayBuffer) {
    var pdfjs = getPdfJs();
    if (!pdfjs || typeof pdfjs.getDocument !== "function") {
      throw new Error("PDF reader not loaded. Reinstall extension and reload (F5).");
    }
    try {
      pdfjs.GlobalWorkerOptions.workerSrc = api.runtime.getURL("pdf.worker.min.js");
    } catch (_) {}
    var clean = toCleanArrayBuffer(arrayBuffer);
    var doc;
    try {
      doc = await pdfjs.getDocument({ data: clean, disableWorker: true }).promise;
    } catch (e) {
      throw new Error("PDF parse failed: " + (e.message || e));
    }
    var parts = [];
    var maxPages = Math.min(doc.numPages, 80);
    for (var i = 1; i <= maxPages; i++) {
      var page = await doc.getPage(i);
      var content = await page.getTextContent();
      parts.push(content.items.map(function (it) { return it.str; }).join(" "));
    }
    return parts.join("\n\n");
  }

  async function handleFile(file) {
    const status = document.querySelector("#noor-prep-panel .status");
    const setStatus = (msg, ok) => {
      if (status) {
        status.textContent = msg;
        status.style.color = ok === false ? "#c40" : ok === true ? "#0a7" : "#555";
      }
    };
    setStatus("Reading " + file.name + "…");

    try {
      const name = file.name.toLowerCase();
      let text = "";
      if (name.endsWith(".txt")) {
        text = await file.text();
      } else if (name.endsWith(".docx") || name.endsWith(".doc")) {
        if (name.endsWith(".doc") && !name.endsWith(".docx")) {
          throw new Error("Old .doc format is not supported. Please save as .docx or PDF.");
        }
        const buf = await readFileAsArrayBuffer(file);
        text = await extractTextFromDocx(buf);
      } else if (name.endsWith(".pdf")) {
        const buf = await readFileAsArrayBuffer(file);
        text = await extractTextFromPdf(buf);
      } else {
        throw new Error("Unsupported type. Use .docx, .pdf or .txt");
      }

      const lessons = parseAllLessonsFromText(text, file.name);
      if (!lessons.length) throw new Error("Could not extract lessons from file.");

      fileLessons = lessons;
      fileLesson = lessons[0];

      var unitNames = [];
      var seenU = {};
      lessons.forEach(function (L) {
        if (!seenU[L.unit]) { seenU[L.unit] = true; unitNames.push(L.unit); }
      });
      setStatus(
        "Loaded " + lessons.length + " lessons · " + unitNames.length + " units\\n" +
        unitNames.join(" · "),
        true
      );

      const gradeSel = document.querySelector("#noor-grade");
      const unitSel = document.querySelector("#noor-unit");
      const lessonSel = document.querySelector("#noor-lesson");
      const detectedGrade = (lessons[0] && lessons[0].grade) || "From file";

      function populateFileSelectors() {
        if (!gradeSel || !unitSel || !lessonSel) return;

        // Ensure grade option exists and shows file count
        var optG = null;
        for (var i = 0; i < gradeSel.options.length; i++) {
          if (gradeSel.options[i].value === detectedGrade) { optG = gradeSel.options[i]; break; }
        }
        if (!optG) {
          optG = document.createElement("option");
          optG.value = detectedGrade;
          gradeSel.appendChild(optG);
        }
        optG.textContent = detectedGrade + " (" + fileLessons.length + ")";
        gradeSel.value = detectedGrade;

        // Units from imported file
        unitSel.replaceChildren();
        unitNames.forEach(function (u) {
          var o = document.createElement("option");
          o.value = u;
          o.textContent = u;
          unitSel.appendChild(o);
        });

        function fillLessons() {
          var u = unitSel.value;
          var list = fileLessons.filter(function (L) { return L.unit === u; });
          if (!list.length) list = fileLessons.slice();
          lessonSel.replaceChildren();
          list.forEach(function (L) {
            var o = document.createElement("option");
            o.value = L.id;
            o.textContent = L.name;
            lessonSel.appendChild(o);
          });
        }
        unitSel.onchange = fillLessons;
        fillLessons();
      }
      populateFileSelectors();

      console.log("[Noor] Parsed file lessons", lessons.length, detectedGrade, unitNames, lessons.map(function (L) { return L.unit + " / " + L.name; }));
      return lessons[0];
    } catch (e) {
      console.error(e);
      setStatus("Error: " + e.message, false);
      alert("Could not read file:\n" + e.message);
      return null;
    }
  }

  // ---- Dates / periods ----
  function isoDate(d) {
    return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0") + "-" + String(d.getDate()).padStart(2, "0");
  }
  function parseIso(iso) {
    const [y, m, d] = iso.split("-").map(Number);
    return new Date(y, m - 1, d);
  }
  function schoolDates(count, fromToday, startIso) {
    const out = [];
    const base = startIso ? parseIso(startIso) : new Date();
    const startK = startIso ? 0 : (fromToday == null ? 1 : fromToday);
    for (let k = startK; out.length < count && k < 400; k++) {
      const x = new Date(base.getFullYear(), base.getMonth(), base.getDate() + k);
      if (x.getDay() === 5 || x.getDay() === 6) continue;
      out.push(isoDate(x));
    }
    return out;
  }
  function buildSchedule(days, n, fromIso) {
    const byClass = new Map();
    const sorted = [...(days || [])].sort((a, b) => (a.date < b.date ? -1 : 1));
    for (const d of sorted) {
      if (fromIso && d.date < fromIso) continue;
      for (const it of d.items || []) {
        if (it.has || !it.tsId) continue;
        const k = (it.level || "") + " / " + (it.section || "");
        if (!byClass.has(k)) byClass.set(k, []);
        const arr = byClass.get(k);
        if (arr.length < n) arr.push({ date: d.date, tsId: it.tsId, period: it.period });
      }
    }
    return byClass;
  }
  function scheduleToPicks(byClass) {
    const byDate = new Map();
    for (const slots of byClass.values()) {
      for (const s of slots) {
        if (!byDate.has(s.date)) byDate.set(s.date, new Set());
        byDate.get(s.date).add(s.tsId);
      }
    }
    return [...byDate.entries()]
      .sort((a, b) => (a[0] < b[0] ? -1 : 1))
      .slice(0, 20)
      .map(([date, set]) => ({ date, tsIds: [...set] }));
  }

  async function assignDatesAndSave(opts) {
    const periods = Math.max(1, Math.min(15, Number(opts.periods) || 1));
    const doSave = !!opts.save;
    const start = opts.startDate || null;
    const results = [];

    await waitHelper();

    try {
      const ping = await callPage("ping", {}, 4000);
      results.push("cid=" + (ping.cid || "?") + " jq=" + !!ping.hasJq + " dateRow=" + !!ping.hasDateRow);
      if (!ping.cid) {
        results.push("ERROR: course id not found — open Add Preparation from a course page");
        return results;
      }
      if (!ping.hasDateRow) {
        results.push("ERROR: publishdate-1 missing — are you on the preparation form?");
        return results;
      }
    } catch (e) {
      results.push("ping fail: " + e.message);
      return results;
    }

    const dates = schoolDates(Math.max(20, periods * 8), start ? 0 : 1, start);
    results.push("Querying " + dates.length + " school days from " + (start || "tomorrow"));

    let days = [];
    try {
      const ts = await callPage("timeslots", { dates }, 60000);
      if (ts && ts.error) {
        results.push("Timeslots error: " + ts.error + (ts.cid ? " cid=" + ts.cid : ""));
        return results;
      }
      days = (ts && ts.days) || [];
      const freeCount = days.reduce((n, d) => n + (d.items || []).filter(i => i.tsId && !i.has).length, 0);
      results.push("Days with data: " + days.filter(d => (d.items || []).length).length + ", free slots: " + freeCount);
      if (!freeCount) {
        results.push("No free periods. Does this course have a timetable?");
        return results;
      }
    } catch (e) {
      results.push("Timeslots fail: " + e.message);
      return results;
    }

    const byClass = buildSchedule(days, periods, start || null);
    const usedDates=[...byClass.values()].flat().map(x=>x.date).filter(Boolean).sort();
    if (opts && typeof opts.onDates==='function')opts.onDates(usedDates);
    const picks = scheduleToPicks(byClass);
    if (!picks.length) {
      results.push("Could not build period picks.");
      return results;
    }
    for (const [cls, slots] of byClass.entries()) {
      results.push((cls || "class") + ": " + slots.map(s => s.date + " " + (s.period || s.tsId)).join(" | "));
    }
    results.push("Form rows: " + picks.length);

    try {
      const ap = await callPage("applyPeriods", { picks }, 90000);
      if (ap && ap.error) results.push("applyPeriods: " + ap.error);
      let okN = 0;
      for (const r of (ap && ap.results) || []) {
        results.push(
          "Row " + (r.n || "?") + " " + r.date + ": " +
          (r.ok ? "OK checked=" + r.checked : "FAIL " + (r.reason || "") + " boxes=" + (r.foundBoxes || 0)) +
          (r.week ? " week=" + r.week : "")
        );
        if (r.ok) okN++;
      }
      results.push("Periods applied: " + okN + "/" + ((ap && ap.results) || []).length);
    } catch (e) {
      results.push("Apply periods fail: " + e.message);
    }

    try { await callPage("publishFlags"); } catch (_) {}

    // Multi-select dropdowns (Bloom levels, strategies, educational resources).
    // Choose options offered by Noor only; never replace existing selections.
    try {
      const activeLesson = opts.lesson || {};
      const text = [activeLesson.title,activeLesson.name,activeLesson.objectives,activeLesson.procedures].join(' ').toLowerCase();
      const groups={
        levels: /debate|argue|evaluate|assess|judge|ناقش|تقييم|حجج/.test(text)
          ? ['التقييم','التذكر'] : ['الفهم','التطبيق'],
        strategies: /debate|discussion|discuss|group|collaborat|حوار|نقاش/.test(text)
          ? ['التعلم التعاوني','التعلم التشاركي'] : ['التعلم التعاوني','التعلم بالاكتشاف'],
        resources: ['الكتاب','جهاز الحاسب','عروض تقديمية']
      };
      const chosen=await callPage('fillMultiChoices',{groups},6000);
      results.push('Dropdowns: '+JSON.stringify(chosen));
      if(!['selected','selected_fallback'].includes(chosen?.levels?.status)){
        results.push('FAIL: لم يُحدّد «المستوى» في نموذج التحضير. أوقف الحفظ حتى يُختار مستوى تعليمي موجود في نور.');
        return results;
      }
    } catch(e) {results.push('Dropdowns: FAIL '+e.message);}

    if (doSave) {
      await new Promise(r => setTimeout(r, 600));
      try {
        const s = await callPage("clickSave");
        results.push("Save: " + (s && s.ok ? "clicked حفظ" : "no button"));
      } catch (e) {
        results.push("Save fail: " + e.message);
      }
    }
    return results;
  }

  async function fillLessonWithDates(lesson, opts) {
    opts = opts || {};
    const status = document.querySelector("#noor-prep-panel .status");
    if (status) {
      setSafeStatusMarkup(status, "Filling lesson…");
      status.style.color = "#0984e3";
    }
    await fillLesson(lesson, { save: false });
    if (status) setSafeStatusMarkup(status, (getSafeStatusMarkup(status) || "") + "<br>Setting dates / periods…");
    const extra = await assignDatesAndSave(opts);
    if (status) {
      setSafeStatusMarkup(status, (getSafeStatusMarkup(status) || "") + "<br><br><b>Dates / periods</b><br>" + extra.join("<br>"));
      status.style.color = extra.some(l => /ERROR|FAIL|fail|error|No free/.test(l)) ? "#c40" : "#0a7";
    }
    console.log("[Noor] dates", extra);
  }

  function normTitle(t) {
    return String(t || "")
      .toLowerCase()
      .replace(/[ً-ْـ]/g, "")
      .replace(/[^\w\u0600-\u06ff\s]/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function matchBankToTree(bankLessons, treeUnits, preferredUnitName) {
    if (!bankLessons || !bankLessons.length || !(treeUnits || []).length) return [];
    const want = normTitle(preferredUnitName || bankLessons[0].unit || "");
    function scoreUnit(name) {
      const tn = normTitle(name);
      if (!want) return 0;
      if (tn === want) return 100;
      if (tn.includes(want) || want.includes(tn)) return 85;
      const ww = want.split(" ").filter((w) => w.length > 2);
      return ww.filter((w) => tn.includes(w)).length * 15;
    }
    let bestU = null, bestS = -1;
    for (const u of treeUnits) {
      const sc = scoreUnit(u.unit) * 10 + (u.lessons || []).length;
      if (sc > bestS) { bestS = sc; bestU = u; }
    }
    if (!bestU) bestU = treeUnits[0];
    const treeLessons = bestU.lessons || [];
    const n = Math.min(bankLessons.length, treeLessons.length);
    const matched = [];
    for (let i = 0; i < n; i++) {
      matched.push({
        bank: bankLessons[i],
        tree: {
          termId: bestU.termId,
          unitId: bestU.unitId,
          unit: bestU.unit,
          lessonId: treeLessons[i].id,
          title: treeLessons[i].title
        },
        score: 1
      });
    }
    return matched;
  }

  async function startBatchUnit(lessonsInUnit, opts) {
    if (!lessonsInUnit || !lessonsInUnit.length) {
      alert("لا توجد دروس في هذه الوحدة.");
      return;
    }
    try { sessionStorage.removeItem("noor_batch"); } catch (_) {}

    if (!isAddPage()) {
      const status0 = document.querySelector("#noor-prep-panel .status");
      if (status0) {
        setSafeStatusMarkup(status0, "Opening Add Preparation…");
        status0.style.color = "#0984e3";
      }
      try {
        sessionStorage.setItem("noor_batch_pending", JSON.stringify({
          bankIds: lessonsInUnit.map((L) => L.id),
          unit: lessonsInUnit[0].unit || "",
          grade: lessonsInUnit[0].grade || "",
          opts: opts
        }));
      } catch (_) {}
      const ok = await goToAddPreparation();
      if (!ok) {
        alert("Could not open Add Preparation automatically.\nOpen it once, then run batch again.");
      }
      return;
    }

    await waitHelper(12000);
    await new Promise((r) => setTimeout(r, 1000));

    const status = document.querySelector("#noor-prep-panel .status");
    if (status) {
      setSafeStatusMarkup(status, "Reading LMS course tree…");
      status.style.color = "#0984e3";
    }

    let tree;
    try {
      tree = await callPage("curriculum", {}, 90000);
    } catch (e) {
      alert("Could not read course tree:\n" + e.message + "\n\nWait until the left tree is fully loaded.");
      return;
    }
    if (!tree || tree.error || !(tree.units || []).length) {
      alert(
        "LMS tree not ready or empty.\n" +
        "Error: " + ((tree && tree.error) || "no units") + "\n" +
        "rootChildren: " + ((tree && tree.rootChildren) || 0) + "\n\n" +
        "Open Add Preparation, expand the tree, then try again."
      );
      return;
    }

    const preferredUnit = lessonsInUnit[0].unit || "";
    const matched = matchBankToTree(lessonsInUnit, tree.units, preferredUnit);
    const unitList = tree.units.map((u) =>
      "• " + u.unit + " (" + (u.lessons || []).length + " lessons)"
    ).join("\n");

    if (!matched.length) {
      alert("Could not pair bank lessons with tree.\n\nTree units:\n" + unitList);
      return;
    }

    const preview = matched.slice(0, 10).map((m, i) =>
      (i + 1) + ". " + (m.bank.name || "").slice(0, 28) + " → " + (m.tree.title || "").slice(0, 28)
    ).join("\n");

    const statusPrev = document.querySelector("#noor-prep-panel .status");
    if (statusPrev) {
      setSafeStatusMarkup(statusPrev, "Batch: " + matched.length + " lessons · periods=" + (opts.periods || 2) + " · auto-save ON<br>" +
        preview.replace(/\n/g, "<br>"));
      statusPrev.style.color = "#0984e3";
    }

    const state = {
      active: true,
      auto: true,
      periods: opts.periods || 2,
      startDate: opts.startDate || schoolDates(1, 1, null)[0],
      cursorDate: opts.startDate || schoolDates(1, 1, null)[0],
      addUrl: location.href,
      index: 0,
      items: matched.map((m) => ({
        bankId: m.bank.id,
        bankName: m.bank.name,
        termId: m.tree.termId,
        unitId: m.tree.unitId,
        lessonId: m.tree.lessonId,
        treeTitle: m.tree.title,
        status: "pending"
      }))
    };
    sessionStorage.setItem("noor_batch", JSON.stringify(state));
    await runBatchStep();
  }

  async function runBatchStep() {
    let state;
    try { state = JSON.parse(sessionStorage.getItem("noor_batch") || "null"); } catch (_) { state = null; }
    if (!state || !state.active) return false;
    if (state.index >= (state.items || []).length) {
      sessionStorage.removeItem("noor_batch");
      alert("Batch complete: all " + state.items.length + " lessons processed.");
      return false;
    }

    const it = state.items[state.index];
    const label = (state.index + 1) + "/" + state.items.length + " – " + (it.bankName || it.treeTitle || "");
    const bank = (typeof SITE_LESSONS !== "undefined" ? SITE_LESSONS : []).concat(fileLessons || []);
    const lesson = bank.find(L => L.id === it.bankId);

    const status = document.querySelector("#noor-prep-panel .status");
    if (status) {
      setSafeStatusMarkup(status, "Batch " + label + "<br>Selecting in tree…");
      status.style.color = "#0984e3";
    }

    if (!isAddPage()) {
      sessionStorage.setItem("noor_batch", JSON.stringify(state));
      const url = state.addUrl || findAddPreparationUrl();
      if (url) location.href = url;
      else await goToAddPreparation();
      return false;
    }

    await waitHelper(12000);
    await new Promise((r) => setTimeout(r, 600));

    let sel;
    try {
      sel = await callPage("selectLesson", {
        termId: it.termId,
        unitId: it.unitId,
        lessonId: it.lessonId,
        title: it.treeTitle
      }, 45000);
    } catch (e) {
      if (status) setSafeStatusMarkup(status, "Select error: " + e.message);
      alert("Tree select failed for:\n" + it.treeTitle + "\n" + e.message);
      return false;
    }
    if (!sel || !sel.ok) {
      alert(
        "Could not select lesson in tree:\n" + it.treeTitle +
        "\nReason: " + ((sel && sel.reason) || "unknown") +
        "\n\nMake sure the course tree is visible and this lesson exists in it."
      );
      return false;
    }
    if (status) {
      setSafeStatusMarkup(status, "Batch " + label + "<br>Selected (" + (sel.method || "") + "): " +
        (sel.title || "") + "<br>Filling…");
    }

    await new Promise((r) => setTimeout(r, 700));

    if (!lesson) {
      alert("Bank content missing for: " + it.bankName);
      return false;
    }

    await fillLesson(lesson, { save: false });
    const extra = await assignDatesAndSave({
      startDate: state.cursorDate,
      periods: state.periods,
      save: false
    });
    if (status) setSafeStatusMarkup(status, "Batch " + label + "<br>" + extra.join("<br>"));

    const used = schoolDates(Math.max(state.periods * 4, 5), 0, state.cursorDate);
    if (used.length) {
      const last = parseIso(used[Math.min(used.length, state.periods) - 1] || used[0]);
      last.setDate(last.getDate() + 1);
      state.cursorDate = isoDate(last);
    }

    if (state.auto) {
      if (status) setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br>Saving…"));
      await new Promise((r) => setTimeout(r, 500));
      try {
        if(!sessionStorage.getItem("noor_batch"))return false;
        const s = await callPage("clickSave");
        if(!sessionStorage.getItem("noor_batch"))return false;
        if (!s || !s.ok) {
          alert("Save button not found. Save manually, then re-open Add Preparation to continue.");
          it.status = "filled";
          sessionStorage.setItem("noor_batch", JSON.stringify(state));
          return false;
        }
      } catch (e) {
        alert("Save failed: " + e.message);
        sessionStorage.setItem("noor_batch", JSON.stringify(state));
        return false;
      }
      it.status = "saved";
      state.index++;
      sessionStorage.setItem("noor_batch", JSON.stringify(state));
      setTimeout(async () => {
        if (!sessionStorage.getItem("noor_batch")) return;
        if (isAddPage()) await runBatchStep();
        else {
          const st2 = JSON.parse(sessionStorage.getItem("noor_batch") || "null");
          const url = (st2 && st2.addUrl) || findAddPreparationUrl();
          if (url) location.href = url;
        }
      }, 3000);
      return true;
    }

    // Fully automatic: always save and continue
    if (status) setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br>Saving…"));
    await new Promise((r) => setTimeout(r, 500));
    try {
      if(!sessionStorage.getItem("noor_batch"))return false;
      const s = await callPage("clickSave");
      if(!sessionStorage.getItem("noor_batch"))return false;
      if (!s || !s.ok) {
        it.status = "filled";
        sessionStorage.setItem("noor_batch", JSON.stringify(state));
        if (status) setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br><span style=color:#c40>Save button not found — stop</span>"));
        return false;
      }
    } catch (e) {
      sessionStorage.setItem("noor_batch", JSON.stringify(state));
      if (status) setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br><span style=color:#c40>Save failed: " + e.message + "</span>"));
      return false;
    }
    it.status = "saved";
    state.index++;
    sessionStorage.setItem("noor_batch", JSON.stringify(state));
    setTimeout(async () => {
      if (!sessionStorage.getItem("noor_batch")) return;
      if (isAddPage()) await runBatchStep();
      else {
        const st2 = JSON.parse(sessionStorage.getItem("noor_batch") || "null");
        const url = (st2 && st2.addUrl) || findAddPreparationUrl();
        if (url) location.href = url;
      }
    }, 3000);
    return true;
  }

  async function fillLesson(lesson, opts) {
    if (!lesson) { alert("لم يتم اختيار درس"); return; }
    opts = opts || {};
    const doSave = !!opts.save;

    const ready = await waitHelper();
    const results = [];

    if (!ready) {
      results.push("Helper: FAIL (CKEditor not reachable)");
    } else {
      try {
        const ping = await callPage("ping", {}, 3000);
        results.push("CKEditor: " + (ping.hasCk ? "yes" : "NO") +
          (ping.editors && ping.editors.length ? " (" + ping.editors.length + " editors)" : ""));
      } catch (e) {
        results.push("Ping: " + e.message);
      }
    }

    try {
      const r = await callPage("setTitle", { text: lesson.title || (lesson.unit + ": " + lesson.name) });
      results.push("Title: " + (r && r.set ? "OK" : "FAIL"));
    } catch (e) { results.push("Title: FAIL " + e.message); }

    try {
      const r = await callPage("setObjective", { text: lesson.objectives || "" });
      results.push("Objectives: " + (r && r.set ? "OK (" + r.len + ")" : "FAIL"));
    } catch (e) { results.push("Objectives: FAIL " + e.message); }

    const editorMap = {
      lesson_vocabulary:          toHtml(lesson.concepts),
      description:                toHtml(lesson.warmUp),
      thinking_skills:            toHtml(lesson.procedures),
      formative_assessment:       toHtml(lesson.formative),
      closing_assessment:         toHtml(lesson.closing),
      weekly_study_plan_comments: toHtml(lesson.details || lesson.closing || "")
    };

    try {
      const r = await callPage("fillEditors", { map: editorMap }, 20000);
      results.push("Editors: " + ((r && r.done && r.done.length) ? r.done.join(", ") : "none") +
                   (r && r.error ? " [" + r.error + "]" : ""));
    } catch (e) {
      results.push("Editors: FAIL " + e.message);
    }

    try {
      await callPage("setTextareas", {
        map: {
          lesson_vocabulary: lesson.concepts || "",
          description: lesson.warmUp || "",
          thinking_skills: lesson.procedures || "",
          formative_assessment: lesson.formative || "",
          closing_assessment: lesson.closing || "",
          weekly_study_plan_comments: lesson.details || lesson.closing || "",
          pre_learning: lesson.warmUp || "",
          activities: (lesson.procedures || "").slice(0, 800)
        }
      });
    } catch (_) {}

    try {
      const phrases = (lesson.objectives || "").split(/[;\n•\-\.]/).map(s => s.trim()).filter(s => s.length > 15);
      const r = await callPage("checkOutcomes", { phrases });
      results.push("Outcomes/criteria: " + (r ? r.checked : 0));
    } catch (_) {}

    try { await callPage("publishFlags"); } catch (_) {}

    try {
      const strategies = lesson.procedures
        ? ("Strategies / Methods:\n" + String(lesson.procedures).slice(0, 1200))
        : "";
      const materials = lesson.concepts
        ? ("Key vocabulary / concepts:\n" + String(lesson.concepts).slice(0, 800))
        : "";
      const notes = lesson.details || lesson.closing || "";
      const r = await callPage("fillExtraFields", { strategies, materials, notes });
      if (r && r.done && r.done.length) results.push("Extra fields: " + r.done.length);
    } catch (_) {}

    if (doSave) {
      await new Promise(r => setTimeout(r, 600));
      try {
        const s = await callPage("clickSave");
        results.push("Save: " + (s && s.ok ? "clicked حفظ" : "no button"));
        // Never store previously prepared lesson titles across teachers.
      } catch (e) {
        results.push("Save fail: " + e.message);
      }
    }

    const status = document.querySelector("#noor-prep-panel .status");
    if (status) {
      setSafeStatusMarkup(status, results.join("<br>"));
      status.style.color = results.some(r => /FAIL|NO\b/.test(r)) ? "#c40" : "#0a7";
    }
    console.log("[Noor v2.6]", results);
    const required=['Title: OK','Objectives: OK'];
    const ok=required.every(k=>results.some(x=>x.startsWith(k))) &&
      !results.some(x=>/^(?:Title|Objectives|Editors):\s*(?:FAIL|none)/.test(x));
    return {ok,results};
  }





  function buildHomeworkDraft(lesson) {
    if (!lesson) return null;
    const title = "واجب: " + (lesson.name || lesson.title || "الدرس").replace(/^Lesson\s+\d+\s*[–-]\s*/i, "");
    const vocab = String(lesson.concepts || "")
      .split(/[\n,;•]+/)
      .map(function (s) { return s.replace(/\*+/g, "").trim(); })
      .filter(function (s) { return s.length > 2 && s.length < 40; })
      .slice(0, 8);
    const objs = String(lesson.objectives || "")
      .split(/[\n;•]+/)
      .map(function (s) { return s.replace(/^[\-\d\.\)\s]+/, "").trim(); })
      .filter(function (s) { return s.length > 15; })
      .slice(0, 5);

    const lines = [];
    lines.push(title);
    lines.push("");
    lines.push("أجب عن الأسئلة التالية:");
    lines.push("");

    let n = 1;
    // True/False from objectives
    objs.slice(0, 3).forEach(function (o) {
      lines.push(n + ") صح / خطأ: " + o.slice(0, 120));
      lines.push("   الإجابة النموذجية: (يحددها المعلم)");
      lines.push("");
      n++;
    });
    // MCQ-style from vocabulary
    vocab.slice(0, 4).forEach(function (w, i) {
      const others = vocab.filter(function (x) { return x !== w; }).slice(0, 3);
      while (others.length < 3) others.push("—");
      lines.push(n + ") اختر المعنى / الاستخدام الأنسب لكلمة: **" + w + "**");
      lines.push("   أ) " + w);
      lines.push("   ب) " + others[0]);
      lines.push("   ج) " + others[1]);
      lines.push("   د) " + others[2]);
      lines.push("   الإجابة: أ");
      lines.push("");
      n++;
    });
    if (n === 1) {
      lines.push("1) لخّص أفكار الدرس الرئيسة في 4–5 جمل.");
      lines.push("2) اكتب جملة من إنشائك مستخدماً مفردات الدرس.");
      lines.push("");
    }
    lines.push("---");
    lines.push("من الدرس: " + (lesson.unit || "") + " / " + (lesson.name || ""));
    if (lesson.details) {
      lines.push("");
      lines.push("ملاحظات: " + String(lesson.details).slice(0, 300));
    }
    return {
      title: title.slice(0, 120),
      text: lines.join("\n"),
      lessonId: lesson.id,
      lessonName: lesson.name || lesson.title
    };
  }

  function findHomeworkUrl() {
    const links = Array.from(document.querySelectorAll("a[href]"));
    const prefer = [
      /homework/i, /assignment/i, /e-?task/i, /واجب/, /مهام/
    ];
    for (const re of prefer) {
      for (const a of links) {
        const h = a.getAttribute("href") || "";
        const t = (a.textContent || "").trim();
        if (re.test(h) || re.test(t)) {
          try { return new URL(h, location.href).href; } catch (_) {}
        }
      }
    }
    // common LMS paths
    const cid = (location.href.match(/cid[=:]([^&/]+)/i) || [])[1];
    if (cid) {
      return location.origin + "/teacher/courses/homeworks_index/cid:" + cid;
    }
    return null;
  }

  function findAttachmentUrl() {
    const links = Array.from(document.querySelectorAll("a[href]"));
    const prefer = [/attachment/i, /resource/i, /مرفق/, /مستودع/, /content/i];
    for (const re of prefer) {
      for (const a of links) {
        const h = a.getAttribute("href") || "";
        const t = (a.textContent || "").trim();
        if (re.test(h) || re.test(t)) {
          try { return new URL(h, location.href).href; } catch (_) {}
        }
      }
    }
    const cid = (location.href.match(/cid[=:]([^&/]+)/i) || [])[1];
    if (cid) {
      return location.origin + "/teacher/courses/attachments/cid:" + cid;
    }
    return null;
  }

  function createPanel(lessons) {
    if (document.getElementById("noor-prep-panel")) return;

    // Group: grade -> unit -> lessons
    const byGrade = {};
    lessons.forEach(L => {
      const g = L.grade || "Grade 9";
      const u = L.unit || "General";
      if (!byGrade[g]) byGrade[g] = {};
      if (!byGrade[g][u]) byGrade[g][u] = [];
      byGrade[g][u].push(L);
    });
    const grades = Object.keys(byGrade).sort();

    const panel = document.createElement("div");
    panel.id = "noor-prep-panel";
    panel.innerHTML = `
      <div class="header" id="noor-drag-handle" title="اسحب لتحريك اللوحة">
        <strong>أدوات نور | دفتر المعلم</strong>
        <span class="hdr-actions">
          <button id="noor-min" type="button" title="تصغير">–</button>
          <button id="noor-close" type="button" title="إغلاق">×</button>
        </span>
      </div>
      <div class="body">
        <div id="noor-selected-current" role="status" aria-live="polite">جارٍ اكتشاف الدرس المحدد في نور…</div>
        <label for="noor-context-semester" class="noor-term-label">الفصل الدراسي</label>
        <select id="noor-context-semester" aria-label="الفصل الدراسي"><option value="">اختر الفصل الدراسي</option><option value="1">الفصل الأول</option><option value="2">الفصل الثاني</option></select>
        <div class="noor-context-bar" id="noor-context-bar" hidden></div>
        <details id="noor-prep-controls" hidden><summary>✎ تعديل بيانات الدرس (عند الحاجة)</summary>
        <p class="hint"></p>
        <label>المادة / Subject</label>
        <input id="noor-subject" type="text" placeholder="تُكتشف من صفحة نور أو أدخل المادة" autocomplete="off">
        <details id="noor-lesson-library"><summary>📁 تحاضيرك المستوردة من ملف (اختياري)</summary>
          <p class="note">لا توجد تحاضير محفوظة مسبقًا في الإضافة. ارفع ملفًا من جهازك أو ولّد تحضيرًا جديدًا باستخدام Gemini.</p>
          <label>الصف</label><select id="noor-grade"></select>
          <label>الوحدة</label><select id="noor-unit"></select>
          <label>الدرس</label><select id="noor-lesson"></select>
        </details>
        <details id="noor-lesson-context"><summary>🎯 الصف والوحدة والدرس للنشاط</summary>
          <label>الصف</label><input id="noor-context-grade" placeholder="مثال: 10">
          <label>الوحدة / Theme</label><input id="noor-context-unit" placeholder="اسم الوحدة أو موضوع الدرس">
          <label>الدرس / Lesson</label><input id="noor-context-lesson" placeholder="عنوان الدرس">
          
          <p class="note">راجع البيانات المكتشفة قبل إنشاء النشاط. يمكنك تعديلها لأي مادة.</p>
        </details>
        <hr class="sep">
        <label>تاريخ البدء وعدد الحصص</label>
        <div style="display:flex;gap:6px;margin-bottom:6px;">
          <input type="date" id="noor-start-date" style="flex:1;padding:6px;border:1px solid #ccc;border-radius:6px;font-size:12px;">
          <input type="number" id="noor-periods" min="1" max="15" value="2" title="عدد الحصص للدرس" style="width:52px;padding:6px;border:1px solid #ccc;border-radius:6px;font-size:12px;">
        </div>
        <input type="hidden" id="noor-autosave" checked>
        <label style="display:flex;align-items:center;gap:8px;font-weight:500;margin-bottom:10px;">
          <input type="checkbox" id="noor-preview" checked style="width:18px;height:18px;">
          معاينة قبل التعبئة
        </label>
        <button id="noor-fill-btn" type="button" style="width:100%;padding:10px;background:#6c5ce7;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;margin-bottom:6px;">▶ تعبئة + تواريخ + حفظ</button>
        <button id="noor-fill-dates-btn" type="button" style="display:none">Fill + set dates</button>
        <button id="noor-batch-btn" type="button" style="width:100%;padding:8px;background:#e17055;color:#fff;border:none;border-radius:8px;font-weight:600;cursor:pointer;">▶ تعبئة الوحدة كاملة (تلقائي)</button>
        <p class="note">يعمل تلقائياً: تعبئة ← توزيع الحصص من تاريخ البدء ← حفظ. الدفعة تنتقل للدرس التالي بعد كل حفظ.</p>
        </details>
        <details class="noor-ai-prep" open><summary>✨ توليد تحضير Gemini</summary>
          <div id="noor-key-setup">
          <p class="note">يرتبط المفتاح بحساب المعلم الذي فتح دفتر المعلم المدرسي في Firefox. لا يُزامَن المفتاح بين الأجهزة؛ وعند توليد التحضير تتصل الإضافة مباشرة بخدمة Google Gemini باستخدام حصة مشروع المعلم نفسه، دون إرسال المفتاح إلى خادم دفتر المعلم. لا تفعّل الفوترة تلقائيًا.</p>
          <p class="note" id="noor-teacher-profile-status" role="status">جارٍ التعرف على حساب المعلم…</p>
          <p class="note">لتفعيل التحضير الذكي لأول مرة: اضغط الزر، سجّل الدخول بحساب Google، أنشئ مفتاح API وانسخه ثم الصقه أدناه. لا تُدخل كلمة مرور Google داخل الإضافة.</p>
          <button type="button" id="noor-open-gemini-setup">🔑 إنشاء مفتاح Gemini</button>
          <p class="note">في Google AI Studio اختر Get API key ثم Create API key، وحدد مشروعًا إذا طُلب منك ذلك. قد تختلف الخيارات حسب الحساب، وقد تتطلب الموافقة على الشروط. استخدام Gemini يخضع لحصة الحساب وخطة الفوترة.</p>
          <label for="noor-teacher-gemini-key">مفتاح Gemini API الشخصي</label>
          <input id="noor-teacher-gemini-key" type="password" autocomplete="off" placeholder="ألصق مفتاح Gemini من Google AI Studio (قد يبدأ AQ. أو AIza)" style="width:100%;box-sizing:border-box" />
          <button type="button" id="noor-save-teacher-key">📋 لصق وحفظ المفتاح</button>
          </div>
          <button type="button" id="noor-migrate-teacher-key">نقل مفتاح النسخة القديمة لهذا المعلم (اختياري)</button>
          <button type="button" id="noor-remove-teacher-key">حذف مفتاح هذا المعلم</button>
          <p class="note" id="noor-key-status" aria-live="polite"></p><div id="noor-prep-primary-actions" hidden><button type="button" id="noor-generate-prep">✨ تحضير الدرس</button><button type="button" id="noor-apply-prep" disabled>📋 نسخ التحضير / تعبئته في نور</button></div><p class="note" id="noor-prep-ai-status" aria-live="polite"></p><details id="noor-generated-output" hidden><summary>مراجعة التحضير الناتج</summary><textarea readonly id="noor-generated-preview" rows="8" style="width:100%"></textarea></details></details>
        <details class="noor-ai-section"><summary>🎮 نشاط SCORM (تجريبي)</summary>
          <label>عدد الأسئلة</label><select id="noor-ai-count"><option>5</option><option selected>10</option><option>15</option><option>20</option><option>25</option><option>30</option><option>40</option></select>
          <label>نوع النشاط</label><select id="noor-ai-type"><option value="mixed">متنوع حسب الدرس</option><option value="quiz">اختيار من متعدد</option><option value="matching">مطابقة</option><option value="gap">إكمال الفراغات</option><option value="game">مسابقة تفاعلية</option></select>
          <p class="note">تستخدم هذه الأداة نفس مفتاح Gemini الخاص بالمعلم المرتبط أعلاه، دون مشاركة المفتاح بين حسابات المعلمين. لا ترسل بيانات طلاب لتوليد الأنشطة.</p>
          <button id="noor-ai-generate" type="button" style="width:100%">✨ إنشاء وتنزيل SCORM ZIP باستخدام Gemini</button>
          <p id="noor-ai-progress" class="note" aria-live="polite">يُنشأ ملف SCORM 1.2 محليًا بعد استلام الأسئلة. نوع النشاط في هذه التجربة: اختيار من متعدد.</p>
        </details>
        <details class="noor-att-section"><summary>📎 إرفاق ملف SCORM / PDF</summary>
          <button id="noor-att-btn" type="button">اختيار ملف للإرفاق</button>
          <input type="file" id="noor-att-file" accept=".zip,.scorm,.html,.htm,.pdf,.pptx,.ppt,.docx,.mp4,.webm" style="display:none">
        </details>
        <details class="noor-file-section"><summary>📁 استيراد تحضير من ملف</summary><label>أو تحميل من ملف</label>
        <input type="file" id="noor-file" accept=".docx,.pdf,.txt,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain">
        <p class="note">يدعم docx و pdf و txt</p></details>
        <div class="status" style="max-height:160px;overflow:auto;font-size:11px;margin-top:8px;"></div>
      </div>
    `;
    document.body.appendChild(panel);
    // No badges or previous preparations are retained in the extension.

    // Restore last position if any
    try {
      const pos = JSON.parse(sessionStorage.getItem("noor_panel_pos") || "null");
      if (pos && typeof pos.left === "number" && typeof pos.top === "number") {
        panel.style.right = "auto";
        panel.style.left = pos.left + "px";
        panel.style.top = pos.top + "px";
      }
    } catch (_) {}

    // Drag by header (mouse + touch)
    (function enableDrag() {
      const handle = panel.querySelector("#noor-drag-handle");
      if (!handle) return;
      let dragging = false, startX = 0, startY = 0, origLeft = 0, origTop = 0;
      const savePos = () => {
        try {
          const r = panel.getBoundingClientRect();
          sessionStorage.setItem("noor_panel_pos", JSON.stringify({ left: r.left, top: r.top }));
        } catch (_) {}
      };
      const onDown = (e) => {
        if (e.target.closest("button")) return;
        dragging = true;
        const rect = panel.getBoundingClientRect();
        panel.style.right = "auto";
        panel.style.left = rect.left + "px";
        panel.style.top = rect.top + "px";
        startX = e.clientX;
        startY = e.clientY;
        origLeft = rect.left;
        origTop = rect.top;
        e.preventDefault();
      };
      const onMove = (e) => {
        if (!dragging) return;
        let nx = origLeft + (e.clientX - startX);
        let ny = origTop + (e.clientY - startY);
        const maxX = window.innerWidth - panel.offsetWidth - 4;
        const maxY = window.innerHeight - 40;
        nx = Math.max(4, Math.min(maxX, nx));
        ny = Math.max(4, Math.min(maxY, ny));
        panel.style.left = nx + "px";
        panel.style.top = ny + "px";
      };
      const onUp = () => {
        if (dragging) { dragging = false; savePos(); }
      };
      handle.addEventListener("mousedown", onDown);
      window.addEventListener("mousemove", onMove);
      window.addEventListener("mouseup", onUp);
      handle.addEventListener("touchstart", (e) => {
        if (e.target.closest("button")) return;
        const touch = e.touches[0];
        const rect = panel.getBoundingClientRect();
        panel.style.right = "auto";
        panel.style.left = rect.left + "px";
        panel.style.top = rect.top + "px";
        dragging = true;
        startX = touch.clientX;
        startY = touch.clientY;
        origLeft = rect.left;
        origTop = rect.top;
      }, { passive: true });
      window.addEventListener("touchmove", (e) => {
        if (!dragging) return;
        if (e.cancelable) e.preventDefault();
        const touch = e.touches[0];
        let nx = origLeft + (touch.clientX - startX);
        let ny = origTop + (touch.clientY - startY);
        const maxX = window.innerWidth - panel.offsetWidth - 4;
        const maxY = window.innerHeight - 40;
        nx = Math.max(4, Math.min(maxX, nx));
        ny = Math.max(4, Math.min(maxY, ny));
        panel.style.left = nx + "px";
        panel.style.top = ny + "px";
        panel.style.right = "auto";
        panel.style.bottom = "auto";
      }, { passive: false });
      window.addEventListener("touchend", onUp);
    })();

    // Open AI website only after an explicit user click. Never send Noor data automatically.
    function makeActivityPrompt() {
      const lesson = currentLesson();
      const grade = panel.querySelector('#noor-context-grade').value.trim() || panel.querySelector('#noor-grade').value;
      const unit = panel.querySelector('#noor-context-unit').value.trim() || panel.querySelector('#noor-unit').value;
      const title = panel.querySelector('#noor-context-lesson').value.trim() || panel.querySelector('#noor-lesson').selectedOptions[0]?.textContent || '';
      const subject = panel.querySelector('#noor-subject').value.trim() || 'Not specified';
      const count = Number(panel.querySelector('#noor-ai-count').value);
      const kind = panel.querySelector('#noor-ai-type').selectedOptions[0]?.textContent || 'متنوع';
      return `Act as an expert instructional designer for the Omani school curriculum. Subject: ${subject}. Create a complete, age-appropriate, engaging interactive learning activity.\nGrade/level: ${grade}\nTheme or unit: ${unit}\nLesson: ${title}\nActivity format: ${kind}\nExactly ${count} scored questions.\nLearning objectives: ${lesson?.objectives || 'Infer carefully from the given lesson title; do not invent textbook facts.'}\nLesson content: ${(lesson?.procedures || '').slice(0,2200)}\nRequirements: Match the grade and specific lesson, vary difficulty, use accurate English, provide immediate answer feedback and a brief explanation, responsive mobile-first interface, accessible controls, and a final score. Include Arabic support only for brief explanations where useful. Avoid repetition and off-topic questions. Provide a complete downloadable self-contained HTML activity first, then explain how to package it as SCORM 1.2 with imsmanifest.xml and LMSInitialize/LMSSetValue/LMSCommit/LMSFinish for score and completion. If direct ZIP generation is available, provide a valid SCORM 1.2 ZIP package ready to upload to the LMS. Do not claim SCORM compatibility without a valid manifest and runtime integration.`;
    }
    // ZIP stored entries (no external CDN, works offline after Gemini responds).
    function makeZip(entries) {
      const enc=new TextEncoder(), parts=[], central=[]; let offset=0;
      const u16=(n)=>[n&255,(n>>>8)&255],u32=(n)=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];
      const crcTable=makeZip.table||(makeZip.table=Array.from({length:256},(_,n)=>{for(let j=0;j<8;j++)n=n&1?(0xedb88320^(n>>>1)):(n>>>1);return n>>>0;}));
      const crc=(bytes)=>{let c=0xffffffff;for(const b of bytes)c=crcTable[(c^b)&255]^(c>>>8);return (c^0xffffffff)>>>0;};
      for(const [name,content] of entries){const filename=enc.encode(name),data=enc.encode(content),check=crc(data),len=data.length;
        const local=new Uint8Array([...u32(0x04034b50),...u16(20),...u16(0x800),...u16(0),...u16(0),...u16(0),...u32(check),...u32(len),...u32(len),...u16(filename.length),...u16(0),...filename]);
        parts.push(local,data);
        central.push(new Uint8Array([...u32(0x02014b50),...u16(20),...u16(20),...u16(0x800),...u16(0),...u16(0),...u16(0),...u32(check),...u32(len),...u32(len),...u16(filename.length),...u16(0),...u16(0),...u16(0),...u16(0),...u32(0),...u32(offset),...filename]));offset+=local.length+len;
      }
      const centralLength=central.reduce((n,a)=>n+a.length,0), end=new Uint8Array([...u32(0x06054b50),...u16(0),...u16(0),...u16(central.length),...u16(central.length),...u32(centralLength),...u32(offset),...u16(0)]);
      return new Blob([...parts,...central,end],{type:'application/zip'});
    }
    function makeScorm(data){
      const escapeXml=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
      const manifest=`<?xml version="1.0" encoding="UTF-8"?><manifest identifier="NOOR_GEMINI_SCORM" version="1.0" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2" xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata><organizations default="ORG1"><organization identifier="ORG1"><title>${escapeXml(data.title)}</title><item identifier="ITEM1" identifierref="RES1"><title>${escapeXml(data.title)}</title></item></organization></organizations><resources><resource identifier="RES1" type="webcontent" adlcp:scormtype="sco" href="index.html"><file href="index.html"/><file href="questions.json"/></resource></resources></manifest>`;
      const html=`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Interactive activity</title><style>body{font:16px system-ui,sans-serif;background:#eef5fb;color:#172b43;margin:0;padding:15px}.app{max-width:650px;margin:auto;background:white;border-radius:16px;padding:20px;box-shadow:0 4px 22px #0001}button{display:block;width:100%;margin:9px 0;padding:13px;border:1px solid #b8cbd9;border-radius:10px;background:#f5faff;text-align:left;font:inherit}button:disabled{opacity:.8}.next{background:#1558a4;color:white;text-align:center}#feedback{margin-top:12px;line-height:1.6}h1{font-size:23px}</style></head><body><div class="app"><h1 id="title">Activity</h1><p id="progress"></p><h2 id="question"></h2><div id="choices"></div><div id="feedback" aria-live="polite"></div><button id="next" class="next" hidden>Next</button></div><script src="questions.js"></`+`script><script src="runtime.js"></`+`script></body></html>`;
      const runtime=`(function(){'use strict';const d=window.ACTIVITY_DATA;let i=0,score=0,answered=false;const el=id=>document.getElementById(id);let api=null,w=window;for(let n=0;n<10&&w;n++){try{if(w.API){api=w.API;break;}if(w.parent===w)break;w=w.parent;}catch(e){break;}}try{if(api)api.LMSInitialize('');}catch(e){}function save(){if(!api)return;try{api.LMSSetValue('cmi.core.score.raw',String(Math.round(score*100/d.questions.length)));api.LMSSetValue('cmi.core.score.min','0');api.LMSSetValue('cmi.core.score.max','100');api.LMSSetValue('cmi.core.lesson_status','completed');api.LMSCommit('');}catch(e){}}function draw(){answered=false;el('feedback').textContent='';el('next').hidden=true;el('title').textContent=d.title;el('progress').textContent='Question '+(i+1)+' / '+d.questions.length;const q=d.questions[i];el('question').textContent=q.question;el('choices').replaceChildren();q.options.forEach((option,n)=>{const b=document.createElement('button');b.textContent=String.fromCharCode(65+n)+'. '+option;b.onclick=()=>{if(answered)return;answered=true;if(n===q.correct)score++;for(const c of el('choices').children)c.disabled=true;el('feedback').textContent=(n===q.correct?'Correct! ':'Correct answer: '+q.options[q.correct]+'. ')+q.explanation;el('next').hidden=false;el('next').textContent=i===d.questions.length-1?'Show results':'Next question';};el('choices').appendChild(b);});}el('next').onclick=()=>{i++;if(i>=d.questions.length){save();el('question').textContent='Finished!';el('progress').textContent='Score: '+score+' / '+d.questions.length;el('choices').replaceChildren();el('feedback').textContent='Your score has been submitted to the LMS when available.';el('next').hidden=true;try{if(api)api.LMSFinish('');}catch(e){}}else draw();};window.addEventListener('pagehide',()=>{try{if(api)api.LMSFinish('');}catch(e){}});draw();})();`;
      return makeZip([['imsmanifest.xml',manifest],['index.html',html],['questions.js','window.ACTIVITY_DATA='+JSON.stringify(data).replace(/</g,'\\u003c')+';'],['runtime.js',runtime]]);
    }
    panel.querySelector('#noor-ai-generate').addEventListener('click',async()=>{
      const button=panel.querySelector('#noor-ai-generate'),status=panel.querySelector('#noor-ai-progress');
      const {id,key}=await teacherProfile.read();if(!id||!key){status.textContent='اربط حسابك واحفظ مفتاح Gemini لهذا المعلم أولًا.';return;}
      if(panel.querySelector('#noor-ai-type').value!=='quiz'){status.textContent='الإصدار التجريبي يولد اختيارًا من متعدد فقط؛ غيّر نوع النشاط.';return;}
      button.disabled=true;status.textContent='جارٍ إنشاء الأسئلة بواسطة Gemini...';
      try{const result=await browser.runtime.sendMessage({type:'NOOR_GEMINI_GENERATE',count:Number(panel.querySelector('#noor-ai-count').value),prompt:makeActivityPrompt()});
        if(!result?.ok)throw Error(result?.error||'تعذر الاتصال بخدمة Gemini');
        status.textContent='تم إنشاء '+result.data.questions.length+' سؤالًا. جارٍ تجهيز SCORM ZIP...';
        const blob=makeScorm(result.data),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='noor-scorm-gemini-'+Date.now()+'.zip';document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
        status.textContent='تم إعداد ملف SCORM 1.2. تحقق من تنزيل ZIP، ثم اختبره على نور قبل نشره.';
      }catch(e){status.textContent='تعذر الإنشاء: '+String(e.message||e);}finally{button.disabled=false;}
    });

    // Detect the actual selected Noor tree item, not the bundled lesson bank.
    // A tree click is remembered only when it is on a lesson item.
    let lastTreeLesson = null;
    const clean = value => String(value || '').replace(/\s+/g, ' ').trim();
    // Noor uses lesson badges for Arabic titles (e.g. "1-3 الشيفرة الجينية")
    // and some English courses label entire units as lessons.
    const lessonPattern = /(?:\bLesson\s*\d+\b|\bدرس\s*\d+\b|(?:^|\s)\d+\s*[-–.]\s*\d+(?:\s|$)|^Starter$)/i;
    const treeLesson = el => {
      if (!el || el.closest('#noor-prep-panel')) return null;
      const node = el.closest('a, li, [role="treeitem"], .jstree-anchor, .jstree-node, .tree-node, span');
      if (!node) return null;
      const label = node.closest('li, [role="treeitem"], .jstree-node, .tree-node') || node.parentElement || node;
      // Read the actual row, not the small purple "درس" badge clicked by the user.
      const row = clean([...label.childNodes].filter(n=>n.nodeType===3 || (n.nodeType===1 && !n.matches?.('ul,ol'))).map(n=>n.textContent||'').join(' '));
      const own = clean(node.innerText || node.textContent);
      const badge = [...label.querySelectorAll('span,small,b,em,strong')]
        .some(x => /^(?:درس|Lesson)$/i.test(clean(x.innerText || x.textContent)));
      const strip = t => clean(t.replace(/^(?:درس|Lesson)\s*/i,'').replace(/\s*(?:درس|Lesson)$/i,''));
      const candidates = [strip(own), strip(row)].filter(t => t && !/^(?:درس|Lesson)$/i.test(t) && t.length <= 150);
      const text = candidates.find(t => lessonPattern.test(t)) || (badge ? candidates.find(t => t !== 'درس') : '');
      if (!text || (!badge && !lessonPattern.test(text))) return null;
      if (/^(?:فصل|Semester|Chapter|وحدة|كتاب|Book)\b/i.test(text)) return null;
      const match = text.match(/(?:Unit\s*\d+\s*:\s*[^:]+?)\s*:\s*Lesson\s*\d+/i);
      let unit = match ? clean(match[0].replace(/\s*:\s*Lesson\s*\d+.*/i,'')) : '';
      let semester='';
      let ancestor=label.closest('li,[role=treeitem],.jstree-node,.tree-node');
      for(let depth=0;ancestor&&depth<6;depth++){
        ancestor=ancestor.parentElement?.closest('li,[role=treeitem],.jstree-node,.tree-node');
        if(!ancestor)break;
        const name=clean(ancestor.querySelector(':scope > a,:scope > .jstree-anchor,:scope > .tree-label')?.textContent||'');
        if(!name)continue;
        if(!unit&&/^(?:unit|theme|الوحدة|وحدة)/i.test(name))unit=name.replace(/\s*(?:وحدة|Unit)$/i,'').trim();
        if(!semester&&/الفصل\s*(?:الدراسي\s*)?(?:الاول|الأول|الثاني)/.test(name))semester=/الثاني/.test(name)?'2':'1';
      }
      return {text,unit,semester};
    };
    document.addEventListener('click', event => {
      const selected = treeLesson(event.target);
      if (selected) { lastTreeLesson = selected; setTimeout(updateContextBar, 120); }
    }, true);
    function detectNoorContext() {
      const main = document.querySelector('main') || document.body;
      const text = clean(main.innerText.slice(0, 18000));
      const pick = patterns => {for (const re of patterns) {const m=text.match(re);if(m?.[1])return clean(m[1]).slice(0,120);}return '';};
      const header = [...document.querySelectorAll('h1,h2,h3,h4,.page-title,.breadcrumb, .course-title')]
        .map(n=>clean(n.innerText)).filter(Boolean).join(' | ');
      const courseText = (header + ' | ' + text.slice(0,450)).replace(/#noor-prep-panel/g,'');
      let subject = pick([/(?:المادة|اسم المادة|Subject)\s*[:：]\s*([^|\n]{2,65})/i]);
      if (!subject) {
        const m = courseText.match(/(?:اللغة\s+الإنجليزية|اللغة\s+الانجليزية|English\s+Language|الرياضيات|Mathematics|العلوم|Science|اللغة\s+العربية|Arabic|التربية\s+الإسلامية|الأحياء|أحياء|Biology|الفيزياء|Physics|الكيمياء|Chemistry|الجغرافيا|التاريخ|الدراسات\s+الاجتماعية|تقنية\s+المعلومات)/i);
        if (m) subject = m[0];
      }
      let grade = pick([/(?:الصف|Grade|Class)\s*[:：]?\s*(العاشر|الحادي عشر|الثاني عشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول|\d{1,2})/i]);
      if (!grade) {const m=courseText.match(/(?:صف\s*(?:عاشر|تاسع|ثامن|سابع|سادس|خامس|رابع|ثالث|ثاني|أول)|Grade\s*\d{1,2})/i);if(m)grade=m[0];}
      // Prefer the course book heading over generic page notices such as "الصفوف 1-12".
      const bookLabel = [...document.querySelectorAll('main *, body *')]
        .filter(el => el.children.length < 5 && /(?:عرض الشجرة|Book|كتاب)/i.test(clean(el.innerText || '')))
        .map(el => clean(el.innerText || '')).find(t => t.length < 180 && /(?:صف|Grade)/i.test(t)) || '';
      // Prefer the book node and explicit grade labels; never infer grade from a lesson number.
      const gradeSource = bookLabel || courseText;
      const courseBookNodes = [...document.querySelectorAll('main *, body *')]
        .filter(el => el.children.length < 5)
        .map(el => clean(el.innerText || ''))
        .filter(t => t.length > 8 && t.length < 190 && /(?:عرض الشجرة|Book|كتاب)/i.test(t));
      const courseBookText = courseBookNodes.find(t => /(?:صف|الصف|Grade)\s*(?:ال)?(?:ثاني\s*عشر|حادي\s*عشر|[1-9]|1[0-2])/i.test(t)) || bookLabel;
      // Support Arabic ordinal grades both with and without definite articles, and with optional spaces.
      const explicitGrade = (courseBookText || courseText).match(/(?:الصف|صف)\s+(?:(?:ال)?ثاني\s+(?:ال)?عشر|(?:ال)?حادي\s+(?:ال)?عشر|(?:ال)?عاشر|(?:ال)?تاسع|(?:ال)?ثامن|(?:ال)?سابع|(?:ال)?سادس|(?:ال)?خامس|(?:ال)?رابع|(?:ال)?ثالث|(?:ال)?ثاني|(?:ال)?أول|1[0-2]|[1-9])(?=\s|[-–.)،]|$)/i);
      const explicitGradeNumber = explicitGrade ? (explicitGrade[0].match(/ثاني\s+(?:ال)?عشر/) ? '12' : explicitGrade[0].match(/حادي\s+(?:ال)?عشر/) ? '11' : '') : '';

      // Arabic book labels can say "صف ثاني عشر" (without definite article).
      const gradeWords = {'أول':1,'ثاني':2,'ثالث':3,'رابع':4,'خامس':5,'سادس':6,'سابع':7,'ثامن':8,'تاسع':9,'عاشر':10};
      const bookGrade = gradeSource.match(/(?:الصف|صف)\s+(?:ال)?(حادي\s+عشر|ثاني\s+عشر|عاشر|تاسع|ثامن|سابع|سادس|خامس|رابع|ثالث|ثاني|أول)(?!\S)/i);
      let exactBookGrade = '';
      if (bookGrade) {
        const v=bookGrade[1].replace(/\s+/g,' ').trim();
        exactBookGrade = v==='حادي عشر'?'Grade 11':v==='ثاني عشر'?'Grade 12':('Grade '+(gradeWords[v]||10));
      }

      const arGrade = gradeSource.match(/(?:صف|الصف)\s*(?:ال)?\s*(الثاني\s*عشر|الحادي\s*عشر|عاشر|تاسع|ثامن|سابع|سادس|خامس|رابع|ثالث|ثاني|أول|العاشر|التاسع|الثامن|السابع|السادس|الخامس|الرابع|الثالث|الثاني|الأول)/i);
      const enGrade = gradeSource.match(/Grade\s*(1[0-2]|[1-9])\b/i);
      if (arGrade) grade = arGrade[1]; else if (enGrade) grade = enGrade[1];
      const gradeMap={'الثاني عشر':'12','الحادي عشر':'11','عاشر':'10','العاشر':'10','تاسع':'9','التاسع':'9','ثامن':'8','الثامن':'8','سابع':'7','السابع':'7','سادس':'6','السادس':'6','خامس':'5','الخامس':'5','رابع':'4','الرابع':'4','ثالث':'3','الثالث':'3','ثاني':'2','الثاني':'2','أول':'1','الأول':'1'};
      for(const [word,num] of Object.entries(gradeMap))if(grade.includes(word)){grade='Grade '+num;break;}
      if (/^\d{1,2}$/.test(grade))grade='Grade '+grade;
      if (exactBookGrade) grade=exactBookGrade;
      // Avoid the old substring bug: "ثاني عشر" was reduced to "ثاني" -> Grade 2.
      if (explicitGradeNumber) grade='Grade '+explicitGradeNumber;
      if (explicitGrade && !explicitGradeNumber) {
        const raw=explicitGrade[0].replace(/^(?:الصف|صف)\s+/,'').replace(/^ال/,'').trim();
        const gradeOrdinals={أول:1,ثاني:2,ثالث:3,رابع:4,خامس:5,سادس:6,سابع:7,ثامن:8,تاسع:9,عاشر:10};
        if (gradeOrdinals[raw]) grade='Grade '+gradeOrdinals[raw];
        else if (/^(?:1[0-2]|[1-9])$/.test(raw))grade='Grade '+raw;
      }
      // If the book grade is missing, do not accept grade extracted from lesson numbering.
      if (!explicitGrade && !exactBookGrade && !/Grade\s*(?:1[0-2]|[1-9])\b/i.test(header)) grade='';
      if (!subject) {
        const sm=(courseBookText+' '+header).match(/الأحياء|أحياء|Biology|الفيزياء|Physics|الكيمياء|Chemistry|اللغة\s+العربية|اللغة\s+الإنجليزية|الرياضيات|العلوم|التربية\s+الإسلامية/i);
        if(sm)subject=sm[0];
      }
      const active = [...document.querySelectorAll('#jstree_node_tree [aria-selected="true"], #jstree_node_tree .jstree-clicked, #jstree_node_tree .jstree-wholerow-clicked')]
        .map(el=>treeLesson(el)).find(Boolean);
      const selected = lastTreeLesson || active;
      let unit = '',lesson = '';
      if (selected) {
        lesson = selected.text;
        unit = selected.unit || (selected.text.match(/Unit\s*\d+\s*:\s*[^:]+/i)||[])[0] || '';
        if(!unit) {
          const ancestor = [...document.querySelectorAll('[role="treeitem"],li,.jstree-node')].find(el=>el.contains(document.activeElement));
          const m=clean(ancestor?.parentElement?.innerText).match(/Unit\s*\d+\s*:\s*[^:]+/i);
          if(m)unit=m[0];
        }
      }
      // Highest-priority grade source: exact course book label, never a lesson number.
      // Match full Arabic compound ordinals BEFORE simple ordinals (ثاني عشر != ثاني).
      const bookHeading = courseBookNodes.find(t => /(?:عرض الشجرة|Book|كتاب)/i.test(t) && /(?:صف|الصف|Grade)/i.test(t)) || bookLabel;
      const fullArabicGrade = bookHeading.match(/(?:الصف|صف)\s+(?:(?:ال)?(ثاني|حادي)\s+(?:ال)?عشر|(?:ال)?(عاشر|تاسع|ثامن|سابع|سادس|خامس|رابع|ثالث|ثاني|أول))(?![\p{L}])/iu);
      const numericBookGrade = bookHeading.match(/(?:Grade|الصف|صف)\s*[:：]?\s*(1[0-2]|[1-9])(?=\D|$)/i);
      if (fullArabicGrade) {
        const compound = fullArabicGrade[1];
        const single = fullArabicGrade[2];
        if (compound) grade = 'Grade ' + (compound === 'ثاني' ? 12 : 11);
        else grade = 'Grade ' + ({أول:1,ثاني:2,ثالث:3,رابع:4,خامس:5,سادس:6,سابع:7,ثامن:8,تاسع:9,عاشر:10}[single] || '');
      } else if (numericBookGrade) grade = 'Grade ' + numericBookGrade[1];
      // Fallback for Noor book headings with no spaces around punctuation.
      if (/صف\s+(?:ال)?ثاني\s+(?:ال)?عشر/.test(bookHeading)) grade = 'Grade 12';
      if (/صف\s+(?:ال)?حادي\s+(?:ال)?عشر/.test(bookHeading)) grade = 'Grade 11';
      const values=[['noor-subject',subject],['noor-context-grade',grade],['noor-context-unit',unit],['noor-context-lesson',lesson]];
      for(const [id,value] of values){const field=panel.querySelector('#'+id);if(field && value && (id==='noor-context-lesson'||id==='noor-context-unit'||id==='noor-context-grade'||id==='noor-subject'||!field.value.trim()))field.value=value;}
      return Boolean(subject && grade && lesson);
    }
    const contextBar=panel.querySelector('#noor-context-bar');
    const selectedCurrent=panel.querySelector('#noor-selected-current');
    const semesterSel=panel.querySelector('#noor-context-semester');
    const field=id=>panel.querySelector('#'+id);
    let lastContextUrl=location.href;
    let lastSourceSignature='';
    let semesterManuallySet=false;
    let contextSequence=0;
    semesterSel.addEventListener('change',()=>{semesterManuallySet=true;refreshCurrentDisplay();});
    const semesterFromText=txt=>{
      if(/(?:الفصل\s*(?:الدراسي\s*)?(?:الأول|الاول|1)|(?:first|1st)\s*(?:semester|term)|semester\s*(?:1|one)|term\s*1)/i.test(txt))return '1';
      if(/(?:الفصل\s*(?:الدراسي\s*)?(?:الثاني|2)|(?:second|2nd)\s*(?:semester|term)|semester\s*(?:2|two)|term\s*2)/i.test(txt))return '2';
      return '';
    };
    function refreshCurrentDisplay(){
      const subject=field('noor-subject').value.trim(),grade=field('noor-context-grade').value.trim();
      const unit=field('noor-context-unit').value.trim(),lesson=field('noor-context-lesson').value.trim();
      const term=semesterSel.value==='1'?'الفصل الأول':semesterSel.value==='2'?'الفصل الثاني':'اختر الفصل الدراسي';
      selectedCurrent.replaceChildren();
      const line=document.createElement('strong');line.textContent=lesson||'اختر درسًا من شجرة نور أولًا';
      const small=document.createElement('small');small.textContent=[subject,grade,term,unit].filter(Boolean).join(' · ');
      selectedCurrent.append(line,small);
      contextBar.textContent=[subject,grade,term,unit,lesson].filter(Boolean).join(' · ');
    }
    function refreshLessonContext(){
      if(location.href!==lastContextUrl){lastContextUrl=location.href;lastTreeLesson=null;lastSourceSignature='';semesterManuallySet=false;}
      const active=[...document.querySelectorAll('#jstree_node_tree .jstree-clicked,#jstree_node_tree [aria-selected="true"],#jstree_node_tree .jstree-wholerow-clicked')]
        .map(el=>treeLesson(el)).find(Boolean);
      if(active && (!lastTreeLesson||active.text!==lastTreeLesson.text))lastTreeLesson=active;
    }
    async function updateContextBar(){
      const sequence=++contextSequence;
      refreshLessonContext();
      detectNoorContext();
      refreshCurrentDisplay();
      // Main-world jsTree exposes the selected leaf and all ancestor titles,
      // including the term and unit. It is more reliable than text scraping.
      try{
        if(!pageReady)await waitHelper(1200);
        const result=await callPage('activeTreeLesson',{},2600);
        if(sequence!==contextSequence)return;
        if(result?.ok&&result.lesson){
          const signature=[result.nodeId||'',result.lesson,result.unit,result.semester].join('|');
          if(signature!==lastSourceSignature){
            field('noor-context-lesson').value=result.lesson;
            if(result.unit)field('noor-context-unit').value=result.unit;
            if(result.semester){semesterSel.value=result.semester;semesterManuallySet=false;}
            lastSourceSignature=signature;
          }
        }else if(lastTreeLesson){
          if(lastTreeLesson.text)field('noor-context-lesson').value=lastTreeLesson.text;
          if(lastTreeLesson.unit)field('noor-context-unit').value=lastTreeLesson.unit;
          if(lastTreeLesson.semester&&!semesterManuallySet)semesterSel.value=lastTreeLesson.semester;
        }
      }catch(_){
        // Content-world click detection remains available when jsTree loads slowly.
      }
      if(!semesterManuallySet&&!semesterSel.value){
        const tree=document.querySelector('#jstree_node_tree');
        const navText=clean((tree?.querySelector('.jstree-clicked')?.closest('li')?.parentElement?.innerText)||'');
        const guessed=semesterFromText(navText);
        if(guessed)semesterSel.value=guessed;
      }
      refreshCurrentDisplay();
      const needsCorrection=!field('noor-context-lesson').value.trim()||!field('noor-context-unit').value.trim()||!field('noor-context-grade').value.trim()||!field('noor-subject').value.trim();
      panel.querySelector('#noor-prep-controls').hidden=!needsCorrection;
      if(needsCorrection)panel.querySelector('#noor-lesson-context').open=true;
    }
    void updateContextBar();
    // Tree click detection should work both on purple درس badges and on a jsTree anchor.
    document.addEventListener('click',event=>{
      if(event.target.closest?.('#noor-prep-panel'))return;
      const treeClick=event.target.closest?.('#jstree_node_tree');
      const clickedLesson=treeLesson(event.target);
      if(treeClick&&!clickedLesson){
        lastTreeLesson=null;
        panel.querySelector('#noor-context-lesson').value='';
      }
      if(treeClick||clickedLesson){
        setTimeout(()=>void updateContextBar(),160);
        setTimeout(()=>void updateContextBar(),700);
      }
    },false);
    const contextObserver=new MutationObserver(mutations=>{
      if(!mutations.some(m=>!m.target.closest?.('#noor-prep-panel')&&!m.target.closest?.('#stnNoorWidget')))return;
      clearTimeout(contextTimer);contextTimer=setTimeout(()=>void updateContextBar(),400);
    });
    let contextTimer;
    contextObserver.observe(document.querySelector('#jstree_node_tree')||document.querySelector('main')||document.body,
      {childList:true,subtree:true,attributes:true,attributeFilter:['class','aria-selected']});
    ['noor-subject','noor-context-grade','noor-context-unit','noor-context-lesson'].forEach(id=>{
      field(id).addEventListener('change',()=>refreshCurrentDisplay());
    });
    const refreshDelayed=[900,2100,4400];refreshDelayed.forEach(ms=>setTimeout(()=>void updateContextBar(),ms));
    const teacherKeyInput=panel.querySelector('#noor-teacher-gemini-key');
    const keyStatus=panel.querySelector('#noor-key-status');
    const validTeacherKey=key=>teacherProfile.validKey(key);
    const teacherProfile=window.NOOR_TEACHER_PROFILE;
    const profileStatus=panel.querySelector('#noor-teacher-profile-status');
    let currentTeacherId='';
    async function refreshTeacherProfile(){
      try{
        const {id,key}=await teacherProfile.read();
        currentTeacherId=id;
        const ready=Boolean(id&&key&&validTeacherKey(key));
        teacherKeyInput.value='';
        panel.querySelector('#noor-key-setup').hidden=ready;
        panel.querySelector('#noor-prep-primary-actions').hidden=!ready;
        profileStatus.textContent=id?'':'افتح دفتر المعلم المدرسي بحسابك أولًا لربط المفتاح.';
        keyStatus.textContent=ready?'':'لم يتم حفظ مفتاح Gemini لهذا المعلم بعد.';
      }catch(e){teacherKeyInput.value='';profileStatus.textContent='تعذر قراءة حساب المعلم.';}
    }
    void refreshTeacherProfile();
    api.storage.onChanged.addListener((changes,area)=>{
      if(area==='local' && (changes.stnActiveTeacherId || (currentTeacherId&&changes['stnGeminiKey:'+currentTeacherId])))
        void refreshTeacherProfile();
    });
    panel.querySelector('#noor-open-gemini-setup').addEventListener('click',()=>{
      window.open('https://aistudio.google.com/api-keys','_blank','noopener,noreferrer');
      keyStatus.textContent='بعد إنشاء المفتاح في Google AI Studio، انسخه لهذا المعلم ثم اضغط حفظ.';
    });
    panel.querySelector('#noor-save-teacher-key').addEventListener('click',async()=>{
      if(!teacherKeyInput.value.trim()){
        try{teacherKeyInput.value=(await navigator.clipboard.readText()).trim();}catch(_){teacherKeyInput.focus();keyStatus.textContent='الصق المفتاح في الحقل ثم اضغط لصق وحفظ.';return;}
      }
      const key=teacherKeyInput.value.trim();
      if(!validTeacherKey(key)){keyStatus.textContent='صيغة المفتاح غير معروفة. انسخ مفتاح Gemini API كاملًا من Google AI Studio دون إضافة حروف؛ المفاتيح الجديدة قد تبدأ بـ AQ. والقديمة بـ AIza.';return;}
      try {
        await teacherProfile.save(key);
        keyStatus.textContent='تم حفظ المفتاح لهذا المعلم. جارٍ اختبار اتصاله بـ Google…';
        let testResult;
        try { testResult=await api.runtime.sendMessage({type:'NOOR_GEMINI_TEST_KEY'}); }
        catch(e) { testResult={ok:false,error:'تعذر الاتصال بخدمة التحقق: '+String(e.message||e).slice(0,100)}; }
        if(testResult?.ok){
          keyStatus.textContent='';
          panel.querySelector('#noor-key-setup').hidden=true;
          panel.querySelector('#noor-prep-primary-actions').hidden=false;
          teacherKeyInput.value='';
        }else{
          keyStatus.textContent='تعذر التحقق من المفتاح: '+String(testResult?.error||'تعذر التحقق').slice(0,220)+' — راجع المفتاح ثم احفظه مجددًا.';
          panel.querySelector('#noor-key-setup').hidden=false;
          panel.querySelector('#noor-prep-primary-actions').hidden=true;
        }
      }
      catch(e){keyStatus.textContent=String(e.message||e);}
    });
    panel.querySelector('#noor-migrate-teacher-key').addEventListener('click',async()=>{
      if(!confirm('هل هذا المفتاح القديم يخص حساب المعلم الحالي؟ لا تنقل مفتاح شخص آخر.'))return;
      try {await teacherProfile.migrateLegacy();await refreshTeacherProfile();keyStatus.textContent='نُقل مفتاح الإضافة القديمة لهذا المعلم وحُذف المفتاح العام.';}
      catch(e){keyStatus.textContent=String(e.message||e);}
    });
    panel.querySelector('#noor-remove-teacher-key').addEventListener('click',async()=>{
      if(!confirm('حذف مفتاح Gemini المحفوظ لهذا المعلم فقط؟'))return;
      try {await teacherProfile.remove();await refreshTeacherProfile();keyStatus.textContent='تم حذف مفتاح هذا المعلم.';}
      catch(e){keyStatus.textContent=String(e.message||e);}
    });
    const aiStatus = panel.querySelector('#noor-prep-ai-status');
    let generatedPrep = null;
    panel.querySelector('#noor-generate-prep').addEventListener('click',async () => {
      updateContextBar();
      const subject=panel.querySelector('#noor-subject').value.trim();
      const grade=panel.querySelector('#noor-context-grade').value.trim();
      const unit=panel.querySelector('#noor-context-unit').value.trim();
      const semester=panel.querySelector('#noor-context-semester').value;
      const lesson=panel.querySelector('#noor-context-lesson').value.trim();
      if(!semester){aiStatus.textContent='اختر الفصل الدراسي أولًا.';return;}
      const official=globalThis.NoorHubClassUI?.selected?.();
      const actual=globalThis.NoorCourseCatalog?.subjectOf?.(official?.label||'')||'';
      const normSubject=t=>String(t||'').normalize('NFKC').replace(/[أإآ]/g,'ا').trim().toLowerCase();
      if(!actual||normSubject(actual)!==normSubject(subject)){
       aiStatus.textContent='مادة الصف الرسمي في نور غير متطابقة مع حقل التحضير. افتح بطاقة المادة الصحيحة؛ لن نرسل Gemini طلبًا لمادة افتراضية.';return;
      }
      if(!subject||!grade||!unit||!lesson){aiStatus.textContent='تعذر تحديد المادة أو الصف أو الدرس؛ افتح تفاصيل الدرس أو صحح البيانات في قسم التحضير.';return;}
      const {id,key:personalKey}=await teacherProfile.read();
      if(!id||!validTeacherKey(personalKey)){aiStatus.textContent='اربط حسابك من دفتر المعلم واحفظ مفتاح Gemini الخاص بك أولًا.';return;}
      const btn=panel.querySelector('#noor-generate-prep');btn.disabled=true;
      aiStatus.textContent='جارٍ توليد التحضير…';
      try {
        const result=await api.runtime.sendMessage({type:'NOOR_PREP_GENERATE',subject,grade,unit:(semester==='1'?'First semester':'Second semester')+' — '+unit,lesson,
          lessonText:(document.querySelector('main')||document.body).innerText.slice(0,4500),
          fields:['objectives','concepts','warmUp','procedures','formative','closing','details']});
        if(!result?.ok)throw new Error(result?.error||'تعذر التوليد');
        generatedPrep={title:lesson,name:lesson,unit,semester,grade,...result.fields};
        if(!generatedPrep.objectives||!generatedPrep.procedures)throw new Error('استجابة ناقصة: الأهداف أو الإجراءات');
        panel.querySelector('#noor-apply-prep').disabled=false;
        const lines=['الدرس: '+lesson,'الوحدة: '+unit,'الفصل: '+(semester==='1'?'الأول':'الثاني'),...['objectives','concepts','warmUp','procedures','formative','closing','details'].map(k=>k+':\n'+(generatedPrep[k]||''))];
        panel.querySelector('#noor-generated-preview').value=lines.join('\n\n');
        panel.querySelector('#noor-generated-output').hidden=false;
        aiStatus.textContent='✅ التحضير جاهز للمراجعة. استخدم زر النسخ أو التعبئة دون حفظ تلقائي.';
      }catch(e){aiStatus.textContent='خطأ: '+String(e.message||e);}
      finally{btn.disabled=false;}
    });
    panel.querySelector('#noor-apply-prep').addEventListener('click',async()=>{
      if(!generatedPrep)return;
      if(!isAddPage()){
        const preparedText=panel.querySelector('#noor-generated-preview').value;
        try{await navigator.clipboard.writeText(preparedText);aiStatus.textContent='✅ نُسخ التحضير. افتح نموذج التحضير في نور للصقه.';}
        catch(_){
          const txt=panel.querySelector('#noor-generated-preview');
          panel.querySelector('#noor-generated-output').open=true;
          txt.focus();txt.select();
          const copied=document.execCommand('copy');
          aiStatus.textContent=copied?'✅ تم نسخ التحضير.':'حدد النص وانسخه يدويًا من مربع المراجعة.';
        }
        return;
      }
      if(!confirm('ستُملأ حقول التحضير الظاهرة في نور دون حفظ نهائي. متابعة؟'))return;
      try{
        await fillLesson(generatedPrep,{save:false});
        const context=[generatedPrep.title,generatedPrep.unit,generatedPrep.objectives,generatedPrep.procedures].join(' ').toLowerCase();
        const debate=/debate|argument|discuss|evaluate|judge|نقاش|حوار|تقييم/.test(context);
        const groups={
          levels:debate?['التقييم','الفهم']:['الفهم','التطبيق'],
          strategies:debate?['التعلم التعاوني','التعلم التشاركي']:['التعلم التعاوني','التعلم بالاكتشاف'],
          resources:['الكتاب','جهاز الحاسب','عروض تقديمية']
        };
        let summary='';
        try{
          const picks=await callPage('fillMultiChoices',{groups},10000);
          summary=Object.entries(picks||{}).map(([k,v])=>k+': '+(v.status||'unknown')+' '+(v.matched||[]).join('، ')).join(' | ');
        }catch(dropErr){summary='فشل تعبئة القوائم: '+String(dropErr.message||dropErr);}
        aiStatus.textContent='تمت تعبئة النصوص. نتائج القوائم: '+summary+' — راجعها قبل الحفظ.';
      }
      catch(e){aiStatus.textContent='فشلت التعبئة: '+String(e.message||e);}
    });
    const gradeSel = panel.querySelector("#noor-grade");
    const unitSel = panel.querySelector("#noor-unit");
    const lessonSel = panel.querySelector("#noor-lesson");

    if (!grades.length) {
      const empty = document.createElement("option");
      empty.value = ""; empty.textContent = "لا توجد تحاضير مستوردة";
      gradeSel.appendChild(empty);
    }
    grades.forEach(g => {
      const o = document.createElement("option");
      o.value = g; o.textContent = g + " (" + Object.values(byGrade[g]).reduce((n, a) => n + a.length, 0) + ")";
      gradeSel.appendChild(o);
    });

    function fileGradeActive() {
      return fileLessons && fileLessons.length &&
        fileLessons[0].grade && gradeSel.value === fileLessons[0].grade;
    }
    function refreshUnits() {
      const g = gradeSel.value;
      unitSel.replaceChildren();
      if (fileGradeActive() || (g === "From file" && fileLessons && fileLessons.length)) {
        const seen = {};
        fileLessons.forEach(function (L) {
          if (seen[L.unit]) return;
          seen[L.unit] = true;
          const o = document.createElement("option");
          o.value = L.unit;
          o.textContent = L.unit.length > 55 ? L.unit.slice(0, 52) + "…" : L.unit;
          unitSel.appendChild(o);
        });
        refreshLessons();
        return;
      }
      const units = Object.keys(byGrade[g] || {});
      if (!units.length) {
        const empty = document.createElement("option"); empty.value = "";
        empty.textContent = "استورد تحضيرًا لعرض الوحدات"; unitSel.appendChild(empty);
      }
      units.forEach(u => {
        const o = document.createElement("option");
        o.value = u;
        o.textContent = u.length > 55 ? u.slice(0, 52) + "…" : u;
        unitSel.appendChild(o);
      });
      refreshLessons();
    }
    function refreshLessons() {
      var list;
      if (fileGradeActive() || (gradeSel.value === "From file" && fileLessons && fileLessons.length)) {
        const u = unitSel.value;
        list = fileLessons.filter(function (L) { return L.unit === u; });
        if (!list.length) list = fileLessons.slice();
      } else {
        list = (byGrade[gradeSel.value] || {})[unitSel.value] || [];
      }
      lessonSel.replaceChildren();
      if (!list.length) {
        const empty = document.createElement("option"); empty.value = "";
        empty.textContent = "لا توجد تحاضير محفوظة"; lessonSel.appendChild(empty);
      }
      list.forEach(function (L) {
        const o = document.createElement("option");
        o.value = L.id;
        o.textContent = L.name;
        lessonSel.appendChild(o);
      });
    }
    refreshUnits();
    // Keep the premade lesson library hidden; selecting one can populate editable context.
    function syncSelectedLessonContext(){
      if(!panel.querySelector('#noor-lesson-library').open) return;
      panel.querySelector('#noor-context-grade').value=gradeSel.value;
      panel.querySelector('#noor-context-unit').value=unitSel.value;
      panel.querySelector('#noor-context-lesson').value=lessonSel.selectedOptions[0]?.textContent || '';
    }
    panel.querySelector('#noor-lesson-library').addEventListener('toggle',syncSelectedLessonContext);
    lessonSel.addEventListener('change',syncSelectedLessonContext);
    gradeSel.addEventListener('change',()=>setTimeout(syncSelectedLessonContext,0));
    unitSel.addEventListener('change',()=>setTimeout(syncSelectedLessonContext,0));
    gradeSel.onchange = refreshUnits;
    unitSel.onchange = refreshLessons;

    try {
      const st = loadSettings();
      const dateEl = panel.querySelector("#noor-start-date");
      const perEl = panel.querySelector("#noor-periods");
      if (dateEl) dateEl.value = st.startDate || new Date().toISOString().slice(0, 10);
      if (perEl && st.periods) perEl.value = st.periods;
      if (st.grade && [...gradeSel.options].some(o => o.value === st.grade)) {
        gradeSel.value = st.grade;
        refreshUnits();
        if (st.unit && [...unitSel.options].some(o => o.value === st.unit)) {
          unitSel.value = st.unit;
          refreshLessons();
        }
      }
    } catch (_) {
      try { panel.querySelector("#noor-start-date").value = new Date().toISOString().slice(0, 10); } catch (__) {}
    }

    function currentLesson() {
      if (fileLessons && fileLessons.length) {
        const f = fileLessons.find(function (L) { return L.id === lessonSel.value; });
        if (f) return f;
      }
      if (fileLesson && lessonSel.value === fileLesson.id) return fileLesson;
      return lessons.find(L => L.id === lessonSel.value);
    }

    panel.querySelector("#noor-close").onclick = (ev) => {
      ev.stopPropagation();
      panel.remove();
    };
    const minBtn = panel.querySelector("#noor-min");
    if (minBtn) {
      minBtn.onclick = (ev) => {
        ev.stopPropagation();
        panel.classList.toggle("minimized");
        minBtn.textContent = panel.classList.contains("minimized") ? "+" : "–";
      };
    }
    panel.querySelector("#noor-fill-btn").onclick = async () => {
      const lesson = currentLesson();
      if (!lesson) { alert("لم يتم اختيار درس"); return; }
      const startDate = panel.querySelector("#noor-start-date").value;
      const periods = Number(panel.querySelector("#noor-periods").value) || 2;
      saveSettings({
        grade: gradeSel.value,
        unit: unitSel.value,
        startDate: startDate,
        periods: periods
      });
      const previewOn = panel.querySelector("#noor-preview") ? panel.querySelector("#noor-preview").checked : true;
      if (previewOn) {
        const ok = confirm(
          "معاينة قبل التعبئة\n\n" +
          "الدرس: " + (lesson.name || lesson.title || "") + "\n" +
          "الوحدة: " + (lesson.unit || "") + "\n" +
          "التاريخ: " + (startDate || "اليوم") + " · الحصص: " + periods + "\n\n" +
          "الأهداف: " + String(lesson.objectives || "").slice(0, 160).replace(/\s+/g, " ") + "…\n\n" +
          "متابعة التعبئة والحفظ؟"
        );
        if (!ok) return;
      }
      const opts = { startDate, periods, save: true };
      const status = panel.querySelector(".status");
      if (status) { setSafeStatusMarkup(status, "جاري التعبئة التلقائية…"); status.style.color = "#0984e3"; }
      try {
        await fillLessonWithDates(lesson, opts);
        if (status) setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br><b>تم.</b>"));
      } catch (e) {
        if (status) { setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br>خطأ: " + e.message)); status.style.color = "#c40"; }
      }
    };
    panel.querySelector("#noor-fill-dates-btn").onclick = panel.querySelector("#noor-fill-btn").onclick;
    panel.querySelector("#noor-batch-btn").onclick = async () => {
      let list = (byGrade[gradeSel.value] || {})[unitSel.value] || [];
      if (fileLessons && fileLessons.length &&
          (gradeSel.value === "From file" || gradeSel.value === (fileLessons[0] && fileLessons[0].grade))) {
        list = fileLessons.filter(function (L) { return L.unit === unitSel.value; });
        if (!list.length) list = fileLessons.slice();
      }
      if (!list.length) { alert("لا توجد دروس في هذه الوحدة."); return; }
      await startBatchUnit(list, {
        startDate: panel.querySelector("#noor-start-date").value,
        periods: Number(panel.querySelector("#noor-periods").value) || 2,
        save: true
      });
    };
    panel.querySelector("#noor-file").onchange = async (ev) => {
      const file = ev.target.files && ev.target.files[0];
      if (file) {
        await handleFile(file);
        // handleFile already fills grade/unit/lesson dropdowns — do not overwrite
      }
    };

    
    const hwFill = panel.querySelector("#noor-hw-fill");
    const hwAutoSubmit = panel.querySelector("#noor-hw-autosubmit");
    if (hwFill) hwFill.onclick = async () => {
      const lesson = currentLesson();
      const draft = buildHomeworkDraft(lesson) || {
        title: "واجب " + new Date().toISOString().slice(0, 10),
        text: "أجب عن أسئلة الدرس."
      };
      try { sessionStorage.setItem("noor_hw_draft", JSON.stringify(draft)); } catch (_) {}
      const status = panel.querySelector(".status");
      try {
        await waitHelper();
        const page = await callPage("detectLmsPage", {}, 2000);
        if (page && page.isHomework) {
          const due = new Date(); due.setDate(due.getDate() + 3);
          const r = await callPage("fillHomeworkDraft", {
            title: draft.title,
            description: draft.text,
            dueDate: due.toISOString().slice(0, 10),
            publishDate: new Date().toISOString().slice(0, 10),
            autoSubmit: !!(hwAutoSubmit && hwAutoSubmit.checked),
            grade: (lesson && lesson.grade) || ""
          }, 20000);
          if (status) {
            let msg = r && r.ok
              ? "تم تعبئة نموذج الواجب ✓ (" + (r.done || []).join(", ") + ")"
              : "تعذّرت تعبئة بعض الحقول";
            if (r && r.failed && r.failed.length) msg += "<br>تخطّي: " + r.failed.join(", ");
            if (r && r.submitted) msg += "<br>تم الضغط على إضافة";
            setSafeStatusMarkup(status, msg);
            status.style.color = r && r.ok ? "#0a7" : "#c40";
          }
          return;
        }
      } catch (e) {
        if (status) { setSafeStatusMarkup(status, "خطأ التعبئة: " + e.message); status.style.color = "#c40"; }
      }
      // Not on homework page → navigate
      const url = findHomeworkUrl();
      if (url) {
        if (confirm("لست على صفحة الواجب.\nالانتقال الآن لتعبئة النموذج؟")) {
          location.href = url;
        }
      } else {
        alert("افتح صفحة «إضافة واجب جديد» من قائمة المادة، ثم اضغط «تعبئة نموذج الواجب في الصفحة».");
      }
    };

    const hwBtn = panel.querySelector("#noor-hw-btn");
    const hwOut = panel.querySelector("#noor-hw-out");
    const hwCopy = panel.querySelector("#noor-hw-copy");
    const hwOpen = panel.querySelector("#noor-hw-open");
    const attBtn = panel.querySelector("#noor-att-btn");
    const attFile = panel.querySelector("#noor-att-file");

    if (hwBtn) hwBtn.onclick = () => {
      const lesson = currentLesson();
      if (!lesson) { alert("اختر درساً أولاً"); return; }
      const draft = buildHomeworkDraft(lesson);
      if (!draft) return;
      try {
        sessionStorage.setItem("noor_hw_draft", JSON.stringify(draft));
      } catch (_) {}
      if (hwOut) {
        hwOut.style.display = "block";
        hwOut.value = draft.text;
      }
      if (hwCopy) hwCopy.style.display = "block";
      const status = panel.querySelector(".status");
      if (status) {
        setSafeStatusMarkup(status, "تم إنشاء مسودة واجب: <b>" + draft.title + "</b><br>انسخ النص أو افتح صفحة الواجبات للصقها.");
        status.style.color = "#0a7";
      }
    };

    if (hwCopy) hwCopy.onclick = async () => {
      const text = (hwOut && hwOut.value) || "";
      try {
        await navigator.clipboard.writeText(text);
        hwCopy.textContent = "تم النسخ ✓";
        setTimeout(() => { hwCopy.textContent = "نسخ نص الواجب"; }, 1500);
      } catch (_) {
        if (hwOut) { hwOut.select(); document.execCommand("copy"); }
      }
    };

    if (hwOpen) hwOpen.onclick = async () => {
      const lesson = currentLesson();
      if (lesson) {
        const draft = buildHomeworkDraft(lesson);
        try { sessionStorage.setItem("noor_hw_draft", JSON.stringify(draft)); } catch (_) {}
      }
      // try fill if already on homework page
      try {
        const page = await callPage("detectLmsPage", {}, 2000);
        if (page && page.isHomework) {
          const draft = JSON.parse(sessionStorage.getItem("noor_hw_draft") || "null");
          if (draft) {
            const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 2);
            const iso = tomorrow.toISOString().slice(0, 10);
            await callPage("fillHomeworkDraft", {
              title: draft.title,
              description: draft.text,
              dueDate: iso,
              publishDate: ""
            });
            const status = panel.querySelector(".status");
            if (status) setSafeStatusMarkup(status, "تم تعبئة حقول الواجب في الصفحة الحالية.");
            return;
          }
        }
      } catch (_) {}
      const url = findHomeworkUrl();
      if (url) location.href = url;
      else alert("لم يُعثر على رابط الواجبات. افتح صفحة الواجبات من قائمة المادة يدوياً، ثم اضغط الزر مرة أخرى للتعبئة.");
    };

    if (attBtn && attFile) {
      attBtn.onclick = () => attFile.click();
      attFile.onchange = async () => {
        const file = attFile.files && attFile.files[0];
        if (!file) return;
        const lesson = currentLesson();
        const meta = {
          title: (lesson && (lesson.name || lesson.title)) || file.name,
          description: lesson
            ? ("مرفق للدرس: " + (lesson.unit || "") + " / " + (lesson.name || "") + "\\n" + (lesson.objectives || "").slice(0, 200))
            : file.name,
          fileName: file.name
        };
        try { sessionStorage.setItem("noor_att_meta", JSON.stringify(meta)); } catch (_) {}
        const status = panel.querySelector(".status");
        if (status) {
          setSafeStatusMarkup(status, "ملف جاهز: <b>" + file.name + "</b><br>افتح صفحة مرفقات المادة، اختر نفس الملف من زر الرفع في نور، والعنوان سيُقترح من الدرس.");
          status.style.color = "#0984e3";
        }
        try {
          const page = await callPage("detectLmsPage", {}, 2000);
          if (page && (page.isAttachment || page.hasFileInput)) {
            await callPage("fillAttachmentMeta", meta);
            if (status) setSafeStatusMarkup(status, getSafeStatusMarkup(status) + ("<br>تم تعبئة عنوان المرفق في الصفحة."));
            return;
          }
        } catch (_) {}
        const url = findAttachmentUrl();
        if (url && confirm("الانتقال إلى صفحة المرفقات الآن؟\\nبعدها اختر الملف من زر الرفع في نور.")) {
          location.href = url;
        }
      };
    }

    // Auto-apply draft when landing on homework/attachment pages
    (async function applyPendingDrafts() {
      try {
        await waitHelper();
        const page = await callPage("detectLmsPage", {}, 2500);
        if (!page) return;
        if (page.isHomework) {
          const draft = JSON.parse(sessionStorage.getItem("noor_hw_draft") || "null");
          if (draft) {
            const tomorrow = new Date(); tomorrow.setDate(tomorrow.getDate() + 2);
            await callPage("fillHomeworkDraft", {
              title: draft.title,
              description: draft.text,
              dueDate: tomorrow.toISOString().slice(0, 10),
              publishDate: new Date().toISOString().slice(0, 10),
              autoSubmit: false
            });
            const status = document.querySelector("#noor-prep-panel .status");
            if (status) {
              setSafeStatusMarkup(status, "تم تعبئة مسودة الواجب في النموذج. راجعها ثم احفظ/انشر.");
              status.style.color = "#0a7";
            }
          }
        }
        if (page.isAttachment || page.hasFileInput) {
          const meta = JSON.parse(sessionStorage.getItem("noor_att_meta") || "null");
          if (meta) {
            await callPage("fillAttachmentMeta", meta);
          }
        }
      } catch (_) {}
    })();

  }

  function maybeShow(lessons) {
    if (document.getElementById("noor-prep-panel")) return;
    const url = location.href.toLowerCase();
    const body = (document.body && document.body.innerText) || "";
    if (url.includes("add_preparation") || url.includes("preparation") ||
        body.includes("Warm up Activity") || body.includes("Formative Assessment") ||
        body.includes("OBJECTIVES") || body.includes("اجراءات سير") ||
        document.getElementById("PreparationObjective") ||
        document.querySelector('a[href*="add_preparation"]')) {
      createPanel(lessons);
    }
  }

  const lessons = typeof SITE_LESSONS !== "undefined" ? SITE_LESSONS : [];

  async function resumeBatchIfNeeded() {
    try {
      const pending = JSON.parse(sessionStorage.getItem("noor_batch_pending") || "null");
      if (pending && isAddPage()) {
        sessionStorage.removeItem("noor_batch_pending");
        await new Promise(r => setTimeout(r, 2000));
        await waitHelper(10000);
        const bank = (typeof SITE_LESSONS !== "undefined" ? SITE_LESSONS : []).concat(fileLessons || []);
        const list = (pending.bankIds || []).map(id => bank.find(L => L.id === id)).filter(Boolean);
        if (list.length) {
          if (window.__noorBatchRunning) return;
          window.__noorBatchRunning = true;
          try {
            await startBatchUnit(list, pending.opts || {});
          } finally {
            window.__noorBatchRunning = false;
          }
          return;
        }
      }

      const st = JSON.parse(sessionStorage.getItem("noor_batch") || "null");
      if (!st || !st.active) return;
      if (st.index >= (st.items || []).length) return;

      if (!isAddPage()) {
        const url = st.addUrl || findAddPreparationUrl();
        if (url) {
          location.href = url;
          return;
        }
        await goToAddPreparation();
        return;
      }

      if (!document.getElementById("add_preparation_form") && !document.getElementById("PreparationObjective")) {
        await new Promise(r => setTimeout(r, 1500));
      }
      await new Promise(r => setTimeout(r, 2000));
      await waitHelper(8000);
      if (window.__noorBatchRunning) return;
      window.__noorBatchRunning = true;
      try { await runBatchStep(); } finally { window.__noorBatchRunning = false; }
    } catch (e) { console.warn("[Noor] resume batch", e); }
  }

  // Verified, headless preparation interface for the unified teacher pipeline.
  // Reuses the existing Noor tree/timeslot APIs, without duplicating form selectors.
  globalThis.NoorPrepBridge2828 = Object.freeze({
    onAddPage: isAddPage,
    async courseIdentity() {
      if (!isAddPage()) return {};
      await waitHelper(7000);
      return callPage('courseId',{strict:true},6000);
    },
    async activeTreeLesson() {
      if (!isAddPage()) return {ok:false,reason:'not_preparation_page'};
      await waitHelper(7000);
      return callPage('activeTreeLesson',{},6000);
    },
    findAddPage: findAddPreparationUrl,
    openAddPage: goToAddPreparation,
    async orderedUnit({semester,unitNo}) {
      if(!isAddPage())return {error:'tree'};
      await waitHelper(12000);
      return callPage('orderedUnit',{semester,unitNo},42000);
    },
    async curriculum() {
      if (!isAddPage()) throw Error('افتح نموذج إضافة تحضير من الصف الصحيح أولًا.');
      await waitHelper(12000);
      const tree=await callPage('curriculum',{},90000);
      if (tree?.error || !Array.isArray(tree?.units) || !tree.units.length)
        throw Error('لم أتمكن من قراءة شجرة نور الحقيقية: '+(tree?.error||'empty_tree'));
      return tree.units;
    },
    async parseFile(file) {
      if (!file || file.size>18*1024*1024) throw Error('ملف التحضير غير موجود أو كبير جدًا.');
      const name=file.name.toLowerCase();let text='';
      if (name.endsWith('.txt')) text=await file.text();
      else if (name.endsWith('.docx')) text=await extractTextFromDocx(await readFileAsArrayBuffer(file));
      else if (name.endsWith('.pdf')) text=await extractTextFromPdf(await readFileAsArrayBuffer(file));
      else throw Error('ملف التحضير يجب أن يكون PDF أو Word DOCX أو TXT.');
      const list=parseAllLessonsFromText(text,file.name);
      if (!list.length) throw Error('لم أستطع استخراج أي درس من الملف.');
      // Preserve imported text in memory only; pipeline state is stored under the verified teacher.
      fileLessons=list;fileLesson=list[0];
      return list.map(l=>({id:l.id,unit:l.unit,name:l.name,title:l.title,
        objectives:l.objectives,concepts:l.concepts,warmUp:l.warmUp,
        procedures:l.procedures,formative:l.formative,closing:l.closing,details:l.details}));
    },
    async selectLesson(tree) {
      if (!isAddPage())throw Error('نموذج التحضير لم يفتح بعد.');
      if (!tree?.termId||!tree?.unitId||!tree?.lessonId)throw Error('معرفات الدرس غير مؤكدة من شجرة نور.');
      await waitHelper(12000);
      const sel=await callPage('selectLesson',{termId:tree.termId,unitId:tree.unitId,
        lessonId:tree.lessonId},45000);
      // Unsafe title_click fallback is not enough to prove the target lesson.
      if(!sel?.ok||sel.method!=='node_id'||String(sel.lessonId)!==String(tree.lessonId))
        throw Error('لم يؤكد نور اختيار الدرس بالمعرف الرسمي. تم إيقاف الحفظ.');
      return sel;
    },
    async stagePreparation(tree,content,options={}) {
      await this.selectLesson(tree);
      const required=['objectives','procedures','formative','closing'];
      if(required.some(k=>String(content?.[k]||'').trim().length<15))
        throw Error('التحضير يحتاج أهدافًا وإجراءات وتقييمًا تكوينيًا وختاميًا كاملة.');
      const filled=await fillLesson({...content,name:tree.title,title:(tree.title||content.title),unit:tree.unit||content.unit}, {save:false});
      if(!filled?.ok)throw Error('لم أتحقق من تعبئة أهداف التحضير وعنوانه ومحرراته: '+(filled?.results||[]).join(' | ').slice(0,250));
      let selectedDates=[];
      const log=await assignDatesAndSave({startDate:options.startDate,
        periods:options.periods,save:false,lesson:content,onDates:ds=>{selectedDates=ds}});
      if(log.some(s=>/(?:ERROR|FAIL|fail|No free periods|Could not|0\/)/.test(s)))
        throw Error('لم ينجح توزيع الحصص والتواريخ: '+log.filter(s=>/(?:ERROR|FAIL|fail|No free|Could not|0\/)/.test(s)).join(' | ').slice(0,280));
      if(!log.some(s=>/^Periods applied: [1-9]/.test(s)))
        throw Error('لم يتم إثبات اختيار الحصص في نور.');
      if(!selectedDates.length)throw Error('لم يُحدد نور تاريخًا للحصة.');
      return {ok:true,log,scheduledDate:selectedDates[0]};
    },
    async verifyPreparationBeforeSave(expectedLessonNodeId){
      if(!isAddPage())return {ok:false,reason:'not_add_preparation_page'};
      const report=await callPage('reviewPreparationState',{},10000);
      if(!report?.ok)return report||{ok:false,reason:'no_page_response'};
      if(!expectedLessonNodeId||String(report.lessonNodeId)!==String(expectedLessonNodeId))
        return {ok:false,reason:'lesson_tree_selection_changed'};
      return report;
    },
    async submitPreparation(){
      if(!isAddPage())throw Error('لسنا في نموذج حفظ التحضير.');
      const result=await callPage('clickSave',{},12000);
      if(!result?.ok||!result?.scheduled)throw Error('لم يقبل نور حفظ التحضير: '+(result?.reason||'no_save_ack'));
      return {scheduled:true,needsServerVerification:true};
    }
  });

  function start() { maybeShow(lessons); resumeBatchIfNeeded(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
  [1000, 3000, 6000].forEach(t => setTimeout(start, t));
  try {
    new MutationObserver(() => maybeShow(lessons)).observe(document.documentElement, { childList: true, subtree: true });
  } catch (_) {}
})();
