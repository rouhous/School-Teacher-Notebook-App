/* Verify only the course and branch chosen by the teacher. */
(function(root){
 'use strict';
 const KEY='stnNoorPositionLookup:v1';
 const prepIndex='/teacher/courses/preparations_index/';
 const addPrep='/teacher/courses/add_preparation/';
 const dashboardPage=()=>/^\/teacher\/?$/i.test(location.pathname);
 const normalize=value=>String(value||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const cid=url=>decodeURIComponent(url.pathname.match(/\/cid:([^/]+)/i)?.[1]||'');
 function officialURL(value,prefix){
  try{
   const url=new URL(value,location.href);
   if(url.origin===location.origin&&url.pathname.toLowerCase().startsWith(prefix)&&!url.username&&!url.password){url.hash='';return url;}
  }catch(_){}
  return null;
 }
 const addLinks=()=>[...new Set([...document.querySelectorAll('a[href*="add_preparation"]')]
   .map(a=>officialURL(a.href,addPrep)?.href).filter(Boolean))];
 const position=value=>{
  const number=String(value??'').trim().replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776));
  return /^\d+$/.test(number)&&Number.isSafeInteger(Number(number))&&Number(number)>0?Number(number):null;
 };
 const snapshotKey=(teacher,courseId,semester,unit)=>'stnNoorOrderedUnit:v1:'+JSON.stringify([teacher,courseId,semester,unit]);
 const lessonAt=(branch,lesson)=>branch?.lessons?.[position(lesson)-1]||null;
 const matchIds=(branch,lesson,proof)=>Boolean(proof&&branch?.termId===proof.termId&&branch.unitId===proof.unitId&&lesson?.id===proof.lessonId);
 const load=()=>{
  try{
   const job=JSON.parse(sessionStorage.getItem(KEY)||'null');
   if(job&&Date.now()-job.at<10*60*1000)return job;
   sessionStorage.removeItem(KEY);
  }catch(_){}
  return null;
 };
 let cancellation=0;
 function cancel(){cancellation++;sessionStorage.removeItem(KEY);}
 const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 async function until(check,active){
  for(let attempt=0;attempt<24&&active();attempt++){
   const value=check();if(value)return value;
   await wait(250);
  }
  return null;
 }
 function routeFor(course){
  if(!/^\d+$/.test(course?.cidNumeric||''))return null;
  const route=officialURL(course.routes?.preparation,prepIndex);
  return route&&cid(route)===course.cidNumeric?route:new URL(prepIndex+'cid:'+course.cidNumeric,location.origin);
 }
 function go(job,stage,path,replace=false){
  const next=new URL(path,location.origin),here=new URL(location.href);here.hash='';
  sessionStorage.setItem(KEY,JSON.stringify({...job,stage,target:next.href}));
  if(here.href===next.href)return false;
  if(replace)location.replace(next.href);else location.assign(next.href);
  return true;
 }
 function create({teacher,allowed,proof,onProgress,onFinish}){
  let running=false;
  async function start(choice){
   if(running||load())return;
   const epoch=cancellation,id=await teacher();
   if(!id||!await allowed()||epoch!==cancellation||load())return;
   const job={id:crypto.randomUUID(),teacher:id,at:Date.now(),...choice};
   if(choice.cid&&proof(choice.cid)){
    go(job,'tree',location.href);
   }else if(choice.cid){
    const route=routeFor(root.NoorCourseCatalog?.get?.(choice.cid));
    if(!route){onFinish(job,{error:'class'});return;}
    if(go(job,'index',route.href))return;
   }else if(go(job,'dashboard','/teacher'))return;
   await resume();
  }
  async function resume(){
   const job=load();
   if(running||!job)return;
   running=true;
   const active=()=>load()?.id===job.id;
   const finish=result=>{if(active()){cancel();onFinish(job,result);}};
   try{
    if(await teacher()!==job.teacher){if(active())cancel();return;}
    if(!active())return;
    const page=new URL(location.href);page.hash='';
    if(page.href!==job.target&&!(job.stage==='dashboard'&&dashboardPage())){finish({error:'route'});return;}
    onProgress(job);
    const catalog=root.NoorCourseCatalog;
    if(job.stage==='dashboard'){
     await catalog.init();
     const cards=await until(()=>{
      const matches=catalog.cards().filter(card=>normalize(card.label)===normalize(job.label));
      return matches.length&&matches;
     },active);
     if(!active())return;
     if(cards?.length!==1){finish({error:'class'});return;}
     const getCourse=()=>{
      catalog.scan();
      const matches=catalog.all().filter(course=>normalize(course.label)===normalize(job.label)&&routeFor(course));
      return matches.length===1?matches[0]:null;
     };
     let course=getCourse();
     if(!course){
      const card=cards[0].element;
      const opener=card.querySelector('[data-toggle="popover"],[data-bs-toggle="popover"],button[type="button"]')||card;
      opener.click();
      course=await until(getCourse,active);
     }
     if(!active())return;
     if(!course){finish({error:'class'});return;}
     await catalog.flush();
     if(active())go({...job,cid:course.cidNumeric},'index',routeFor(course).href,true);
    }else if(job.stage==='index'){
     if(!officialURL(page.href,prepIndex)||cid(page)!==job.cid){finish({error:'class'});return;}
     const links=await until(()=>{const list=addLinks();return list.length&&list;},active);
     if(!active())return;
     if(links?.length!==1){finish({error:'route'});return;}
     const add=officialURL(links[0],addPrep);
     if(/^\d+$/.test(cid(add))&&cid(add)!==job.cid){finish({error:'class'});return;}
     go({...job,indexVerified:true},'tree',add.href,true);
    }else if(job.stage==='tree'){
     const bridge=root.NoorPrepBridge2828;
     if(!bridge?.onAddPage()||!job.indexVerified&&!proof(job.cid)){finish({error:'route'});return;}
     const identity=await bridge.courseIdentity().catch(()=>null);
     if(!active())return;
     if(identity?.cid&&String(identity.cid)!==job.cid){finish({error:'class'});return;}
     const branch=await bridge.orderedUnit(job);
     if(!active())return;
     if(branch?.error||!branch?.unitId){finish(branch||{error:'tree'});return;}
     await browser.storage.local.set({[snapshotKey(job.teacher,job.cid,job.semester,job.unitNo)]:branch});
     if(!active())return;
     sessionStorage.setItem('stnNoorVerifiedAddNavigation:v1',JSON.stringify({teacherId:job.teacher,numericCid:job.cid,addURL:location.href,at:Date.now()}));
     finish({branch});
    }
   }catch(_){finish({error:'tree'});}
   finally{running=false;}
  }
  return {start,resume};
 }
 root.NoorCurriculumDiscovery=Object.freeze({create,load,cancel,addLinks,dashboardPage,position,snapshotKey,lessonAt,matchIds});
})(globalThis);
