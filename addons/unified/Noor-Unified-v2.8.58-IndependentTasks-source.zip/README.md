# Noor Unified Firefox Extension 2.8.58

Choose Preparation, Activity, Exam, or SCORM in Noor Tools. Each task keeps its own class, lesson, settings, and progress. Opening a task in a separate tab lets it use its own Noor page. Stopping a task clears its pending steps. A submission already sent remains in Noor. The grade task appears when the Teacher Notebook sends a grade transfer.

- **Preparation** reuses the lesson selected in Noor or lets the teacher choose a position in the curriculum tree. Generation and file import keep the preparation review and automatic save options.
- **Activity** creates one activity per run with 1–10 questions. It tries the selected unit and lesson automatically. If the optional lesson link is unavailable, it proceeds to the class selection at the end of the form.
- **Exam** opens page 2 of the class card, then opens the electronic exam flow. The teacher chooses a traditional exam or one-question-at-a-time display. The extension sets the title, duration, publication date, and late deadline. Gemini generates the questions after the exam is saved in Noor. The extension inserts each question and checks its save before adding the next one.
- **SCORM** opens page 3 of the class card, then Digital Library → Interactive Lessons Library → Upload New Interactive Lesson. The extension attaches the ZIP and ticks the class in the publication form. An unavailable optional unit or lesson link does not block upload. Automatic save requires Noor’s mandatory fields.

The installable Firefox package is published by the repository’s Mozilla signing workflow.
