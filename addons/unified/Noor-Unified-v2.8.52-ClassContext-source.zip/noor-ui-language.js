/* Translate the extension panel without changing Noor labels or saved form values. */
(function(root){
 'use strict';
 const messages=new Map(Object.entries({
  '🧩 أدوات نور':'🧩 Noor Tools',
  'أدوات نور · دفتر المعلم':'Noor Tools · Teacher Notebook',
  'اسحب هنا لتحريك النافذة':'Drag to move the panel',
  'اسحب الشريط لتغيير مكان النافذة':'Drag to move the panel',
  'اضغط للفتح، واسحب لنقل الزر':'Click to open, or drag to move the button',
  'أدوات نور الموحدة':'Noor Tools',
  'أقسام إضافة نور':'Noor Tools tabs',
  'تصغير أو توسيع':'Minimize or expand',
  'تصغير الإضافة':'Minimize panel',
  'إعادة الموضع الافتراضي':'Reset position',
  'إعادة موضع النافذة':'Reset panel position',
  'إغلاق':'Close',
  '📘 الصف والمحتوى':'📘 Class and content',
  '⚙️ المهمة والإعدادات':'⚙️ Task and settings',
  'المادة المكتشفة من نور':'Subject detected in Noor',
  'اختر صفًا من بطاقة المادة أولًا':'Choose a class from its subject card first',
  'الصف / الفصل':'Grade / section',
  'اختر الفصل الظاهر في نور':'Choose the class shown in Noor',
  'اختر صفك من نور':'Choose your class in Noor',
  'الفصل الدراسي':'Semester',
  'الأول':'First',
  'الثاني':'Second',
  'التقييم':'Assessment',
  'درجات CSV: اختر تقييم الملف وحقل نور. مطابقة الطلاب تسبق التعبئة دائمًا، ولا يُضغط حفظ.':'CSV grades: choose the assessment and the Noor field. Students are matched before filling. Saving stays manual.',
  'التقييم في ملف CSV':'Assessment in the CSV file',
  'الحقل الذي سيُعبأ في نور':'Noor field to fill',
  'افتح جدول الدرجات وانقر فحص':'Open the gradebook and check matches',
  'السماح باستبدال الدرجات الموجودة (اختياري)':'Allow replacing existing grades (optional)',
  'الوحدة (رقمها أو اسمها كما يظهر في نور)':'Unit (number or name as shown in Noor)',
  'مثال: 4 أو المحور السادس: واقع وطموح':'Example: 4 or the unit name',
  'الدرس (رقمه أو اسمه كما يظهر في نور)':'Lesson (number or name as shown in Noor)',
  'مثال: 1 للدرس 4-1 أو الوحدة الأولى: القراءة':'Example: 1 for lesson 4-1, or the lesson name',
  'طريقة تحديد الدرس':'Lesson selection',
  'اكتشاف تلقائي من اختيار المعلم في نور (افتراضي)':'Detect the lesson selected in Noor (default)',
  'اختيار المعلم من شجرة الدروس أو قائمة نور':'Choose from the Noor lesson tree or list',
  'الوحدة / الفصل الدراسي':'Unit / semester',
  'اختر وحدة / مجموعة من نور':'Choose a Noor unit or group',
  'اختر الوحدة حسب اسمها في نور':'Choose the unit as named in Noor',
  'الدرس في الوحدة':'Lesson in this unit',
  'اختر الدرس من القائمة':'Choose a lesson from the list',
  '↻ تحديث دروس نور':'↻ Refresh Noor lessons',
  'تُعرض الوحدات أو المحاور بأسمائها والدروس الموجودة في نور. عند غياب الشجرة، تُستخدم قائمة «الدروس» الموجودة في نموذج المادة.':'Uses the units and lessons in Noor. If there is no tree, uses the lesson list in the Noor form.',
  'الخدمة':'Service',
  '📚 تحضير درس':'📚 Lesson preparation',
  '📝 نشاط / اختبار':'📝 Activity / quiz',
  '📊 نقل الدرجات':'📊 Transfer grades',
  '🎮 مساق تفاعلي SCORM':'🎮 Interactive SCORM lesson',
  'عدد الأسئلة لكل نشاط / درس':'Questions per activity / lesson',
  'اكتب أي عدد صحيح من 1 إلى 30.':'Enter a whole number from 1 to 30.',
  'نطاق التحضير من ملف':'Preparation scope from file',
  'الدرس الحالي فقط':'Current lesson only',
  'جميع دروس الوحدة':'All lessons in the unit',
  'جميع دروس الفصل المتاحة في الملف':'All semester lessons in the file',
  'تاريخ بداية التحضير':'Preparation start date',
  'الحصص لكل درس':'Periods per lesson',
  'طريقة الحفظ بعد إنشاء التحضير':'Save after generating the preparation',
  '🔎 مراجعة قبل الحفظ':'🔎 Review before saving',
  '💾 حفظ تلقائي بعد التوليد':'💾 Save automatically after generation',
  '🔎 عرض التحضير للمراجعة':'🔎 Review preparation',
  '💾 اعتماد وحفظ التحضير':'💾 Approve and save preparation',
  '✨ توليد التحضير وحفظه تلقائيًا':'✨ Generate and save preparation',
  '✨ توليد التحضير للمراجعة':'✨ Generate preparation for review',
  'استكمال النشاط المتوقف':'Resume paused activity',
  'نطاق إنشاء الأنشطة':'Activity generation scope',
  'الدرس المحدد فقط':'Selected lesson only',
  'جميع دروس الوحدة المختارة في نور':'All lessons in the selected Noor unit',
  'حفظ كل نشاط تلقائيًا بعد تأكيد نور حفظ السابق':'Save each activity after Noor confirms the previous save',
  'يُحفظ نشاط مستقل لكل درس؛ يتوقف التسلسل عند أي نتيجة حفظ غير مؤكدة دون تكرار.':'Each lesson gets its own activity. The sequence pauses if a save is unconfirmed.',
  'تاريخ نشر الأنشطة (اختياري)':'Activity publication date (optional)',
  'اترك الحقل فارغًا لاستخدام تاريخ نور.':'Leave blank to use the date set by Noor.',
  'عدد الأنشطة/الاختبارات':'Number of activities / quizzes',
  'أنواع الأسئلة المطلوبة':'Question types',
  'اختيار من متعدد':'Multiple choice',
  'صح / خطأ':'True / false',
  'توصيل':'Matching',
  'ملء فراغات':'Fill in the blanks',
  'متعدد الإجابات':'Multiple answers',
  'إجابة قصيرة':'Short answer',
  'نطاق إنشاء SCORM':'SCORM generation scope',
  'ملف SCORM مستقل لجميع دروس الوحدة':'Separate SCORM package for each lesson in the unit',
  'رفع وحفظ كل درس تلقائيًا بعد تأكيد نور حفظ السابق':'Upload and save each lesson after Noor confirms the previous save',
  'تُحمّل ملفات ZIP الاحتياطية لكل درس. لن يبدأ رفع الدرس التالي إذا كان حفظ السابق غير مؤكد.':'Backup ZIPs are downloaded for each lesson. The next upload waits until Noor confirms the previous save.',
  'تاريخ نشر الدروس التفاعلية':'Interactive lesson publication date',
  'عدد الدروس التفاعلية':'Number of interactive lessons',
  'الصورة المصاحبة للنشاط':'Activity illustration',
  'صورة Gemini ثلاثية الأبعاد؛ عند تعذرها استخدم SVG':'Gemini 3D image with SVG fallback',
  'صورة Gemini ثلاثية الأبعاد؛ عند تعذرها بدون صورة':'Gemini 3D image, or no image if unavailable',
  'رسم SVG تعليمي دون استدعاء Gemini للصور':'Local educational SVG illustration',
  'بدون صورة (مباشرة)':'No image',
  'الإجراء بعد تجهيز ملف SCORM':'After preparing the SCORM package',
  '🔎 رفع الملف وعرضه للمراجعة':'🔎 Upload and review',
  '💾 حفظ تلقائي إذا تحقق كل شرط':'💾 Save automatically after verification',
  '↻ استكمال تعبئة SCORM':'↻ Resume SCORM',
  'إلغاء النشر المعلّق':'Cancel pending publication',
  'إعادة محاولة توليد الدرس المتوقف':'Retry generation for the paused lesson',
  '■ إيقاف وإلغاء كل العمليات':'■ Stop and cancel all operations',
  'الأنشطة المستوردة: اختر بعضها أو الكل':'Select imported activities',
  'نشر الأنشطة المحددة':'Publish selected activities',
  'إنشاء مفتاح':'Create key',
  'لصق وحفظ المفتاح':'Paste and save key',
  '✨ توليد باستخدام Gemini':'✨ Generate with Gemini',
  '📁 استيراد ملف':'📁 Import file',
  '📁 استيراد ملف جاهز':'📁 Import file',
  '📁 استيراد الدرجات':'📁 Import grades',
  '📊 مطابقة الطلاب ومعاينة الدرجات':'📊 Match students and preview grades',
  '📊 تعبئة الدرجات التي راجعتها — دون حفظ':'📊 Fill reviewed grades without saving',
  'حزمة SCORM المستوردة':'Imported SCORM package',
  'اختر حزمة SCORM':'Choose a SCORM package',
  'تعبئة الدرس التفاعلي تلقائيًا':'Fill interactive lesson automatically',
  'اختر الخدمة والصف والوحدة والدرس. لن تختار الإضافة فصلًا آخر بالخطأ.':'Choose a service, class, unit and lesson.',
  'سيُعبأ التحضير أولًا، ثم تظهر معاينته قبل الضغط على «اعتماد وحفظ». حدد طريقة الحفظ الآن، قبل إرسال طلب Gemini.':'Choose how to save before sending the request to Gemini.',
  'بعد اكتمال التوليد والتعبئة، تتحقق الإضافة من الصف والوحدة والدرس والمستوى والتواريخ، ثم تضغط حفظ مرة واحدة دون خطوة مراجعة. إذا فشل التحقق تتوقف دون حفظ.':'After generation, Noor Tools verifies the grade, lesson, level and dates before saving once.',
  'ستعبئ الإضافة التحضير دون حفظ، وتعرض معاينته ثم تنتظر موافقتك على «اعتماد وحفظ». أجرِ هذا الاختيار قبل إرسال الطلب إلى Gemini.':'Preview the preparation before approving and saving it. Choose this mode before sending the request to Gemini.',
  'لا يوجد مفتاح Gemini مرتبط بهذا المعلم بعد. يحتاج التحضير والتوليد إلى ربط المفتاح مرة واحدة.':'Connect a Gemini key once to use preparation and generation.',
  'مسار التعبئة في نور هو المكتبة الرقمية ← الدروس التفاعلية ← إضافة الدرس. تختار الإضافة الصف وتتحقق من الدرس ثم ترفق ملف ZIP.':'Open Digital Library, Interactive Lessons, then Add Lesson. Noor Tools verifies the class and lesson before attaching the ZIP.',
  'عند نفاد رصيد صور Gemini أو رفض الخطة (مثل 429)، يستمر إنشاء SCORM بالخيار المحدد. SVG رسم متجهي محلي، وليس صورة ثلاثية الأبعاد من Gemini.':'SCORM generation uses the selected fallback when Gemini images are unavailable.',
  'اللغة الإنجليزية':'English',
  'اللغة العربية':'Arabic',
  'الدراسات الاجتماعية':'Social Studies',
  'تقنية المعلومات':'Information Technology',
  'الرياضيات':'Mathematics',
  'العلوم':'Science',
  'الفصل تغير أثناء التنقل':'The class changed during navigation.',
  'الصف تغير بين صفحات نور':'The grade changed between Noor pages.',
  'جارٍ التحقق من الفصل والتاريخ واستكمال النشاط.':'Checking the class and publication date before resuming.',
  'أُوقفت العمليات المعلّقة. يمكنك بدء عملية جديدة. ما أُرسل بالفعل إلى نور يبقى في نور.':'Pending operations stopped. You can start again. Items already sent to Noor remain there.'
 }));
 const prefix=[
  ['توقفت التعبئة تلقائيًا: ','Automatic filling paused. '],
  ['توقف: ','Operation paused. '],
  ['توقف توليد الوحدة. ','Unit generation paused. '],
  ['تعذر تحديد مربع الفصل «','Could not uniquely match the class “']
 ];
 function english(text){
  const value=text.trim();
  const unmatchedClass=/^تعذر تحديد مربع الفصل «(.+)» بصورة واحدة مؤكدة$/.exec(value);
  if(unmatchedClass)return text.replace(value,'Could not uniquely match the class “'+unmatchedClass[1]+'”.');
  const exact=messages.get(value);
  if(exact)return text.replace(value,exact);
  for(const [ar,en] of prefix)if(value.startsWith(ar))return text.replace(value,en+english(value.slice(ar.length)));
  return text;
 }
 function bind(container,chooser){
  const KEY='stnNoorUiLanguage:v1';
  const attributes=['title','placeholder','aria-label'];
  const originals=new WeakMap(),originalAttributes=new WeakMap();
  let language='ar',chosen=false;
  function apply(){
   container.dir=language==='en'?'ltr':'rtl';
   container.lang=language;
   const walker=container.ownerDocument.createTreeWalker(container,NodeFilter.SHOW_TEXT);
   for(let node=walker.nextNode();node;node=walker.nextNode()){
    let saved=originals.get(node);
    if(!saved||node.data!==saved.rendered)saved={source:node.data};
    saved.rendered=language==='en'?english(saved.source):saved.source;
    originals.set(node,saved);
    if(node.data!==saved.rendered)node.data=saved.rendered;
   }
   for(const element of container.querySelectorAll('[title],[placeholder],[aria-label]')){
    const records=originalAttributes.get(element)||{};
    for(const name of attributes){
     const current=element.getAttribute(name);if(current===null)continue;
     const saved=records[name]&&current===records[name].rendered?records[name]:{source:current};
     saved.rendered=language==='en'?english(saved.source):saved.source;
     records[name]=saved;
     if(current!==saved.rendered)element.setAttribute(name,saved.rendered);
    }
    originalAttributes.set(element,records);
   }
  }
  function set(value){language=value==='en'?'en':'ar';chooser.value=language;apply();}
  chooser.addEventListener('change',()=>{chosen=true;set(chooser.value);browser.storage.local.set({[KEY]:language}).catch(()=>{});});
  browser.storage.local.get(KEY).then(value=>{if(!chosen)set(value[KEY]);}).catch(()=>{});
  browser.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[KEY])set(changes[KEY].newValue);});
  let frame=0;
  const observer=new MutationObserver(()=>{
   if(frame)return;
   frame=requestAnimationFrame(()=>{frame=0;apply();});
  });
  observer.observe(container,{subtree:true,childList:true,characterData:true});
 }
 root.NoorUiLanguage=Object.freeze({bind,english});
})(globalThis);
