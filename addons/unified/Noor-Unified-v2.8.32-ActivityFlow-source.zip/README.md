# Noor Unified 2.8.32 — Durable activity navigation

- Save the selected teacher, verified course CID/grade/label, semester, unit, lesson, and count in a per-tab transaction before navigating to the Noor homework page.
- Do not remove pending data until successfully handed off to the activities automation; wait until the course catalog loads on the destination.
- Preserve the exact teacher dashboard course binding in the activity job, even when the Noor homework index has no class header.
- On the Noor create form require a uniquely confirmed target-class checkbox; never infer a class only from a numeric or opaque URL token.
- Prevent duplicate submission/re-generation after page reload or failed publishing.
- No claims of live Noor validation; local simulation is required before Mozilla signing.
