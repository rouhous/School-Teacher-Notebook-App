/* Noor unified tools v2.8.22. Grade and activity modules deliberately require
 * confirmation and never submit Noor forms automatically until field mapping is validated. */
(function(){
'use strict';
if(document.getElementById('stnNoorWidget'))return;
const api=typeof browser!=='undefined'?browser:chrome;
const prefix='stnNoor';
let pane=null;
let gradeData=null,activities=[],teacherId='',selection=[];
const $=(tag,attrs={},text='')=>{
 const n=document.createElement(tag);
 Object.entries(attrs).forEach(([k,v])=>k==='className'?n.className=v:k==='type'?n.type=v:k==='title'?n.title=v:n.setAttribute(k,v));
 if(text)n.textContent=text;
 return n;
};
const norm=t=>String(t??'').normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[أإآ]/g,'ا').replace(/ى/g,'ي').replace(/[^\p{L}\p{N}]+/gu,' ').trim().toLowerCase().replace(/\s+/g,' ');
const e=id=>document.getElementById(id);
const show=(id)=>{for(const x of pane.querySelectorAll('[data-tool-tab]'))x.hidden=x.dataset.toolTab!==id;};
const status=(id,msg)=>{const n=e(id);if(n)n.textContent=msg;};
const option=(v,label)=>{const o=$('option');o.value=v;o.textContent=label;return o;};
function mkButton(label,callback,style=''){
 const b=$('button',{type:'button',className:'stnToolButton '+style},label);b.addEventListener('click',callback);return b;
}
async function refreshTeacher(){
 const data=await api.storage.local.get('stnActiveTeacherId');teacherId=String(data.stnActiveTeacherId||'');
 status('stnTeacherInfo',teacherId?'الدفتر مرتبط بحساب المعلم: '+teacherId.slice(0,4)+'…'+teacherId.slice(-4):'افتح دفتر المعلم بحسابك المعتمد لربط الأدوات والبيانات.');
 if(!teacherId){gradeData=null;activities=[];refreshGrades();refreshActivities();return;}
 const saved=await api.storage.local.get(['stnGrades:'+teacherId,'stnActivities:'+teacherId]);
 gradeData=saved['stnGrades:'+teacherId]||null;activities=Array.isArray(saved['stnActivities:'+teacherId])?saved['stnActivities:'+teacherId]:[];
 refreshGrades();refreshActivities();
}
function create(){
 const holder=$('div',{id:'stnNoorWidget'});
 const badge=mkButton('🧩 أدوات نور',()=>{pane.hidden=!pane.hidden;if(!pane.hidden)void refreshTeacher();});
 badge.id='stnNoorToggle';holder.append(badge);
 // Keep grade and activity tools accessible only when their relevant Noor page is open.
 // The teacher-facing preparation page has just two primary actions in the prep panel.
 const toolsRelevant=()=>{
  const path=location.pathname;
  if(/grades?|marks?|assessment|evaluat|activities?|quiz|question|test/i.test(path))return true;
  if(/add_preparation|preparations?|teacher\/courses/i.test(path))return false;
  return Boolean([...document.querySelectorAll('h1,h2,.page-title')].some(n=>/رصد الدرجات|إدخال الدرجات|المهام الإلكترونية|إضافة مفردة|إضافة نشاط/.test(n.textContent||'')));
 };
 const syncVisibility=()=>{holder.hidden=!toolsRelevant();if(holder.hidden&&pane)pane.hidden=true;};
 syncVisibility();window.addEventListener('popstate',syncVisibility);
 let lastPage=location.href;setInterval(()=>{if(location.href!==lastPage){lastPage=location.href;syncVisibility();}},1800);
 pane=$('section',{id:'stnNoorPanel'});pane.hidden=true;
 const head=$('div',{className:'stnToolHeader'});head.append($('strong',{},'أدوات نور · دفتر المعلم المدرسي'),mkButton('×',()=>pane.hidden=true));pane.append(head);
 pane.append($('p',{id:'stnTeacherInfo',className:'stnToolInfo'},'جارٍ قراءة حساب المعلم…'));
 const tabs=$('nav',{className:'stnToolTabs'});
 tabs.append(mkButton('تحضير',()=>{show('prep');}),mkButton('الدرجات',()=>{show('grades');}),mkButton('الاختبارات والأنشطة',()=>{show('activities');}));pane.append(tabs);
 const prep=$('section',{'data-tool-tab':'prep'});
 prep.append($('p',{},'لتحضير الدروس افتح صفحة تحضير الدرس في نور. ستظهر لوحة التحضير الأصلية مع إعداد Gemini الخاص بهذا المعلم فقط.'));
 prep.append(mkButton('فتح لوحة التحضير',()=>{const n=e('noor-prep-panel');if(n){n.style.display='';n.scrollIntoView({block:'nearest'});pane.hidden=true;}else status('stnPrepInfo','هذه ليست صفحة تحضير درس؛ افتح درسًا من شجرة نور أولًا.');}));
 prep.append($('p',{id:'stnPrepInfo',className:'stnToolInfo'}));pane.append(prep);
 const grades=$('section',{'data-tool-tab':'grades'});grades.hidden=true;
 grades.append($('h3',{},'درجات دفتر المعلم ← نور'),$('p',{id:'stnGradeSource',className:'stnToolInfo'},'لم تُستقبل بيانات الدرجات بعد.'));
 const assessment=$('select',{id:'stnGradeAssessment'});assessment.addEventListener('change',()=>previewGrades());
 grades.append($('label',{},'التقييم المراد إدراج درجاته'),assessment);
 const column=$('select',{id:'stnGradeColumn'});column.append(option('0','الحقل الأول في صف الطالب'),option('1','الحقل الثاني'),option('2','الحقل الثالث'),option('3','الحقل الرابع'),option('4','الحقل الخامس'));
 column.addEventListener('change',previewGrades);
 grades.append($('label',{},'حقل الدرجة في جدول نور (عند وجود عدة حقول)'),column);
 grades.append(mkButton('فحص مطابقة الطلاب دون تعديل',previewGrades));
 grades.append($('p',{id:'stnGradePreview',className:'stnToolInfo'},'افتح صفحة رصد الدرجات أولًا.'));
 grades.append(mkButton('تعبئة الحقول المطابقة فقط — دون حفظ',applyGrades,'stnDanger'));
 grades.append(mkButton('مسح بيانات الدرجات المحلية',async()=>{if(!teacherId||!confirm('حذف بيانات الدرجات المحفوظة لهذا المعلم من الإضافة؟'))return;await api.storage.local.remove('stnGrades:'+teacherId);gradeData=null;refreshGrades();}));
 grades.append($('p',{className:'stnToolInfo'},'يجب مراجعة جميع الدرجات بعد التعبئة. لا تضغط الإضافة حفظ أو نشر. لا تستخدم المطابقة التقريبية إذا اختلفت أسماء الطلاب.'));
 pane.append(grades);
 const activitiesTab=$('section',{'data-tool-tab':'activities'});activitiesTab.hidden=true;
 activitiesTab.append($('h3',{},'بنك اختبارات وأنشطة نور'),$('p',{className:'stnToolInfo'},'استورد ملف JSON ببنك الأنشطة، واختر الوحدة والدرس. تعبئة الحقول في نور تجريبية وتتطلب مراجعة قبل إضافة المفردة.'));
 const file=$('input',{type:'file',accept:'.json,application/json',id:'stnActivityJson'});file.addEventListener('change',()=>void loadActivityFile(file));activitiesTab.append(file);
 const unit=$('select',{id:'stnActivityUnit'}),lesson=$('select',{id:'stnActivityLesson'}),act=$('select',{id:'stnActivityItem'});
 unit.addEventListener('change',()=>refreshLessons());lesson.addEventListener('change',()=>refreshActivityItems());act.addEventListener('change',previewActivity);
 activitiesTab.append($('label',{},'الوحدة'),unit,$('label',{},'الدرس'),lesson,$('label',{},'النشاط / الاختبار'),act);
 activitiesTab.append($('p',{id:'stnActivityStatus',className:'stnToolInfo'}));
 const activityPreview=$('textarea',{id:'stnActivityPreview',readonly:'',rows:'6'});activitiesTab.append(activityPreview);
 activitiesTab.append(mkButton('تعبئة العنوان والتعليمات في نموذج نور — دون نشر',fillActivityDraft));
 activitiesTab.append(mkButton('مسح بنك الأنشطة المحلي',async()=>{if(!teacherId||!confirm('حذف بنك الأنشطة المحلي لهذا المعلم؟'))return;await api.storage.local.remove('stnActivities:'+teacherId);activities=[];refreshActivities();}));
 activitiesTab.append($('p',{className:'stnToolInfo'},'إدراج الأسئلة وخياراتها والانتقال تلقائيًا بين صفحات نور يحتاج اختبار واجهات الأنشطة الفعلية. لا يُعلن نجاح الإضافة قبل التحقق من جميع المفردات.'));
 pane.append(activitiesTab);
 holder.append(pane);document.body.append(holder);void refreshTeacher();
 api.storage.onChanged.addListener((changes,area)=>{
  if(area==='local'&&(changes.stnActiveTeacherId||changes['stnGrades:'+teacherId]))void refreshTeacher();
 });
}
function refreshGrades(){
 const source=e('stnGradeSource'),sel=e('stnGradeAssessment');if(!source||!sel)return;
 sel.replaceChildren(option('','اختر تقييمًا'));
 if(!gradeData){source.textContent='افتح «الدرجات» في دفتر المعلم واضغط «⇄ Noor» أولًا.';selection=[];status('stnGradePreview','');return;}
 source.textContent='الصف: '+gradeData.className+' — الطلاب: '+gradeData.students.length+' — التقييمات: '+gradeData.assessments.length;
 gradeData.assessments.forEach(a=>sel.append(option(a.id,a.name+' / '+a.max)));
 selection=[];status('stnGradePreview','اختر تقييمًا، وافتح جدول درجات الصف نفسه في نور ثم اضغط فحص المطابقة.');
}
function rowsWithInputs(){
 return [...document.querySelectorAll('tr')].map(row=>{
  const input=[...row.querySelectorAll('input:not([type=hidden]):not([type=button]):not([type=submit])')]
   .filter(x=>!x.disabled&&!x.readOnly&&/^(number|text|tel|)$/.test(x.type||''));
  return {row,input,text:norm(row.textContent)};
 }).filter(x=>x.input.length>0&&x.text.length>3&& !e('stnNoorWidget')?.contains(x.row));
}
function sameStudent(row,student){
 const sid=norm(student.studentNumber),name=norm(student.name);
 if(sid && sid.length>=4 && (new RegExp('(?:^| )'+sid.replace(/[-/\\^$*+?.()|[\]{}]/g,'\\$&')+'(?: |$)')).test(row.text))return true;
 if(!name)return false;
 if(row.text.includes(name))return true;
 const words=name.split(' ').filter(Boolean);
 return words.length>=3 && row.text.includes(words.slice(0,3).join(' '));
}
function previewGrades(){
 selection=[];if(!gradeData||!gradeData.students?.length){status('stnGradePreview','أرسل الدرجات من دفتر المعلم أولًا.');return;}
 const a=e('stnGradeAssessment').value;if(!a){status('stnGradePreview','اختر التقييم المراد تعبئته.');return;}
 const col=Number(e('stnGradeColumn').value)||0;
 const rows=rowsWithInputs();let ambiguous=0,unmatched=0,invalid=0;
 const used=new Set();
 for(const st of gradeData.students){
  const score=st.grades?.[a];if(score===undefined || score===null||String(score).trim()==='')continue;
  const num=Number(score);if(!Number.isFinite(num)){invalid++;continue;}
  const target=gradeData.assessments.find(x=>String(x.id)===String(a));
  if(num<0 || (target?.max>0&&num>target.max)){invalid++;continue;}
  const matches=rows.filter(r=>sameStudent(r,st));
  if(matches.length!==1){if(matches.length>1)ambiguous++;else unmatched++;continue;}
  const entry=matches[0],field=entry.input[col];
  if(!field||used.has(field)){ambiguous++;continue;}
  const min=field.min!==''?Number(field.min):null,max=field.max!==''?Number(field.max):null;
  if((min!==null&&Number.isFinite(min)&&num<min)||(max!==null&&Number.isFinite(max)&&num>max)){invalid++;continue;}
  used.add(field);selection.push({field,num,student:st.name});
 }
 status('stnGradePreview','مطابق: '+selection.length+'، بلا مطابقة: '+unmatched+'، ملتبس: '+ambiguous+'، غير صالح: '+invalid+'. المعاينة لا تعدّل شيئًا؛ تحقق من الصف والتقييم والعمود.');
}
async function applyGrades(){
 previewGrades();if(!selection.length)return;
 if(!confirm('سيتم تعبئة '+selection.length+' حقلًا في صفحة نور الحالية فقط، دون حفظ. هل تأكدت من الصف والتقييم وعمود الدرجات؟'))return;
 const setValue=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,'value').set;
 for(const {field,num} of selection){setValue.call(field,String(num));field.dispatchEvent(new Event('input',{bubbles:true}));field.dispatchEvent(new Event('change',{bubbles:true}));}
 status('stnGradePreview','تمت تعبئة '+selection.length+' درجة في الحقول المرئية. راجعها قبل الحفظ النهائي في نور.');
}
function unpackActivities(json){
 const result=[];let count=0;
 function scan(node,context={unit:'',lesson:''},depth=0){
  if(depth>9||++count>14000)return;
  if(Array.isArray(node)){node.slice(0,500).forEach(x=>scan(x,context,depth+1));return;}
  if(!node||typeof node!=='object')return;
  const unit=String(node.unit||node.unitTitle||node.unit_name||context.unit||'غير محدد');
  const lesson=String(node.lesson||node.lessonTitle||node.lesson_name||context.lesson||'غير محدد');
  const title=String(node.title||node.activityTitle||node.name||node.question||node.prompt||'').slice(0,250);
  const questions=node.questions||node.items||node.questionsBank||node.exercises;
  if(title && (Array.isArray(questions)||node.question||node.prompt||node.type||node.activity_type)){
   result.push({unit,lesson,title,type:String(node.type||node.activity_type||'نشاط'),questions:Array.isArray(questions)?questions.slice(0,100):[],instructions:String(node.instructions||node.description||node.prompt||'').slice(0,4000)});
  }
  for(const [key,value] of Object.entries(node)){
   if(['questions','items','exercises','options','answers','choices'].includes(key))continue;
   if(value&&typeof value==='object')scan(value,{unit,lesson},depth+1);
  }
 }
 scan(json);
 return result.slice(0,1200);
}
async function loadActivityFile(file){
 if(!teacherId){status('stnActivityStatus','اربط حساب المعلم من الدفتر أولًا.');return;}
 const f=file.files?.[0];if(!f)return;
 if(f.size>4*1024*1024){status('stnActivityStatus','ملف JSON أكبر من 4 ميغابايت.');return;}
 try{
  const raw=JSON.parse(await f.text()),list=unpackActivities(raw);
  if(!list.length)throw Error('لم أجد أنشطة معرّفة في الملف. تحقق من بنية بنك JSON.');
  activities=list;await api.storage.local.set({['stnActivities:'+teacherId]:activities});
  refreshActivities();status('stnActivityStatus','تم تحميل '+list.length+' نشاطًا محليًا لهذا المعلم.');
 }catch(ex){status('stnActivityStatus','تعذر استيراد الملف: '+String(ex.message||ex));}
}
function refreshActivities(){
 const unit=e('stnActivityUnit');if(!unit)return;
 const units=[...new Set(activities.map(a=>a.unit))];
 unit.replaceChildren(option('','اختر الوحدة'));units.forEach(u=>unit.append(option(u,u)));
 status('stnActivityStatus',activities.length?'بنك محفوظ: '+activities.length+' نشاطًا.':'لم يتم تحميل بنك اختبارات بعد.');refreshLessons();
}
function refreshLessons(){
 const val=e('stnActivityUnit').value;const lessons=[...new Set(activities.filter(a=>a.unit===val).map(a=>a.lesson))];
 e('stnActivityLesson').replaceChildren(option('','اختر الدرس'));lessons.forEach(l=>e('stnActivityLesson').append(option(l,l)));
 refreshActivityItems();
}
function refreshActivityItems(){
 const items=activities.filter(a=>a.unit===e('stnActivityUnit').value&&a.lesson===e('stnActivityLesson').value);
 const box=e('stnActivityItem');box.replaceChildren(option('','اختر النشاط'));items.forEach((item,i)=>box.append(option(String(i),item.title)));
 previewActivity();
}
function currentActivity(){
 const v=e('stnActivityItem').value;
 if(v==='')return null;
 return activities.filter(a=>a.unit===e('stnActivityUnit').value&&a.lesson===e('stnActivityLesson').value)[Number(v)]||null;
}
function previewActivity(){
 const x=currentActivity();e('stnActivityPreview').value=x?[x.title,'الوحدة: '+x.unit,'الدرس: '+x.lesson,'النوع: '+x.type,x.instructions,'الأسئلة: '+x.questions.length,JSON.stringify(x.questions.slice(0,3),null,2)].join('\n'):'';
}
function labeledField(labels){
 const fields=[...document.querySelectorAll('form input[type=text],form textarea,form input:not([type]),form [contenteditable=true]')];
 for(const input of fields){
  if(input.disabled||input.readOnly||e('stnNoorWidget')?.contains(input))continue;
  const label=document.querySelector('label[for="'+CSS.escape(input.id)+'"]');
  const identity=norm([input.name,input.id,input.placeholder,label?.textContent].join(' '));
  if(labels.some(k=>identity.includes(norm(k))))return input;
 }
 return null;
}
function setDraft(input,value){
 if(!input||!value)return false;
 if(input.isContentEditable){input.textContent=value;input.dispatchEvent(new InputEvent('input',{bubbles:true}));}
 else{const proto=input.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto,'value').set.call(input,value);
  input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));}
 return true;
}
function fillActivityDraft(){
 const item=currentActivity();if(!item){status('stnActivityStatus','اختر نشاطًا أولًا.');return;}
 if(!document.querySelector('form')){status('stnActivityStatus','افتح نموذج إضافة نشاط أو مفردة في نور أولًا.');return;}
 const name=labeledField(['عنوان','اسم النشاط','title','activity name']);
 const text=labeledField(['التعليمات','الوصف','description','instructions','محتوى النشاط']);
 if(!name&&!text){status('stnActivityStatus','لم أتعرف على الحقول بشكل آمن. لم أغيّر الصفحة.');return;}
 if(!confirm('تعبئة عنوان وتعليمات النشاط فقط دون الضغط على إضافة مفردة أو نشر؟'))return;
 const changed=[];
 if(setDraft(name,item.title))changed.push('العنوان');
 if(setDraft(text,item.instructions||item.title))changed.push('الوصف/التعليمات');
 status('stnActivityStatus','تمت تعبئة '+changed.join(' و ')+'. إدراج الأسئلة كاملة يحتاج مطابقة نموذج نور في النسخة النهائية. راجع ولا تنشر تلقائيًا.');
}
function start(){if(!document.body||document.getElementById('stnNoorWidget'))return;create();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start,{once:true});else start();
})();
