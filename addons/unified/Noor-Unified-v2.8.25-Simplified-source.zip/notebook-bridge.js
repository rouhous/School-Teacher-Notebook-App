/* The Notebook page emits the current teacher's opaque Google subject only after
 * its approved session check succeeds. Do not transfer Google credentials. */
(function () {
  'use strict';
  const api = typeof browser !== 'undefined' ? browser : chrome;
  const origin=location.origin;
  if (origin!=='https://rouhous.github.io') return;
  const isAuthenticated=()=>!document.getElementById('schoolAuthCover');
  let activeTeacher='';
  const validTeacher=t=>typeof t==='string' && /^[A-Za-z0-9_:\-.]{3,200}$/.test(t);
  const safeReply=(type,extra)=>window.postMessage({type,...extra},origin);
  async function handleIdentity(message){
    if (!isAuthenticated() || !validTeacher(message.teacherId))return;
    try {
      const result=await api.runtime.sendMessage({type:'STN_SET_ACTIVE_TEACHER',teacherId:message.teacherId});
      if (result?.ok){activeTeacher=message.teacherId;safeReply('STN_NOOR_ADDON_CONNECTED',{version:api.runtime.getManifest().version});}
    } catch(e){console.warn('[Noor unified] identity link:',e.message);}
  }
  async function handleGrades(payload){
    if (!isAuthenticated() || !activeTeacher){safeReply('TEACHER_NOTEBOOK_NOOR_ERROR',{message:'افتح الدفتر بحسابك المعتمد ثم حاول ثانية.'});return;}
    if (!payload || payload.schema!=='teacher-notebook-noor-v1' ||
        !Array.isArray(payload.students)||!Array.isArray(payload.assessments)||
        payload.students.length>300||payload.assessments.length>120){
      safeReply('TEACHER_NOTEBOOK_NOOR_ERROR',{message:'صيغة الدرجات غير مدعومة. أعد تصديرها من دفتر المعلم.'});return;
    }
    if (JSON.stringify(payload).length>500000){safeReply('TEACHER_NOTEBOOK_NOOR_ERROR',{message:'حجم البيانات أكبر من الحد المسموح.'});return;}
    try {
      const r=await api.runtime.sendMessage({type:'STN_STORE_GRADES',teacherId:activeTeacher,payload});
      if (r?.ok)safeReply('TEACHER_NOTEBOOK_NOOR_ACK',{count:Number(r.count||0)});
      else safeReply('TEACHER_NOTEBOOK_NOOR_ERROR',{message:r?.error||'تعذر حفظ البيانات محليًا'});
    }catch(e){safeReply('TEACHER_NOTEBOOK_NOOR_ERROR',{message:String(e.message||e).slice(0,200)});}
  }
  window.addEventListener('message',event=>{
    if(event.source!==window||event.origin!==origin)return;
    let data=event.data;
    if(typeof data==='string'){try{data=JSON.parse(data)}catch{return;}}
    if(!data||typeof data!=='object')return;
    if(data.type==='STN_NOOR_ACTIVE_TEACHER')void handleIdentity(data);
    if(data.type==='TEACHER_NOTEBOOK_NOOR_EXPORT')void handleGrades(data.payload);
  });
  function ask(){if(isAuthenticated())safeReply('STN_NOOR_WHOAMI',{});}
  document.addEventListener('DOMContentLoaded',ask,{once:true});
  ask();
  const o=new MutationObserver(()=>{
    if(isAuthenticated()){o.disconnect();ask();}
  });
  o.observe(document.documentElement,{childList:true,subtree:true});
})();
