# Noor Unified v2.8.33 — Gemini Model Fix

- Fixed model-not-found 404 in Noor smart activities: the hub forced `gemini-2.5-flash-lite` even though Gemini 2.5 generation is restricted for new API projects.
- The extension now uses a single Gemini model router across activities, preparation, interactive questions and triple-service generation.
- Model names are read from Google `models.list`, and only generation-capable current **Flash-Lite** models are eligible. Actual generation may still return 404 despite appearing in the list, so one alternate Lite model may be tried **only** on 404.
- No automatic retry on 429, authentication error, invalid requests, network failure or 5xx; no attempt to switch to Pro / paid-only model families. Google may still charge according to each teacher project/billing plan.
- The shared Gemini API key stays in the extension storage under the already-established per-teacher key. No new key is required.
- The class, unit, lesson and preexisting navigation/publishing safety guards remain unchanged.
- Local unit tests use mocked Google API responses; teacher credentials are neither available nor used. Live testing inside Noor still required.
