/* One action produces one complete, structurally validated lesson bundle.
 * No shared Gemini key, no teacher/student PII, no key in page DOM or storage logs. */
(function(){'use strict';
const ORIGIN='https://lms.moe.gov.om/';
const validKey=k=>/^(?:AIza[A-Za-z0-9_-]{20,}|AQ\.[A-Za-z0-9._~=-]{20,})$/.test(k||'');
const trim=(v,n=180)=>String(v??'').trim().slice(0,n);
const validator=q=>q&&typeof q.stem==='string'&&q.stem.trim().length>5&&Array.isArray(q.options)&&q.options.length===4&&q.options.every(x=>typeof x==='string'&&x.trim().length>0)&&typeof q.answer==='string'&&q.options.includes(q.answer)&&typeof q.explanation==='string';
async function generateBundle(msg){
 const id=(await browser.storage.local.get('stnActiveTeacherId')).stnActiveTeacherId;
 if(!id||!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))throw Error('سجّل الدخول إلى دفتر المعلم بحساب Google أولًا.');
 if(msg.teacherId&&msg.teacherId!==id)throw Error('تغيّر حساب المعلم؛ تم إيقاف التوليد لحماية الخصوصية.');
 const {['stnGeminiKey:'+id]:key}=await browser.storage.local.get('stnGeminiKey:'+id);
 if(!validKey(key))throw Error('احفظ مفتاح Gemini الخاص بهذا المعلم في الإضافة مرة واحدة.');
 const grade=Number(msg.grade),unit=trim(msg.unit,160),lesson=trim(msg.lesson,160),term=Number(msg.semester||1);
 const count=Math.min(10,Math.max(3,Number(msg.count)||6));
 if(!Number.isInteger(grade)||grade<1||grade>12||!unit||!lesson||![1,2].includes(term))throw Error('الصف/الفصل/الوحدة/الدرس غير مكتمل.');
 const supplied=trim(msg.lessonText,6000);
 const prompt=`You are a teacher in Oman creating exactly THREE connected teaching resources for ONE specific lesson.
Return ONLY a valid JSON object in this exact format:
{"preparation":{"objectives":"...","concepts":"...","warmUp":"...","procedures":"...","formative":"...","closing":"...","details":"..."},"activity":{"title":"...","questions":[{"kind":"mcq","stem":"...","options":["...","...","...","..."],"answer":"exact option string","points":1,"explanation":"..."}]},"scorm":{"title":"...","questions":[{"question":"...","options":["...","...","...","..."],"correct":0,"explanation":"..."}]}}.
Grade ${grade}; English subject; semester ${term}; unit/theme: ${unit}; selected lesson: ${lesson}.
Teacher-provided textbook lesson content: ${supplied||'[No textbook text provided; offer appropriate suggestions, NEVER invent textbook exercise/page numbers]'}.
All content MUST match the specified lesson and age group. Preparation: detailed, usable teacher/student learning procedures, lesson-specific objectives, vocabulary, warm-up, differentiation; formative AND closing assessment fields must include ACTUAL varied QUESTIONS with correct MODEL ANSWERS, not teacher instructions. Keep plain text fields 140-1500 characters each. Both activity.questions and scorm.questions MUST have EXACTLY ${count} separate, original multiple-choice questions each, four nonempty options, single unambiguous correct answer, a brief educational explanation, and no repeated stems. The SCORM correct index must be 0..3. Activities must use answer as exact matching option TEXT, not an index. No audio or copyrighted textbook reproductions. No fabricated reference pages or user data. Keep response under 12000 output tokens.`;
 const body={contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.35,maxOutputTokens:12000}};
 try{
  const generated=await globalThis.NoorGeminiModels.generate(key,body,{timeoutMs:90000});
  const payload=generated.data;
  const raw=(payload.candidates?.[0]?.content?.parts||[]).map(x=>x.text||'').join('');
  let data;try{data=JSON.parse(raw)}catch{throw Error('رد Gemini غير مكتمل أو ليس JSON؛ يمكن إعادة محاولة الدرس دون نشر.')}
  if(!data?.preparation||!data.activity||!data.scorm)throw Error('رد Gemini لا يحتوي الخدمات الثلاث.');
  const prep=data.preparation;
  for(const field of ['objectives','concepts','warmUp','procedures','formative','closing']){
   if(typeof prep[field]!=='string'||prep[field].trim().length<35)throw Error('تحضير ناقص: '+field);
  }
  const activity=data.activity.questions,scorm=data.scorm.questions;
  if(!Array.isArray(activity)||activity.length!==count||!activity.every(q=>q.kind==='mcq'&&validator(q)&&Number(q.points)>0))
   throw Error('أسئلة النشاط غير كاملة أو إجاباتها غير متطابقة مع الخيارات.');
  if(!Array.isArray(scorm)||scorm.length!==count||!scorm.every(q=>Array.isArray(q.options)&&q.options.length===4&&Number.isInteger(q.correct)&&q.correct>=0&&q.correct<4&&typeof q.question==='string'&&q.question.length>5))
   throw Error('أسئلة SCORM غير كاملة أو مفاتيح الإجابات غير صالحة.');
  const unique=arr=>new Set(arr.map(x=>trim(x.stem||x.question).toLowerCase())).size===arr.length;
  if(!unique(activity)||!unique(scorm))throw Error('أعاد Gemini أسئلة مكررة؛ لم أُنشئ عملية النشر.');
  return {ok:true,teacherId:id,bundle:{unit,lesson,grade,semester:term,createdAt:Date.now(),
    preparation:Object.fromEntries(Object.entries(prep).filter(([k])=>['objectives','concepts','warmUp','procedures','formative','closing','details'].includes(k)).map(([k,v])=>[k,trim(v,3500)])),
    activity:{title:trim(data.activity.title||'نشاط — '+lesson,130),questions:activity.map(q=>({kind:'mcq',stem:trim(q.stem,1200),options:q.options.map(x=>trim(x,350)),answer:q.answer,points:Number(q.points),explanation:trim(q.explanation,900)}))},
    scorm:{title:trim(data.scorm.title||'درس تفاعلي — '+lesson,130),questions:scorm.map(q=>({question:trim(q.question,1200),options:q.options.map(x=>trim(x,350)),correct:q.correct,explanation:trim(q.explanation,600)}))}}};
 }catch(e){throw Error(String(e.message||e))}
}
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(msg?.type!=='NOOR_PIPELINE_GENERATE_BUNDLE'||!String(sender?.url||'').startsWith(ORIGIN))return false;
 return generateBundle(msg).catch(e=>({ok:false,error:String(e?.message||e).slice(0,350)}));
});
})();
