/* Shared model selection for preparation, activities and SCORM.
 * Never pass Gemini keys to Noor's page, URL or diagnostics.
 * Do not retry generation after quota, auth or server errors.
 * Only a definite 404 (model unavailable) may trigger a different Lite model.
 */
(function(global){'use strict';
 const API='https://generativelanguage.googleapis.com/v1beta';
 const SUPPORTED=['gemini-3.5-flash-lite','gemini-3.1-flash-lite'];
 const DEFAULT=SUPPORTED[0];
 function safeError(status){
   if(status===401||status===403)return 'رفضت Google مفتاح Gemini أو صلاحيات مشروعه ('+status+'). افتح إعداد مفتاح المعلم للتحقق.';
   if(status===402)return 'خدمة Gemini تتطلب رصيدًا أو إعداد فواتير لهذا المشروع (402).';
   if(status===429)return 'تجاوز مشروع Gemini حد الطلبات أو الحصة (429). انتظر تجدد الحصة؛ لن نُعيد الطلب تلقائيًا.';
   if(status===400)return 'رفض Gemini صيغة الطلب أو إعداداته (400). لم يُنشر أي نشاط.';
   if(status===404)return 'النموذج المحدد غير متاح لهذا المفتاح (404).';
   if(status>=500)return 'خدمة Gemini غير متاحة حاليًا (HTTP '+status+'). لم نُكرر الطلب.';
   return 'تعذر الاتصال بـ Gemini (HTTP '+status+').';
 }
 async function jsonFetch(url,key,body,timeoutMs){
   let response;
   try{
     response=await fetch(url,{method:body===undefined?'GET':'POST',
       headers:{'x-goog-api-key':key,'Content-Type':'application/json'},
       ...(body===undefined?{}:{body:JSON.stringify(body)}),
       cache:'no-store',signal:AbortSignal.timeout(timeoutMs)});
   }catch(e){
     throw Error(e?.name==='TimeoutError'||e?.name==='AbortError'?'انتهت مهلة الاتصال بـ Gemini؛ لم نُكرر التوليد.':'تعذر الاتصال بـ Gemini؛ يمكنك إعادة المحاولة دون نشر مكرر.');
   }
   let data={};
   try{data=await response.json()}catch(_){}
   return {status:response.status,ok:response.ok,data};
 }
 async function available(key){
   const found=new Set();
   let pageToken='';
   // The API is paginated. Model visibility is not proof of generation entitlement.
   for(let i=0;i<5;i++){
     const query=new URLSearchParams({pageSize:'100'});
     if(pageToken)query.set('pageToken',pageToken);
     const r=await jsonFetch(API+'/models?'+query.toString(),key,undefined,20000);
     if(!r.ok)throw Error(safeError(r.status));
     for(const m of (Array.isArray(r.data.models)?r.data.models:[])){
       const name=String(m?.name||'').replace(/^models\//,'');
       if(SUPPORTED.includes(name)&&Array.isArray(m.supportedGenerationMethods)&&m.supportedGenerationMethods.includes('generateContent'))found.add(name);
     }
     pageToken=String(r.data.nextPageToken||'');
     if(!pageToken)break;
   }
   return SUPPORTED.filter(m=>found.has(m));
 }
 async function generate(key,body,opts={}){
   if(typeof key!=='string'||key.length<20)throw Error('احفظ مفتاح Gemini الخاص بالمعلم أولًا.');
   const discovered=await available(key);
   if(!discovered.length)throw Error('لا يعرض مشروع Google نموذجًا حديثًا من Gemini Flash-Lite قادرًا على التوليد. تحقق من المشروع والمفتاح في AI Studio.');
   // A saved 2.5 preference is no longer used: some new projects see it but get 404.
   const preferred=SUPPORTED.includes(opts.preferred)?opts.preferred:DEFAULT;
   const sequence=[preferred,...SUPPORTED].filter((name,index,all)=>discovered.includes(name)&&all.indexOf(name)===index);
   const failures=[];
   for(const model of sequence){
     const r=await jsonFetch(API+'/models/'+model+':generateContent',key,body,opts.timeoutMs||90000);
     if(r.ok)return {model,data:r.data};
     if(r.status===404){failures.push(model);continue;}
     throw Error(safeError(r.status));
   }
   throw Error('نماذج Gemini Flash-Lite غير متاحة للتوليد بهذا المفتاح ('+failures.join('، ')+'). قد تظهر في قائمة Google رغم تقييد الاستخدام. جرّب مفتاح مشروع يدعم النماذج الحديثة.');
 }
 global.NoorGeminiModels=Object.freeze({generate,available,DEFAULT,safeError});
})(globalThis);
