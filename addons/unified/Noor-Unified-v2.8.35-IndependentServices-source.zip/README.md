# Noor Unified Tools v2.8.35 — Independent Teacher Services

Source baseline: Mozilla-signed v2.8.34 (latest published on 17 November 2026), retrieved from GitHub Actions package artifact, retaining the same Firefox add-on ID and update URL.

## Product behavior

1. On the authenticated Noor teacher page, discover the teacher-specific class cards, subject, grade, and official course service links. A class without a verified course ID or recognized subject is visible but **cannot be used for automated writes**.
2. Teacher chooses class, semester, unit/theme, lesson, **then one service**: preparation, activity/test, interactive SCORM lesson, or grade transfer. The former triple-service auto-pipeline is no longer loaded or packaged.
3. Preparation generation requires a subject and a single verified official Noor curriculum tree lesson ID, plus date and periods; navigate to the official Add Preparation link discovered from the course page, fill via the existing preparation bridge, and attempt saving once. A server confirmation of successful save remains necessary before claiming completion.
4. Imported PDF/DOCX/TXT preparations reuse the older lesson parser and single-lesson or full selected-unit batch process with auto-save, dates and lesson periods. **Multi-unit semester-wide file automation remains disabled** pending validated one-to-one lesson matching, to prevent wrong-class writes.
5. Activity generation lets the teacher specify number of activities and allowed question types; imported activities can be selected individually or as a set and are validated against the selected unit/lesson/subject. Publishing uses the existing Noor question insertion automator and checks the selected course ID.
6. SCORM generation can create 1–10 individual SCORM ZIPs, but will attach at most one file at a time to a uniquely verified Noor input. Multiple imports validate packages but **do not auto-post an entire set** because the private Noor form has not been end-to-end tested.
7. Grades remain separate. The School Notebook transfer stores its payload per teacher and navigates only to a verified official Noor grades route matching exactly one of that teacher's dashboard classes. Grade matching requires preview and explicit confirmation; no automatic final grade save.
8. Gemini key remains stored per Notebook teacher. All AI workflows require the selected subject; no hardcoded `English` default and no cross-subject generation.

## Checks and limitations

Local tests cover subject classification, type-specific generation guardrails, single-service routing, content scripts/manifest integrity and JavaScript syntax. **No live authenticated end-to-end Noor form test is possible with the supplied screenshots alone**. This release must be piloted first with a teacher's test lesson/assessment before wider use. A Mozilla signature confirms package provenance, NOT that automated form mapping or save is correct.

Signing: use the repository's existing GitHub Actions workflow and Mozilla API secrets; keep extension ID `noor-prep-filler-private-2026@rouhous.github.io` and `updates.json` unchanged until the signed XPI exists.
