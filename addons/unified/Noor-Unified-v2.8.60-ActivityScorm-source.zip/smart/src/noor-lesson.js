/* Noor lesson picker: compare the unit and lesson IDENTIFIERS, never a preparation title.
   Handles visible selected chips as well as native selects (including hidden Select2 sources). */
(function(root){'use strict';
 const digits=v=>String(v??'').replace(/[٠-٩۰-۹]/g,c=>String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)>=0?'٠١٢٣٤٥٦٧٨٩'.indexOf(c):'۰۱۲۳۴۵۶۷۸۹'.indexOf(c)));
 const compact=v=>digits(v).replace(/\s+/g,' ').trim();
 const num=v=>compact(v).match(/\d+/)?.[0]?.replace(/^0+(?=\d)/,'')||null;
 const pattern=(word,number)=>new RegExp('(?:^|[^\\p{L}\\p{N}])(?:'+word+')\\s*[:#._-]?\\s*0*'+number+'(?![\\p{L}\\p{N}])','iu');
 const norm=s=>compact(s).normalize('NFKC').replace(/[ً-ٟـ]/g,'').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').toLowerCase();
 const code=v=>{const m=compact(v).match(/(?:^|\s)(\d{1,2})\s*[-–.]\s*(\d{1,2})(?=\s|$)/);return m?{unit:Number(m[1]),lesson:Number(m[2])}:null};
 const removeCode=v=>norm(v).replace(/^\d{1,2}\s*[-–.]\s*\d{1,2}\s*/, '').trim();
 const fullIdentity=(text,unit,lesson)=>{
  const s=compact(text),u=root.NoorLessonNumbers?.number?.(unit,'unit'),l=root.NoorLessonNumbers?.number?.(lesson,'lesson');
  if(u&&l&&pattern('unit|الوحدة',u).test(s)&&pattern('lesson|الدرس',l).test(s))return true;
  // Science and similar curricula: code 4-4 = unit 4, lesson 4.
  const actual=code(s),requested=code(lesson);
  if(actual&&requested)return actual.unit===requested.unit&&actual.lesson===requested.lesson;
  if(actual&&u&&l)return actual.unit===u&&actual.lesson===l;
  // Other subjects identify their units by title and lessons by full names.
  // Accept a unique exact lesson name, not a substring or an invented number.
  const name=removeCode(lesson),got=removeCode(s);
  if(name.length>=6&&name===got){if(actual&&u&&actual.unit!==u)return false;return true;}
  return false;
 };
 const oneIdentity=s=>(/(?:unit|الوحدة)\s*[:#._-]?\s*[0-9٠-٩۰-۹]+/iu.test(s)&&/(?:lesson|الدرس)\s*[:#._-]?\s*[0-9٠-٩۰-۹]+/iu.test(s))||!!code(s);
 const SELECTED_CSS=[
  '.select2-selection__choice','.select2-selection__rendered',
  '.selectize-input .item','.bootstrap-tagsinput .tag','.choices__item--selectable',
  '.multiselect__tag','.multiselect__single','.multiselect-selected-text',
  '.tagify__tag','.chosen-choices .search-choice','.ng-value-label',
  '.vue-treeselect__multi-value-item','.vue-treeselect__single-value',
  '[class*="selection__choice"]','[class*="selected-option"]',
  '[class*="selected-item"]','.token','.tag-pill',
  '.select2-container .select2-selection','.lesson-selected',
  '.badge','.badge-pill','.badge-primary','.form-group .label-primary',
  '[class*="lesson-chip"]','[class*="lesson-tag"]','[class*="selected-pill"]'
 ].join(',');
 const selectedTexts=(doc,visible=()=>true)=>{
  const out=[];
  for(const sel of doc.querySelectorAll('select')){
   if(sel.disabled)continue;
   const values=[...(sel.selectedOptions||[...sel.options||[]].filter(x=>x.selected))];
   for(const o of values)if(oneIdentity(compact(o.textContent)))out.push({source:'select',text:compact(o.textContent),element:sel});
  }
  for(const el of doc.querySelectorAll(SELECTED_CSS)){
   if(el.closest?.('#noor-smart-activities-root')||!visible(el))continue;
   const txt=compact(el.textContent);
   if(txt.length<=240&&oneIdentity(txt))out.push({source:'chip',text:txt,element:el});
  }
  // Last resort: Noor may render a selected lesson as a plain pill with no
  // standard class. Read ONLY the short value next to the “الدروس” form label.
  // Do not inspect a whole page or a lesson-preparation heading.
  if(!out.length){
   const labels=[...doc.querySelectorAll('label')].filter(e=>compact(e.textContent)==='الدروس');
   if(labels.length===1){
    const label=labels[0];
    const scopes=[label.nextElementSibling,label.parentElement?.querySelector?.('[role="combobox"]'),label.closest?.('.form-group,.form-field,.field,.input-group')];
    for(const el of scopes){if(!el||!visible(el))continue;
     const txt=compact(el.textContent).replace(/^الدروس\s*/, '');
     const count=(txt.match(/(?:lesson|الدرس)\s*[:#._-]?\s*[0-9٠-٩۰-۹]+/giu)||[]).length;
     if(txt.length>0&&txt.length<=240&&count===1&&oneIdentity(txt)){
      out.push({source:'lessons-field',text:txt,element:el});break;
     }
    }
   }
  }
  // Nested Select2 containers often duplicate the same selected value.
  const seen=new Set();return out.filter(x=>{const key=x.text.toLowerCase();if(seen.has(key))return false;seen.add(key);return true});
 };
 const selectedMatch=(doc,unit,lesson,visible)=>{
  const values=selectedTexts(doc,visible);
  const matches=values.filter(x=>fullIdentity(x.text,unit,lesson));
  const different=values.filter(x=>!fullIdentity(x.text,unit,lesson));
  return {selected:matches.length===1&&different.length===0,ambiguous:matches.length>1||different.length>0&&matches.length>0,matching:matches,other:different};
 };
 root.NoorLesson={number:num,fullIdentity,oneIdentity,selectedTexts,selectedMatch};
})(typeof globalThis==='object'?globalThis:this);
