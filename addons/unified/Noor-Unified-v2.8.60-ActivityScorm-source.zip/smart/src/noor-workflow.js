/* Noor live-page adapter. Restrained to supported teacher pages; no hidden API calls.
   A draft is filled only where exact, uniquely identifiable controls are found.
   NO submit/publication is attempted without an independently tested selector profile. */
(() => {
 if(globalThis.__NOOR_SMART_WORKFLOW__)return;
 globalThis.__NOOR_SMART_WORKFLOW__=true;
 const clean=v=>String(v??'').replace(/\s+/g,' ').trim().slice(0,220);
 const visible=e=>!!(e && e.getClientRects().length && getComputedStyle(e).visibility!=='hidden');
 const ownPanel='#stnNoorHub,#noor-smart-activities-root,#noor-prep-panel';
 const cid=()=>location.pathname.match(/(?:^|\/)cid:([^/?#]+)(?:\/|$)/i)?.[1]||null;
 function collectContexts(){
  const candidates=[],seen=new Set();
  const grade=globalThis.NoorContext;
  const add=(source,el,value)=>{
   const text=clean(value??el?.textContent);
   if(!text||(el&&(!visible(el)||el.closest(ownPanel)))||seen.has(source+'|'+text))return;
   candidates.push({source,text});seen.add(source+'|'+text);
  };
  const isLabel=s=>Boolean(grade?.isClassLabel(s));
  // Noor's "نشر الاختبار للفصول التالية" section displays the class as a
  // checkbox option (e.g. Tenth - 1). The checkbox starts UNCHECKED.
  // Read its visible label without requiring the teacher to tick it first.
  const checkboxes=[...document.querySelectorAll('input[type="checkbox"],input[type="radio"]')];
  for(const checkbox of checkboxes){
   if(checkbox.closest(ownPanel)||checkbox.disabled||checkbox.type!=='checkbox')continue;
   const pieces=[...(checkbox.labels||[]),checkbox.closest('label'),
     checkbox.previousElementSibling,checkbox.nextElementSibling,
     ...[checkbox.parentElement,checkbox.parentElement?.parentElement,checkbox.parentElement?.parentElement?.parentElement]
       .filter(node=>node?.querySelectorAll('input[type=checkbox],input[type=radio]').length===1)];
   for(const part of pieces){
    if(!part||!visible(part))continue;
    const name=clean(part.textContent);
    if(isLabel(name))add(checkbox.checked?'selectedClass':'classOption',part,name);
    // Some Noor templates put the text in a sibling <span> next to the input.
    else if(part.querySelectorAll&&name.length<350){
     for(const child of [...part.querySelectorAll('label,span,strong,b,small')].slice(0,35)){
      const text=clean(child.textContent);
      if(visible(child)&&isLabel(text))add(checkbox.checked?'selectedClass':'classOption',child,text);
     }
    }
   }
  }
  // Class text can also be an independent text node alongside a styled
  // checkbox. Match an isolated class name ONLY if a checkbox shares a short
  // local container; do not scan arbitrary headings or the school banner.
  if(document.body&&typeof document.createTreeWalker==='function'){
   const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
   let leaf,count=0;
   while((leaf=walker.nextNode())&&++count<=6000){
    const value=clean(leaf.nodeValue),el=leaf.parentElement;
    if(!isLabel(value)||!el||!visible(el))continue;
    for(let parent=el,depth=0;parent&&depth<5;parent=parent.parentElement,depth++){
     if(clean(parent.textContent).length>400)break;
     const local=[...parent.querySelectorAll('input[type="checkbox"]')];
     if(local.length!==1)continue;
     add(local[0].checked?'selectedClass':'classOption',el,value);
     break;
    }
   }
  }
  for(const el of document.querySelectorAll('select')){
   if(!visible(el))continue;
   const key=clean([el.name,el.id,el.getAttribute('aria-label')].join(' ')).toLowerCase();
   for(const option of el.selectedOptions||[]){
    const text=clean(option.textContent);
    if(!isLabel(text))continue;
    if(/class|course|grade|section|صف|المادة/i.test(key))add('selectedCourse',el,text);
    else add('selectedOption',el,text);
   }
  }
  document.querySelectorAll('.breadcrumb,ol.breadcrumb,.course-title,.course-name,[data-course-name],nav[aria-label*="breadcrumb"],nav[aria-label*="مسار"]').forEach(el=>add('breadcrumb',el));
  for(const el of document.querySelectorAll('h1,h2,h3'))add('heading',el);
  return candidates.slice(0,75);
 }
 function lessonSelects(){
   return [...document.querySelectorAll('select')].filter(el=>{
     if(!visible(el))return false;
     const key=clean([el.name,el.id,el.getAttribute('aria-label'),el.closest('.form-group')?.querySelector('label')?.textContent||''].join(' '));
     return /الدرس|الدروس|lesson|unit|الوحدة/i.test(key);
   });
 }
 function lessonOptions(){
   return [...new Set(lessonSelects().flatMap(el=>[...el.options].map(o=>clean(o.textContent)).filter(x=>x.length>2)))].slice(0,100);
 }
 function uniqueLessonOption(unit,lesson){
   const want=clean(lesson).toLowerCase(),wantUnit=clean(unit).toLowerCase();
   if(!want)return null;
   const matched=[];
   for(const el of lessonSelects())for(const option of el.options){
     const label=clean(option.textContent).toLowerCase();
     if(label && (label===want || label.includes(want)) && (!wantUnit || label.includes(wantUnit)||label===want))matched.push({el,option});
   }
   return matched.length===1?matched[0]:null;
 }
 function detect(){
  const candidates=collectContexts();
  const picked=globalThis.NoorContext?.choose(candidates)||{verified:false,grade:null,className:''};
  const course=candidates.filter(c=>c.source==='breadcrumb'||c.source==='selectedCourse').map(c=>c.text).join(' • ');
  const subject=/اللغة الانجليزية|اللغة الإنجليزية|\benglish\b/i.test(course)?'English':'';
  return {path:location.pathname,cid:cid(),cidKind:cid()?(/^\d+$/.test(cid())?'numeric':'opaque'):null,
   grade:picked.grade,gradeVerified:Boolean(picked.verified),className:picked.className,source:picked.evidence,subject,
   classSelectionChecked: Boolean(picked.verified && candidates.some(c=>c.source==='selectedClass'&&c.text===picked.className)),
   // Expose limited class/grade candidates, not page HTML or private form contents.
   candidates:candidates.filter(c=>globalThis.NoorContext?.parseGrade(c.text)).slice(0,12),lessonOptions:lessonOptions()};
 }
 function attrMatch(el,labels){const s=clean([el.getAttribute('name'),el.id,el.getAttribute('placeholder'),el.getAttribute('aria-label')].join(' '));return labels.some(l=>s===l||s.includes(l));}
 function candidatesFor(labels,tagNames){
  const pool=[...document.querySelectorAll(tagNames)];const found=[];
  for(const el of pool){if(!visible(el)||el.disabled)continue;
   if(attrMatch(el,labels))found.push(el);
  }
  for(const label of document.querySelectorAll('label')){
    if(!labels.some(l=>clean(label.textContent).replace(/\*/g,'').trim()===l))continue;
    if(label.control && visible(label.control))found.push(label.control);
    const group=label.closest('.form-group,.field,.form-field,[class*="field"],[class*="form-group"]')||label.parentElement;
    if(group){const els=group.querySelectorAll(tagNames);if(els.length===1&&visible(els[0]))found.push(els[0]);}
  }
  return [...new Set(found)];
 }
 function uniqueField(labels,tagNames){const arr=candidatesFor(labels,tagNames);return arr.length===1?arr[0]:null;}
 function fill(el,v){if(!el)throw Error('Field not identified');
   if(!['INPUT','TEXTAREA'].includes(el.tagName))throw Error('Unsupported field');
   const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
   Object.getOwnPropertyDescriptor(proto,'value')?.set?.call(el,String(v??''));
   el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
 }
 const titleField=()=>uniqueField(['العنوان','title','عنوان الواجب'],'input:not([type="hidden"]),textarea');
 const instructionsField=()=>uniqueField(['التعليمات','instructions'],'textarea,input:not([type="hidden"])');
 function preview(payload){
   const context=detect();const issues=[];
   if(!/^\/teacher\/homeworks\/create(?:\/|$)/i.test(location.pathname))issues.push('افتح صفحة «إضافة واجب جديد» الخاصة بالصف أولًا.');
   if(!context.cid)issues.push('صفحة نور بلا معرّف CID.');
   if(!context.gradeVerified)issues.push('تعذر تحديد فصل واحد من الأسماء الظاهرة. تأكد أنك في صفحة الفصل الصحيح، أو اختر الفصل المقصود داخل نور.');
   if(payload?.expectedCid && context.cid!==payload.expectedCid)issues.push('تغيّر CID منذ ربط الصفحة.');
   if(payload?.grade && context.grade && Number(payload.grade)!==context.grade)issues.push('الصف في الملف لا يطابق الصف المعروض في نور.');
   if(!payload?.title?.trim())issues.push('عنوان النشاط مفقود.');
   if(!payload?.unit?.trim()||!payload?.lesson?.trim())issues.push('اختر الوحدة والدرس في الإضافة.');
   if(!titleField())issues.push('لم أتعرف بدقة على حقل عنوان نور.');
   const actions=[];
   if(titleField())actions.push('fill_title');
   if(uniqueLessonOption(payload?.unit,payload?.lesson))actions.push('select_lesson');
   if(instructionsField()&&payload?.instructions)actions.push('fill_instructions');
   return {ok:issues.length===0,issues,context,actions,lessonMappingVerified:false,publishReady:false};
 }
 function stage(payload){
  const check=preview(payload);if(!check.ok)return check;
  fill(titleField(),payload.title);
  if(instructionsField()&&payload.instructions)fill(instructionsField(),payload.instructions);
  const lessonMatch=uniqueLessonOption(payload.unit,payload.lesson);
  if(lessonMatch){
    const {el,option}=lessonMatch;
    if(!el.multiple)[...el.options].forEach(o=>{o.selected=(o===option)});
    else option.selected=true;
    el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
  }
  return {...check,staged:true,lessonSelected:Boolean(lessonMatch),message:lessonMatch?'نُقل العنوان والدرس إلى نموذج نور. لم تُنشر الأسئلة بعد.':'نُقل عنوان الواجب إلى نموذج نور. لم تتطابق خيارات الدروس مع الاسم المحدد، ولم يُنشر شيء.'};
 }
 function snapshotQuestion(){
  const heading=clean([...document.querySelectorAll('h1,h2,h3')].filter(visible).map(x=>x.textContent).join(' | '));
  const editors=[...document.querySelectorAll('textarea,[contenteditable="true"],iframe.cke_wysiwyg_frame,iframe.tox-edit-area__iframe')].filter(visible);
  return {heading,editors:editors.length,scoreInputs:candidatesFor(['درجة المفردة','points','score'],'input:not([type="hidden"])').length,
   // This is for future safe mapping, deliberately does not collect student data or field contents.
   readyForAutomaticInsertion:false};
 }
 // Used only by this extension's visible Noor toolbar in the same isolated content-script world.
 globalThis.__NoorSmartReadContext=detect;
 browser.runtime.onMessage.addListener(msg=>{
  if(msg?.type==='NOOR_READ_CONTEXT')return Promise.resolve(detect());
  if(msg?.type==='NOOR_PREVIEW_TRANSFER')return Promise.resolve(preview(msg.payload));
  if(msg?.type==='NOOR_STAGE_HOMEWORK')return Promise.resolve(stage(msg.payload));
  if(msg?.type==='NOOR_QUESTION_FORM_INFO')return Promise.resolve(snapshotQuestion());
 });
})();
