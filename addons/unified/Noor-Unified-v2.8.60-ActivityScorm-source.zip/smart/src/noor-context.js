/* Extract class/grade only from Noor's visible course or selected class UI. No CID-to-grade guessing. */
(function(root){'use strict';
 const arabic=['','الأول','الثاني','الثالث','الرابع','الخامس','السادس','السابع','الثامن','التاسع','العاشر','الحادي عشر','الثاني عشر'];
 const english=['','first','second','third','fourth','fifth','sixth','seventh','eighth','ninth','tenth','eleventh','twelfth'];
 const clean=s=>String(s??'').replace(/\s+/g,' ').trim().slice(0,200);
 const normalized=s=>clean(s).normalize('NFKC').replace(/[\u064b-\u065f\u0640\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,'')
  .replace(/[أإآ]/g,'ا').replace(/[–—−]/g,'-').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632))
  .replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776)).toLowerCase();
 const gradeNames=new Map(english.slice(1).map((name,index)=>[name,index+1]));
 arabic.slice(1).forEach((name,index)=>gradeNames.set(normalized(name),index+1));
 gradeNames.set('nineth',9);
 gradeNames.set('eigth',8);
 const names=[...gradeNames.keys()].sort((a,b)=>b.length-a.length).join('|');
 const className=new RegExp('^(?:(?:grade|class|الصف|صف)\\s*[:#]?\\s*)?('+names+'|1[0-2]|[1-9])(?:\\s*(?:[-/]|section\\s+|الشعبه\\s+|الشعبة\\s+)\\s*|\\s+)?(\\d{1,3})?$');
 function classIdentity(source){
  const text=normalized(source);
  const label=text.includes('/')&&/[^\d]\s*\/\s*[^\d]/.test(text)?text.slice(text.lastIndexOf('/')+1).trim():text;
  const m=className.exec(label);
  if(!m||m[2]&&!/[-/\s]/.test(label))return null;
  return {grade:gradeNames.get(m[1])||Number(m[1]),section:m[2]?String(Number(m[2])):''};
 }
 function parseGrade(source){
  const full=classIdentity(source);
  if(full)return full.grade;
  const text=normalized(source);
  if(!text||/الصفوف\s*\(?\s*1\s*-\s*12|grades\s*1\s*-\s*12/.test(text))return null;
  const numeric=text.match(/(?:^|[^\p{L}\p{N}])(?:grade|class|الصف|صف)\s*[:-]?\s*(1[0-2]|[1-9])(?=$|[^\p{L}\p{N}])/u);
  if(numeric)return Number(numeric[1]);
  const ordinal=new RegExp('(?:^|[^\\p{L}\\p{N}])(?:(?:grade|class|الصف|صف)\\s+)?('+names+')(?=$|[^\\p{L}\\p{N}])','gu');
  const matches=[...new Set([...text.matchAll(ordinal)].map(match=>gradeNames.get(match[1])))];
  return matches.length===1?matches[0]:null;
 }
 function isClassLabel(value){return Boolean(classIdentity(value));}
 const sourceRank={selectedClass:7,selectedCourse:6,classOption:5,selectedOption:1,breadcrumb:3,courseTitle:3,heading:2};
 function choose(candidates){
  const found=[];
  for(const c of candidates||[]){
   const label=clean(c.text);const grade=parseGrade(label);
   if(!grade)continue;
   found.push({label,grade,source:c.source,rank:sourceRank[c.source]||0});
  }
  found.sort((a,b)=>b.rank-a.rank);
  if(!found.length)return {verified:false,grade:null,className:'',evidence:'No displayed class found'};
  const peak=found.filter(x=>x.rank===found[0].rank);
  if(new Set(peak.map(x=>x.grade)).size!==1)return {verified:false,grade:null,className:'',evidence:'Conflicting displayed grades'};
  // Two sections of the same grade are different classes. Don't choose one at random.
  const distinct=new Set(peak.map(x=>{const identity=classIdentity(x.label);return identity?identity.grade+':'+identity.section:normalized(x.label);}));
  if(distinct.size>1)return {verified:false,grade:null,className:'',evidence:'Multiple classes shown; select the intended one in Noor'};
  return {verified:peak[0].rank>=3,grade:peak[0].grade,className:peak[0].label,evidence:peak[0].source};
 }
 root.NoorContext={parseGrade,isClassLabel,classIdentity,choose};
})(typeof globalThis==='object'?globalThis:this);
