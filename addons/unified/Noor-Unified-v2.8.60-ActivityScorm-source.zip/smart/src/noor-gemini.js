/* Gemini assessment adapter for the Noor floating panel. No API key in this file. */
(function(root){'use strict';
const KINDS=Object.freeze([
 {kind:'mcq',label:'اختيار من متعدد',default:true},
 {kind:'true_false',label:'صح / خطأ',default:true},
 {kind:'multi_select',label:'متعدد الإجابات',default:true},
 {kind:'matching',label:'توصيل عمودين',default:true},
 {kind:'fill_blanks',label:'ملء الفراغات',default:true},
 {kind:'short_text',label:'إجابة قصيرة',default:false},
 {kind:'essay',label:'سؤال إنشائي',default:false},
 {kind:'pairing',label:'اقتران',default:false}
]);
const allowed=new Set(KINDS.map(x=>x.kind));
const trim=(value,max=200)=>String(value??'').trim().slice(0,max);
function makeRequest(input){
 const grade=Number(input.grade),unit=trim(input.unit,80),lesson=trim(input.lesson,80),subject=trim(input.subject,120);
 const selected=[...new Set(Array.isArray(input.kinds)?input.kinds:[])];
 if(!Number.isInteger(grade)||grade<1||grade>12)throw Error('افتح واجب الصف الصحيح في نور حتى تتعرف الإضافة على الصف تلقائيًا.');
 if(!unit||!lesson||!subject)throw Error('تحقق من المادة والوحدة والدرس أولًا.');
 if(!selected.length||selected.some(x=>!allowed.has(x)))throw Error('اختر نوع سؤال واحدًا على الأقل من الأنواع المدعومة في نور.');
 const count=Number(input.count);
 if(!Number.isInteger(count)||count<1||count>30)throw Error('عدد الأسئلة يجب أن يكون بين 1 و30.');
 const difficulty=trim(input.difficulty,20);
 if(!['easy','medium','mixed','hard'].includes(difficulty))throw Error('مستوى الصعوبة غير معروف.');
 const title=trim(input.title,150)||`أنشطة Gemini — ${unit} / ${lesson}`;
 const instructions=trim(input.description,1800);
 const limits='Questions MUST be valid for the Noor LMS editors. MCQ: exactly 3 or 4 options and answer exactly equal to one option. Multi-select: 3 to 5 options and 2 or more correct answers that are options. Matching: 2 to 5 complete {left,right} pairs, no images. Pairing: 2 to 5 complete {left,right} pairs, no images. Fill_blanks: supply blanks array with ordered answers, 1 to 5 blanks. True_false: answer must be boolean true or false. Short_text: provide a precise model answer. Essay: provide model answer and keep teacher manual marking in mind. Never generate a question requiring pictures, audio, files, answer attachments, or unavailable media. Use no student names or data. All points must be positive. Use the selected types as a pool. Return exactly the requested total. If the total is smaller than the number of types, use a varied subset; there is no requirement to use every type. Avoid questions that rely on a listening recording or a textbook passage not supplied. Do not invent official textbook quotations.';
 return {mode:'generate',grade:String(grade),subject,unit,lesson,activityType:'assignment',title,count,difficulty,
  supportedKinds:selected,description:[limits,instructions&&'Teacher focus: '+instructions].filter(Boolean).join('\n').slice(0,5200)};
}
function parseResult(result,context,schema,{allowPartial=false}={}){
 if(!Array.isArray(result?.questions))throw Error('لم يُرجع Gemini قائمة أسئلة.');
 const valid=[],issues=[],allow=new Set(context.supportedKinds);
 for(let i=0;i<result.questions.length;i++){
  const raw=result.questions[i];
  if(!raw||!allow.has(raw.kind)){issues.push(`سؤال ${i+1}: نوع غير مطلوب`);continue;}
  const q=schema.normalizeQuestion({...raw,source:'gemini'}, {grade:context.grade,subject:context.subject,unit:context.unit,lesson:context.lesson});
  if(!q){issues.push(`سؤال ${i+1}: تعذر قراءة السؤال`);continue;}
  const errs=schema.validateQuestion(q);
  if((q.kind==='matching'||q.kind==='pairing')&&q.pairs.length>5)errs.push('أكثر من خمسة أزواج');
  if(q.kind==='fill_blanks'&&(q.blanks.length>5||(q.stem.match(/_{4,}/g)||[]).length!==q.blanks.length))
   errs.push('عدد الفراغات في نص السؤال لا يطابق الإجابات أو يتجاوز خمسة');
  if(errs.length){issues.push(`سؤال ${i+1}: ${errs.join('، ')}`);continue;}
  valid.push(q);
 }
 if(!valid.length&&!allowPartial)throw Error('الأسئلة المولدة لم تجتز التحقق. '+issues.slice(0,3).join(' | '));
 const warnings=(Array.isArray(result.warnings)?result.warnings:[]).map(x=>trim(x,250)).filter(Boolean);
 return {questions:valid,issues,warnings,totalPoints:valid.reduce((s,q)=>s+q.points,0),allValid:issues.length===0};
}
async function generateComplete(request,schema,send,onRetry=()=>{}){
 const questions=[],stems=new Set(),issues=[],warnings=[];
 let modelUsed='';
 for(let attempt=0;attempt<3&&questions.length<request.count;attempt++){
  const missing=request.count-questions.length;
  if(attempt)onRetry(missing);
  const avoid=questions.length
   ?' Write new questions distinct from these accepted stems: '+questions.map(q=>q.stem.slice(0,95)).join(' | ')
   :'';
  const response=await send({...request,count:missing,description:(request.description.slice(0,2200)+avoid).slice(0,5200)});
  if(!response?.ok)throw Error(response?.error||'فشل الاتصال بخدمة Gemini');
  const parsed=parseResult(response,request,schema,{allowPartial:true});
  modelUsed=response.modelUsed||modelUsed;
  issues.push(...parsed.issues);warnings.push(...parsed.warnings);
  for(const question of parsed.questions){
   if(questions.length===request.count)break;
   const key=question.stem.normalize('NFKC').toLowerCase().replace(/\s+/g,' ').trim();
   if(stems.has(key)){issues.push('أعاد Gemini سؤالًا مكررًا');continue;}
   stems.add(key);questions.push(question);
  }
 }
 if(questions.length!==request.count){
  const details=[...new Set(issues)].slice(0,3).join(' | ');
  throw Error('اجتاز التحقق '+questions.length+' من '+request.count+' سؤالًا بعد ثلاث محاولات.'+(details?' '+details:''));
 }
 return {questions,issues:[],warnings:[...new Set(warnings)].slice(0,20),
  totalPoints:questions.reduce((total,q)=>total+q.points,0),allValid:true,modelUsed};
}
root.NoorGemini={KINDS,makeRequest,parseResult,generateComplete};
})(typeof globalThis==='object'?globalThis:this);
