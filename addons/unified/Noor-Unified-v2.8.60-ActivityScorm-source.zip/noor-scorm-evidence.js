/* Independent Noor SCORM context verification (2.8.37).
 * Opaque repository cid/tid is not the numeric class course cid. Instead
 * verify the page's official textbook/subject and the selected class in
 * "نشر لفصول". A matching subject + grade + unique section is required. */
(function(root){'use strict';
 // Keep this verifier available on teacher pages even when Noor navigates via
 // AJAX instead of loading a new document. inspect() itself checks the form.
 function onUploadForm(){return Boolean(root.NoorScormPublisher?.onUploadPage?.());}
 const clean=s=>String(s||'').normalize('NFKC').replace(/[\u064b-\u065f\u0640]/g,'')
   .replace(/[إأآ]/g,'ا').replace(/\s+/g,' ').trim();
 const catalog=()=>root.NoorCourseCatalog;
 function nearbyLabel(input){
  if(input.id){for(const x of document.querySelectorAll('label[for]'))if(x.htmlFor===input.id)return clean(x.textContent);}
  const containing=input.closest('label');if(containing)return clean(containing.textContent);
  // Only use a local row with a single checkbox; "select all" has its own row.
  let node=input.parentElement;
  for(let depth=0;node&&depth<4;depth++,node=node.parentElement){
   if(node.querySelectorAll('input[type="checkbox"]').length!==1)break;
   const text=clean(node.textContent);if(text&&text.length<95)return text;
  }
  return '';
 }
 function pageGrade(text){
  const official=catalog()?.gradeOf?.(text);if(official)return official;
  // Noor's textbook heading uses "صف تاسع", while its class checkbox uses
  // "التاسع - 1". Both forms are official names for Grade 9.
  const words={'اول':1,'ثاني':2,'ثالث':3,'رابع':4,'خامس':5,'سادس':6,'سابع':7,
    'ثامن':8,'تاسع':9,'عاشر':10,'حادي عشر':11,'ثاني عشر':12};
  const a=clean(text).match(/(?:^|\s)(?:الصف|صف)\s+(?:(?:ال)?(حادي عشر|ثاني عشر|اول|ثاني|ثالث|رابع|خامس|سادس|سابع|ثامن|تاسع|عاشر))(?:\b|(?=\s|$|[-–]))/);
  if(a)return words[a[1]]||null;
  return null;
 }
 function bookIdentities(){
  const results=[];
  for(const node of document.querySelectorAll('h1,h2,h3,h4,span,p,strong,div')){
   if(node.closest('#stnNoorHub,#noor-prep-panel,nav,aside,footer')||!node.getClientRects().length)continue;
   const text=clean(node.textContent);
   if(text.length<12||text.length>170||!/عرض\s*الشجر[هة]|(?:^|\s)كتاب(?:\s|$)|\bBook\b|show (?:the )?(?:lesson )?tree/i.test(text))continue;
   const grade=pageGrade(text),subject=catalog()?.subjectOf?.(text);
   if(grade&&subject){const key=subject+'|'+grade;if(!results.some(x=>x.key===key))results.push({key,grade,subject,text});}
  }
  return results;
 }
 function inspect(course){
  if(!onUploadForm())return {ok:false,reason:'not_interactive_upload_form'};
  if(!course?.verified||!Number.isInteger(Number(course.grade))||!course.subject)return {ok:false,reason:'class_not_verified'};
  const books=bookIdentities();
  const match=books.filter(x=>x.grade===Number(course.grade)&&x.subject===course.subject);
  if(match.length!==1||books.length!==1)return {ok:false,reason:'book_subject_or_grade_unconfirmed',books:books.map(x=>x.key)};
  const checks=[...document.querySelectorAll('input[type="checkbox"]')]
   .filter(x=>!x.disabled&&!x.closest('#stnNoorHub,#noor-prep-panel'))
   .map(input=>({input,label:nearbyLabel(input)}))
   .filter(x=>x.label && x.label.length<95 && catalog()?.gradeOf?.(x.label));
  const other=checks.filter(x=>catalog()?.gradeOf?.(x.label)!==Number(course.grade) && x.input.checked);
  if(other.length)return {ok:false,reason:'other_grade_already_selected'};
  const own=checks.filter(x=>catalog()?.gradeOf?.(x.label)===Number(course.grade));
  if(!own.length)return {ok:false,reason:'publish_class_not_found'};
  // The course label might specify a section (e.g. "التاسع - 2"). In that
  // case require the same section, never choose another one merely by grade.
  const section=root.NoorContext?.classIdentity(course.label)?.section||'';
  const selected=section?own.filter(x=>root.NoorContext?.classIdentity(x.label)?.section===section):own;
  if(!selected.length)return {ok:false,reason:'target_section_not_found'};
  const checked=own.filter(x=>x.input.checked);
  if(checked.some(x=>!selected.includes(x)))return {ok:false,reason:'other_section_already_selected'};
  if(selected.length>1&&!checked.length)return {ok:false,reason:'multiple_sections_choose_first'};
  if(selected.length>1&&checked.length!==1)return {ok:false,reason:'ambiguous_section_selection'};
  return {ok:true,book:match[0].text,section:checked[0]||selected[0],autoSelect:checked.length===0};
 }
 function ensureSelected(course){
  const data=inspect(course);
  if(!data.ok)return data;
  if(data.autoSelect){
   const input=data.section.input;
   input.checked=true;
   input.dispatchEvent(new Event('input',{bubbles:true}));
   input.dispatchEvent(new Event('change',{bubbles:true}));
   if(!input.checked)return {ok:false,reason:'section_selection_failed'};
  }
  return {ok:true,book:data.book,section:data.section.label};
 }
 function ensureVisibleSection(course,scope){
  const visible=input=>!input.disabled&&!input.closest('#stnNoorHub,#noor-prep-panel')&&
   [input,...(input.labels||[]),input.parentElement].some(el=>el?.getClientRects().length&&getComputedStyle(el).visibility!=='hidden');
  if(!scope)return {ok:false,reason:'publish_form_not_found'};
  const checks=[...scope.querySelectorAll('input[type="checkbox"]')].filter(visible)
   .map(input=>({input,label:nearbyLabel(input)})).filter(row=>catalog()?.gradeOf?.(row.label));
  const section=root.NoorContext?.classIdentity(course.label)?.section;
  const target=checks.filter(row=>catalog().gradeOf(row.label)===Number(course.grade)&&
   (!section||root.NoorContext?.classIdentity(row.label)?.section===section));
  if(target.length!==1)return {ok:false,reason:'publish_class_not_unique'};
  const input=target[0].input;
  for(const row of checks)if(row.input!==input&&row.input.checked)row.input.click();
  if(!input.checked)input.click();
  return {ok:input.checked&&!checks.some(row=>row.input!==input&&row.input.checked),section:target[0].label};
 }
 root.NoorScormClassEvidence=Object.freeze({inspect,ensureSelected,ensureVisibleSection});
})(typeof globalThis==='object'?globalThis:this);
