// Gemini is billed/limited against each linked teacher's own API project.
// The key stays in Firefox extension storage and is sent directly to Google
// Gemini only; it never passes through the Notebook or Supabase backend.
const STN_TEACHER_KEY='stnActiveTeacherId';
const STN_KEY_PREFIX='stnGeminiKey:';
const STN_NOTEBOOK_URL='https://rouhous.github.io/School-Teacher-Notebook-App/school-edition/school-notebook.html';
const STN_NOOR_ORIGIN='https://lms.moe.gov.om/';
const keyPattern=/^(?:AIza[A-Za-z0-9_-]{20,}|AQ\.[A-Za-z0-9._~=-]{20,})$/;
async function teacherContext(){
  await globalThis.STN_NOOR_LICENSE.authorized();
  const {stnActiveTeacherId}=await browser.storage.local.get(STN_TEACHER_KEY);
  const id=String(stnActiveTeacherId||'');
  if(!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))throw Error('افتح دفتر المعلم بحساب Google المعتمد، ثم ارجع إلى نور.');
  const {['stnGeminiKey:'+id]:key}=await browser.storage.local.get(STN_KEY_PREFIX+id);
  if(!keyPattern.test(String(key||'')))throw Error('لم يتم حفظ مفتاح Gemini لهذا المعلم.');
  return {id,key};
}
const fromNotebook=sender=>String(sender?.url||'').startsWith(STN_NOTEBOOK_URL);
const fromNoor=sender=>String(sender?.url||'').startsWith(STN_NOOR_ORIGIN);
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!msg||!fromNotebook(sender))return false;
 if(msg.type==='STN_STORE_GRADES')return (async()=>{
   await globalThis.STN_NOOR_LICENSE.authorized();
   const p=msg.payload;
   const id=(await browser.storage.local.get(STN_TEACHER_KEY)).stnActiveTeacherId;
   if(!id||msg.teacherId!==id||p?.schema!=='teacher-notebook-noor-v1' ||
      !Array.isArray(p.students)||!Array.isArray(p.assessments)||
      p.students.length>300||p.assessments.length>120||JSON.stringify(p).length>500000)
     return {ok:false,error:'invalid_payload'};
   const safe={schema:p.schema,exportedAt:String(p.exportedAt||''),className:String(p.className||'').slice(0,120),
     assessments:p.assessments.map(a=>({id:String(a.id||''),name:String(a.name||'').slice(0,100),max:Number(a.max)||0})),
     students:p.students.map(st=>({name:String(st.name||'').slice(0,180),studentNumber:String(st.studentNumber||'').slice(0,40),
       grades:Object.fromEntries(Object.entries(st.grades||{}).slice(0,120).map(([k,v])=>[String(k).slice(0,80),String(v??'').slice(0,30)]))}))};
   await browser.storage.local.set({['stnGrades:'+id]:safe});
   let navigation='awaiting_course';
   const catalog=(await browser.storage.local.get('stnCourseCatalog:v4:'+id))['stnCourseCatalog:v4:'+id];
   const norm=v=>String(v||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/\s+/g,' ').trim().toLowerCase();
   const exact=Array.isArray(catalog)?catalog.filter(c=>norm(c.label)===norm(safe.className)&&c.cidNumeric&&/^\d+$/.test(c.cidNumeric)):[];
   // Never invent Noor grade routes. The link must come from the selected class card.
   if(exact.length===1){
     const candidate=exact[0],raw=candidate.routes?.grades;
     let target='';try{const u=new URL(raw);if(u.origin==='https://lms.moe.gov.om'&&u.pathname.startsWith('/teacher/')&&u.pathname.includes('cid:'))target=u.href}catch(_){}
     if(target){
       const tabs=await browser.tabs.query({url:'https://lms.moe.gov.om/*'}).catch(()=>[]);
       const tab=tabs.find(t=>t.active)||tabs[0];
       if(tab?.id)await browser.tabs.update(tab.id,{url:target,active:true});else await browser.tabs.create({url:target,active:true});
       navigation='opened_official_grades';
     }
   }
   await browser.storage.local.set({['stnPendingGrades:'+id]:{className:safe.className,receivedAt:Date.now(),navigation}});
   return {ok:true,count:safe.students.length,navigation};
 })();
 return false;
});
browser.runtime.onMessage.addListener((msg,sender) => {
 if (!msg || msg.type !== 'NOOR_GEMINI_GENERATE' || !fromNoor(sender)) return false;
 return (async()=>{
 let key; try {({key}=await teacherContext())}catch(e){return {ok:false,error:String(e.message||e)}}
 const count=Math.max(1,Math.min(40,Number(msg.count)||10));
 const prompt=String(msg.prompt||'').slice(0,6500)+`\nReturn ONLY JSON with exactly ${count} questions: {"title":"...","questions":[{"question":"...","options":["...","...","...","..."],"correct":0,"explanation":"..."}]}. Each question must have exactly 4 options, one correct index 0-3. No markdown. Do not invent specific textbook facts not in supplied context. If lesson details are missing, write broadly relevant questions and avoid unsupported curriculum claims.`;
 try {
    const generated=await globalThis.NoorGeminiModels.generate(key,{contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.6,maxOutputTokens:16000}},{timeoutMs:90000});
    const payload=generated.data;
    const raw=payload.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('')||'';
    const data=JSON.parse(raw);
    if(!Array.isArray(data.questions)||data.questions.length!==count)throw Error('عدد الأسئلة غير مطابق للمطلوب. حاول مرة أخرى.');
    for(const q of data.questions){if(typeof q.question!=='string'||!Array.isArray(q.options)||q.options.length!==4||!q.options.every(x=>typeof x==='string')||!Number.isInteger(q.correct)||q.correct<0||q.correct>3||typeof q.explanation!=='string')throw Error('صيغة سؤال غير صحيحة. حاول مجددًا.');}
    return {ok:true,modelUsed:generated.model,data:{title:String(data.title||'Interactive Activity').slice(0,150),questions:data.questions}};
  }catch(e){return {ok:false,error:String(e.message||e).slice(0,400)};}

})();
});
// Independent, richer SCORM generation. Gemini supplies lesson content only;
// a fixed vetted offline HTML/CSS/JS engine creates the actual SCORM 1.2 package.
// Do NOT alter NOOR_GEMINI_GENERATE: the legacy standalone quiz uses that schema.
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!msg||msg.type!=='NOOR_GEMINI_SCORM_GENERATE'||!fromNoor(sender))return false;
 return (async()=>{
  let key;try{({key}=await teacherContext())}catch(e){return {ok:false,error:String(e.message||e)}}
  const subject=String(msg.subject||'').trim().slice(0,90),grade=String(msg.grade||'').trim().slice(0,30),
        unit=String(msg.unit||'').trim().slice(0,140),lesson=String(msg.lesson||'').trim().slice(0,160),
        semester=String(msg.semester||'').trim().slice(0,15),variant=Math.max(1,Math.min(10,Number(msg.variant)||1));
  const count=Number(msg.count);
  if(!subject||!grade||!unit||!lesson||!Number.isInteger(count)||count<1||count>30)
    return {ok:false,error:'حدد المادة والصف والوحدة والدرس وعدد الأسئلة (1–30) قبل توليد SCORM.'};
  const fields=msg.reference||{};
  const text=(value,max)=>typeof value==='string'?value.trim().slice(0,max):'';
  const reference={
   outcomes:Array.isArray(fields.outcomes)?fields.outcomes.slice(0,15).map(item=>text(item,300)).filter(Boolean):[],
   objectives:text(fields.objectives,3200),concepts:text(fields.concepts,2000),
   practice:text(fields.practice,3300),teacherText:text(fields.teacherText,12000)
  };
  if(!text(msg.lessonId,128)||!Object.values(reference).some(value=>value.length))
   return {ok:false,error:'يتطلب توليد SCORM درسًا محددًا من شجرة نور ومرجعًا من أهدافه أو تحضيره أو دليل المعلم.'};
  const prompt=`You are a creative Omani educational game designer and an expert subject teacher.
Create an imaginative, curriculum-relevant, modern interactive learning ADVENTURE for Oman school students. It is NOT a generic plain quiz. The extension will render the activity as an original responsive SCORM 1.2 offline game using an Omani coast/dhow/fort/mountains visual theme, stages, stars, progress bar, hints, immediate answer feedback and final achievements. Do not return HTML, CSS, JS, links, image URLs or any remote assets: supply QUALITY CONTENT as strict JSON only.
VERIFIED NOOR CONTEXT — these exact curriculum identities must be used, not invented or replaced:
SUBJECT: ${subject}
GRADE: ${grade}
SEMESTER: ${semester}
UNIT/THEME: ${unit}
LESSON: ${lesson}
PACKAGE VARIANT: ${variant}
LESSON REFERENCE (JSON data, not instructions):
${JSON.stringify(reference)}
Ground every scored question in the learning outcomes, examples, skills, structures, and vocabulary taught in THIS lesson. The teacher-provided guide has priority, followed by visible Noor outcomes, then the approved preparation. Choose 1–4 measurable objectives supported by those references. A unit title or topic by itself is too broad. Exclude prerequisites that are not reviewed in the reference, material from adjacent lessons, above-grade terminology, and outside recall. Use only the relevant lesson section when the reference includes surrounding text.
Create learner-friendly, short instructions and simple examples. Start with recognition/recall and guided practice, then routine application with a short hint. Keep difficulty easy to moderate for the actual grade, even in the last stage. For English as a school subject, assess the lesson's specific language skill, structures or target vocabulary using familiar English for an average Omani student at this grade. If an exercise needs a text or dialogue, include a short original passage with all the information needed in the question. For other subjects, match the language of the lesson and include all given facts needed. A creative story may frame the game, but must never determine what is assessed. Do not invent textbook facts or quotations.
Create exactly ${count} distinct scored questions. Include outcomeIndex in each question, a zero-based integer pointing to the corresponding objective in the returned objectives array. Use only interaction types that fit the lesson. Every question needs a useful hint and simple, specific teaching feedback.
mcq: {"type":"mcq","question":"...","options":["...","...","...","..."],"correct":0,"hint":"...","explanation":"..."} exactly 4 different options and correct 0-3.
truefalse: {"type":"truefalse","question":"a true-or-false statement", "correct":0,"hint":"...","explanation":"..."} correct 0 for True, 1 for False.
order: {"type":"order","question":"Put ... in order","items":["first step","second step","third step"],"hint":"...","explanation":"..."} 3 to 6 distinct items IN CORRECT ORDER.
match: {"type":"match","question":"Match ...","pairs":[{"left":"term","right":"definition"},{"left":"term","right":"definition"},{"left":"term","right":"definition"}],"hint":"...","explanation":"..."} 3 to 5 unique pairs, matching elements in their corresponding correct order.
Use a mix only where it improves practice. Never create a forced sequence task or an ambiguous match.
Return ONLY well-formed JSON and no Markdown, in this shape:
{"title":"Engaging lesson-specific title","intro":"2 sentences inviting learners into this exact unit/lesson","mission":"Short motivating Omani adventure mission","objectives":["...","..."],"questions":[...exactly ${count} typed challenges...]}`;
  try{
   const generated=await globalThis.NoorGeminiModels.generate(key,{contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.35,maxOutputTokens:18000}},{timeoutMs:90000});
   const raw=(generated.data?.candidates?.[0]?.content?.parts||[]).map(p=>String(p.text||'')).join('');
   let data;try{data=JSON.parse(raw)}catch{return {ok:false,error:'لم يرجع Gemini بيانات صالحة للنشاط التفاعلي. أعد التوليد.'}}
   if(!Array.isArray(data?.questions)||data.questions.length!==count)return {ok:false,error:'عدد تحديات SCORM لا يطابق العدد المطلوب.'};
   const objectives=Array.isArray(data.objectives)?data.objectives.slice(0,4).filter(value=>typeof value==='string'&&value.trim()).map(value=>value.trim().slice(0,200)):[];
   if(!objectives.length)return {ok:false,error:'لم يرجع Gemini أهدافًا تعليمية لهذا الدرس.'};
   const seen=new Set();
   for(const [i,q] of data.questions.entries()){
    if(typeof q.question!=='string'||q.question.trim().length<8||typeof q.explanation!=='string'||q.explanation.trim().length<8)
      return {ok:false,error:'تحدي '+(i+1)+' يفتقد سؤالًا أو تفسيرًا تعليميًا.'};
    const stem=q.question.trim().toLowerCase();if(seen.has(stem))return {ok:false,error:'Gemini كرر سؤالًا في SCORM.'};seen.add(stem);
    if(!Number.isInteger(q.outcomeIndex)||q.outcomeIndex<0||q.outcomeIndex>=objectives.length)return {ok:false,error:'تحدي '+(i+1)+' لا يرتبط بهدف من أهداف الدرس.'};
    if(q.type==='mcq' && !(Array.isArray(q.options)&&q.options.length===4&&new Set(q.options).size===4&&Number.isInteger(q.correct)&&q.correct>=0&&q.correct<4))return {ok:false,error:'اختيارات غير صالحة في تحدي '+(i+1)};
    if(q.type==='truefalse' && !(q.correct===0||q.correct===1))return {ok:false,error:'إجابة صح/خطأ غير صالحة.'};
    if(q.type==='order' && !(Array.isArray(q.items)&&q.items.length>=3&&q.items.length<=6&&new Set(q.items).size===q.items.length))return {ok:false,error:'خطوات الترتيب غير صالحة.'};
    if(q.type==='match' && !(Array.isArray(q.pairs)&&q.pairs.length>=3&&q.pairs.length<=5&&q.pairs.every(p=>typeof p.left==='string'&&typeof p.right==='string')&&new Set(q.pairs.map(p=>p.left)).size===q.pairs.length&&new Set(q.pairs.map(p=>p.right)).size===q.pairs.length))return {ok:false,error:'أزواج التوصيل غير صالحة.'};
    if(!['mcq','truefalse','order','match'].includes(q.type))return {ok:false,error:'نوع تفاعل SCORM غير مدعوم.'};
   }
   return {ok:true,modelUsed:generated.model,data:{title:String(data.title||'Omani Learning Quest').slice(0,140),intro:String(data.intro||'').slice(0,400),mission:String(data.mission||'').slice(0,200),objectives,questions:data.questions}};
  }catch(e){return {ok:false,error:String(e?.message||e).slice(0,400)}}
 })();
});

// Validate the current teacher's stored key against Google instead of guessing its
// validity from the prefix alone. Never send the credential to the web page or logs.
browser.runtime.onMessage.addListener((msg,sender) => {
  if (!msg || msg.type!=='NOOR_GEMINI_TEST_KEY' || !fromNoor(sender)) return false;
  return (async()=>{
    let key;
    try {({key}=await teacherContext());} catch(e) {return {ok:false,error:String(e.message||e)}}
    try {
      const response=await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1',{
        method:'GET',headers:{'x-goog-api-key':key},cache:'no-store',signal:AbortSignal.timeout(15000)
      });
      if(response.ok) return {ok:true};
      const payload=await response.json().catch(()=>({}));
      let reason=String(payload?.error?.message||'HTTP '+response.status);
      if(key) reason=reason.split(key).join('[hidden]');
      if(response.status===401 || response.status===403)
        return {ok:false,error:'Google رفض المفتاح أو صلاحيات مشروعه ('+response.status+'): '+reason.slice(0,150)};
      if(response.status===429)return {ok:false,error:'وصل مشروع Gemini إلى حد الطلبات (429).'};
      return {ok:false,error:'Google HTTP '+response.status+': '+reason.slice(0,150)};
    } catch(e){return {ok:false,error:'تعذر فحص اتصال Google: '+String(e.message||e).slice(0,120)}}
  })();
});

// Generate a lesson directly through the teacher's Google account API project.
// This deliberately avoids the older Supabase relay that only accepted AIza keys.
// It does not auto-save or publish any response in Noor.
browser.runtime.onMessage.addListener((msg,sender) => {
 if (!msg || msg.type!=='NOOR_PREP_GENERATE' || !fromNoor(sender)) return false;
 return (async()=>{
   let key;
   try {({key}=await teacherContext());} catch(e){return {ok:false,error:String(e.message||e)}}
   const subject=String(msg.subject||'').trim().slice(0,120);
   const grade=String(msg.grade||'').trim().slice(0,60);
   const unit=String(msg.unit||'').trim().slice(0,160);
   const lesson=String(msg.lesson||'').trim().slice(0,180);
   const lessonText=String(msg.lessonText||'').slice(0,5000);
   const fields=Array.isArray(msg.fields)?msg.fields.filter(v=>typeof v==='string'&&/^[A-Za-z][\w-]{1,79}$/.test(v)).slice(0,25):[];
   if(!subject||!grade||!lesson||!fields.length)return {ok:false,error:'حدّد المادة والصف والدرس وحقول التحضير أولًا.'};
   const prompt=`You are an experienced teacher preparing a professional lesson in Oman. Create detailed, actionable curriculum-aligned lesson preparation in the same language as the subject. Base it on the teacher-supplied textbook content when present. If specific lesson pages are not given, never claim to have read them or invent exact textbook page or exercise numbers. Include measurable objectives, learning vocabulary and concepts, a warm-up, clear procedures with teacher/student actions, guided and independent practice, differentiation, and formative and final assessment with actual ready-to-use questions and model answers. Avoid generic boilerplate and do not invent official policy. Reply with a single JSON object whose keys exactly match the requested fields and whose values are complete plain-text explanations, no Markdown tables.\nSubject: ${subject}\nGrade: ${grade}\nUnit: ${unit}\nLesson: ${lesson}\nAvailable lesson text: ${lessonText||'[Not supplied: provide suggested activities rather than fabricated textbook quotations]'}\nRequired Noor field names: ${JSON.stringify(fields)}`;
   const payload={contents:[{parts:[{text:prompt}]}],generationConfig:{responseMimeType:'application/json',temperature:0.35,maxOutputTokens:5500}};
   try {
     const generated=await globalThis.NoorGeminiModels.generate(key,payload,{timeoutMs:60000});
     const raw=(generated.data?.candidates?.[0]?.content?.parts||[]).map(p=>String(p.text||'')).join('');
     let parsed;
     try{parsed=JSON.parse(raw)}catch{return {ok:false,error:'لم يرجع Gemini تحضيرًا بصيغة JSON صالحة، حاول مرة أخرى.'}}
     const prepared={};
     for(const f of fields){if(typeof parsed?.[f]==='string')prepared[f]=parsed[f].slice(0,3500);}
     if(!Object.keys(prepared).length)return {ok:false,error:'لم يُرجع Gemini حقول تحضير مطابقة لحقول نور.'};
     return {ok:true,fields:prepared,modelUsed:generated.model};
   }catch(e){return {ok:false,error:String(e?.message||e).slice(0,350)}}

 })();
});

// One Gemini key per Notebook teacher, shared by preparation, activities, and SCORM.
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!fromNoor(sender)||!msg||!['NOOR_HUB_KEY_STATUS','NOOR_HUB_SAVE_KEY'].includes(msg.type))return false;
 return (async()=>{
  await globalThis.STN_NOOR_LICENSE.authorized();
  const info=(await browser.storage.local.get(STN_TEACHER_KEY))[STN_TEACHER_KEY];
  const id=String(info||'');
  if(!/^[A-Za-z0-9_:\-.]{3,200}$/.test(id))return {ok:false,error:'افتح دفتر المعلم بحساب Google المعتمد أولًا.'};
  const storage='stnGeminiKey:'+id;
  if(msg.type==='NOOR_HUB_KEY_STATUS'){
   const obj=await browser.storage.local.get(storage);return {ok:true,ready:keyPattern.test(String(obj[storage]||''))};
  }
  const candidate=String(msg.apiKey||'').replace(/\s/g,'').slice(0,240);
  if(!keyPattern.test(candidate))return {ok:false,error:'تحقق من صحة مفتاح Gemini: يبدأ عادةً AQ. أو AIza.'};
  try {
   const resp=await fetch('https://generativelanguage.googleapis.com/v1beta/models?pageSize=1',{
    method:'GET',headers:{'x-goog-api-key':candidate},cache:'no-store',signal:AbortSignal.timeout(20000)
   });
   if(!resp.ok)return {ok:false,error:'رفضت Google المفتاح (HTTP '+resp.status+'). تأكد من صلاحيات مشروعه.'};
   await browser.storage.local.set({[storage]:candidate});return {ok:true,ready:true};
  }catch(e){return {ok:false,error:'تعذر اختبار مفتاح Gemini: '+String(e.message||e).slice(0,110)};}
 })();
});

// Noor 2.8.41 — Generate an actual subject-specific Omani 3D cartoon image.
// Text-only Gemini cannot render an image, and SVG/CSS drawings are not an
// adequate substitute. The image is returned for inclusion in the OFFLINE ZIP.
// Credentials remain in the extension background and are sent only to Google.
browser.runtime.onMessage.addListener((msg,sender)=>{
 if(!msg||msg.type!=='NOOR_GEMINI_SCORM_IMAGE'||!fromNoor(sender))return false;
 return (async()=>{
  let key;try{({key}=await teacherContext())}catch(e){return {ok:false,error:String(e?.message||e)}}
  const subject=String(msg.subject||'').trim().slice(0,90);
  const grade=String(msg.grade||'').trim().slice(0,25);
  const unit=String(msg.unit||'').trim().slice(0,145);
  const lesson=String(msg.lesson||'').trim().slice(0,160);
  const variant=Math.max(1,Math.min(10,Number(msg.variant)||1));
  if(!subject||!grade||!unit||!lesson)return {ok:false,error:'المادة والصف والوحدة والدرس مطلوبة لإنشاء صورة النشاط.'};
  const prompt=`Create ONE original polished 3D cartoon render for an Omani school educational interactive learning adventure.
Subject: ${subject}. Grade: ${grade}. Unit/theme: ${unit}. Lesson: ${lesson}. Image variant ${variant}.
The scene MUST visibly illustrate the ACTUAL educational concept, topic or vocabulary of this particular lesson. Use age-appropriate friendly Omani boy and girl students wearing culturally authentic Omani school clothing when people are relevant to the lesson. Use a bright appealing premium 3D animated-film illustration aesthetic, dimensional lighting, lifelike textures, vivid but harmonious colors, interesting educational props and engaging storytelling. An Omani setting can include local school, coastline, mountains or architecture if contextually appropriate, but NEVER use a dhow, a fort or unrelated decorative objects just because the school is in Oman. A science lesson must feature science; a language lesson should clearly depict its particular story or vocabulary; math lessons should visually represent the relevant problem in a meaningful setting. Landscape 16:9 composition suitable for a children's activity cover. No text, no labels, no lettering, no logos, no watermarks, no UI, no screenshots, no flat vector SVG art, no icons or stickers. Return the finished illustrated image only.`;
  const payload={contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{responseModalities:['IMAGE'],imageConfig:{aspectRatio:'16:9'}}};
  for(const model of ['gemini-2.5-flash-image','gemini-3.1-flash-image']){
   let response;
   try{response=await fetch('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',{
    method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},
    body:JSON.stringify(payload),cache:'no-store',signal:AbortSignal.timeout(120000)});
   }catch(e){return {ok:false,error:'تعذر الاتصال بخدمة صور Gemini: '+String(e?.message||e).slice(0,140)}}
   if(!response.ok){
    const status=response.status;
    if(status===404||status===400){if(model==='gemini-2.5-flash-image')continue;}
    const data=await response.json().catch(()=>({}));
    const detail=String(data?.error?.message||'Google HTTP '+status).replaceAll(key,'[hidden]').slice(0,170);
    return {ok:false,error:'تعذر توليد صورة Gemini ('+status+'): '+detail};
   }
   const data=await response.json().catch(()=>({}));
   const part=(data?.candidates?.[0]?.content?.parts||[]).find(p=>(p.inlineData||p.inline_data)?.data);
   const inline=part?.inlineData||part?.inline_data;
   const mime=String(inline?.mimeType||inline?.mime_type||'').toLowerCase();
   const base64=inline?.data;
   if(typeof base64==='string'&&/^image\/(?:png|jpeg|webp)$/.test(mime)&&/^[a-zA-Z0-9+/=]+$/.test(base64)&&base64.length>1000){
     if(base64.length>13*1024*1024)return {ok:false,error:'صورة Gemini كبيرة جدًا للتخزين. أعد التوليد.'};
     return {ok:true,image:{base64,mime,model,alt:'3D Omani illustration of '+subject+' — '+lesson}};
   }
   return {ok:false,error:'لم يرجع نموذج Gemini صورة فعلية. لم أستخدم رسم SVG بديلًا.'};
  }
  return {ok:false,error:'لا يتوفر نموذج توليد صور Gemini لهذا المفتاح.'};
 })();
});
