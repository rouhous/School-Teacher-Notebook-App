/* Independent, offline-first SCORM 1.2 learning quest generator.
 * Gemini supplies structured learning content and a genuine rendered image, never AI-authored executable code.
 * No remote dependencies; all student text is inserted with textContent.
 * SCORM publishing still requires verifying the real Noor class and form. */
(function(root){'use strict';
 const escXML=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
 const toNumber=n=>Number.isInteger(n)?n:Number(n);
 const clip=(v,max=300)=>String(v??'').trim().slice(0,max);
 function normalize(raw){
  const questions=Array.isArray(raw)?raw:(raw?.questions||raw?.data?.questions||[]);
  if(!Array.isArray(questions)||questions.length<1||questions.length>40)throw Error('SCORM: عدد التحديات يجب أن يكون بين 1 و40.');
  return questions.map((x,i)=>{
   const type=clip(x?.type||'mcq',20).toLowerCase();
   const question=clip(x?.question||x?.stem,800);
   const common={type,question,hint:clip(x?.hint,190),explanation:clip(x?.explanation,500)};
   if(!question)throw Error('SCORM: التحدي '+(i+1)+' بلا سؤال واضح.');
   if(type==='mcq'||type==='truefalse'){
    const options=type==='truefalse'?['True','False']:(Array.isArray(x.options)?x.options.map(y=>clip(y,250)):[]);
    let correct=toNumber(x.correct);
    if(type==='truefalse'&&typeof x.correct==='boolean')correct=x.correct?0:1;
    if(!Number.isInteger(correct)&&type==='mcq')correct=options.indexOf(clip(x.answer));
    if(options.length!==(type==='mcq'?4:2)||options.some(y=>!y)||!Number.isInteger(correct)||correct<0||correct>=options.length)
      throw Error('SCORM: خيارات أو إجابة التحدي '+(i+1)+' غير صالحة.');
    if(new Set(options).size!==options.length)throw Error('SCORM: خيارات مكررة في التحدي '+(i+1));
    return {...common,options,correct};
   }
   if(type==='order'){
    const items=Array.isArray(x.items)?x.items.map(y=>clip(y,180)):[];
    if(items.length<3||items.length>6||items.some(y=>!y)||new Set(items).size!==items.length)
      throw Error('SCORM: ترتيب التحدي '+(i+1)+' يحتاج 3-6 خطوات مختلفة.');
    return {...common,items};
   }
   if(type==='match'){
    const pairs=Array.isArray(x.pairs)?x.pairs.map(p=>({left:clip(p?.left,110),right:clip(p?.right,180)})):[];
    if(pairs.length<3||pairs.length>5||pairs.some(p=>!p.left||!p.right)||new Set(pairs.map(p=>p.left)).size!==pairs.length||new Set(pairs.map(p=>p.right)).size!==pairs.length)
      throw Error('SCORM: التوصيل في التحدي '+(i+1)+' يحتاج 3-5 أزواج واضحة وغير مكررة.');
    return {...common,pairs};
   }
   throw Error('SCORM: نوع التحدي '+(i+1)+' غير مدعوم: '+type);
  });
 }
 function zip(entries){
  const encoder=new TextEncoder(),local=[],central=[];let offset=0;
  const b16=n=>[n&255,(n>>>8)&255],b32=n=>[n&255,(n>>>8)&255,(n>>>16)&255,(n>>>24)&255];
  const table=Array.from({length:256},(_,a)=>{let x=a;for(let i=0;i<8;i++)x=(x&1)?(0xedb88320^(x>>>1)):(x>>>1);return x>>>0;});
  const crc=bytes=>{let c=0xffffffff;for(const b of bytes)c=table[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0;};
  for(const [name,body] of entries){
   const n=encoder.encode(name),data=body instanceof Uint8Array?body:encoder.encode(body),sum=crc(data),len=data.length;
   const l=new Uint8Array([...b32(0x04034b50),...b16(20),...b16(0x800),...b16(0),...b16(0),...b16(0),...b32(sum),...b32(len),...b32(len),...b16(n.length),...b16(0),...n]);
   local.push(l,data);
   central.push(new Uint8Array([...b32(0x02014b50),...b16(20),...b16(20),...b16(0x800),...b16(0),...b16(0),...b16(0),...b32(sum),...b32(len),...b32(len),...b16(n.length),...b16(0),...b16(0),...b16(0),...b16(0),...b32(0),...b32(offset),...n]));
   offset+=l.length+len;
  }
  const size=central.reduce((s,b)=>s+b.length,0);
  const end=new Uint8Array([...b32(0x06054b50),...b16(0),...b16(0),...b16(central.length),...b16(central.length),...b32(size),...b32(offset),...b16(0)]);
  return new Blob([...local,...central,end],{type:'application/zip'});
 }
 const themeCSS=String.raw`
 :root{--sea:#075f5c;--deep:#063f47;--teal:#03a6a0;--gold:#ebbe63;--sand:#fff6dc;--paper:#fffdf7;--ink:#173c3e;--grey:#627b7a;--danger:#a53434;color-scheme:light}
 *{box-sizing:border-box}body{margin:0;font:clamp(15px,2vw,18px)/1.55 system-ui,'Segoe UI',Arial,sans-serif;background:#e6f4f2;color:var(--ink)}
 body:before{content:'';position:fixed;inset:0;background:radial-gradient(ellipse at 8% 9%,#a6e7df 0,transparent 42%),linear-gradient(160deg,#c5efe8,#ffefd0 73%);z-index:-1}
 main{max-width:850px;margin:auto;padding:12px 14px 42px}header{position:relative;background:linear-gradient(120deg,#074954,#098a82);color:white;border-radius:0 0 24px 24px;padding:15px 19px 0;overflow:hidden;box-shadow:0 9px 22px #164d4940}
 .brand{font-size:12px;color:#ffe1a0;letter-spacing:.07em;font-weight:800}.hero{display:flex;gap:10px;align-items:center;justify-content:space-between}.hero h1{font-size:clamp(20px,4.4vw,33px);margin:5px 0}.hero p{font-size:13px;margin:2px 0 12px;opacity:.96}.hero-art{width:min(48%,350px);flex:none;aspect-ratio:16/9;max-height:235px;object-fit:cover;border-radius:16px;box-shadow:0 8px 22px #062f3b45;border:2px solid #ffffff8a}
 .chip{display:inline-block;background:#fff4d4;color:#6e4b18;border-radius:99px;padding:3px 12px;font-size:12px;font-weight:800;margin:2px 5px 3px 0}
 .card{background:var(--paper);border:1px solid #d4e6de;border-radius:21px;padding:clamp(16px,4vw,28px);margin-top:15px;box-shadow:0 10px 25px #06474916}h2{font-size:clamp(20px,3.6vw,26px);margin:6px 0 12px}h3{font-size:18px;margin:10px 0}p{margin:8px 0 12px}.muted{color:var(--grey)}
 .primary,.secondary,.choice,.chip-button{font:inherit;cursor:pointer;border-radius:13px;padding:13px 16px;min-height:48px;border:2px solid transparent;font-weight:700}
 .primary{background:var(--sea);color:white}.secondary{background:#f0f9f6;color:var(--sea);border-color:#a6d0c0}.primary:focus-visible,.secondary:focus-visible,.choice:focus-visible,.chip-button:focus-visible,select:focus-visible{outline:3px solid #e1a83b;outline-offset:2px}
 button:disabled{opacity:.64;cursor:default}.choices{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:9px}.choice{background:#f4fbf8;text-align:start;color:var(--ink);border-color:#d5e7e1;transition:transform .14s}.choice:not(:disabled):active{transform:scale(.98)}
 .choice.correct{background:#daf5df;border-color:#1c9e52}.choice.wrong{background:#fff0e9;border-color:#ce7050}.step-dot{display:inline-flex;width:30px;height:30px;border-radius:50%;background:var(--gold);color:#533b13;align-items:center;justify-content:center;margin-inline-end:8px;font-size:14px}
 .bar{height:11px;background:#d8eae4;border-radius:10px;overflow:hidden;margin:10px 0 7px}.bar>span{display:block;height:100%;background:linear-gradient(90deg,#0f9b91,#e9b64e);width:0;transition:width .2s}
 .hud{display:flex;justify-content:space-between;gap:8px;flex-wrap:wrap;font-weight:700;font-size:13px}.note{font-size:14px;color:var(--grey)}.feedback{padding:12px 15px;border-radius:12px;background:#eff7e8;border:1px solid #b9d59f;margin:12px 0}.feedback.bad{background:#fff2ea;border-color:#e5c2a3}
 .stack{display:flex;gap:8px;flex-wrap:wrap;min-height:48px;padding:10px;border:2px dashed #a8c8bc;border-radius:13px;background:#f5faf6;margin:10px 0}.chip-button{padding:9px 12px;border-color:#93c5b2;background:#fff}.pair{display:grid;grid-template-columns:minmax(90px,1fr) minmax(140px,1fr);gap:10px;align-items:center;margin:11px 0}.pair select{width:100%;font:inherit;padding:10px;border:1px solid #88bbad;border-radius:10px;background:white}
 .hidden,[hidden]{display:none!important}.action-row{display:flex;gap:9px;flex-wrap:wrap;margin-top:16px}.action-row>*{flex:1}.mission{background:#fff6dd;border-inline-start:5px solid #d5a046;padding:13px 17px;border-radius:9px;margin:16px 0}.objective{padding:5px 0}.score{font-size:clamp(26px,5vw,41px);font-weight:900;color:var(--sea)}.sparkle{font-size:30px;color:#d4a335}footer{text-align:center;color:#557773;padding:15px;font-size:12px}
 @media(max-width:480px){main{padding:7px 10px 30px}header{padding:11px 12px 10px}.hero{flex-direction:column;align-items:stretch}.hero-art{width:100%;max-height:none}.pair{grid-template-columns:1fr}.choices{grid-template-columns:1fr}.action-row>*{flex-basis:100%}}
 @media(prefers-reduced-motion:reduce){*{transition:none!important;animation:none!important}}
 `;
 const runtime=String.raw`(function(){'use strict';
 const data=window.NOOR_SCORM_DATA,el=id=>document.getElementById(id);
 const $=id=>el(id),ui=data.ui,questions=data.questions;
 let index=0,score=0,answered=false,finished=false,api=null,apiStarted=false;
 function set(id,text){$(id).textContent=text;}
 for(let w=window,i=0;i<12;i++){try{if(w.API){api=w.API;break}if(w.parent===w)break;w=w.parent}catch(_){break}}
 if(!api&&window.opener){try{api=window.opener.API||null}catch(_){}}
 try{if(api){apiStarted=String(api.LMSInitialize(''))!=='false';}}catch(_){apiStarted=false}
 function report(done){if(!apiStarted)return;try{
  api.LMSSetValue('cmi.core.score.raw',String(Math.round(100*score/questions.length)));
  api.LMSSetValue('cmi.core.score.min','0');api.LMSSetValue('cmi.core.score.max','100');
  api.LMSSetValue('cmi.core.lesson_status',done?'completed':'incomplete');api.LMSCommit('');
 }catch(_){}}
 function finishApi(){if(!apiStarted)return;try{api.LMSFinish('')}catch(_){}apiStarted=false;}
 function show(which){['intro','game','results'].forEach(id=>$(id).hidden=id!==which)}
 function shuffle(ids){for(let i=ids.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[ids[i],ids[j]]=[ids[j],ids[i]];}if(ids.length>1&&ids.every((v,i)=>v===i))ids.reverse();return ids;}
 function button(label,clicked,cls='choice'){const b=document.createElement('button');b.type='button';b.className=cls;b.textContent=label;b.addEventListener('click',clicked);return b;}
 function accepted(ok,answerText=''){
  if(answered)return;answered=true;if(ok)score++;
  $('next').hidden=false;$('hint').hidden=true;
  const f=$('feedback');f.hidden=false;f.className='feedback'+(ok?'':' bad');
  f.textContent=(ok?ui.correct:ui.tryAgain)+(answerText?(ui.correctAnswer+' '+answerText+'. '):' ')+questions[index].explanation;
  $('score').textContent=ui.stars+' '+score;report(false);
 }
 function choiceQuestion(q){
  const wrap=$('choices');const options=q.type==='truefalse'?ui.truthLabels:q.options;
  options.forEach((opt,i)=>{const b=button((q.type==='mcq'?String.fromCharCode(65+i)+'. ':'')+opt,()=>{
    if(answered)return;for(const x of wrap.querySelectorAll('button'))x.disabled=true;
    b.classList.add(i===q.correct?'correct':'wrong');accepted(i===q.correct,i===q.correct?'':options[q.correct]);
  });wrap.append(b)});
 }
 function orderQuestion(q){
  const wrap=$('choices'),picked=$('work');let chosen=[];
  const shuffled=shuffle(q.items.map((_,i)=>i));const panel=document.createElement('div');panel.className='stack';wrap.append(panel);
  const draw=()=>{panel.replaceChildren();picked.replaceChildren();shuffled.filter(i=>!chosen.includes(i)).forEach(i=>panel.append(button(q.items[i],()=>{if(answered)return;chosen.push(i);draw();},'chip-button')));
   chosen.forEach((id,j)=>picked.append(button((j+1)+'. '+q.items[id],()=>{if(answered)return;chosen.splice(j,1);draw();},'chip-button')));
  };draw();
  const check=button(ui.check,()=>{if(answered||chosen.length!==q.items.length)return;accepted(chosen.every((id,i)=>id===i),q.items.join(' → '));},'primary');
  const reset=button(ui.reset,()=>{if(!answered){chosen=[];draw()}},'secondary');
  const row=document.createElement('div');row.className='action-row';row.append(check,reset);$('questionActions').append(row);
 }
 function matchQuestion(q){
  const wrap=$('choices'),rightOrder=shuffle(q.pairs.map((_,i)=>i)),selects=[];
  q.pairs.forEach((p,i)=>{const row=document.createElement('label');row.className='pair';const left=document.createElement('strong');left.textContent=p.left;const select=document.createElement('select');
    const start=document.createElement('option');start.value='';start.textContent=ui.choose;select.append(start);
    rightOrder.forEach(j=>{const opt=document.createElement('option');opt.value=String(j);opt.textContent=q.pairs[j].right;select.append(opt)});
    row.append(left,select);wrap.append(row);selects.push(select);
  });
  $('questionActions').append(button(ui.check,()=>{if(answered)return;const values=selects.map(x=>x.value);
   if(values.some(x=>x==='')||new Set(values).size!==values.length){$('feedback').hidden=false;$('feedback').textContent=ui.useEach;return}
   selects.forEach(x=>x.disabled=true);accepted(values.every((x,i)=>Number(x)===i),q.pairs.map(p=>p.left+' — '+p.right).join('; '));
  },'primary'));
 }
 function render(){answered=false;show('game');$('feedback').hidden=true;$('feedback').textContent='';$('next').hidden=true;
  $('work').replaceChildren();$('choices').replaceChildren();$('questionActions').replaceChildren();const q=questions[index];$('work').hidden=q.type!=='order';
  set('question',q.question);set('kind',({mcq:ui.mcq,truefalse:ui.truefalse,order:ui.order,match:ui.match})[q.type]||q.type);
  const n=questions.length;set('progress',String(index+1)+' / '+n);
  const stage=Math.min(3,Math.floor(index*3/n)+1);set('stage',ui.stages[stage-1]);
  $('bar').style.width=Math.round((index/n)*100)+'%';
  $('hint').hidden=!q.hint;$('hint').textContent=ui.hint;$('hintText').hidden=true;$('hintText').textContent=q.hint;
  if(q.type==='mcq'||q.type==='truefalse')choiceQuestion(q);
  if(q.type==='order')orderQuestion(q);
  if(q.type==='match')matchQuestion(q);
 }
 function end(){finished=true;report(true);finishApi();show('results');set('finalScore',String(Math.round(100*score/questions.length))+'%');
  set('scoreText',score+' / '+questions.length);$('bar').style.width='100%';
  set('achievement',score/questions.length>=.8?ui.highAchievement:ui.keepLearning);
 }
 $('start').onclick=()=>{index=0;score=0;finished=false;set('score',ui.stars+' 0');render()};
 $('next').onclick=()=>{if(!answered)return;index++;index<questions.length?render():end()};
 $('hint').onclick=()=>{$('hintText').hidden=!$('hintText').hidden};
 $('restart').onclick=()=>{index=0;score=0;finished=false;render()};
 set('title',data.title);set('heading',data.title);set('subject',data.subject+' · '+ui.grade+' '+data.grade);
 set('unit',data.unit);set('lesson',data.lesson);set('introText',data.intro);set('mission',data.mission);
 (data.objectives||[]).forEach(o=>{const li=document.createElement('li');li.className='objective';li.textContent=o;$('objectives').append(li)});
 set('start',ui.start);set('next',ui.next);set('restart',ui.retry);set('tagline',ui.tagline);
 window.addEventListener('pagehide',()=>{if(!finished)report(false);finishApi()});
 report(false);show('intro');
 })();`;
 // A generated scene is a real raster image embedded offline in the SCORM ZIP.
 // Do not substitute the old flat decorative SVG when Gemini has not generated one.
 function educationalSVG(meta){
  const subject=String(meta?.subject||''),lesson=String(meta?.lesson||'');
  const topic=(subject+' '+lesson).toLowerCase();
  const science=/(علوم|science|كائنات|خلايا|طاقة|ذرات|كيمياء|فيزياء|biology|cells|energy|physics)/i.test(topic);
  const math=/(رياضيات|math|geometry|عدد|numbers|قياس|مساحة)/i.test(topic);
  const language=/(انجليزي|إنجليزي|عربية|english|language|reading|writing|قراءة|كتابة|لغة)/i.test(topic);
  const history=/(اجتماع|تاريخ|حضارة|جغرافيا|history|geography|social)/i.test(topic);
  const emblem=science?'<circle cx="480" cy="230" r="108" fill="#e7f6ff" stroke="#1e8090" stroke-width="12"/><circle cx="480" cy="230" r="50" fill="#77cdc6"/><circle cx="444" cy="205" r="17" fill="#ffdd9f"/><circle cx="516" cy="258" r="20" fill="#ffdd9f"/><circle cx="518" cy="192" r="12" fill="#ffdd9f"/>':
   math?'<polygon points="425,137 565,355 340,355" fill="#7bd7bd" stroke="#256e74" stroke-width="12"/><circle cx="585" cy="239" r="70" fill="#f8d795" stroke="#cc8850" stroke-width="11"/>':
   history?'<circle cx="480" cy="236" r="104" fill="#b8e6d8" stroke="#217b7a" stroke-width="12"/><path d="M395 220Q480 145 565 220M395 260Q480 330 565 260M480 135V338M375 238H585" fill="none" stroke="#358b7c" stroke-width="8"/>':
   language?'<path d="M310 175Q397 135 480 178Q563 135 650 175V358Q566 330 480 376Q394 330 310 358Z" fill="#fff8e8" stroke="#347977" stroke-width="12"/><path d="M480 178V376M340 225Q405 202 458 235M502 235Q555 202 620 225M340 267Q405 245 458 276M502 276Q555 245 620 267" stroke="#71aea4" stroke-width="8" fill="none"/>':
   '<path d="M310 175Q397 135 480 178Q563 135 650 175V358Q566 330 480 376Q394 330 310 358Z" fill="#fff8e8" stroke="#347977" stroke-width="12"/><path d="M480 178V376" stroke="#347977" stroke-width="10"/>';
  return '<svg xmlns="http://www.w3.org/2000/svg" width="960" height="540" viewBox="0 0 960 540" role="img" aria-label="Educational illustration">'+
   '<defs><linearGradient id="bg" x2="1" y2="1"><stop stop-color="#e1f7f0"/><stop offset="1" stop-color="#fce9bd"/></linearGradient></defs>'+
   '<rect width="960" height="540" fill="url(#bg)"/><path d="M0 434Q245 375 480 443T960 432V540H0Z" fill="#a8d8ce"/>'+
   '<circle cx="803" cy="104" r="47" fill="#ffd37d" opacity=".7"/><circle cx="177" cy="112" r="23" fill="#ffffff" opacity=".75"/>'+
   '<rect x="260" y="105" width="440" height="334" rx="44" fill="#ffffff" opacity=".75"/>'+emblem+'</svg>';
 }
 function sceneImage(raw,meta){
  const v=raw?.image;if(!v)return null;
  if(v.kind==='svg-fallback')return {filename:'omani-lesson-scene.svg',bytes:new TextEncoder().encode(educationalSVG(meta)),
    alt:'رسم SVG تعليمي مرتبط بالمادة، غير مولّد بالذكاء الاصطناعي'};
  const mime=String(v.mime||'').toLowerCase();
  if(!/^image\/(?:png|jpeg|webp)$/.test(mime)||typeof v.base64!=='string'||v.base64.length>5*1024*1024||!v.base64.length)
   throw Error('SCORM: صورة Gemini غير صالحة أو كبيرة جدًا.');
  const binary=atob(v.base64),bytes=new Uint8Array(binary.length);
  for(let i=0;i<binary.length;i++)bytes[i]=binary.charCodeAt(i);
  const ext=mime==='image/jpeg'?'jpg':mime==='image/webp'?'webp':'png';
  return {filename:'omani-lesson-scene.'+ext,bytes,alt:clip(v.alt||'Omani 3D educational scene',160)};
 }
 function create(title,content,meta={}){
  const raw=(!Array.isArray(content)&&content&&typeof content==='object')?content:{questions:content};
  const scene=sceneImage(raw,meta);
  const art=scene?'<img class="hero-art" src="'+scene.filename+'" alt="'+escXML(scene.alt)+'">':'';
  const questions=normalize(raw);
  const subject=clip(meta.subject||raw.subject,90),grade=clip(meta.grade||raw.grade,18);
  const unit=clip(meta.unit||raw.unit,130),lesson=clip(meta.lesson||raw.lesson,155);
  const isArabic=/[\u0600-\u06ff]/.test((raw.questions||[]).map(q=>q.question).join(' ').slice(0,120)) && !/(english|اللغة\s*الانجليزية|اللغة\s*الإنجليزية)/i.test(subject);
  const ui=isArabic?{
   tagline:'مغامرة المعرفة العُمانية',grade:'الصف',start:'ابدأ المغامرة',next:'التحدي التالي',retry:'أعد المحاولة',stars:'⭐',truthLabels:['صح','خطأ'],
   correct:'ممتاز! ',tryAgain:'حاول مجددًا في التحدي القادم. ',correctAnswer:'الإجابة الصحيحة:',hint:'💡 تلميح',
   check:'تحقق من الإجابة',reset:'إعادة الترتيب',choose:'اختر المطابقة',useEach:'اختر إجابة مختلفة لكل عنصر.',
   mcq:'اختر الإجابة',truefalse:'صح أم خطأ',order:'رتّب الخطوات',match:'وصّل العناصر',
   stages:['اكتشف','تدرّب','تحدَّ نفسك'],highAchievement:'إنجاز رائع! 🏅',keepLearning:'مغامرة رائعة، واصل التدريب!'
  }:{
   tagline:'An Omani learning adventure',grade:'Grade',start:'Start the adventure',next:'Next challenge',retry:'Play again',stars:'⭐',truthLabels:['True','False'],
   correct:'Excellent! ',tryAgain:'Keep trying. ',correctAnswer:'Correct answer:',hint:'💡 Hint',
   check:'Check answer',reset:'Reset order',choose:'Choose a match',useEach:'Choose a different match for each item.',
   mcq:'Choose',truefalse:'True or false',order:'Put in order',match:'Match the pairs',
   stages:['Explore','Practice','Challenge'],highAchievement:'Amazing achievement! 🏅',keepLearning:'Great adventure — keep practicing!'
  };
  const data={title:clip(title||raw.title||'Omani Learning Quest',160),subject,grade,unit,lesson,
   intro:clip(raw.intro||raw.description||(isArabic?'اكتشف الدرس من خلال أنشطة متنوعة وتحديات ممتعة.':'Explore this lesson with interactive activities and challenges.'),350),
   mission:clip(raw.mission||(isArabic?'اجمع النجوم واجتز التحديات الثلاثة!':'Earn stars and complete all three stages!'),200),
   objectives:Array.isArray(raw.objectives)?raw.objectives.slice(0,4).map(v=>clip(v,140)).filter(Boolean):[],questions,ui};
  const manifest=`<?xml version="1.0" encoding="UTF-8"?>\n<manifest identifier="NOOR_OMANI_QUEST_SCORM_12" version="1.0" xmlns="http://www.imsproject.org/xsd/imscp_rootv1p1p2" xmlns:adlcp="http://www.adlnet.org/xsd/adlcp_rootv1p2"><metadata><schema>ADL SCORM</schema><schemaversion>1.2</schemaversion></metadata><organizations default="ORG"><organization identifier="ORG"><title>${escXML(data.title)}</title><item identifier="ITEM" identifierref="SCO"><title>${escXML(data.title)}</title></item></organization></organizations><resources><resource identifier="SCO" type="webcontent" adlcp:scormtype="sco" href="index.html"><file href="index.html"/><file href="questions.js"/><file href="runtime.js"/><file href="theme.css"/>${scene?'<file href="'+scene.filename+'"/>':''}</resource></resources></manifest>`;
  const html=`<!doctype html><html lang="${isArabic?'ar':'en'}" dir="${isArabic?'rtl':'ltr'}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="light"><title>${escXML(data.title)}</title><link rel="stylesheet" href="theme.css"></head><body>
 <main><header><div class="brand" id="tagline"></div><div class="hero"><div><h1 id="heading"></h1><p id="subject"></p><span class="chip" id="unit"></span><span class="chip" id="lesson"></span></div>${art}</div></header>
 <section class="card" id="intro"><h2 id="title"></h2><p id="introText"></p><div class="mission" id="mission"></div><ul id="objectives"></ul><button class="primary" id="start" type="button"></button></section>
 <section class="card" id="game" hidden><div class="hud"><span id="stage"></span><span id="progress"></span><span id="score">⭐ 0</span></div><div class="bar" aria-hidden="true"><span id="bar"></span></div><p class="muted" id="kind"></p><h2 id="question"></h2><div class="choices" id="choices"></div><div class="stack" id="work" hidden></div><div id="questionActions"></div><button class="secondary" id="hint" type="button" hidden></button><p id="hintText" class="note" hidden></p><p id="feedback" role="status" aria-live="polite" hidden></p><div class="action-row"><button class="primary" id="next" type="button" hidden></button></div></section>
 <section class="card" id="results" hidden><div class="sparkle" aria-hidden="true">🌟🏅🌟</div><h2 id="achievement"></h2><div class="score" id="finalScore"></div><p id="scoreText"></p><button class="primary" id="restart" type="button"></button></section>
 <footer>School Teacher Notebook · Oman · SCORM 1.2 · Offline learning activity</footer></main><script src="questions.js"></script><script src="runtime.js"></script></body></html>`;
  const embedded='window.NOOR_SCORM_DATA='+JSON.stringify(data).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029')+';';
  return zip([['imsmanifest.xml',manifest],['index.html',html],['theme.css',themeCSS],['questions.js',embedded],['runtime.js',runtime],...(scene?[[scene.filename,scene.bytes]]:[])]);
 }
 function hasManifest(buffer){
  const zip=new DataView(buffer);
  const manifestName='imsmanifest.xml';
  // Look for a root manifest in the ZIP directory. A nested ZIP or a stray
  // reference to imsmanifest.xml in document text does not identify a package.
  for(let end=zip.byteLength-22;end>=Math.max(0,zip.byteLength-65557);end--){
   if(zip.getUint32(end,true)!==0x06054b50||end+22+zip.getUint16(end+20,true)!==zip.byteLength)continue;
   if(zip.getUint16(end+4,true)||zip.getUint16(end+6,true))return false;
   const start=zip.getUint32(end+16,true),size=zip.getUint32(end+12,true);
   if(start+size>end)return false;
   const limit=start+size,entries=zip.getUint16(end+10,true);
   let cursor=start;
   let manifest=false;
   for(let entry=0;entry<entries;entry++){
    if(cursor+46>limit||zip.getUint32(cursor,true)!==0x02014b50)return false;
    const length=zip.getUint16(cursor+28,true);
    const next=cursor+46+length+zip.getUint16(cursor+30,true)+zip.getUint16(cursor+32,true);
    if(next>limit)return false;
    if(length===manifestName.length){
     const name=new Uint8Array(buffer,cursor+46,length);
     if(new TextDecoder().decode(name).toLowerCase()===manifestName)manifest=true;
    }
    cursor=next;
   }
   return manifest;
  }
  return false;
 }

 root.NoorScorm=Object.freeze({create,normalize,hasManifest});
})(typeof globalThis==='object'?globalThis:this);
