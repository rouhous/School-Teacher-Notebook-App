/* Noor Unified 2.8.43: optional official lesson-list evidence.
 * Reads the existing teacher-facing lesson picker, never another class or a
 * guessed server endpoint. A missing tree is normal for some subjects. */
(function(root){'use strict';
 const norm=s=>String(s||'').normalize('NFKC').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632))
  .replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776)).replace(/[\u064b-\u065f\u0640]/g,'')
  .replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/\s+/g,' ').trim().toLowerCase();
 const clean=s=>String(s||'').replace(/\s+/g,' ').trim();
 const code=s=>{const m=norm(s).match(/(?:^|\s)(\d{1,2})\s*[-–.]\s*(\d{1,2})(?=\s|$)/);return m?{unit:Number(m[1]),lesson:Number(m[2])}:null};
 const trimCode=s=>clean(s).replace(/^\s*[0-9٠-٩۰-۹]{1,2}\s*[-–.]\s*[0-9٠-٩۰-۹]{1,2}\s*/, '').trim();
 const specific=s=>norm(trimCode(s));
 function match(actual,request,unit){
  if(!actual||!request)return false;
  const a=code(actual),r=code(request),un=root.NoorLessonNumbers?.number?.(unit,'unit');
  if(r&&a)return a.unit===r.unit&&a.lesson===r.lesson;
  if(a&&/^\s*[0-9٠-٩۰-۹]{1,2}\s*$/.test(request)&&un!==null&&un!==undefined)
    return a.unit===un&&a.lesson===Number(norm(request));
  if(specific(actual)===specific(request)){
   if(a&&un!==null&&un!==undefined&&a.unit!==un)return false;
   return specific(actual).length>2;
  }
  return false;
 }
 function labelFor(el){
  const texts=[el?.id,el?.name,el?.getAttribute?.('aria-label'),el?.getAttribute?.('placeholder')];
  if(el?.labels)for(const label of el.labels)texts.push(label.textContent);
  if(el?.id)for(const label of document.querySelectorAll('label[for]')){
   if(label.htmlFor===el.id)texts.push(label.textContent);
  }
  for(const node of [el?.closest?.('.form-group,.form-field,.input-group,.form-row'),el?.parentElement]){
   if(!node)continue;
   const labels=[...node.querySelectorAll('label,.control-label,.field-label')];
   if(labels.length===1)texts.push(labels[0].textContent);
  }
  return norm(texts.filter(Boolean).join(' '));
 }
 function isLessonControl(el){return /(?:^|[^\p{L}])(الدروس|درس|الدرس|lessons?|lesson_ids?)(?:$|[^\p{L}])/iu.test(labelFor(el));}
 function selectedUnit(doc){
  const matching=[...doc.querySelectorAll('select,input:not([type=hidden])')].filter(el=>
   !el.closest?.('#stnNoorHub,#noor-smart-activities-root')&&/الوحده|unit|theme/i.test(labelFor(el)));
  if(matching.length!==1)return '';
  const control=matching[0];return clean(control.tagName==='SELECT'?(control.selectedOptions?.[0]?.textContent||''):control.value);
 }
 function scan(doc){
  if(!doc?.querySelectorAll)return {options:[],selected:null,hasList:false};
  const found=[],groups=[];let sourceCount=0;
  const unit=selectedUnit(doc);
  for(const select of doc.querySelectorAll('select')){
   if(select.disabled||select.closest?.('#stnNoorHub,#noor-smart-activities-root,#noor-prep-panel')||!isLessonControl(select))continue;
   sourceCount++;
   for(const option of select.options||[]){
    if(option.disabled||!String(option.value||'').trim())continue;
    const title=clean(option.textContent);
    if(title.length<4||title.length>180||/^(اختر|select|please|كل الدروس)/i.test(title))continue;
    const pair=code(title);
    const fromGroup=clean(option.closest?.('optgroup')?.label||'');
    const grouping=fromGroup||unit||(pair?'الوحدة '+pair.unit:'دروس المادة');
    found.push({title,unit:grouping,unitNumber:pair?.unit||null,selected:!!option.selected,
      origin:'noor-select',control:select.id||select.name||'',optionValue:String(option.value)});
   }
  }
  // Noor also uses readonly/Select2 text fields with a selected value.
  if(sourceCount===0){
   const inputs=[...doc.querySelectorAll('input:not([type=hidden]),[role="combobox"]')].filter(el=>
    !el.disabled&&!el.closest?.('#stnNoorHub,#noor-smart-activities-root,#noor-prep-panel')&&isLessonControl(el));
   for(const input of inputs){
    const value=clean(input.value||input.getAttribute?.('aria-valuetext')||'');
    if(value.length<4||value.length>180||/^(اختر|select|please)/i.test(value))continue;
    const pair=code(value);
    found.push({title:value,unit:unit||(pair?'الوحدة '+pair.unit:'دروس المادة'),unitNumber:pair?.unit||null,
     selected:true,origin:'noor-control',control:input.id||input.name||'',optionValue:value});
   }
  }
  const unique=new Map();for(const entry of found){const key=norm(entry.unit)+'|'+norm(entry.title)+'|'+entry.control+'|'+entry.optionValue;
   const prev=unique.get(key);if(!prev)unique.set(key,{...entry});else if(entry.selected)prev.selected=true;
  }
  const options=[...unique.values()];const sel=options.filter(x=>x.selected);
  return {options,selected:sel.length===1?sel[0]:null,ambiguous:sel.length>1,hasList:sourceCount>0||options.length>0,unit};
 }
 function resolveFromList(view,{unit,lesson,manualSelection}={}){
  const options=view?.options||[];
  const chosen=manualSelection?.source==='form'
   ?options.filter(x=>norm(x.title)===norm(manualSelection.title)&&norm(x.unit)===norm(manualSelection.unit))
   :options.filter(x=>match(x.title,lesson,unit));
  if(chosen.length!==1)return {ok:false,reason:chosen.length?'ambiguous':'not_found'};
  const entry=chosen[0],pair=code(entry.title);
  // The teacher must have selected this entry in Noor (automatic), or must
  // explicitly choose the unique entry through the add-on's manual picker.
  if(manualSelection?.source!=='form'&&!entry.selected)return {ok:false,reason:'not_selected'};
  if(!manualSelection&&view.ambiguous)return {ok:false,reason:'ambiguous'};
  if(pair){const requested=root.NoorLessonNumbers?.number?.(unit,'unit');if(requested!==null&&requested!==undefined&&pair.unit!==requested)
    return {ok:false,reason:'unit_mismatch'};}
  return {ok:true,unit:entry.unit,title:entry.title,source:'form',lessonEvidence:{source:'form',title:entry.title,
     unit:entry.unit,selected:entry.selected,teacherChosen:manualSelection?.source==='form',observedAt:Date.now()}};
 }
 root.NoorLessonEvidence=Object.freeze({norm,code,match,scan,resolveFromList});
})(typeof globalThis==='object'?globalThis:this);
