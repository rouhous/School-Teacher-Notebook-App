/* The native Noor bulk form adds one editable table row per selected item type. */
(function(root){
 'use strict';
 const labels={
  mcq:/^(?:متعدد الاختيارات|متعدد الخيارات|multiple choice)$/,
  true_false:/^(?:صح\s*\/?\s*خطا|true\s*\/?\s*false)$/,
  essay:/^(?:اضافه )?(?:مفرده )?(?:مقاليه|essay)$/,
  short_text:/^(?:اضافه )?(?:مفرده )?(?:مقاليه|essay)$/,
  fill_blanks:/^(?:املا|ملء) الفراغات$|^fill in the blanks$/,
  multi_select:/^(?:مفرده )?متعدد(?:ه)? الاجابات$|^multiple (?:correct )?answers$/
 };
 const normalize=text=>String(text??'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/[\u064b-\u065f]/g,'').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776)).replace(/^[+＋\s]+|[+＋\s]+$/g,'').replace(/\s+/g,' ').toLowerCase();
 const visible=el=>el.getClientRects().length&&!el.disabled;
 const controls='button,a,[role="button"],input[type="submit"],input[type="button"]';
 const actions=(scope,re)=>[...scope.querySelectorAll(controls)].filter(x=>visible(x)&&!x.closest('#stnNoorHub')&&[x.textContent,x.value,x.getAttribute('aria-label')].some(v=>re.test(normalize(v))));
 const only=items=>items.length===1?items[0]:null;
 const open=()=>only(actions(document,/^اضافه مجموعه مفردات دفعه واحده$|^add (?:a group of |multiple |bulk )?(?:items|questions)(?: at once)?$/));
 const submit=()=>only(actions(document,/^انشاء المفردات$|^create (?:items|questions)$/));
 const supported=questions=>questions.every(q=>labels[q.kind]);
 function grid(){
  return only([...document.querySelectorAll('table')].filter(t=>visible(t)&&/الجواب الصحيح|correct answer/i.test(t.tHead?.textContent||'')&&/النص|text/i.test(t.tHead?.textContent||'')));
 }
 const rows=table=>[...table.tBodies].flatMap(b=>[...b.rows]).filter(r=>[...r.cells].some(c=>c.querySelector('input:not([type="hidden"]),textarea,select,[contenteditable],iframe,button')));
 const delay=ms=>new Promise(resolve=>setTimeout(resolve,ms));
 async function until(get,active){
  for(let i=0;i<25&&active();i++){
   const found=get();if(found)return found;
   await delay(120);
  }
  return null;
 }
 function assign(el,value){
  if(!el||el.disabled||el.readOnly)throw Error('أحد حقول المفردة الجماعية غير متاح.');
  if(el.isContentEditable)el.textContent=String(value);
  else{
   const setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el),'value')?.set;
   if(setter)setter.call(el,String(value));else el.value=String(value);
   if(String(el.value)!==String(value))throw Error('رفض محرر نور قيمة حقل المفردة.');
  }
  for(const e of ['input','change','blur'])el.dispatchEvent(new Event(e,{bubbles:true}));
 }
 function select(el,choices){
  const option=[...(el?.options||[])].find(o=>!o.disabled&&choices.map(normalize).some(v=>v===normalize(o.textContent)||v===normalize(o.value)));
  if(!option)throw Error('أحد خيارات المفردة غير موجود في نموذج المجموعة.');
  assign(el,option.value);
 }
 const editable='input:not([type="hidden"]):not([type="button"]):not([type="submit"]):not([type="checkbox"]):not([type="radio"]),textarea,[contenteditable="true"],iframe';
 function editor(cell){
  const elements=[...(cell?.querySelectorAll(editable)||[])].filter(visible);
  const rich=elements.filter(el=>el.isContentEditable||el.tagName==='IFRAME');
  const chosen=only(rich.length?rich:elements);
  if(chosen?.tagName!=='IFRAME')return chosen;
  try{return chosen.contentDocument?.body?.isContentEditable?chosen.contentDocument.body:null;}catch(_){return null;}
 }
 async function editText(cell,value,active){
  const inline=editor(cell);
  if(inline){assign(inline,value);return;}
  const trigger=only([...(cell?.querySelectorAll('button,a,[role="button"],[onclick]')||[])].filter(visible));
  if(!trigger)throw Error('لم يظهر محرر النص داخل صف المجموعة.');
  const dialogs=()=>[...document.querySelectorAll('.modal,[role="dialog"]')].filter(el=>visible(el)&&!el.closest('#stnNoorHub'));
  const existing=new Set(dialogs());
  trigger.click();
  const dialog=await until(()=>only(dialogs().filter(el=>!existing.has(el))),active);
  if(!dialog)throw Error('لم يظهر محرر نص المفردة بعد فتحه.');
  const field=await until(()=>editor(dialog),active);
  assign(field,value);
  const confirm=only(actions(dialog,/^(?:حفظ|تم|موافق|اعتماد|save|ok|done|apply)$/));
  if(!confirm)throw Error('لم يظهر زر اعتماد النص داخل محرر المفردة.');
  confirm.click();
  if(!await until(()=>!dialogs().includes(dialog),active))throw Error('لم يُغلق محرر نص المفردة بعد الاعتماد.');
 }
 async function fill(questions,active){
  if(!supported(questions))throw Error('تدعم واجهة المجموعة الاختيار المتعدد والصح والخطأ والمقالي والفراغات ومتعدد الإجابات.');
  const table=grid();
  if(!table||!submit())throw Error('لم تظهر حقول إضافة مجموعة مفردات في نور.');
  let current=rows(table);
  if(current.length)throw Error('هناك صفوف مدخلة مسبقًا في نموذج المجموعة. راجعها قبل إعادة المحاولة.');
  for(const q of questions){
   if(!active())throw Error('أُلغيت تعبئة المجموعة.');
   const add=only(actions(document,labels[q.kind]));
   if(!add)throw Error('لم يظهر زر إضافة نوع المفردة '+q.kind+' إلى المجموعة.');
   const before=current.length;
   add.click();
   const row=await until(()=>{current=rows(table);return current.length===before+1?current[before]:null;},active);
   if(!row)throw Error('لم يظهر صف المفردة الجديدة في المجموعة.');
   const columns=[...table.tHead.rows[0].cells].map(c=>normalize(c.textContent));
   const cell=re=>row.cells[columns.findIndex(title=>re.test(title))];
   const prompt=cell(/^(?:النص|نص المفرده|text|question text)$/);
   const points=cell(/^(?:الدرجه|النقاط|score|marks|points)$/);
   const answer=cell(/الجواب الصحيح|الاجابه الصحيحه|correct answer/);
   if(q.options?.length){
    const qty=cell(/عدد (?:الاختيارات|الخيارات|الاختبارات)|number of (?:options|choices)/)?.querySelector('select,input');
    if(qty?.tagName==='SELECT')select(qty,[String(q.options.length)]);
    else if(qty)assign(qty,q.options.length);
    for(const [index,text] of q.options.entries()){
     const digit=index+1;
     const choice=cell(new RegExp('^(?:خيار|اختيار|option|choice) '+digit+'$'));
     await editText(choice,text,active);
    }
   }
   await editText(prompt,q.stem,active);
   assign(editor(points),q.points||1);
   if(q.kind==='mcq'){
    const i=q.options.indexOf(q.answer)+1;
    const selection=answer?.querySelector('select');
    if(selection)select(selection,[String(i),'خيار '+i,'الاختيار '+i,'Option '+i]);
    else assign(editor(answer),i);
   }else if(q.kind==='true_false'){
    select(answer?.querySelector('select'),q.answer===true?['true','صح','صحيح','صواب','1']:['false','خطا','خطأ','0']);
   }else if(q.kind==='multi_select'){
    const choices=[...(answer?.querySelectorAll('input[type="checkbox"]')||[])].filter(visible);
    if(choices.length!==q.options.length)throw Error('خانات الإجابات المتعددة في المجموعة غير واضحة.');
    choices.forEach((el,i)=>{const checked=q.answers.includes(q.options[i]);if(el.checked!==checked)el.click();if(el.checked!==checked)throw Error('تعذر تثبيت الإجابة الصحيحة.');});
   }else if(q.kind==='fill_blanks'){
    const fields=[...(answer?.querySelectorAll('input[type="text"],textarea')||[])].filter(visible);
    if(fields.length!==q.blanks.length)throw Error('خانات إجابات الفراغات في المجموعة غير واضحة.');
    fields.forEach((el,i)=>assign(el,q.blanks[i]));
   }else if(q.answer)assign(editor(answer),q.answer);
  }
  const button=submit();
  if(!button||current.length!==questions.length)throw Error('تعذر التحقق من صفوف المجموعة قبل الإرسال.');
  const form=button.form||table.closest('form');
  if(form?.checkValidity&&!form.checkValidity())throw Error('في نموذج المجموعة حقول مطلوبة. راجع الصفوف قبل الحفظ.');
  return button;
 }
 function error(){
  return [...document.querySelectorAll('.alert-danger,.validation-summary-errors,.field-validation-error,[role="alert"]')]
   .filter(el=>visible(el)&&!el.closest('#stnNoorHub')).map(el=>el.textContent.trim())
   .find(text=>text&&/خط[اأ]|فشل|مطلوب|تعذر|غير صالح|غير مقبول|رفض|failed|error|required|invalid|unsupported/i.test(text))||'';
 }
 root.NoorBulkItems=Object.freeze({open,submit,fill,supported,error});
})(globalThis);
