/* DOM-only Noor automation. Operates in the current teacher session; never calls hidden Noor APIs.
   Fail closed on unknown controls, missing lesson, unsupported question types, or unverified save.
   Designed as an idempotent restartable state machine across full page navigations. */
(()=>{'use strict';
if(window.top!==window)return;
const activityPage=/^\/teacher\/(?:homeworks|questions)(?:\/|$)/i.test(location.pathname)||Boolean(globalThis.NoorBulkItems?.submit());
const KEY='noorSmartRunV1',STOP_KEY='stnNoorStopAll:v1',sleep=ms=>new Promise(r=>setTimeout(r,ms));let busy=false;
const isQuestionsPath=()=>/^\/teacher\/questions(?:\/|$)/i.test(location.pathname);
const clean=v=>String(v??'').replace(/\s+/g,' ').replace(/\*/g,'').trim();
const visible=e=>!!(e&&e.getClientRects().length&&getComputedStyle(e).visibility!=='hidden'&&getComputedStyle(e).display!=='none');
const norm=v=>clean(v).toLowerCase().replace(/[^\p{L}\p{N}]+/gu,'');
const stopReason=(job,reason)=>({...job,active:false,pausedFromStage:job.stage,pausedPath:location.pathname,pausedSearch:location.search,stage:'paused',message:'توقفت التعبئة تلقائيًا: '+reason,pausedAt:Date.now()});
const actionText=e=>clean(e.getAttribute('aria-label')||e.getAttribute('title')||e.textContent||e.value||'');
const exactActions=()=>[...document.querySelectorAll('button,a,input[type="submit"],input[type="button"],[role="button"]')].filter(e=>visible(e)&&!e.disabled&&!e.closest('#noor-smart-activities-root'));
const byText=(words,strict=true)=>{const target=Array.isArray(words)?words:[words];const list=exactActions().filter(el=>target.some(w=>strict?norm(actionText(el))===norm(w):norm(actionText(el)).includes(norm(w))));return list.length===1?list[0]:null};
// On Noor's actual question form the submit caption is «إضافة مفردة»,
// NOT the shorter «إضافة» used by the parent homework form.
// Exact match only: do not accidentally click a question-type dropdown.
function questionSaveButton(){
 return byText(['إضافة مفردة','إضافة المفردة','حفظ المفردة','إضافة السؤال','حفظ السؤال','Add Item','Save Item','Add Question','Save Question'])
   ||byText(['إضافة','حفظ','Add','Save']);
}
const fieldPool='input:not([type="hidden"]):not([type="button"]):not([type="submit"]),textarea,select';
function findFields(labels,{tag}={}){
 const matches=new Set();const query=tag||fieldPool;
 for(const field of document.querySelectorAll(query)){
  if(field.disabled||!visible(field)&&field.tagName!=='SELECT')continue;
  const meta=clean([field.id,field.name,field.placeholder,field.getAttribute('aria-label')].join(' '));
  if(labels.some(x=>norm(meta)===norm(x)||norm(meta).includes(norm(x))&&norm(x).length>5))matches.add(field);
 }
 for(const label of document.querySelectorAll('label')){
   if(!labels.some(x=>norm(clean(label.textContent))===norm(x)))continue;
   const a=label.control||document.getElementById(label.getAttribute('for'));
   if(a&&a.matches(query))matches.add(a);
   const box=label.closest('.form-group,.row,.form-field,.field,.form-control-wrapper')||label.parentElement;
   if(box){const all=[...box.querySelectorAll(query)].filter(x=>x.tagName==='SELECT'||visible(x));if(all.length===1)matches.add(all[0]);}
 }
 return [...matches];
}
const unique=(labels,opts)=>{const arr=findFields(labels,opts);return arr.length===1?arr[0]:null};
function setText(el,v){if(!el||!['INPUT','TEXTAREA'].includes(el.tagName))throw Error('تعذر تحديد حقل نص مطلوب');
 const proto=el.tagName==='INPUT'?HTMLInputElement.prototype:HTMLTextAreaElement.prototype;
 Object.getOwnPropertyDescriptor(proto,'value').set.call(el,String(v??''));
 el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
}
function setSelect(el,v){if(!el||el.tagName!=='SELECT')throw Error('حقل اختيار غير معروف');
 const name=norm(v);const options=[...el.options],match=options.filter(o=>norm(o.textContent)===name||norm(o.value)===name);if(match.length!==1)throw Error('تعذر اختيار «'+v+'» بصورة مؤكدة');
 el.value=match[0].value;match[0].selected=true;el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
}
function containingSelect(labels){const els=[...document.querySelectorAll('select')].filter(x=>!x.disabled&&[...x.options].some(o=>labels.some(l=>norm(o.textContent)===norm(l))));return els.length===1?els[0]:null;}
function selectOption(labels,selectLabels=[]){let field=selectLabels.length?unique(selectLabels,{tag:'select'}):null;if(!field)field=containingSelect(labels);if(!field)throw Error('لم أعثر على قائمة الخيارات المطلوبة: '+labels.join(' / '));
 let option=[...field.options].filter(o=>labels.some(l=>norm(o.textContent)===norm(l)));if(option.length!==1)throw Error('الاختيار ملتبس: '+labels.join(' / '));setSelect(field,option[0].textContent);return true;
}
function editableCandidates(){const out=[];
 for(const f of document.querySelectorAll('iframe.cke_wysiwyg_frame,iframe.tox-edit-area__iframe,iframe[id*="_ifr"]')){
  try {const b=f.contentDocument?.body;if(b&&visible(f)&&b.isContentEditable)out.push({type:'rich',el:b});}catch{}
 }
 for(const e of document.querySelectorAll('[contenteditable="true"],[contenteditable=""]'))if(visible(e)&&!out.some(x=>x.el===e))out.push({type:'rich',el:e});
 for(const e of document.querySelectorAll('textarea'))if(visible(e))out.push({type:'text',el:e});
 return out;
}
function fillEditor(item,text){if(!item)throw Error('المحرر المطلوب غير موجود');const el=item.el;
 if(item.type==='text')return setText(el,text);
 // WYSIWYG: use text nodes for untrusted student-facing question text, not HTML.
 const value=String(text??'');
 if(value.includes('\n')){
  const paragraphs=value.split(/\n\s*\n/).map(x=>x.replace(/\n/g,' ').trim()).filter(Boolean);
  el.replaceChildren(...paragraphs.map(x=>{const p=el.ownerDocument.createElement('p');p.textContent=x;return p;}));
 }else el.replaceChildren(el.ownerDocument.createTextNode(value));
 for(const type of ['input','change','keyup','blur'])el.dispatchEvent(new Event(type,{bubbles:true}));
}
function labelNear(e){let p=e;for(let i=0;i<3&&p;i++,p=p.parentElement){const label=p.querySelector?.('label');if(label)return clean(label.textContent)}return ''}
function labeledEditor(labels){const all=editableCandidates();const byLabel=all.filter(item=>labels.some(l=>norm(labelNear(item.el))===norm(l)));return byLabel.length===1?byLabel[0]:null}
function currentPage(){const path=location.pathname;
 if(/\/teacher\/homeworks\/create(?:\/|$)/i.test(path))return 'create';
 // Noor navigates to a SEPARATE /teacher/questions module after the homework is saved.
 // This must be classified before looking for text on the page.
 if(/^\/teacher\/questions\/(?:index|list)(?:\/|$)/i.test(path))return 'question_list';
 if(/^\/teacher\/questions\/(?:add|create|new|edit|question|tfq|mcq|msq|fill|matching|pairing|essay|attachment)[^/]*(?:\/|$)/i.test(path))return 'question';
 if(/\/teacher\/homeworks\/(?:add|create|new|addquestion|add-question|question)[^/]*/i.test(path)&&!/\/(?:index)\//i.test(path))return 'question';
 if(document.querySelector('table')&&/إضافة مفردة جديدة|إضافة مفردة جديد|بنك المفردات|قائمة المفردات/i.test((document.querySelector('main')||document.body).innerText||''))return 'question_list';
 if(/إضافة مفردة|إنشاء مفردة|نص المفردة|درجة المفردة/i.test((document.querySelector('main')||document.body).innerText||''))return 'question';
 if(/\/teacher\/homeworks\/(?:index)(?:\/|$)/i.test(path))return 'index';
 return 'other';
}
function getGrade(){return globalThis.__NoorSmartReadContext?.()||{gradeVerified:false};}
function contextVerify(job,strict=true){
 const context=getGrade();
 if(job.verifiedClassFromDashboard&&job.cid&&job.grade&&job.className){
  const actual=decodeURIComponent(location.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
  if(/^\d+$/.test(actual)&&actual!==String(job.cid))
   throw Error('رابط واجب نور مختلف عن الصف المؤكد في الصفحة السابقة.');
  return context;
 }
 if(context.gradeVerified&&job.grade&&Number(job.grade)!==Number(context.grade))
  throw Error('الصف تغير بين صفحات نور');
 if(!job.grade&&strict&&!context.gradeVerified)throw Error('لا يمكن تحديد الصف الحالي من صفحة نور');
 const expected=globalThis.NoorContext?.classIdentity(job.className);
 const observed=globalThis.NoorContext?.classIdentity(context.className);
 const subjectOf=label=>globalThis.NoorCourseCatalog?.subjectOf?.(label);
 const expectedSubject=subjectOf(job.className),observedSubject=subjectOf(context.className);
 if(context.gradeVerified&&(
  expected?.section&&observed?.section&&expected.section!==observed.section||
  expectedSubject&&observedSubject&&expectedSubject!==observedSubject
 ))throw Error('الفصل تغير أثناء التنقل');
 // A grade heading and its section checkbox carry different detail. The
 // latter is verified immediately before Add or Save by selectTargetClass.
 return context;
}
// Select only from the lesson field belonging to THIS homework, not from every
// select on the page (Noor may render preparation and hidden template lists).
function lessonIdentity(element,record){
 const text=element.textContent;
 if(!record.lessonNodeId)return globalThis.NoorLesson.fullIdentity(text,record.unit,record.lesson);
 const id=element.getAttribute?.('node_id')||element.getAttribute?.('data-node-id')||element.getAttribute?.('data-lesson-id');
 if(id)return String(id)===String(record.lessonNodeId);
 return norm(text)===norm(record.lesson)||norm(text)===norm(record.unit+' '+record.lesson);
}
function lessonPickerFields(record){
 const all=[...document.querySelectorAll('select')].filter(el=>!el.disabled&&!el.closest?.('#noor-smart-activities-root'));
 const labels=[...document.querySelectorAll('label,.control-label,.field-label')].filter(el=>visible(el)&&['الدروس','Lessons'].some(label=>norm(el.textContent)===norm(label)));
 const picked=new Set();
 for(const label of labels){
  const direct=label.control||document.getElementById?.(label.getAttribute?.('for')||'');
  if(direct?.tagName==='SELECT')picked.add(direct);
  let box=label;
  for(let depth=0;depth<5&&box;depth++,box=box.parentElement){
   if(depth>0&&box.querySelectorAll?.('label,.control-label,.field-label').length>2)break;
   const fields=[...box.querySelectorAll?.('select')||[]].filter(el=>all.includes(el));
   if(fields.length===1){picked.add(fields[0]);break}
   // Prefer a select explicitly named after lessons within a larger form row.
   const identified=fields.filter(el=>/lesson|الدروس|الدرس/i.test([el.id,el.name,el.getAttribute?.('aria-label')].join(' ')));
   if(identified.length===1){picked.add(identified[0]);break}
  }
 }
 if(picked.size)return [...picked];
 // Many Select2 implementations use an invisible native select as the actual
 // value holder. Its name/id still identifies it as the lesson picker.
 const byName=all.filter(el=>/lesson|الدروس|الدرس/i.test([el.name,el.id,el.getAttribute?.('aria-label')].join(' ')));
 if(byName.length===1)return byName;
 // Last fallback is allowed only when exactly one select on the entire page
 // contains the requested *unit and lesson* identity. Duplicate lists are NOT
 // a reason to click arbitrarily in a different field.
 const byContent=all.filter(el=>[...el.options].some(o=>lessonIdentity(o,record)));
 return byContent.length===1?byContent:[];
}
function activeLessonChoices(select,record){
 const matches=[...select.options].filter(o=>!o.disabled&&!o.value?.startsWith?.('placeholder')&&lessonIdentity(o,record));
 if(!record.lessonNodeId)return matches;
 const identified=matches.filter(o=>o.hasAttribute?.('node_id')||o.hasAttribute?.('data-node-id')||o.hasAttribute?.('data-lesson-id'));
 return identified.length?identified:matches;
}
function confirmedSelectedLesson(record){
 const selects=lessonPickerFields(record);
 if(selects.length===1){
  const selected=[...selects[0].options].filter(o=>o.selected&&String(o.value||'')!==''&&clean(o.textContent));
  if(selected.length)return selected.length===1&&(record.lessonNodeId?
   activeLessonChoices(selects[0],record).length===1&&activeLessonChoices(selects[0],record)[0]===selected[0]:lessonIdentity(selected[0],record));
 }
 // Some custom widgets have no native selection. A purple selected chip can be
 // accepted when it contains the full Unit+Lesson identity and no other lesson.
 // If the native picker exists but selected the wrong lesson, DO NOT trust a
 // coincidental chip elsewhere on the screen.
 if(selects.length||record.lessonNodeId)return false;
 const state=globalThis.NoorLesson.selectedMatch(document,record.unit,record.lesson,visible);
 return state.selected&&!state.ambiguous;
}
function setLessonOption(el,option){
 // Noor's lesson field can be a multiple-select. Pick exactly one item from
 // the requested Unit and Lesson, and clear a previously selected wrong lesson.
 for(const other of [...el.options])other.selected=(other===option);
 el.value=option.value;
 el.dispatchEvent(new Event('input',{bubbles:true}));
 el.dispatchEvent(new Event('change',{bubbles:true}));
 return [...el.options].filter(o=>o.selected&&String(o.value||'')!=='').length===1&&option.selected;
}
async function selectLesson(job,record){
 if(confirmedSelectedLesson(record))return true;
 const selects=lessonPickerFields(record);
 if(selects.length===1){
  const el=selects[0],choices=activeLessonChoices(el,record);
  // More than one preparation may exist for the SAME Unit/Lesson. Their
  // titles need not match the activity; choose the first matching tree entry.
  // Never choose an option from another Unit or Lesson.
  if(choices.length){
   const preselected=choices.filter(o=>o.selected);
   if(choices.length!==1&&(record.lessonNodeId||preselected.length!==1))throw Error('توجد عدة دروس متطابقة في قائمة نور؛ اختر الدرس بنفسك للتأكد من عدم نشر نشاط في درس آخر.');
   const chosen=preselected[0]||choices[0];
   if(!setLessonOption(el,chosen))throw Error('تعذر تأكيد تحديد الدرس في قائمة نور');
   await sleep(180);
   if(confirmedSelectedLesson(record))return true;
   throw Error('لم يؤكد نور اختيار '+record.unit+' / '+record.lesson+' في خانة الدروس');
  }
 }
 // AJAX/Select2 picker: open only the control next to Noor's "الدروس" label.
 const findVisible=()=>[...document.querySelectorAll('li[role="option"],div[role="option"],.select2-results__option,.choices__list--dropdown .choices__item,.multiselect-container li')]
  .filter(el=>visible(el)&&!el.getAttribute?.('aria-disabled')?.includes('true')&&lessonIdentity(el,record));
 const lessonLabels=[...document.querySelectorAll('label,.control-label,.field-label')].filter(el=>visible(el)&&['الدروس','Lessons'].some(label=>norm(el.textContent)===norm(label)));
 if(lessonLabels.length===1){
  const label=lessonLabels[0];
  const container=label.closest('.form-group,.form-field,.field,.input-group')||label.parentElement;
  const triggers=[...container?.querySelectorAll?.('.select2-selection,[role="combobox"],.choices__inner,.selectize-input,.multiselect,.dropdown-toggle')||[]].filter(visible);
  if(triggers.length===1){
   triggers[0].click();await sleep(320);
   const visibleChoices=findVisible();
   if(visibleChoices.length===1){
    // Only one unique option can be selected; never click an ambiguous duplicate.
    visibleChoices[0].click();await sleep(300);
    if(confirmedSelectedLesson(record))return true;
   }
  }
 }
 throw Error('تعذر اختيار '+record.unit+' / '+record.lesson+' تلقائيًا من خانة الدروس في نور');
}
// Noor requires an actual target class before clicking Add on the homework form.
// The class label is displayed beside an UNCHECKED checkbox; grade recognition alone
// does not mean the class has been selected for publication.
function labeledControlText(el){
 const nodes=[...(el.labels||[]),el.closest('label'),el.previousElementSibling,el.nextElementSibling];
 let node=el.parentElement;
 for(let depth=0;depth<4&&node;depth++,node=node.parentElement){
  if(node.querySelectorAll('input[type=checkbox],input[type=radio]').length===1)nodes.push(node);
 }
 return [...new Set(nodes.filter(Boolean))].flatMap(n=>{
  const texts=[clean(n.textContent),clean(n.getAttribute?.('aria-label'))];
  if(n.querySelectorAll)for(const t of [...n.querySelectorAll('label,span,b,strong,small')].slice(0,24))texts.push(clean(t.textContent));
  return texts.filter(Boolean);
 });
}
function classCheckboxAvailable(visibleOnly=false){
 const boxes=[...document.querySelectorAll('input[type="checkbox"]')],result=[];
 for(const cb of boxes){
  if(cb.disabled||cb.closest('#stnNoorHub,#noor-prep-panel,#noor-smart-activities-root')||(visibleOnly&&!cb.getClientRects().length&&!cb.parentElement?.getClientRects().length))continue;
  const direct=[...(cb.labels||[]),cb.closest('label')]
   .map(label=>clean(label?.textContent)).filter(Boolean);
  const own=[...direct,clean(cb.getAttribute('aria-label'))].filter(Boolean);
  if(own.some(label=>/^(?:اختيار الكل|تحديد الكل|select all)$/i.test(label)))continue;
  const local=[...own,...labeledControlText(cb)];
  const labels=local.filter(label=>globalThis.NoorContext?.isClassLabel(label));
  const actual=labels.filter(label=>globalThis.NoorContext.classIdentity(label).section);
  const candidates=actual.length?actual:labels;
  const ids=new Set(candidates.map(label=>{const id=globalThis.NoorContext.classIdentity(label);return id.grade+':'+id.section;}));
  if(ids.size===1){result.push({cb,label:candidates[0]});continue;}
  // The mobile form can render the section label separately from its checkbox.
  // In the dedicated publication box, include the single real section even
  // when Noor omits an accessible label.
  if(!ids.size&&!local.some(label=>/^(?:اختيار الكل|تحديد الكل|select all|خاص|private)$/i.test(label))){
   let group=cb.parentElement;
   for(let depth=0;group&&depth<5;depth++,group=group.parentElement){
    const caption=clean(group.textContent);
    if(caption.length<=250&&/نشر (?:الاختبار |النشاط )?(?:للفصول|لفصول)|publish (?:the (?:exam|activity) )?to (?:the following )?(?:classes|sections)/i.test(caption)&&
       group.querySelectorAll('input[type="checkbox"]').length<=12){
     if(visible(cb)||visible(cb.parentElement))result.push({cb,label:'',publication:true});
     break;
    }
   }
  }
 }
 // If multiple checkbox elements mapped to the same one class label, the mapping
 // is ambiguous (e.g. a Select All checkbox). Do not click either one.
 return result;
}
function sameClass(a,b){return norm(a)===norm(b);}
function classMatchesForRun(all,job){
 const target=globalThis.NoorContext?.classIdentity(job.className);
 const identity=x=>globalThis.NoorContext?.classIdentity(x.label);
 const wantedGrade=Number(job.grade)||target?.grade;
 const matching=all.filter(x=>identity(x)?.grade===wantedGrade);
 if(target?.section)return matching.filter(x=>identity(x).section===target.section);
 const exact=all.filter(x=>sameClass(x.label,job.className));
 if(exact.length)return exact;
 if(!job.verifiedClassFromDashboard&&!job.useVisibleSection)return [];
 if(matching.length===1)return matching;
 if(matching.length>1){const chosen=matching.filter(x=>x.cb?.checked);return chosen.length===1?chosen:[];}
 return all.length===1&&all[0].publication?[all[0]]:[];
}

// Noor has a heading "نشر الاختبار للفصول التالية" ABOVE several radios.
// Reading that whole section once for each radio incorrectly makes them ALL
// look like "نشر للفصول". Read ONLY each radio's own nearby short label.
function radioOwnLabels(r){
 const labels=[...(r.labels||[]),r.closest?.('label'),r.previousElementSibling,r.nextElementSibling].filter(Boolean);
 for(let p=r.parentElement,d=0;p&&d<3;p=p.parentElement,d++){
  if(p.querySelectorAll?.('input[type="radio"]')?.length===1)labels.push(p);
 }
 return [...new Set(labels)].map(el=>clean(el.textContent||el.getAttribute?.('aria-label')))
  .filter(txt=>txt&&txt.length<=45&& !/نشر الاختبار للفصول التالية|اختيار الكل/.test(txt));
}
function chooseModeForClasses(){
 const radios=[...document.querySelectorAll('input[type="radio"]')].filter(e=>!e.disabled);
 const isClass=txt=>/^(?:نشر\s*)?(?:للفصول|لفصول|فصول|الفصول|للفصل|للفصول الدراسية|للفصل الدراسي|للصفوف|لصفوف|publish\s*(?:to\s*)?(?:classes|sections))$/i.test(clean(txt));
 const possible=radios.filter(r=>radioOwnLabels(r).some(isClass));
 if(possible.length===1){
  const radio=possible[0];const wasChecked=radio.checked;
  if(!wasChecked)radio.click();
  if(!radio.checked)throw Error('لم يؤكد نور اختيار النشر للفصول');
  return !wasChecked;
 }
 // A mode can already be selected even if Noor renders the words in custom
 // sibling elements. If the target class checkbox is present, retain that
 // mode rather than choosing another (student/group) radio at random.
 const conflicting=radios.some(r=>r.checked&&radioOwnLabels(r).some(t=>/^(?:نشر\s*)?(?:لطلبة|للطلبة|للمجموعات|لمجموعات|publish\s*(?:to\s*)?(?:students|groups))$/i.test(t)));
 if(conflicting)throw Error('نمط النشر الحالي للطلاب أو المجموعات، وليس للفصول');
 if(possible.length>1&&possible.filter(r=>r.checked).length===1)return false;
 return false;
}
async function selectTargetClass(job){
 // Changing the publish mode can redraw Noor's checkboxes asynchronously.
 const changed=chooseModeForClasses();
 let all=classCheckboxAvailable(true),matching=classMatchesForRun(all,{...job,useVisibleSection:true});
 for(let attempt=0;(changed&&attempt===0||matching.length!==1)&&attempt<8;attempt++){
  await sleep(220);all=classCheckboxAvailable(true);matching=classMatchesForRun(all,{...job,useVisibleSection:true});
 }
 if(matching.length!==1)throw Error('تعذر تحديد مربع الفصل «'+job.className+'» بصورة واحدة مؤكدة');
 const cb=matching[0].cb;
 const otherChecked=all.filter(x=>x.cb!==cb&&x.cb.checked);
 if(otherChecked.length&&!job.verifiedClassFromDashboard)throw Error('وجدت فصلًا مختلفًا محددًا للنشر؛ لم أغيّر اختياراتك');
 for(const other of otherChecked){
  other.cb.click();
  if(other.cb.checked)throw Error('تعذّر إلغاء تحديد فصل آخر في نموذج نور.');
 }
 if(!cb.checked)cb.click();
 if(!cb.checked)throw Error('فشل تحديد الفصل «'+job.className+'» في نور');
 // 'خاص' means the task remains private. When publishing to the verified class,
 // turn off this Noor option, if it is uniquely identifiable.
 const privateBoxes=[...document.querySelectorAll('input[type="checkbox"]')].filter(x=>!x.disabled&&labeledControlText(x).some(t=>['خاص','Private'].some(label=>norm(t)===norm(label))));
 if(privateBoxes.length===1&&privateBoxes[0].checked!==Boolean(job.draft)){
  privateBoxes[0].click();
  if(privateBoxes[0].checked!==Boolean(job.draft))throw Error('تعذر ضبط خصوصية النشاط');
 }
 // The UI can replace controls on radio changes; read the class list once more.
 const finalClasses=classCheckboxAvailable(true);
 const again=classMatchesForRun(finalClasses,{...job,useVisibleSection:true});
 if(again.length!==1||!again[0].cb.checked||finalClasses.some(entry=>entry.cb!==again[0].cb&&entry.cb.checked))throw Error('فُقد اختيار الفصل قبل حفظ الواجب');
 return {className:job.className,selected:true,mode:'class'};
}
async function setJob(job,stage,message){
 const snapshot=await browser.storage.local.get([KEY,STOP_KEY]);
 const stored=snapshot[KEY];
 if((job.stopToken||'')!==(snapshot[STOP_KEY]||''))throw Error('أُلغيت عملية النشاط.');
 if(!stored||stored.id!==job.id||!stored.active&&(!job.active||job.stage!=='paused')&&stage!=='done')throw Error('أُلغيت عملية النشاط أو تغيّرت.');
 const next={...job,stage,message,updatedAt:Date.now()};
 await browser.storage.local.set({[KEY]:next});
 return next;
}
async function pause(job,msg){const next=stopReason(job,msg);await browser.storage.local.set({[KEY]:next});return next}
function show(msg){browser.runtime.sendMessage({type:'NOOR_AUTOMATOR_STATUS',message:msg}).catch(()=>{});}
function findCreate(){const exact=byText('إضافة نشاط / تقويم جديد')||byText('إضافة تقويم / نشاط جديد');if(exact)return exact;
 const possible=exactActions().filter(e=>/إضافة.*(نشاط|تقويم).*جديد|^(?:add|create)\s+(?:new\s+)?(?:assignment|homework|activity|assessment|quiz)(?:\s*[/&]\s*(?:activity|assessment))?$/i.test(actionText(e)));return possible.length===1?possible[0]:null;
}
const publicationLabels=['تاريخ النشر','موعد النشر','publication date','publish date','publishing date'];
function activityDateField(scope,labels,metadata){
 const candidates=[...scope.querySelectorAll('input[type="date"],input[type="datetime-local"],input[type="text"],input:not([type])')]
  .filter(el=>!el.disabled&&visible(el)&&!el.closest('#stnNoorHub,#noor-prep-panel,#noor-smart-activities-root'));
 const matches=text=>labels.some(label=>norm(text)===norm(label));
 const linked=candidates.filter(el=>[...(el.labels||[])].some(label=>matches(label.textContent))||matches(el.getAttribute('aria-label')));
 if(linked.length)return linked.length===1?linked[0]:null;
 const adjacent=new Set();
 for(const label of scope.querySelectorAll('label,.control-label,.form-label,.field-label')){
  if(!visible(label)||!matches(label.textContent))continue;
  const control=label.control;
  if(control){if(candidates.includes(control))adjacent.add(control);continue;}
  for(let node=label.parentElement,depth=0;node&&node!==scope&&depth<4;node=node.parentElement,depth++){
   const fields=candidates.filter(el=>node.contains(el));
   if(fields.length){if(fields.length===1)adjacent.add(fields[0]);break;}
  }
 }
 if(adjacent.size)return adjacent.size===1?[...adjacent][0]:null;
 const byName=candidates.filter(el=>[el.id,el.name].some(value=>metadata.test(norm(value))));
 return byName.length===1?byName[0]:null;
}
function readActivityDate(value){
 const ascii=String(value||'').trim().replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776));
 const m=/^(\d{4}-\d{2}-\d{2})(?:([ T])([01]\d|2[0-3]):([0-5]\d)(?::([0-5]\d))?)?$/.exec(ascii);
 if(!m)return null;
 const date=new Date(m[1]+'T00:00:00Z');
 if(!Number.isFinite(+date)||date.toISOString().slice(0,10)!==m[1])return null;
 return {day:m[1],suffix:ascii.slice(10),time:m[3]?m[3]+':'+m[4]+':'+(m[5]||'00'):''};
}
function applyActivityPublishDate(title,requested){
 const day=readActivityDate(requested);
 if(!day||day.time)throw Error('صيغة تاريخ نشر النشاط غير صحيحة.');
 const scope=title.form||title.closest('form')||document;
 const pub=activityDateField(scope,publicationLabels,/(?:publish(?:ing|ed)?date|datepublish|startdate|datefrom|publishat)$/i);
 if(!pub)throw Error('لا يمكن إثبات حقل تاريخ النشر في نشاط نور؛ لن أحفظ بتاريخ مختلف.');
 const previous=readActivityDate(pub.value);
 const type=pub.type;
 if(previous?.day!==day.day){
  if(pub.readOnly||type!=='date'&&!previous?.time){
   throw Error('اضبط تاريخ النشر في تقويم نور على '+day.day+' ثم اضغط «استكمال النشاط المتوقف».');
  }
  const suffix=type==='date'?'':type==='datetime-local'?previous.suffix.replace(/^ /,'T'):previous.suffix;
  setText(pub,day.day+suffix);
 }
 const current=readActivityDate(pub.value);
 if(current?.day!==day.day||(previous?.time&&current.time!==previous.time)||pub.validity?.valid===false)
  throw Error('رفض نور تاريخ النشر المحدد للنشاط. اضبطه في التقويم ثم استكمل النشاط.');
 for(const [labels,meta] of [
  [['تاريخ التسليم','due date','submission date'],/(?:duedate|datedue|submissiondate)$/i],
  [['تاريخ التسليم المتأخر','late submission date','late date'],/(?:latedate|dateslate|latesubmissiondate)$/i]
 ]){
  const field=activityDateField(scope,labels,meta);
  const deadline=readActivityDate(field?.value);
  if(field?.required&&!field.value)throw Error('تاريخ التسليم المطلوب فارغ في نور.');
  if(deadline&&(deadline.day<current.day||deadline.day===current.day&&deadline.time&&current.time&&deadline.time<current.time))
   throw Error('تاريخ التسليم في نور يسبق تاريخ النشر. عدّل تاريخ التسليم في النموذج ثم استكمل النشاط.');
 }
}
async function runCreate(job){const record=job.items[job.nextAssessment];const ctx=contextVerify(job,true);
 const now=decodeURIComponent(location.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'');
 if(/^\d+$/.test(now)&&job.cid&&now!==String(job.cid))throw Error('رابط واجب نور مختلف عن الصف المؤكد في الصفحة السابقة.');
 if(!ctx.gradeVerified){
  // The class was bound to the numeric homework index by a verified teacher
  // dashboard card. After Noor navigates to the create form, re-check the
  // actual class checkbox instead of requiring an unrelated page heading.
  if(!job.verifiedClassFromDashboard||!job.cid||!job.grade||!job.className)
   throw Error('تأكد من الصف الظاهر في صفحة إضافة الواجب');
  // selectTargetClass verifies the actual checkbox AFTER choosing publish-to-classes mode.
 }
 // Do not infer class from opaque CID; record a verified visible class name.
 if(!job.grade){job.grade=ctx.grade;job.className=ctx.className;}
 const t=unique(['العنوان','عنوان الواجب','title'],{tag:'input:not([type="hidden"])'});
 if(!t)throw Error('حقل عنوان الواجب غير واضح في نور');setText(t,record.title);
 if(!job.allowUnlinkedLesson||record.lessonNodeId||job.tryLesson){
  try{await selectLesson(job,record);}
  catch(error){if(!job.allowUnlinkedLesson)throw error;}
 }
 if(job.publishDate){
  const liveTitle=unique(['العنوان','عنوان الواجب','title'],{tag:'input:not([type="hidden"])'});
  if(!liveTitle||clean(liveTitle.value)!==clean(record.title))throw Error('تعذر تأكيد نموذج الواجب بعد اختيار الفصل.');
  applyActivityPublishDate(liveTitle,job.publishDate);
 }
 await selectTargetClass({...job,draft:true});
 const add=byText(['إضافة','Add','Create'])||byText(['حفظ','Save']);if(!add)throw Error('لم أتعرف على زر إضافة الواجب بدقة');
 await setJob(job,'await_parent_save',`تم اختيار «${job.className}» وتعبئة الواجب؛ انتظار تأكيد حفظ نور`);
 add.click();await sleep(1100);
}
function questionTable(){
 const tables=[...document.querySelectorAll('table')].filter(visible);
 const questionColumns=/(?:نص|نوع|درجة) (?:المفرد[هة]|السؤال)|متن السؤال|question (?:text|type)|item (?:text|type)|الجواب الصحيح|correct answer/i;
 const matching=tables.filter(table=>{
  const head=clean(table.querySelector('thead')?.textContent);
  return questionColumns.test(head)||/ترتيب.*النوع|(?:order|position).*type/i.test(head)||(/متعدد الاختيارات|صح.?خطأ|multiple choice|true.?false/i.test(clean(table.textContent))&&/الدرجة|النقاط|score|marks|points/i.test(head));
 });
 return matching.length===1?matching[0]:null;
}
function questionRows(table){
 return table?[...table.querySelectorAll('tbody tr')].filter(row=>
  !row.matches?.('.child,.dtrg-group,.dataTables_empty,.dt-empty')&&
  !row.querySelector('.dataTables_empty,.dt-empty')&&
  !/لا توجد (?:بيانات|مفردات)|no (?:data|matching records)/i.test(clean(row.textContent))):[];
}
const asciiDigits=value=>String(value||'').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776));
function listCount(){
 const table=questionTable();
 if(!table)return null;
 const wrapper=table.closest('.dataTables_wrapper,.dt-container,[id$="_wrapper"]');
 const info=(table.id&&document.getElementById(table.id+'_info'))||wrapper?.querySelector('.dataTables_info,.dt-info');
 const text=asciiDigits(info?.textContent);
 const total=text.match(/(?:showing[\s\S]*?\bof|(?:عنصر|سجل)[\s\S]*?من(?: أصل)?|من أصل)\s*([\d,٬]+)/i);
 const count=total?Number(total[1].replace(/[,٬]/g,'')):null;
 return Number.isSafeInteger(count)?count:questionRows(table).length;
}
function verifyQuestionOnList(q){
 const stem=norm(q.stem).slice(0,45);
 return stem.length>=8&&questionRows(questionTable()).some(row=>norm(row.textContent).includes(stem));
}
const typeNames={
 true_false:['صح/خطأ','صواب أو خطأ','True / False'],mcq:['متعدد الاختيارات','متعددة الاختيارات','متعددة الخيارات','اختيار من متعدد','Multiple Choice'],
 multi_select:['متعددة الإجابات','متعدد الإجابات','متعدد الأجوبة','Multiple Answers','Multiple Correct Answers','Multiple Response'],
 short_text:['مقالية','إنشائية','Essay'],essay:['مقالية','إنشائية','Essay'],matching:['توصيل بين عمودين','توصيل العمودين','Matching'],
 pairing:['الاقتران','اقتران','Pairing'],fill_blanks:['املأ الفراغات','ملء الفراغات','Fill in the Blanks'],
 image_click:['النقر في صورة','النقر على صورة','Click on Image'],attachment:['مرفق','بمرفق','Attachment'],content:['المحتوى','محتوى','Content']};
function questionLabel(text){
 return norm(String(text||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/[\u064b-\u065f\u0640]/g,''))
  .replace(/^(?:اضافه)?مفرده|^(?:اضافه|add(?:an?)?(?:question|item)?)/,'')
  .replace(/(?:question|item)$/,'');
}
const menuSelector='.dropdown-menu,[role="menu"],[role="listbox"]';
function questionChoice(q){
 const names=typeNames[q.kind]?.map(questionLabel);
 if(!names)return null;
 const options=[...document.querySelectorAll('a,button,[role="menuitem"],[role="option"],[role="button"],[onclick],li[data-href]')]
  .filter(el=>visible(el)&&!el.disabled&&el.getAttribute('aria-disabled')!=='true'&&!el.closest('#stnNoorHub,#noor-smart-activities-root'))
  .filter(el=>[el.textContent,el.getAttribute('aria-label'),el.getAttribute('title')].some(label=>names.includes(questionLabel(label))));
 const inMenu=options.filter(el=>el.closest(menuSelector));
 const preferred=inMenu.length?inMenu:options;
 const unique=preferred.filter(el=>!preferred.some(other=>other!==el&&el.contains(other)));
 return unique.length===1?unique[0]:null;
}
function openQuestionMenu(){
 const primary=exactActions().filter(el=>!el.closest('#stnNoorHub')&&
  [el.textContent,el.getAttribute('aria-label'),el.getAttribute('title')].some(label=>
   /اضافهمفردهجديده?$|^addnew(?:question|item)$/.test(norm(String(label||'').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه')))));
 if(primary.length!==1)return;
 const button=primary[0];
 const group=button.closest('.btn-group,.dropdown');
 const toggles=group?[...group.querySelectorAll('.dropdown-toggle,[data-toggle="dropdown"],[data-bs-toggle="dropdown"],[aria-haspopup="menu"]')].filter(visible):[];
 const toggle=toggles.length===1?toggles[0]:button;
 if(toggle.getAttribute('aria-expanded')!=='true')toggle.click();
}
async function findQuestionChoice(q){
 let choice=questionChoice(q);
 if(choice)return choice;
 openQuestionMenu();
 for(let attempt=0;attempt<15;attempt++){
  await sleep(200);
  choice=questionChoice(q);
  if(choice)return choice;
 }
 return null;
}
async function openQuestion(job){const q=job.items[job.nextAssessment].questions[job.nextQuestion];
 if(!q){const next=job.nextAssessment+1;await setJob({...job,nextAssessment:next,nextQuestion:0},'activity_done','اكتملت أسئلة النشاط');return}
 const choice=await findQuestionChoice(q);
 if(!choice)throw Error('لا يوجد خيار واضح لإضافة '+(typeNames[q.kind]?.[0]||q.kind)+' في نور');
 job.prevCount=listCount();job.itemList=location.pathname+location.search;await setJob(job,'await_question_form',`فتح محرر السؤال ${job.nextQuestion+1} من ${job.items[job.nextAssessment].questions.length} (${q.kind})`);
 choice.click();await sleep(850);
}
// Recognize Noor's question editor by its actual route first. The document title
// may appear after a long notification banner/sidebar, so body.innerText.slice()
// is not an authoritative way to detect a type.
function questionKindFromRoute(pathname=location.pathname){
 const segment=String(pathname||'').split('/')[3]||'';
 const slug=segment.toLowerCase().replace(/^(?:create|add|edit)[_-]?/,'').replace(/[^a-z0-9]/g,'');
 const map={mcq:'mcq',multiplechoice:'mcq',singlechoice:'mcq',tfq:'true_false',truefalse:'true_false',msq:'multi_select',multiselect:'multi_select',fill:'fill_blanks',fillblank:'fill_blanks',fillblanks:'fill_blanks',essay:'essay',matching:'matching',pairing:'pairing',attachment:'attachment'};
 return Object.prototype.hasOwnProperty.call(map,slug)?map[slug]:null;
}
function confirmQuestionEditorKind(q,pathname=location.pathname){
 const routed=questionKindFromRoute(pathname);
 if(routed){
  // Noor does not expose a separate 'short answer' question type. Its essay
  // editor has both the question and model-answer fields, so it is the ONLY
  // verified fallback for short_text. Do not generalize this to other types.
  const compatible=routed===q.kind||(q.kind==='short_text'&&routed==='essay');
  if(!compatible)throw Error('نور فتح محرر «'+routed+'» لكن السؤال من نوع «'+q.kind+'»؛ لن أضع إجابة في محرر مختلف');
  return true;
 }
 // Only use visible editor-page headings (not the entire page and unrelated menus).
 const headings=[...document.querySelectorAll('h1,h2,h3,h4,h5,legend,.page-title,.card-title')].filter(visible).map(x=>clean(x.textContent));
 const clues=typeNames[q.kind]||[];
 if(clues.some(x=>headings.some(h=>questionLabel(h)===questionLabel(x))))return true;
 throw Error('لم أتمكن من إثبات نوع محرر السؤال الحالي «'+q.kind+'» من رابط نور أو عنوان المحرر');
}
function fillMainEditor(q){const byLabel=labeledEditor(['نص المفردة','محتوى السؤال','السؤال','Question text','Question']);if(byLabel){fillEditor(byLabel,q.stem);return}
 const fields=editableCandidates();if(!fields.length)throw Error('محرر نص السؤال غير ظاهر');
 // Only use the first editor if the question page has exactly one unambiguous top editor.
 const editors=fields.filter(x=>x.type==='rich');if(editors.length===1||['mcq','multi_select'].includes(q.kind)&&editors.length===q.options.length+1||['essay','short_text'].includes(q.kind)&&editors.length===2){fillEditor(editors[0],q.stem);return}
 throw Error('محرر السؤال غير معروف — لن أضع النص في حقل خاطئ');
}
function fillPoints(q){const field=unique(['درجة المفردة','درجة السؤال','درجة','Question score','Score','Points','Marks'],{tag:'input:not([type="hidden"])'});
 if(!field)throw Error('لم أتعرف على حقل درجة المفردة');setText(field,String(q.points));}
function fillTF(q){const label=q.answer?'صحيح':'خطأ';selectOption([label,q.answer?'صح':'خاطئ',q.answer?'True':'False'],['الجواب الصحيح','Correct answer']);}
// Changing Noor's number-of-options dropdown may asynchronously recreate all
// CKEditor frames. Wait for the required option editors BEFORE filling text.
function countLabels(n){
 const words={2:['اختيارين','الاختيارين','اختبارين','الاختبارين','اثنان','two choices'],3:['ثلاثة اختيارات','ثلاثة اختبارات','three choices'],4:['أربعة اختيارات','أربعة اختبارات','اربعة اختيارات','اربعة اختبارات','four choices'],5:['خمسة اختيارات','خمسة اختبارات','five choices'],6:['ستة اختيارات','ستة اختبارات','six choices']};
 return [...(words[n]||[]),String(n)];
}
async function prepareChoiceEditors(q){
 const wanted=q.options?.length;
 if(!Number.isInteger(wanted)||wanted<2||wanted>6)throw Error('عدد الاختيارات يجب أن يكون بين 2 و6');
 let selector=unique(['عدد الاختيارات','عدد الخيارات','عدد الاختبارات','Number of choices','Number of options'],{tag:'select'});
 const names=countLabels(wanted);
 if(!selector)selector=containingSelect(names.filter(x=>x.length>2));
 if(selector){
  const choices=[...selector.options].filter(o=>names.some(x=>norm(o.textContent)===norm(x)||norm(o.value)===norm(x)));
  if(choices.length!==1)throw Error('لم أتعرف على عدد الاختيارات '+wanted+' في قائمة نور');
  if(String(selector.value)!==String(choices[0].value)){
   setSelect(selector,choices[0].textContent);
   await sleep(350);
  }
 }
 // If the form has no count select, only proceed when the correct number of
 // choice editors is already visible. Never write to the wrong option field.
 for(let attempt=0;attempt<12;attempt++){
  const editors=editableCandidates().filter(x=>x.type==='rich');
  if(editors.length===wanted+1)return;
  await sleep(250);
 }
 throw Error('محررات الاختيارات في نور غير جاهزة: مطلوب '+wanted+' اختيارات ونص السؤال. لم أحفظ المفردة');
}
function fillMCQ(q){
 const editors=editableCandidates().filter(x=>x.type==='rich');
 // Question editor + one rich editor per option. Avoid silently filling the wrong editors.
 if(editors.length!==q.options.length+1)throw Error('عدد محررات الاختيارات في نور لا يطابق عدد الاختيارات في السؤال');
 for(let i=0;i<q.options.length;i++)fillEditor(editors[i+1],q.options[i]);
 const index=q.options.indexOf(q.answer)+1;
 if(index<1)throw Error('الإجابة الصحيحة غير موجودة في الاختيارات');
 selectOption([String(index),'الاختيار '+index,'الاختبار '+index],['الجواب الصحيح']);
}
async function fillMSQ(q){
 const editors=editableCandidates().filter(x=>x.type==='rich');
 if(editors.length!==q.options.length+1)throw Error('عدد محررات الاختيارات المتعددة لا يطابق أسئلة الملف');
 q.options.forEach((v,i)=>fillEditor(editors[i+1],v));
 const wanted=q.answers.map(v=>q.options.indexOf(v)+1);
 if(wanted.some(n=>n<1))throw Error('إجابة في الاختيار المتعدد غير موجودة بين الخيارات');
 // In Noor the number of correct answers may be a drop-down, followed by numbered checkboxes.
 const howMany=unique(['عدد الاستجابات الصحيحة','عدد الإجابات الصحيحة'],{tag:'select'});
 if(howMany){selectOption([String(wanted.length)],['عدد الاستجابات الصحيحة','عدد الإجابات الصحيحة']);await sleep(350);}
 const byNumber=new Map();
 const checkboxes=[...document.querySelectorAll('input[type="checkbox"]')].filter(box=>visible(box)&&!box.disabled&&!box.closest('#stnNoorHub,#noor-smart-activities-root'));
 for(const box of checkboxes){
  const own=[...labeledControlText(box),box.name,box.id,box.getAttribute('aria-label')];
  const group=box.closest('fieldset,.form-group,[role="group"]');
  const caption=group?.querySelector('legend,.control-label,.form-label')?.textContent||'';
  const numbered=own.map(text=>String(text||'').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776)));
  const numbers=new Set(numbered.flatMap(text=>{
   const qualified=[...text.matchAll(/(?:options?|choices?|answers?|responses?|اختيار|إجابة|جواب)[^\d]{0,14}([1-6])\b/gi)].map(match=>Number(match[1]));
   const bare=/^\s*([1-6])\s*$/.exec(text);
   if(bare&&/ال(?:جواب|إجابات|استجابات)|correct (?:answers?|responses?)/i.test(caption))qualified.push(Number(bare[1]));
   return qualified;
  }));
  if(numbers.size!==1)continue;
  const n=[...numbers][0];
  byNumber.set(n,byNumber.has(n)?null:box);
 }
 if(!q.options.every((_,i)=>byNumber.get(i+1)))throw Error('خيارات الإجابات الصحيحة المتعددة في نور غير واضحة.');
 q.options.forEach((_,i)=>{const cb=byNumber.get(i+1),need=wanted.includes(i+1);if(cb.checked!==need)cb.click();if(cb.checked!==need)throw Error('تعذر تثبيت الإجابات الصحيحة المتعددة');});
}
async function fillFill(q){return globalThis.NoorBlanks.fill(document,q.blanks||[],setText,sleep);}
function fillEssay(q){const editors=editableCandidates().filter(x=>x.type==='rich');if(editors.length!==2)throw Error('محرر الإجابة النموذجية غير واضح');fillEditor(editors[1],q.answer||'');}
function fillMatching(q,{pairing=false}={}){
 const editor=editableCandidates().find(item=>item.type==='rich');
 let editorBottom=0;
 if(editor){
  const frame=editor.el.ownerDocument?.defaultView?.frameElement;
  const box=(frame||editor.el).getBoundingClientRect?.();
  if(box)editorBottom=box.bottom;
 }
 const points=unique(['درجة المفردة','درجة السؤال','درجة','Question score','Score','Points','Marks'],{tag:'input:not([type="hidden"])'});
 const scoreTop=points?.getBoundingClientRect?.().top??Infinity;
 const plan=globalThis.NoorMatching.plan(document,q.pairs,visible,{editorBottom,scoreTop,pairing});
 for(const {el,value} of plan.assignments)setText(el,value);
 for(const {el,value} of plan.assignments)if(clean(el.value)!==clean(value))throw Error('لم يؤكد نور تعبئة زوج التوصيل');
}
function fillPairing(q){
 const requiredImages=[...document.querySelectorAll('input[type="file"][required]')].some(visible);
 if(requiredImages)throw Error('هذا محرر اقتران بالصور. اختر صور الأزواج في نور قبل الحفظ.');
 fillMatching(q,{pairing:true});
}
async function fillQuestionFields(q){
 confirmQuestionEditorKind(q);
 if(['mcq','multi_select'].includes(q.kind))await prepareChoiceEditors(q);
 fillMainEditor(q);fillPoints(q);
 if(q.kind==='true_false')fillTF(q);
 else if(q.kind==='mcq')fillMCQ(q);
 else if(q.kind==='multi_select')await fillMSQ(q);
 else if(q.kind==='fill_blanks')await fillFill(q);
 else if(q.kind==='essay'||q.kind==='short_text')fillEssay(q);
 else if(q.kind==='matching')fillMatching(q);
 else if(q.kind==='pairing')fillPairing(q);
 else throw Error('نوع السؤال '+q.kind+' يحتاج محررًا خاصًا؛ لم أضغط نشرًا');
 }
globalThis.NoorQuestionEditor=Object.freeze({fill:fillQuestionFields,choose:questionChoice,saveButton:questionSaveButton,confirmKind:confirmQuestionEditorKind,findChoice:findQuestionChoice,listCount,verifyQuestionOnList});
globalThis.NoorVisibleClass=Object.freeze({select:selectTargetClass,hasChoices:()=>classCheckboxAvailable(true).length>0});
if(!activityPage)return;
async function fillQuestion(job){const record=job.items[job.nextAssessment],q=record.questions[job.nextQuestion];
 if(!q)throw Error('لم أجد سؤالًا حاليًا');
 await fillQuestionFields(q);
 const save=questionSaveButton();if(!save)throw Error('زر حفظ المفردة غير محدد (المتوقع: إضافة مفردة)');
 await setJob(job,'await_question_save',`جارٍ حفظ السؤال ${job.nextQuestion+1} من ${record.questions.length}`);save.click();await sleep(1000);
}
function scoreFromList(){
 const table=questionTable();
 if(!table)return null;
 const idx=[...table.querySelectorAll('thead tr:first-child th,thead tr:first-child td')].findIndex(
  header=>['الدرجة','درجة المفردة','الدرجات','النقاط','Score','Marks','Points','Grade'].some(label=>norm(label)===norm(header.textContent)));
 const rows=questionRows(table);
 if(idx<0||rows.length!==listCount())return null;
 const values=rows.map(row=>{const cell=row.querySelectorAll('td')[idx];return asciiDigits(cell?.querySelector('input')?.value||clean(cell?.textContent)).replace(/[٫,]/g,'.');});
 return values.every(x=>/^\d+(?:\.\d+)?$/.test(x))?values.reduce((n,x)=>n+Number(x),0):null;
}
async function startPublish(job){
 const item=job.items[job.nextAssessment-1];if(!item)throw Error('لم يُحدد نشاط مكتمل للنشر');
 const count=listCount(),marks=scoreFromList();
 if(count!==null&&count!==item.questions.length)throw Error(count===null?'تعذر قراءة إجمالي مفردات نور. افتح قائمة المفردات واضغط استكمال النشاط.':
  'نور يعرض '+count+' مفردة، والمطلوب '+item.questions.length+'. اضغط استكمال بعد ظهور العدد الصحيح.');
 if(marks!==null&&Math.abs(marks-item.points)>0.01)throw Error('مجموع درجات نور '+marks+'، والمطلوب '+item.points+'. اضغط استكمال بعد تصحيح المجموع.');
 const publish=byText(['النشر الآن','انشر الآن','Publish now']);
 if(publish&&!publish.closest('table')){
  await setJob(job,'await_publish_save','أُرسلت المفردات. جارٍ نشر النشاط.');publish.click();await sleep(900);return;
 }
 const edits=exactActions().filter(el=>{
  if(el.closest('table,#stnNoorHub'))return false;
  const href=el.closest('a')?.getAttribute('href')||'';
  return /(?:^|\/)homeworks\/(?:edit|update)(?:\/|[?#]|$)/i.test(href)||
   /^(?:تحرير النشاط|تعديل النشاط|تعديل الواجب|edit activity|edit assignment|edit homework)$/i.test(actionText(el));
 });
 const edit=edits.length===1?edits[0]:edits.length?null:byText('تحرير')||byText('تعديل')||byText(['Edit','Edit Activity','Edit Assignment']);
 if(!edit||edit.closest('table'))throw Error('رابط تحرير النشر غير واضح. الأسئلة محفوظة في نور.');
 await setJob(job,'await_publish_form','تم التحقق من الأسئلة والدرجات؛ فتح إعدادات النشر');edit.click();await sleep(900);
}
async function publishForm(job){
 contextVerify(job,false);
 // Reuse the exact same verified class & publication mode mapping used at
 // initial homework creation. Do not select "all classes" by shortcut.
 await selectTargetClass(job);
 const save=byText('حفظ')||byText('تعديل')||byText('حفظ التغييرات')||byText(['Save','Save Changes','Update']);
 if(!save)throw Error('زر الحفظ النهائي غير معروف؛ لم أنشر النشاط');
 await setJob(job,'await_publish_save','تأكيد نشر النشاط بعد مطابقة الفصل والأسئلة والدرجات');
 save.click();await sleep(1000);
}
async function runNow(){if(busy)return;busy=true;
 try{
 const snapshot=await browser.storage.local.get([KEY,STOP_KEY]);
 let job=snapshot[KEY];const picked=document.getElementById('stnHubService')?.value;
 if(picked&&picked!=='activities'||job?.owner&&sessionStorage.getItem('stnNoorActivityOwner:v1')!==job.owner)return;
 if(!job?.active||(job.stopToken||'')!==(snapshot[STOP_KEY]||''))return;
 let stage=job.stage;
 let page=currentPage();
 if(stage==='open_create'){
   if(page==='create'){await setJob(job,'fill_parent','تعبئة الواجب في نور');stage='fill_parent'}
   else{if(job.verifiedClassFromDashboard)contextVerify(job);const a=findCreate();if(!a)throw Error('افتح صفحة المهام الإلكترونية الخاصة بالصف داخل نور');await setJob(job,'await_create_page','فتح صفحة إضافة واجب جديد');a.click();return}
 }
 if(stage==='await_create_page'){
   if(page!=='create')return;job=await setJob(job,'fill_parent','الصفحة جاهزة لإدخال الواجب');stage='fill_parent';
 }
 if(stage==='fill_parent'){await runCreate(job);return}
 if(stage==='await_parent_save'){
   // Wait for navigation/validation; never press Add twice because that can duplicate a task.
   if(page==='create'){
     const error=[...document.querySelectorAll('.alert-danger,.validation-summary-errors,.text-danger,[role="alert"]')]
       .map(e=>clean(e.textContent)).find(t=>t&&/يجب اختيار|خطأ|مطلوب|يرجى|error|required|validation/i.test(t));
     if(error)throw Error('رفض نور حفظ الواجب: '+error.slice(0,180));
     if(Date.now()-job.updatedAt<16000)return;
     throw Error('لم يؤكد نور حفظ الواجب بعد 16 ثانية؛ لن أعيد الضغط حتى لا يتكرر');
   }
   if(page!=='question_list'){
     if(Date.now()-job.updatedAt<16000)return;
     throw Error('انتقل نور إلى صفحة غير معروفة بعد حفظ الواجب: '+location.pathname);
   }
   stage=job.bulk?'open_bulk':'open_question';
   job=await setJob(job,stage,'تم إنشاء الواجب واختيار الفصل؛ جارٍ إدخال المفردات.');
 }
 if(stage==='open_bulk'){
   const bulk=globalThis.NoorBulkItems,record=job.items[job.nextAssessment];
   if(!bulk?.supported(record.questions))throw Error('تتضمن المجموعة نوعًا يحتاج محرر مفردة مستقلًا. اختر الإدراج المفرد لهذا النشاط.');
   const open=bulk.open();
   if(!open)throw Error('زر إضافة مجموعة مفردات دفعة واحدة غير ظاهر في قائمة النشاط.');
   await setJob({...job,itemList:location.pathname+location.search},'fill_bulk','فتح نموذج المجموعة');open.click();return;
 }
 if(stage==='fill_bulk'){
   const bulk=globalThis.NoorBulkItems,record=job.items[job.nextAssessment];
   if(!bulk?.submit()){if(Date.now()-job.updatedAt<12000)return;throw Error('لم يفتح نموذج إنشاء المجموعة.');}
   const active=()=>!job.owner||sessionStorage.getItem('stnNoorActivityOwner:v1')===job.owner;
   const save=await bulk.fill(record.questions,active);
   await setJob(job,'await_bulk_save','تم تجهيز المجموعة. جارٍ إرسالها مرة واحدة.');save.click();return;
 }
 if(stage==='await_bulk_save'){
   const error=globalThis.NoorBulkItems?.error();
   if(error)throw Error(error);
   if(page!=='question_list'||globalThis.NoorBulkItems?.submit()||location.pathname+location.search!==job.itemList){
    if(Date.now()-job.updatedAt<18000)return;
    throw Error('لم يرجع نور إلى قائمة النشاط بعد إرسال المجموعة. راجعها قبل الإعادة.');
   }
   job=await setJob({...job,nextAssessment:job.nextAssessment+1,nextQuestion:0},'activity_done','انتهى إرسال المجموعة إلى نور.');stage='activity_done';
 }
 if(stage==='open_question'){
   if(page!=='question_list'){
     if(Date.now()-job.updatedAt<16000)return;
     throw Error('قائمة المفردات لم تظهر بعد حفظ الواجب: '+location.pathname);
   }
   await openQuestion(job);return;
 }
 if(stage==='await_question_form'){
   if(page!=='question'){
     if(Date.now()-job.updatedAt<15000)return;
     throw Error('لم يُفتح محرر السؤال خلال 15 ثانية: '+location.pathname);
   }
   job=await setJob(job,'fill_question','المحرر جاهز');stage='fill_question';
 }
 if(stage==='fill_question'){await fillQuestion(job);return}
 if(stage==='await_question_save'){
   const error=globalThis.NoorBulkItems?.error();
   if(error)throw Error(error);
   if(page!=='question_list'){
     if(Date.now()-job.updatedAt<16000)return;
     throw Error('لم يؤكد نور حفظ السؤال خلال 16 ثانية. لن أكرره تلقائيًا');
   }
   const record=job.items[job.nextAssessment],q=record.questions[job.nextQuestion];
   if(job.itemList&&job.itemList!==location.pathname+location.search)throw Error('الصفحة الحالية ليست قائمة المفردات التي أُرسل السؤال منها.');
   const count=listCount(),verified=verifyQuestionOnList(q)||Number.isInteger(job.prevCount)&&count>=job.prevCount+1;
   job=await setJob({...job,nextQuestion:job.nextQuestion+1},'open_question',
    (verified?'حُفظ السؤال ':'أُرسل السؤال دون إعادة حفظ ')+(job.nextQuestion+1)+' من '+record.questions.length);
   stage='open_question';
 }
 if(stage==='activity_done'){job=await setJob(job,'publish_ready','التحقق من درجات نور قبل النشر');stage='publish_ready'}
 if(stage==='publish_ready'){if(page!=='question_list')throw Error('قائمة الأسئلة غير متاحة للتحقق النهائي');await startPublish(job);return}
 if(stage==='await_publish_form'){if(page==='question_list'){if(Date.now()-job.updatedAt<12000)return;throw Error('افتح إعدادات نشر النشاط في نور ثم اضغط استكمال.');}job=await setJob(job,'publish_form','التحقق من الفصل المستهدف');stage='publish_form'}
 if(stage==='publish_form'){await publishForm(job);return}
 if(stage==='await_publish_save'){
   const item=job.items[job.nextAssessment-1];const text=clean((document.querySelector('main')||document.body).textContent||'');
   const row=[...document.querySelectorAll('tbody tr')].find(x=>norm(x.textContent).includes(norm(item.title)));
   const success=/تم (الحفظ|التعديل|التحديث|النشر) بنجاح|saved successfully|updated successfully|published successfully/i.test(text);
   if(!row&&!success)throw Error('لم أجد تأكيدًا من نور بأن النشر النهائي تم؛ لا أعيد الضغط لمنع التكرار');
   if(job.nextAssessment<job.items.length){await setJob(job,'open_create','تم حفظ النشاط؛ الانتقال للنشاط التالي في المكتبة');return}
   await setJob({...job,active:false,completed:job.items.length},'done','اكتمل حفظ الأنشطة في نور وفق تأكيد الصفحة. راجع ظهورها في حساب الطالب.');return;
  }
 if(stage==='open_question')await openQuestion(job);
 }catch(e){const job=(await browser.storage.local.get(KEY))[KEY];if(job?.active&&!/أُلغيت عملية النشاط/.test(String(e.message||e))){const reason=String(e.message||e);await pause(job,reason);show('توقفت العملية لحماية النشاط: '+reason)}}finally{busy=false}
}
// A legacy 0.6.4 job could be PAUSED before filling anything because that
// version searched the beginning of page text instead of the create_mcq route.
// On v0.6.6, a previously paused job is recoverable ONLY when its original
// editor URL is unchanged, its recorded stage is fill_question, and every
// question editor is still blank. No previous Save may have been clicked.
function legacyMCQPauseIsSafe(job, pathname=location.pathname) {
 if(!job||job.active||job.stage!=='paused'||job.pausedFromStage!=='fill_question')return false;
 if(job.pausedPath!==pathname || !/صفحة نور المفتوحة لا تطابق نوع السؤال\s+mcq\b/i.test(String(job.message||'')))return false;
 const q=job.items?.[job.nextAssessment]?.questions?.[job.nextQuestion];
 if(q?.kind!=='mcq'||questionKindFromRoute(pathname)!=='mcq')return false;
 if(currentPage()!=='question')return false;
 // Never overwrite a question that may have been manually entered after pause.
 if(editableCandidates().some(e=>clean(e.el.value??e.el.textContent).length>0))return false;
 return true;
}
// v0.6.6 filled the MCQ correctly, then stopped BEFORE pressing Save because
// it looked only for the generic «إضافة» button. Resume a paused job only
// when the same editor still contains the exact intended question, options,
// score and correct-answer index. Never retry a save that was already clicked.
function unclickedQuestionSavePauseIsSafe(job,pathname=location.pathname){
 if(!job||job.active||job.stage!=='paused'||job.pausedFromStage!=='fill_question')return false;
 if(job.pausedPath!==pathname||!/^\/teacher\/questions\/create_mcq\//i.test(pathname))return false;
 if(!/زر حفظ المفردة غير محدد/.test(String(job.message||'')))return false;
 if(currentPage()!=='question'||!questionSaveButton())return false;
 const q=job.items?.[job.nextAssessment]?.questions?.[job.nextQuestion];
 if(q?.kind!=='mcq'||questionKindFromRoute(pathname)!=='mcq')return false;
 const editors=editableCandidates().filter(x=>x.type==='rich');
 if(editors.length!==q.options?.length+1)return false;
 const expected=[q.stem,...q.options];
 if(expected.some((value,i)=>!norm(value)||norm(clean(editors[i].el.textContent))!==norm(value)))return false;
 const points=unique(['درجة المفردة','درجة السؤال','درجة','Question score','Score','Points','Marks'],{tag:'input:not([type="hidden"])'});
 if(!points||Number(points.value)!==Number(q.points))return false;
 const select=unique(['الجواب الصحيح'],{tag:'select'});
 if(!select)return false;
 const chosen=select.options[select.selectedIndex];
 const index=q.options.indexOf(q.answer)+1;
 if(index<1||!chosen)return false;
 const allowed=[String(index),'الاختيار '+index,'الاختبار '+index];
 return allowed.some(x=>norm(chosen.textContent)===norm(x)||norm(chosen.value)===norm(x));
}
async function resumeUnclickedQuestionSaveIfSafe(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!unclickedQuestionSavePauseIsSafe(job))return false;
 const record=job.items[job.nextAssessment];
 const save=questionSaveButton();
 // Persist 'await_question_save' BEFORE clicking. A navigation may unload this script.
 await setJob({...job,active:true,pausedFromStage:null},'await_question_save',
   `استكمال حفظ السؤال ${job.nextQuestion+1} من ${record.questions.length} بواسطة «إضافة مفردة»`);
 save.click();await sleep(950);return true;
}
async function resumeLegacyMCQIfSafe(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!legacyMCQPauseIsSafe(job))return false;
 // The existing narrowly scoped resume routine checks the original question
 // type again, then persists the new stage BEFORE touching the editor.
 await resumePausedQuestion();
 return true;
}
// v0.6.7 stopped on the four-pair matching question because Noor displays
// five blank rows by default. This failure occurred BEFORE clicking Save.
// Resume only on exactly the same editor with the exact unedited stem/points
// and every matching input blank. Never retry a possibly submitted question.
function legacyMatchingPauseIsSafe(job,pathname=location.pathname){
 if(!job||job.active||job.stage!=='paused'||job.pausedFromStage!=='fill_question')return false;
 if(job.pausedPath!==pathname||questionKindFromRoute(pathname)!=='matching')return false;
 if(!/حقول مطابقة العمودين لا تطابق الأزواج في الملف/.test(String(job.message||'')))return false;
 const q=job.items?.[job.nextAssessment]?.questions?.[job.nextQuestion];
 if(q?.kind!=='matching'||currentPage()!=='question')return false;
 const editor=editableCandidates().find(x=>x.type==='rich');
 if(!editor||norm(clean(editor.el.textContent))!==norm(q.stem))return false;
 const points=unique(['درجة المفردة','درجة السؤال','درجة','Question score','Score','Points','Marks'],{tag:'input:not([type="hidden"])'});
 if(!points||Number(points.value)!==Number(q.points))return false;
 try{
  const frame=editor.el.ownerDocument?.defaultView?.frameElement;
  const editorBottom=(frame||editor.el).getBoundingClientRect?.().bottom||0;
  const scoreTop=points.getBoundingClientRect?.().top??Infinity;
  const plan=globalThis.NoorMatching.plan(document,q.pairs,visible,{editorBottom,scoreTop,pairing});
  // 0.6.7 threw before writing any matching pair; do not overwrite edits.
  return plan.assignments.every(x=>!clean(x.el.value));
 }catch{return false}
}
async function resumeLegacyMatchingIfSafe(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!legacyMatchingPauseIsSafe(job))return false;
 await setJob({...job,active:true,pausedFromStage:null},'fill_question',
  `استئناف سؤال التوصيل من ${job.items[job.nextAssessment].questions.length} أسئلة دون إعادة إنشاء الواجب`);
 await runNow();return true;
}
// A previous version couldn't find Noor's «إضافة مفردة مقالية» for a
// short-text item and stopped on the question LIST before clicking anything.
// Restart only if the same list is open, the expected previous-save count is
// unchanged, and the new question is not already there. If storage was lost
// when uninstalling a temporary add-on, there is nothing to resume.
function pausedShortTextChoiceIsSafe(job,pathname=location.pathname){
 if(!job||job.active||job.stage!=='paused'||job.pausedFromStage!=='open_question'||(job.owner&&job.owner!==sessionStorage.getItem('stnNoorActivityOwner:v1')))return false;
 if(job.pausedPath!==pathname||currentPage()!=='question_list')return false;
 if(!/لا يوجد خيار واضح لإضافة/.test(String(job.message||'')))return false;
 const q=job.items?.[job.nextAssessment]?.questions?.[job.nextQuestion];
 if(!q||!typeNames[q.kind])return false;
 if(verifyQuestionOnList(q))return false;
 const count=listCount();
 if(job.nextQuestion===0)return count===0||count===null&&!document.querySelector('table tbody tr');
 const previous=job.items[job.nextAssessment].questions[job.nextQuestion-1];
 return verifyQuestionOnList(previous)||Number.isInteger(count)&&Number.isInteger(job.prevCount)&&count===job.prevCount+1;
}
async function resumePausedShortTextChoiceIfSafe(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!pausedShortTextChoiceIsSafe(job))return false;
 await setJob({...job,active:true,pausedFromStage:null},'open_question',
  'استئناف إدراج المفردة التالية بعد التحقق من الأسئلة السابقة');
 await runNow();return true;
}
// Resume the older fill-in-the-blanks pause only before Save was clicked, on
// the original editor with the original stem/points. Never resubmit unknown work.
function pausedFillBlanksIsSafe(job,pathname=location.pathname){
 if(!job||job.active||job.stage!=='paused'||job.pausedFromStage!=='fill_question')return false;
 if(job.pausedPath!==pathname||questionKindFromRoute(pathname)!=='fill_blanks')return false;
 if(!/تعذر اختيار|عدد الفراغات|حقول إجابات الفراغات|لم تظهر حقول الإجابات/.test(String(job.message||'')))return false;
 const q=job.items?.[job.nextAssessment]?.questions?.[job.nextQuestion];
 if(q?.kind!=='fill_blanks'||currentPage()!=='question')return false;
 const editor=editableCandidates().find(x=>x.type==='rich');
 if(!editor||norm(clean(editor.el.textContent))!==norm(q.stem))return false;
 const points=unique(['درجة المفردة','درجة السؤال','درجة','Question score','Score','Points','Marks'],{tag:'input:not([type="hidden"])'});
 if(!points||Number(points.value)!==Number(q.points))return false;
 // The failed step preceded saving and must not overwrite manually edited answers.
 const inputs=globalThis.NoorBlanks.answerFields(document,q.blanks.length);
 if(inputs.some(x=>String(x.value||'').trim()))return false;
 return true;
}
async function resumePausedFillBlanksIfSafe(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!pausedFillBlanksIsSafe(job))return false;
 await setJob({...job,active:true,pausedFromStage:null},'fill_question',
  'استئناف اختيار عدد الفراغات ثم كتابة الإجابات قبل حفظ المفردة');
 await runNow();return true;
}
// Safe targeted retry for the known false negative on create_mcq: that error
// happened BEFORE any question fields were written or Save was clicked.
// Never offer generic resume after an unverified save (could duplicate).
const resumableActivityStages=new Set(['open_create','await_create_page','fill_parent','await_parent_save','open_question','await_question_form','open_bulk','fill_bulk','await_bulk_save',
 'fill_question','await_question_save','activity_done','publish_ready','await_publish_form','publish_form','await_publish_save']);
function canResumeActivity(job){
 return Boolean(job&&!job.active&&job.stage==='paused'&&resumableActivityStages.has(job.pausedFromStage)&&
  (!job.owner||job.owner===sessionStorage.getItem('stnNoorActivityOwner:v1')));
}
async function resumeActivity(){
 if(busy)return;
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!canResumeActivity(job))throw Error('لا يوجد نشاط محفوظ يمكن استكماله في هذا التبويب.');
 const target=job.pausedPath||'';
 if(target!==location.pathname||(job.pausedSearch!==undefined&&job.pausedSearch!==location.search))
  throw Error('افتح صفحة نور التي توقف فيها النشاط ثم اضغط استكمال.');
 if(job.pausedFromStage==='fill_question'&&!job.manualPause)return resumePausedQuestion();
 if(job.pausedFromStage==='open_question'&&!job.manualPause)return resumePausedQuestion();
 await setJob({...job,active:true,manualPause:false,pausedFromStage:null},job.pausedFromStage,'جارٍ استكمال النشاط من آخر مرحلة محفوظة.');
 await runNow();
}
async function pauseActivity(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!job?.active||job.owner&&job.owner!==sessionStorage.getItem('stnNoorActivityOwner:v1'))return false;
 await pause({...job,manualPause:true},'أوقفت النشاط مؤقتًا. اضغط استكمال لمتابعته.');
 return true;
}
async function resumePausedQuestion(){
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!job||job.active||job.stage!=='paused')throw Error('لا توجد مفردة متوقفة يمكن استئنافها');
 if(/تعذر اختيار|عدد الفراغات|حقول إجابات الفراغات|لم تظهر حقول الإجابات/.test(String(job.message||''))){
  if(!(await resumePausedFillBlanksIfSafe()))throw Error('لم أتأكد من أن سؤال الفراغات لم يُعدَّل منذ التوقف؛ لن أكرره.');
  return;
 }
 if(/لا يوجد خيار واضح لإضافة/.test(String(job.message||''))){
  if(!(await resumePausedShortTextChoiceIfSafe()))throw Error('لم أتأكد من حالة الأسئلة المحفوظة؛ لن أنشئ أسئلة مكررة');
  return;
 }
 if(/حقول مطابقة العمودين لا تطابق الأزواج في الملف/.test(String(job.message||''))){
   const resumed=await resumeLegacyMatchingIfSafe();
   if(!resumed)throw Error('لم تعد خانات التوصيل مطابقة للسؤال السابق؛ لن أعيد الحفظ');
   return;
 }
 if(/زر حفظ المفردة غير محدد/.test(String(job.message||''))){
   const resumed=await resumeUnclickedQuestionSaveIfSafe();
   if(!resumed)throw Error('بيانات السؤال أو إجابته لم تعد مطابقة. لا يمكن إعادة الحفظ بأمان');
   return;
 }
 if(!/لا تطابق نوع السؤال|لم أتمكن من إثبات نوع محرر السؤال/.test(String(job.message||'')))throw Error('سبب التوقف ليس من النوع الآمن للاستئناف؛ لا أكرر الحفظ');
 if(job.pausedFromStage&&job.pausedFromStage!=='fill_question')throw Error('المفردة توقفت في مرحلة أخرى؛ لا أكررها');
 if(currentPage()!=='question')throw Error('افتح صفحة محرر المفردة غير المكتملة في نور');
 if(job.pausedPath&&job.pausedPath!==location.pathname)throw Error('تغيّرت صفحة المفردة منذ التوقف');
 const q=job.items?.[job.nextAssessment]?.questions?.[job.nextQuestion];
 if(!q)throw Error('معلومات المفردة السابقة غير متاحة');
 confirmQuestionEditorKind(q);
 const next={...job,active:true,pausedFromStage:null};
 await setJob(next,'fill_question','استئناف تعبئة السؤال '+(job.nextQuestion+1)+' بعد تصحيح التعرف على نوع المحرر');
 await runNow();
}
async function stop(){const data=await browser.storage.local.get(KEY);const job=data[KEY];
 if(job&&(!job.owner||job.owner===sessionStorage.getItem('stnNoorActivityOwner:v1')))await pause(job,'تم الإيقاف بواسطة المعلم');}
function isPausedActivityDate(job){
 return Boolean(job&&!job.active&&job.stage==='paused'&&job.pausedFromStage==='fill_parent'&&
  /تاريخ النشر|تاريخ نشر النشاط|تاريخ التسليم|تعذر تحديد مربع الفصل|الفصل تغير أثناء التنقل/.test(job.message||''));
}
async function resumeActivityDate(){
 if(busy)return false;
 const job=(await browser.storage.local.get(KEY))[KEY];
 if(!isPausedActivityDate(job)||job.pausedPath!==location.pathname||currentPage()!=='create')
  throw Error('افتح صفحة إضافة الواجب التي توقفت عند التاريخ أو اختيار الفصل ثم استكمل النشاط.');
 const t=unique(['العنوان','عنوان الواجب','title'],{tag:'input:not([type="hidden"])'});
 const record=job.items?.[job.nextAssessment];
 const blankBeforeClassCheck=t&&!clean(t.value)&&job.verifiedClassFromDashboard&&/الفصل تغير أثناء التنقل/.test(job.message||'');
 if(!t||!record?.title||!blankBeforeClassCheck&&clean(t.value)!==clean(record.title))throw Error('عنوان نموذج الواجب لا يطابق النشاط المتوقف.');
 contextVerify(job);
 await setJob({...job,active:true,pausedFromStage:null},'fill_parent','جارٍ التحقق من الفصل والتاريخ واستكمال النشاط.');
 await runNow();
 return true;
}
globalThis.NoorSmartAutomator={runNow,stop,canResumeActivity,resumeActivity,pauseActivity,resumePausedQuestion,isPausedActivityDate,resumeActivityDate,resumeLegacyMCQIfSafe,legacyMCQPauseIsSafe,unclickedQuestionSavePauseIsSafe,resumeUnclickedQuestionSaveIfSafe,legacyMatchingPauseIsSafe,resumeLegacyMatchingIfSafe,pausedMenuChoiceIsSafe:pausedShortTextChoiceIsSafe,pausedShortTextChoiceIsSafe,resumePausedShortTextChoiceIfSafe,pausedFillBlanksIsSafe,resumePausedFillBlanksIfSafe};
// Full page navigations: the content script is loaded again; resume the same job once.
setTimeout(async()=>{try{const blanks=await resumePausedFillBlanksIfSafe();
 if(!blanks){const shortText=await resumePausedShortTextChoiceIfSafe();
 if(!shortText){const recovered=await resumeUnclickedQuestionSaveIfSafe();
 if(!recovered){const matching=await resumeLegacyMatchingIfSafe();if(!matching){const resumed=await resumeLegacyMCQIfSafe();if(!resumed)await runNow();}}}}
 }catch(e){console.warn('Noor: safe recovery unavailable',String(e.message||e))}},1200);
setInterval(runNow,3000);
})();
