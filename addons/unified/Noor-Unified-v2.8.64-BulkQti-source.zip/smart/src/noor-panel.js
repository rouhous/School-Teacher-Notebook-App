/* The normal teacher interface. One floating panel IN Noor: upload library, unit, lesson, activity, start.
   No dashboard, mapper, JSON editor, tokens or Supabase configuration. */
(()=>{'use strict';
if(window.top!==window||!/^\/teacher\/(?:homeworks|questions)(?:\/|$)/i.test(location.pathname))return;
if(document.getElementById('noor-smart-activities-root'))return;
let KEY='stnSmartLibrary:unlinked';const RUN='noorSmartRunV1';
const BUILTIN='noorSmartBuiltinGrade10V063';
const host=document.createElement('div');host.id='noor-smart-activities-root';host.style.cssText='display:none!important;all:initial;position:fixed;bottom:18px;left:16px;z-index:2147483646;direction:rtl;';
const shadow=host.attachShadow({mode:'closed'});
shadow.innerHTML=`<style>
*{box-sizing:border-box}:host{all:initial}button,input,select{font-family:Tahoma,Arial,sans-serif}button{cursor:pointer}.wrap{direction:rtl;font-family:Tahoma,Arial,sans-serif;color:#14392b;font-size:13px}
.toggle{border:2px solid #fff;background:#176346;color:white;border-radius:24px;padding:12px 18px;box-shadow:0 4px 15px #0004;font-weight:700;font-size:14px}
.panel{position:absolute;bottom:58px;left:0;width:min(440px,calc(100vw - 32px));max-height:min(78vh,750px);overflow:auto;background:white;border:1px solid #b9d6c5;border-radius:15px;box-shadow:0 6px 30px #081e1766;direction:rtl}.panel[hidden]{display:none}
.head{position:sticky;top:0;z-index:2;background:#14563d;color:white;display:flex;justify-content:space-between;align-items:center;padding:12px 15px;font-size:15px;font-weight:bold}
.body{padding:14px}.muted{color:#5c7064;font-size:12px;line-height:1.7}.class{background:#edf7f0;padding:9px;border-radius:9px;font-weight:600;margin:4px 0 12px}.field{margin:10px 0}.field label{display:block;font-weight:600;margin-bottom:5px}
input[type=file],select,input[type=number],input[type=email],input[type=password],input[type=text],textarea{width:100%;border:1px solid #bed3c6;background:white;border-radius:9px;padding:10px;color:#173e2e;font-size:13px}input[type=file]{font-size:11px}textarea{resize:vertical;min-height:55px}.gemini{border:1px solid #c6dfcf;background:#f7fbf8;border-radius:10px;padding:10px;margin:12px 0}.gemini summary{font-weight:700;color:#145b44;cursor:pointer;padding:5px 0}.gemini .types{display:grid;grid-template-columns:1fr 1fr;gap:6px;margin:7px 0}.gemini .types label{font-size:12px;display:flex;gap:5px;align-items:center}.gemini .auth{padding:9px;border-radius:8px;background:#edf4ee;margin-top:10px}.gemini .gstatus{font-size:12px;padding:7px;background:#edf3e9;border-radius:7px;margin-top:7px;line-height:1.6;white-space:pre-wrap}.gemini .row{display:flex;gap:7px}.gemini .row>*{flex:1}.gemini .preview{margin-top:6px;font-size:12px}.gemini .preview li{padding:4px 0}.gemini input[type=checkbox]{accent-color:#187252}.gemini .subtitle{font-size:11px;color:#54705e;line-height:1.5}
.two{display:grid;grid-template-columns:1fr 1fr;gap:8px}.btn{border:0;border-radius:9px;background:#187252;color:white;padding:12px;font-size:13px;font-weight:bold}.btn:disabled{background:#9dafa5;cursor:not-allowed}.secondary{background:#eff6f1;border:1px solid #b8d2c3;color:#18523c}
.buttons{display:flex;gap:7px;align-items:center;margin-top:11px}.buttons>*{flex:1}.item{border:1px solid #d2e4d7;border-radius:9px;padding:10px;display:flex;align-items:start;gap:7px;margin:7px 0;line-height:1.5}.item input{margin-top:3px}.name{font-weight:bold;flex:1}.small{font-size:11px;color:#567162}
.status{padding:9px;background:#f4f5ed;border-right:3px solid #c8ae4c;border-radius:6px;margin-top:11px;min-height:34px;line-height:1.6;white-space:pre-wrap}
.link{border:0;background:transparent;color:#245b49;text-decoration:underline;padding:5px;font-size:11px}.close{color:white;background:none;border:0;font-size:23px;line-height:1}
.count{background:#edf3ee;border-radius:8px;padding:7px;margin-top:8px}.job{background:#e8f5ed;padding:10px;border-radius:7px;margin-top:6px}.warning{color:#8d4e10}.hidden{display:none!important}
@media(max-width:520px){.two{grid-template-columns:1fr}.panel{max-height:80vh}}
</style>
<div class="wrap"><section class="panel" id="panel" hidden aria-label="أنشطة نور الذكية">
 <header class="head"><span id="panelTitle">✦ أنشطة نور الذكية</span><button id="close" class="close" aria-label="إغلاق">×</button></header>
 <div class="body"><div id="class" class="class">قراءة الصف من نور...</div>
 <div class="field"><label for="files">أضف مكتبة الاختبارات (JSON / PDF)</label><input id="files" type="file" accept=".json,.pdf,application/json,application/pdf" multiple></div>
 <div class="two"><div class="field"><label for="unit">الوحدة</label><select id="unit"><option value="">اختر الوحدة</option></select></div>
 <div class="field"><label for="lesson">الدرس</label><select id="lesson"><option value="">اختر الدرس</option></select></div></div>
 <details id="geminiBox" class="gemini"><summary>✨ إنشاء أنشطة باستخدام Gemini</summary>
  <p class="subtitle">إنشاء أسئلة مناسبة للصف والوحدة والدرس وبأنواع موجودة في منصة نور. تُحفظ النتيجة في مكتبة الأنشطة للمراجعة قبل نقلها.</p>
  <div class="row"><div class="field"><label for="geminiCount">عدد الأسئلة</label><input id="geminiCount" type="number" min="1" max="30" step="1" value="6"></div>
  <div class="field"><label for="geminiDifficulty">الصعوبة</label><select id="geminiDifficulty"><option value="mixed">متدرجة ومتنوعة</option><option value="easy">سهلة</option><option value="medium">متوسطة</option><option value="hard">صعبة</option></select></div></div>
  <div class="field"><label for="geminiFocus">عنوان الدرس أو موضوع الأسئلة (اختياري)</label><input id="geminiFocus" type="text" maxlength="800" placeholder="مثال: Renewable Energy – solar and wind"></div>
  <div class="field"><label>أنواع الأسئلة</label><div class="types" id="geminiTypeList"></div></div>
  <details id="geminiKeyBox" class="auth"><summary>🔑 مفتاح Gemini API (مرة واحدة، دون Supabase)</summary>
   <div class="field"><label for="geminiApiKey">Gemini API key</label><input id="geminiApiKey" type="password" autocomplete="off" spellcheck="false" dir="ltr" placeholder="Paste API key from Google AI Studio"></div>
   <div class="row"><button type="button" id="geminiSaveKey" class="btn">حفظ المفتاح</button><button type="button" id="geminiTestKey" class="btn secondary">اختبار الاتصال</button></div>
   <button type="button" id="geminiClearKey" class="btn secondary" style="width:100%;margin-top:6px">حذف المفتاح المحفوظ</button>
   <p class="subtitle">المفتاح محفوظ محليًا في Firefox داخل تخزين الإضافة فقط؛ لا يُعرض داخل صفحة نور أو ملف XPI، لكنه ليس مشفّرًا بضمان مستقل. استخدم مفتاحًا مخصصًا ومقيّدًا لهذه الإضافة.</p>
  </details>
  <div class="field"><label for="geminiModel">نموذج Gemini</label><select id="geminiModel"><option value="gemini-3.5-flash-lite">Gemini 3.5 Flash-Lite (تلقائي)</option><option value="gemini-3.1-flash-lite">Gemini 3.1 Flash-Lite</option></select></div>
  <div id="geminiAccount" class="subtitle" aria-live="polite">أدخل مفتاح Gemini API مرة واحدة؛ لا يلزم Supabase أو تسجيل دخول منفصل.</div>
  <button type="button" id="geminiGenerate" class="btn" style="width:100%;margin-top:9px">✨ توليد النشاط وحفظه في المكتبة</button>
  <div class="gstatus" id="geminiStatus" role="status" aria-live="polite">حدد الوحدة والدرس، ثم اضغط توليد.</div>
  <details id="geminiPreview" class="preview" hidden><summary>معاينة الأسئلة المولدة</summary><ol id="geminiPreviewList"></ol></details>
 </details>
 <div id="items" aria-live="polite"><p class="muted">ارفع بنك الأسئلة لتظهر الأنشطة الجاهزة.</p></div>
 <div class="buttons"><button class="btn" id="start" disabled>تعبئة النشاط المحدد في نور</button><button class="btn secondary" id="stop" type="button" hidden>إيقاف</button></div>
 <button class="btn secondary" id="resumeQuestion" type="button" hidden style="width:100%;margin-top:8px">استئناف إدخال السؤال الحالي دون إعادة إنشاء الواجب</button>
 <div id="status" class="status" role="status" aria-live="polite">كل شيء من هذه النافذة. لا تحتاج إلى فتح لوحة أخرى.</div>
 <div class="buttons"><button id="clear" class="link" type="button">مسح مكتبة الإضافة</button><button id="closeJob" class="link" type="button">تصفير مهمة متوقفة</button></div>
 </div></section><button id="toggle" class="toggle" aria-expanded="false">✦ أنشطة نور</button></div>`;
const STOP_KEY='stnNoorStopAll:v1';
const readStopToken=async()=> (await browser.storage.local.get(STOP_KEY))[STOP_KEY]||'';
const $=x=>shadow.getElementById(x),norm=v=>String(v||'').trim();let library=[],selected=new Set(),ctx=null,hubCourseProof=null,hubTask='activities';
$('panelTitle').textContent='✦ أنشطة نور الذكية · v'+browser.runtime.getManifest().version;
const setStatus=s=>{$('status').textContent=String(s||'');};
function addOptions(id,items,prompt){const old=$(id).value;$(id).replaceChildren();const p=document.createElement('option');p.value='';p.textContent=prompt;$(id).appendChild(p);for(const name of items){const op=document.createElement('option');op.value=name;op.textContent=name;$(id).append(op)}if(items.includes(old))$(id).value=old;}
function refreshContext(){ctx=globalThis.__NoorSmartReadContext?.()||null;
 if(ctx?.gradeVerified){$('class').textContent=`الصف في نور: ${ctx.className} — الصف ${ctx.grade} (تلقائي)`;}
 else if(/^\/teacher\/questions(?:\/|$)/i.test(location.pathname)){
  // Questions pages show the homework title, not necessarily its class checkbox.
  // Display only the class bound to this active run; do not guess a new class.
  browser.storage.local.get(RUN).then(data=>{const j=data[RUN];$('class').textContent=j?.className?`الفصل المرتبط بهذه المهمة: ${j.className} — جارٍ إضافة الأسئلة`:'قائمة الأسئلة: افتح الواجب من صف نور أولًا';});
 }else $('class').textContent='الصف: سيُقرأ تلقائيًا من نموذج نور قبل بدء الإرسال';
}
function updateUnits(){addOptions('unit',[...new Set([...Array.from({length:12},(_,i)=>'Unit '+(i+1)),...NoorLibrary.categories(library)])],'اختر الوحدة');updateLessons()}
function updateLessons(){addOptions('lesson',[...new Set([...Array.from({length:10},(_,i)=>'Lesson '+(i+1)),...NoorLibrary.lessons(library,$('unit').value)])],'اختر الدرس');renderItems()}
function renderItems(){const u=$('unit').value,l=$('lesson').value,filtered=library.filter(a=>NoorLibrary.norm(a.unit)===NoorLibrary.norm(u)&&NoorLibrary.norm(a.lesson)===NoorLibrary.norm(l));
 $('items').replaceChildren();selected=new Set([...selected].filter(id=>filtered.some(a=>a.id===id)));
 if(!u||!l){const p=document.createElement('p');p.className='muted';p.textContent=library.length?'اختر الوحدة والدرس لتظهر الأنشطة الجاهزة.':'المكتبة فارغة. اختر ملف JSON أو PDF.';$('items').append(p)}
 for(const a of filtered){const label=document.createElement('label');label.className='item';const cb=document.createElement('input');cb.type='checkbox';cb.checked=selected.has(a.id);cb.addEventListener('change',()=>{if(cb.checked)selected.add(a.id);else selected.delete(a.id);refreshStart()});const name=document.createElement('div');name.className='name';name.textContent=a.title;const desc=document.createElement('div');desc.className='small';desc.textContent=`${a.questions.length} سؤال · ${a.questions.reduce((n,q)=>n+(Number(q.points)||0),0)} درجة`;name.append(desc);label.append(cb,name);$('items').append(label)}
 refreshStart();
}
function refreshStart(){ $('start').disabled=!selected.size; }
function updateResume(job){
 $('resumeQuestion').hidden=!(job?.stage==='paused'&&
   /لا تطابق نوع السؤال|لم أتمكن من إثبات نوع محرر السؤال|زر حفظ المفردة غير محدد|حقول مطابقة العمودين لا تطابق الأزواج في الملف|لا يوجد خيار واضح لإضافة|تعذر اختيار|عدد الفراغات|حقول إجابات الفراغات|لم تظهر حقول الإجابات/.test(String(job.message||''))&&
   /^\/teacher\/questions\/(?:create|add|edit|new|index|list)/i.test(location.pathname));
 $('resumeQuestion').textContent=/زر حفظ المفردة غير محدد|حقول مطابقة العمودين لا تطابق الأزواج في الملف/.test(String(job?.message||''))
   ? 'متابعة حفظ السؤال الحالي بـ «إضافة مفردة»' : 'استئناف إضافة السؤال دون إعادة إنشاء الواجب';
}

async function saveLibrary(){await browser.storage.local.set({[KEY]:library});}
function upsert(a){
 // Don't silently merge two revisions of a test. Keep one copy per filename/lesson/title; replace only matching import.
 a.id=a.id||crypto.randomUUID();a.uploadedAt=new Date().toISOString();
 const at=library.findIndex(x=>x.fileName===a.fileName&&x.title===a.title&&x.unit===a.unit&&x.lesson===a.lesson);
 if(at>=0){a.id=library[at].id;library[at]=a;}else library.push(a);
}
// Import the teacher's existing Grade 10 bank with the extension. Repair only fields
// accidentally stripped by older importers, never overwrite edited questions.
async function ensureGrade10Library(){return ''; /* clean library per teacher */}

function preferredUnitLesson(){
 if(!library.length)return;const units=NoorLibrary.categories(library);
 if(units.length===1)$('unit').value=units[0];updateLessons();
 const les=NoorLibrary.lessons(library,$('unit').value);if(les.length===1)$('lesson').value=les[0];renderItems();
}
function toBase64(file){return new Promise((res,rej)=>{const r=new FileReader();r.onerror=()=>rej(Error('فشل قراءة PDF'));r.onload=()=>res(String(r.result||'').split(',')[1]);r.readAsDataURL(file)})}
async function importFiles(files){const errors=[],added=[];for(const f of files){try{
 if(f.name.toLowerCase().endsWith('.json')){
   if(f.size>8*1024*1024)throw Error('ملف JSON أكبر من 8 MB');
   const parsed=NoorLibrary.entries(JSON.parse(await f.text()),f.name);
   for(const a of parsed.assessments){a.fileName=f.name;upsert(a);added.push(a)}
   if(parsed.warnings.length)errors.push(`${f.name}: ${parsed.warnings.join('، ')}`);
 }else if(f.name.toLowerCase().endsWith('.pdf')){
   if(f.size>7*1024*1024)throw Error('ملف PDF أكبر من 7 MB');
   // PDF uses the teacher's own Gemini API key, directly from extension background. JSON never contacts any server.
   const out=await browser.runtime.sendMessage({type:'NOOR_ACTIVITY_PARSE_PDF',pdfBase64:await toBase64(f),name:f.name,grade:hubCourseProof?.grade||ctx?.grade||'',unit:$('unit').value,lesson:$('lesson').value,model:$('geminiModel').value});
   if(!out?.ok)throw Error(out?.error||'تعذر تحليل PDF');
   const parsed=NoorLibrary.entries({title:f.name.replace(/\.pdf$/i,''),unit:$('unit').value,lesson:$('lesson').value,questions:out.questions},f.name);
   for(const a of parsed.assessments){a.fileName=f.name;upsert(a);added.push(a)}
 }else throw Error('الملف ليس JSON أو PDF');
 }catch(e){errors.push(`${f.name}: ${String(e.message||e)}`)}}
 await saveLibrary();updateUnits();preferredUnitLesson();
 if(added.length===1){$('unit').value=added[0].unit;updateLessons();$('lesson').value=added[0].lesson;renderItems();selected.add(added[0].id);renderItems();const cb=$('items').querySelector('input[type="checkbox"]');if(cb){cb.checked=true;selected.add(added[0].id);refreshStart()}}
 setStatus(`تم حفظ ${added.length} نشاط في المكتبة.${errors.length?'\nملاحظات: '+errors.join(' | '):''}`);
 return added;
}
async function createRun(publishDate='',stopToken='',lessonNodeId='',allowUnlinkedLesson=false,tryLesson=false,bulk=false){const assays=library.filter(x=>selected.has(x.id));if(!assays.length)throw Error('اختر نشاطًا واحدًا على الأقل');
 const unit=$('unit').value,lesson=$('lesson').value;if(!unit||!lesson)throw Error('اختر الوحدة والدرس');
 // Distinguish one activity from a batch, support both. Unchecked class is still a valid class cue only on Noor form.
 const verified=ctx?.gradeVerified;
 const official=hubCourseProof&&globalThis.NoorCourseCatalog?.get?.(hubCourseProof.cid);
 const proofOK=!!(official?.cidNumeric&&String(official.cidNumeric)===String(hubCourseProof?.cid)&&
    Number(official.grade)===Number(hubCourseProof.grade)&&
    String(official.label).trim()===String(hubCourseProof.label).trim()&&
    decodeURIComponent(location.pathname.match(/(?:^|\/)cid:([^/?#]+)/i)?.[1]||'')===String(hubCourseProof.cid));
 if(hubCourseProof&&!proofOK)throw Error('لم يثبت ارتباط الصف المختار برابط المهام الحالي؛ لن يُنشأ واجب جديد.');
 const bound=proofOK?hubCourseProof:null;
 if(!verified&&!bound)throw Error('افتح واجب الصف الصحيح من نور أو اختر صفًا مؤكّدًا من البطاقة الرئيسية.');
 const effectiveGrade=bound?.grade||ctx.grade;
 const effectiveName=bound?.label||ctx?.className||'';
 const plan=[];const notes=[];
 for(const a of assays){
  if(!a.questions.length)throw Error('نشاط بلا أسئلة: '+a.title);
  if(a.grade&&NoorContext.parseGrade(String(a.grade))&&NoorContext.parseGrade(String(a.grade))!==Number(effectiveGrade))throw Error('صف ملف '+a.title+' لا يطابق الصف في نور');
  const original=a.questions.map(q=>NoorSchema.normalizeQuestion(q,{unit,lesson,grade:effectiveGrade}));
  original.forEach((q,i)=>{const problems=NoorSchema.validateQuestion(q);if(problems.length)throw Error('السؤال '+(i+1)+' ('+(NoorSchema.label[q?.kind]||q?.kind||'غير معروف')+'): '+problems.join('، '));});
  const converted=NoorSchema.prepareForNoor(original);
  if(bulk&&!globalThis.NoorBulkItems?.supported(converted.questions))throw Error('تتضمن الأسئلة نوعًا غير متاح في نموذج المجموعة. اختر مفردة تلو الأخرى.');
  converted.questions.forEach((q,i)=>{const problems=NoorSchema.validateQuestion(q);if(problems.length)throw Error('المفردة '+(i+1)+': '+problems.join('، '));});
  // Image-click and attachment questions require actual file bytes; a JSON filename is not an uploaded media file.
  const unsupported=converted.questions.find(q=>['content','attachment','image_click','ordering'].includes(q.kind));
  if(unsupported)throw Error('سؤال «'+(NoorSchema.label[unsupported.kind]||unsupported.kind)+'» يحتاج ملفًا/محررًا مخصصًا غير متاح بعد. لم أحذف السؤال أو أغيّر إجابته.');
  const sourcePoints=original.reduce((n,q)=>n+q.points,0);
  const convertedPoints=converted.questions.reduce((n,q)=>n+q.points,0);
  if(Math.abs(sourcePoints-convertedPoints)>0.001)throw Error('مجموع الدرجات تغير أثناء تجهيز الأسئلة؛ أوقفت النقل');
  notes.push(...converted.notes);
  plan.push({id:a.id,title:a.title,unit,lesson,lessonNodeId,grade:effectiveGrade,questions:converted.questions,points:sourcePoints});
 }
 const owner=crypto.randomUUID();sessionStorage.setItem('stnNoorActivityOwner:v1',owner);
 const job={id:crypto.randomUUID(),owner,bulk,stage:'open_create',nextAssessment:0,nextQuestion:0,items:plan,grade:effectiveGrade,className:effectiveName,cid:bound?.cid||ctx?.cid||null,verifiedClassFromDashboard:Boolean(bound),allowUnlinkedLesson:Boolean(bound&&allowUnlinkedLesson),tryLesson:Boolean(tryLesson),publishDate,stopToken,originTab:null,createdAt:Date.now(),active:true,history:[],completed:0,notes};
 if(stopToken!==await readStopToken())throw Error('أُلغيت عملية النشاط.');
 await browser.storage.local.set({[RUN]:job});
 return job;
}
async function start({publishDate='',propagateError=false,expectedStopToken,lessonNodeId='',allowUnlinkedLesson=false,tryLesson=false,bulk=false }={}){try{refreshContext();const existing=(await browser.storage.local.get(RUN))[RUN];if(existing?.active)throw Error('هناك نقل جارٍ بالفعل؛ لا تبدأ نقلًا ثانيًا');if(!/\/teacher\/homeworks(?:\/|$)/i.test(location.pathname))throw Error('افتح صفحة المهام الإلكترونية لإضافة نشاط جديد');const stopToken=await readStopToken();if(expectedStopToken!==undefined&&stopToken!==expectedStopToken)throw Error('أُلغيت عملية النشاط.');const job=await createRun(publishDate,stopToken,lessonNodeId,allowUnlinkedLesson,tryLesson,bulk);setStatus(`بدأ تجهيز ${job.items.length} نشاط (${job.items.reduce((n,a)=>n+a.questions.length,0)} مفردة). سيتم استكمال الخطوات داخل نور.${job.notes?.length?'\n'+job.notes.join('\n'):''}`);$('start').disabled=true;$('stop').hidden=false;await globalThis.NoorSmartAutomator?.runNow?.();return job;}
catch(e){setStatus('توقف: '+String(e.message||e));refreshStart();if(propagateError)throw e;}}
$('toggle').addEventListener('click',async()=>{$('panel').hidden=!$('panel').hidden;$('toggle').setAttribute('aria-expanded',String(!$('panel').hidden));refreshContext();await browser.storage.local.set({noorSmartPanelOpen:!$('panel').hidden})});
$('close').addEventListener('click',()=>{$('panel').hidden=true;$('toggle').setAttribute('aria-expanded','false');browser.storage.local.set({noorSmartPanelOpen:false})});
$('files').addEventListener('change',async()=>{const files=[...$('files').files];$('files').value='';if(files.length){setStatus('جارٍ استيراد ملفات المكتبة...');await importFiles(files)}});
// Gemini: all operations originate in this Noor panel, with authentication kept in the extension background.
for(const spec of NoorGemini.KINDS){
 const label=document.createElement('label');const check=document.createElement('input');check.type='checkbox';check.value=spec.kind;check.checked=spec.default;label.append(check,document.createTextNode(spec.label));$('geminiTypeList').append(label);
}
const gstatus=s=>{$('geminiStatus').textContent=String(s||'')};
let geminiConnected=false;
async function checkGeminiLogin(){
 const response=await browser.runtime.sendMessage({type:'NOOR_ACTIVITY_GEMINI_STATUS'});
 geminiConnected=!!response?.connected;
 $('geminiAccount').textContent=geminiConnected?'✓ مفتاح Gemini API محفوظ محليًا. يمكنك توليد الأسئلة أو تحليل PDF.':'أدخل مفتاح Gemini API مرة واحدة داخل «مفتاح Gemini API». لا حاجة إلى Supabase.';
 return geminiConnected;
}
$('geminiSaveKey').addEventListener('click',async()=>{
 const btn=$('geminiSaveKey');btn.disabled=true;
 try{const response=await browser.runtime.sendMessage({type:'NOOR_ACTIVITY_GEMINI_SAVE_KEY',apiKey:$('geminiApiKey').value.trim()});
  if(!response?.ok)throw Error(response?.error||'تعذر حفظ المفتاح');
  $('geminiApiKey').value='';await checkGeminiLogin();gstatus('✓ تم حفظ مفتاح Gemini محليًا. يمكن اختبار الاتصال أو توليد النشاط.');
 }catch(e){gstatus('تعذر حفظ المفتاح: '+e.message)}finally{btn.disabled=false;$('geminiApiKey').value=''}
});
$('geminiTestKey').addEventListener('click',async()=>{
 const btn=$('geminiTestKey');btn.disabled=true;
 try{const response=await browser.runtime.sendMessage({type:'NOOR_ACTIVITY_GEMINI_TEST'});
  if(!response?.ok)throw Error(response?.error||'فشل اختبار الاتصال');gstatus('✓ الاتصال المباشر بـGemini يعمل.');
 }catch(e){gstatus('تعذر اتصال Gemini: '+e.message)}finally{btn.disabled=false}
});
$('geminiClearKey').addEventListener('click',async()=>{
 const response=await browser.runtime.sendMessage({type:'NOOR_ACTIVITY_GEMINI_CLEAR_KEY'});
 if(response?.ok){geminiConnected=false;$('geminiApiKey').value='';await checkGeminiLogin();gstatus('حُذف مفتاح Gemini من تخزين Firefox.');}
});
$('geminiBox').addEventListener('toggle',()=>{if($('geminiBox').open)checkGeminiLogin().catch(e=>gstatus(e.message))});
async function generateActivityFromPanel(){
 const btn=$('geminiGenerate');btn.disabled=true;$('geminiPreview').hidden=true;
 try{
  refreshContext();let grade=hubCourseProof?.grade||(ctx?.gradeVerified?ctx.grade:null);
  if(!grade && /^\/teacher\/questions(?:\/|$)/i.test(location.pathname)){
   const old=(await browser.storage.local.get(RUN))[RUN];
   const cid=location.pathname.match(/(?:^|\/)cid:([^/]+)/i)?.[1];
   if(old?.grade && old?.className && cid && old.cid===decodeURIComponent(cid))grade=old.grade;
  }
  const kinds=[...$('geminiTypeList').querySelectorAll('input[type=checkbox]:checked')].map(x=>x.value);
  const request=NoorGemini.makeRequest({grade,unit:$('unit').value,lesson:$('lesson').value,
   kinds,subject:hubCourseProof?.subject||globalThis.NoorCourseCatalog?.subjectOf?.(ctx?.className)||'',count:Number($('geminiCount').value),difficulty:$('geminiDifficulty').value,
   title:`${hubTask==='exam'?'اختبار':'نشاط'} — ${$('unit').value} / ${$('lesson').value}`,description:$('geminiFocus').value});
  if(!geminiConnected && !(await checkGeminiLogin())){
   $('geminiKeyBox').open=true;throw Error('احفظ مفتاح Gemini API الخاص بك مرة واحدة قبل التوليد.');
  }
  gstatus('جارٍ إنشاء الأسئلة والتحقق من الإجابات والدرجات...');
  const model=$('geminiModel').value;
  const parsed=await NoorGemini.generateComplete(request,NoorSchema,
   attempt=>browser.runtime.sendMessage({type:'NOOR_ACTIVITY_GEMINI_GENERATE',...attempt,model}),
   missing=>gstatus('جارٍ استكمال '+missing+' من الأسئلة الناقصة بعد التحقق…'));
  const date=new Date().toISOString().replace(/[:.]/g,'-');
  if(!parsed.allValid||parsed.questions.length!==request.count)throw Error('المطلوب '+request.count+' أسئلة صالحة. تحقق Gemini من '+parsed.questions.length+' فقط. '+parsed.issues.slice(0,3).join('، '));
  const a={id:crypto.randomUUID(),title:request.title+' · '+new Date().toLocaleString('ar-OM'),unit:request.unit,lesson:request.lesson,subject:request.subject,grade:request.grade,
   fileName:'gemini-'+date+'.json',questions:parsed.questions,source:'gemini',warnings:[...parsed.warnings,...parsed.issues]};
  upsert(a);await saveLibrary();
  // Keep a shared question bank in extension storage. The legacy dashboard can
  // import this collection into its IndexedDB when opened; no extra user action.
  const teacher=await window.NOOR_TEACHER_PROFILE.active();
  const geminiBankKey='stnSmartGeminiBank:'+teacher;
  const saved=(await browser.storage.local.get(geminiBankKey))[geminiBankKey];
  const byId=new Map((Array.isArray(saved)?saved:[]).filter(q=>q?.id).map(q=>[q.id,q]));
  for(const q of parsed.questions)byId.set(q.id,q);
  await browser.storage.local.set({[geminiBankKey]:[...byId.values()].slice(-1000)});
  $('unit').value=request.unit;updateLessons();$('lesson').value=request.lesson;
  if(parsed.allValid)selected.add(a.id);
  renderItems();
  const list=$('geminiPreviewList');list.replaceChildren();
  for(const q of parsed.questions){const li=document.createElement('li');li.textContent=`${NoorSchema.label[q.kind]||q.kind} (${q.points} درجة): ${q.stem}`;list.append(li)}
  $('geminiPreview').hidden=false;
  const details=[`✓ تم إنشاء وحفظ ${parsed.questions.length} سؤالًا (${parsed.totalPoints} درجة) في مكتبة ${request.unit} / ${request.lesson}. نموذج ${parsed.modelUsed||'Gemini Lite'}.`,
   parsed.allValid?'✓ تم تحديد النشاط تلقائيًا. راجع الأسئلة ثم اضغط «تعبئة النشاط المحدد في نور».':'تنبيه: لم يُحدَّد النشاط للنقل تلقائيًا بسبب أسئلة غير مكتملة. راجع التحذيرات أولًا.',
   ...parsed.issues.slice(0,6),...parsed.warnings.slice(0,4)];
  gstatus(details.join('\n'));setStatus('أُضيف نشاط Gemini إلى المكتبة. راجع المعاينة ثم انقله إلى نور.');
  return {ok:true,assessment:a,issues:parsed.issues};
 }catch(e){gstatus('توقف التوليد: '+String(e.message||e));return {ok:false,error:String(e.message||e)};}finally{btn.disabled=false}
}
$('geminiGenerate').addEventListener('click',generateActivityFromPanel);
$('unit').addEventListener('change',updateLessons);$('lesson').addEventListener('change',renderItems);$('start').addEventListener('click',start);
$('stop').addEventListener('click',async()=>{await globalThis.NoorSmartAutomator?.stop?.();setStatus('تم إيقاف التعبئة. لم يُضغط زر نشر غير متحقق منه.')});
$('resumeQuestion').addEventListener('click',async()=>{
 try{await globalThis.NoorSmartAutomator?.resumePausedQuestion?.();$('resumeQuestion').hidden=true}
 catch(e){setStatus('تعذر الاستئناف الآمن: '+String(e.message||e))}
});

$('clear').addEventListener('click',async()=>{if(!confirm('حذف مكتبة الاختبارات المحفوظة من هذه الإضافة؟'))return;library=[];await saveLibrary();updateUnits();setStatus('المكتبة فارغة')});
$('closeJob').addEventListener('click',async()=>{await browser.storage.local.remove(RUN);setStatus('تم تصفير العملية المحفوظة. أنشطتك لا تزال محفوظة في المكتبة.')});
browser.storage.onChanged.addListener((changes,area)=>{if(area!=='local'||!changes[RUN])return;const j=changes[RUN].newValue;if(j?.message)setStatus(j.message);$('stop').hidden=!j?.active;updateResume(j);refreshStart();});
browser.runtime.onMessage.addListener(message=>{if(message?.type==='NOOR_PANEL_STATUS'||message?.type==='NOOR_AUTOMATOR_STATUS'){setStatus(message.message||'');$('panel').hidden=false;return Promise.resolve({ok:true})}if(message?.type==='NOOR_PANEL_TOGGLE'){$('toggle').click();return Promise.resolve({ok:true})}});

function hubSetChoice(id,value){
 const el=$(id),txt=String(value||'').trim();
 if(!txt)return;
 if(![...el.options].some(x=>x.value===txt)){const op=document.createElement('option');op.value=txt;op.textContent=txt;el.append(op)}
 el.value=txt;
}
async function hubPrepare(options={}){
 await hubReady;
 refreshContext();
 hubCourseProof=options.courseProof||null;hubTask=options.task==='exam'?'exam':'activities';
 if(options.courseProof&&!options.courseProof.subject)throw Error('مادة الصف غير معروفة؛ لا يُسمح بتوليد أسئلة افتراضية بالإنجليزية.');
 hubSetChoice('unit',options.unit);updateLessons();
 hubSetChoice('lesson',options.lesson);renderItems();
 if(Number(options.count)>0)$('geminiCount').value=String(Math.min(30,Math.max(1,Number(options.count))));
 if(Array.isArray(options.kinds)&&options.kinds.length){const allowed=new Set(options.kinds);$('geminiTypeList').querySelectorAll('input[type=checkbox]').forEach(el=>el.checked=allowed.has(el.value));}
 $('geminiModel').value='gemini-3.5-flash-lite';
 $('geminiFocus').value=String(options.focus||'').slice(0,800);
 await checkGeminiLogin();
}
let hubReadyResolve;
const hubReady=new Promise(resolve=>hubReadyResolve=resolve);
globalThis.NoorSmartHub=Object.freeze({
 async generate(options){await hubPrepare(options);return generateActivityFromPanel()},
 async importFile(file,options){
  await hubPrepare(options);
  const entries=await importFiles([file]);
  return {entries:entries.map(entry=>({id:entry.id,title:entry.title,questionCount:entry.questions.length})),status:$('status').textContent};
 },
 async publish(options){await this.publishSelection({...options,ids:(await this.list(options)).map(a=>a.id)});return $('status').textContent},
 async list(options={}){await hubReady;const unit=NoorLibrary.norm(options.unit),lesson=NoorLibrary.norm(options.lesson);return library.filter(a=>(!unit||NoorLibrary.norm(a.unit)===unit)&&(!lesson||NoorLibrary.norm(a.lesson)===lesson)).map(a=>({id:a.id,title:a.title,unit:a.unit,lesson:a.lesson,questionCount:a.questions.length,subject:a.subject||''}));},
 async publishSelection(options){const expectedStopToken=await readStopToken();await hubPrepare(options);if(options.publishDate&&!/^\d{4}-\d{2}-\d{2}$/.test(options.publishDate))throw Error('تاريخ نشر النشاط غير صحيح');
  const ids=[...new Set(Array.isArray(options.ids)?options.ids:[])];if(!ids.length||ids.length>25)throw Error('اختر من 1 إلى 25 نشاطًا للنشر');
  const candidates=library.filter(a=>ids.includes(a.id)&&(options.imported||NoorLibrary.norm(a.unit)===NoorLibrary.norm(options.unit)&&NoorLibrary.norm(a.lesson)===NoorLibrary.norm(options.lesson)));
  if(Number.isInteger(options.expectedCount)&&candidates.some(a=>a.questions.length!==options.expectedCount))throw Error('عدد الأسئلة في النشاط لا يطابق العدد المحدد.');
  if(candidates.length!==ids.length)throw Error('بعض الأنشطة لا تطابق الدرس أو الوحدة المختارين؛ لم أغيّر نور');
  if(options.courseProof?.subject && candidates.some(a=>a.subject&&NoorLibrary.norm(a.subject)!==NoorLibrary.norm(options.courseProof.subject)))throw Error('مادة أحد الأنشطة المستوردة مختلفة عن مادة الصف. أوقف النقل.');
  selected.clear();for(const a of candidates)selected.add(a.id);await start({publishDate:options.publishDate||'',propagateError:true,expectedStopToken,lessonNodeId:options.lessonNodeId||'',allowUnlinkedLesson:options.allowUnlinkedLesson===true,tryLesson:options.tryLesson===true,bulk:options.bulk===true});return $('status').textContent;
 },
 async summary(){await hubReady;return {status:$('status').textContent,stored:library.length,context:globalThis.__NoorSmartReadContext?.()||null}},
 async stop(){return globalThis.NoorSmartAutomator?.stop?.()}
});

(document.documentElement||document.body).append(host);
(async()=>{try{const id=await window.NOOR_TEACHER_PROFILE?.active?.();if(!id){setStatus('افتح دفتر المعلم بحسابك أولًا.');hubReadyResolve();return;}KEY='stnSmartLibrary:'+id;library=(await browser.storage.local.get(KEY))[KEY]||[];refreshContext();const migration=await ensureGrade10Library();updateUnits();preferredUnitLesson();if(migration)setStatus(migration);const {noorSmartPanelOpen=false,[RUN]:job}=await browser.storage.local.get(['noorSmartPanelOpen',RUN]);
  if(job?.items?.length && /^\/teacher\/questions(?:\/|$)/i.test(location.pathname)){
   const active=job.items[Math.min(job.nextAssessment||0,job.items.length-1)];
   if(active?.unit && [...$('unit').options].some(x=>x.value===active.unit)){
    $('unit').value=active.unit;updateLessons();
    if([...$('lesson').options].some(x=>x.value===active.lesson)){$('lesson').value=active.lesson;renderItems();}
   }
  }$('panel').hidden=!noorSmartPanelOpen;if(job&&(job.active||job.stage==='paused')){
  $('panel').hidden=false;$('stop').hidden=!job.active;updateResume(job);setStatus(job.message||'استكمال التعبئة السابقة في نور…');
 } $('toggle').setAttribute('aria-expanded',String(!$('panel').hidden));}catch(e){setStatus(String(e.message||e))}finally{hubReadyResolve()}})();
})();
