/* Open only the selected teacher course card and its requested feature page. */
(function(root){'use strict';
 const normalize=text=>String(text||'').normalize('NFKC').replace(/[أإآ]/g,'ا').replace(/ة/g,'ه').replace(/[\u064b-\u065f\u0640]/g,'').replace(/[٠-٩]/g,c=>String(c.charCodeAt(0)-1632)).replace(/[۰-۹]/g,c=>String(c.charCodeAt(0)-1776))
  .replace(/[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/g,'').replace(/\s+/g,' ').trim();
 const visible=el=>el?.getClientRects?.().length&&!el.disabled&&el.getAttribute('aria-disabled')!=='true'&&getComputedStyle(el).visibility!=='hidden';
 const label=el=>normalize(el.getAttribute('aria-label')||el.textContent||el.value);
 const controls='a,button,[role="button"],[role="tab"],[onclick],[data-slide-to],[data-bs-slide-to],[data-page],[data-slide],input[type="button"],input[type="submit"]';
 function action(scope,match){
  if(!scope)return null;
  const items=[...scope.querySelectorAll(controls)].filter(el=>visible(el)&&!el.closest('#stnNoorHub')&&match.test(label(el)));
  const unique=items.filter(el=>!items.some(parent=>parent!==el&&parent.contains(el)));
  return unique.length===1?unique[0]:null;
 }
 function safeClick(element){
  const anchor=element?.closest?.('a');
  if(!element)return false;
  if(anchor?.href&&/^(?:https?:|\/)/i.test(anchor.getAttribute('href')||'')){
   const url=new URL(anchor.href,location.href);
   if(url.origin!==location.origin||!/^\/(?:teacher|digitalrepository|digital-repository)(?:\/|$)/i.test(url.pathname))return false;
   if(anchor.target==='_blank')anchor.target='_self';
  }else if(anchor&&/^javascript:/i.test(anchor.getAttribute('href')||'')&&
   !/^javascript:\s*(?:void\s*\(0\)|;?)\s*;?$/i.test(anchor.getAttribute('href')))return false;
  element.click();return true;
 }
 const popovers=()=>[...document.querySelectorAll('.popover,.dropdown-menu,[role="menu"],[role="dialog"],[class*="course-actions"],[class*="material-actions"]')]
  .filter(el=>visible(el)&&!el.closest('#stnNoorHub'));
 let opened=null;
 function next(course,page,match,createForScope){
  const cards=(root.NoorCourseCatalog?.cards?.()||[]).filter(c=>normalize(c.label)===normalize(course.label));
  if(cards.length!==1)return null;
  const card=cards[0].element;
  const directCreate=createForScope?.(card);
  if(directCreate)return {element:directCreate,step:'create'};
  const direct=action(card,match);
  if(direct)return {element:direct,step:'feature'};
  let scopes=[card];
  if(opened?.card===card){
   const fresh=popovers().filter(el=>!opened.previous.has(el)||opened.previous.get(el)!==normalize(el.textContent));
   if(fresh.length===1)scopes=[fresh[0],card];
  }
  for(const scope of scopes){
   const create=createForScope?.(scope);
   if(create)return {element:create,step:'create'};
   const feature=action(scope,match);
   if(feature)return {element:feature,step:'feature'};
   const indicators=[...scope.querySelectorAll('[data-slide-to],[data-bs-slide-to],[data-page]')].filter(visible);
   const indicated=indicators.filter(el=>el.getAttribute('data-page')===String(page)||
    (el.getAttribute('data-bs-slide-to')||el.getAttribute('data-slide-to'))===String(page-1));
   const pager=(indicated.length===1?indicated[0]:null)||action(scope,new RegExp('^(?:'+page+'|(?:ال)?صفحه '+page+'|(?:Go to |Slide |Activate )?Page '+page+'|Slide '+page+')$','i'));
   const arrow=[...scope.querySelectorAll('[data-slide="next"],[data-bs-slide="next"],.carousel-control-next')].filter(visible);
   const carousel=action(scope,/^(?:التالي|next|›|»|❯|→)$/i)||(arrow.length===1?arrow[0]:null);
   const current=pager&&(pager.getAttribute('aria-current')==='page'||pager.classList.contains('active')||pager.parentElement?.classList.contains('active'));
   if(pager&&!current)return {element:pager,step:'page'};
   if(carousel&&!current)return {element:carousel,step:'next'};
  }
  if(opened?.card===card)return null;
  opened={card,previous:new Map(popovers().map(el=>[el,normalize(el.textContent)]))};
  return {element:card.querySelector('[data-toggle="popover"],[data-bs-toggle="popover"],[data-toggle="dropdown"],[data-bs-toggle="dropdown"],[aria-haspopup],button[type="button"],[role="button"]')||card,step:'open'};
 }
 root.NoorClassCard=Object.freeze({action,next,safeClick,visible,normalize,isHome:()=>/^\/teacher\/?$/i.test(location.pathname)});
})(globalThis);
