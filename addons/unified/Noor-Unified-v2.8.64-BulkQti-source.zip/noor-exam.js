/* Independent Noor exam flow using the visible teacher interface. */
(function(root){'use strict';
 if(window.top!==window)return;
 const KEY='stnNoorExamRun:v1',TTL=2*60*60*1000;
 const card=root.NoorClassCard, editor=root.NoorQuestionEditor;
 const read=()=>{
  try{
   const job=JSON.parse(sessionStorage.getItem(KEY)||'null');
   if(job&&Date.now()-job.at<TTL)return job;
   if(job?.fileKey)browser.storage.local.remove(job.fileKey).catch(()=>{});
  }catch(_){}
  sessionStorage.removeItem(KEY);
  return null;
 };
 const write=job=>sessionStorage.setItem(KEY,JSON.stringify(job));
 const teacher=()=>root.NOOR_TEACHER_PROFILE?.active?.();
 const active=job=>read()?.id===job.id;
 const status=text=>{root.dispatchEvent(new CustomEvent('stnNoorExamStatus',{detail:String(text)}));};
 const action=pattern=>card.action(document,pattern);
 const field=(scope,pattern)=>{
  const candidates=[...scope.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="radio"]):not([type="checkbox"]),textarea,select')]
   .filter(el=>card.visible(el)&&!el.closest('#stnNoorHub')&&[el.placeholder,el.getAttribute('aria-label'),...[...(el.labels||[])].map(label=>label.textContent)].some(name=>pattern.test(card.normalize(name))));
  return candidates.length===1?candidates[0]:null;
 };
 const titles=/^(?:العنوان|عنوان الاختبار|Title|Exam title)(?:\s*\*)?$/i;
 const duration=/وقت الاختبار بالدقائق|مده الاختبار|duration|time limit/i;
 const publication=/تاريخ النشر|publish date|publication date/i;
 const deadline=/تاريخ التسليم المتاخر|late submission|late deadline/i;
 const feature=/^(?:الاختبار|الاختبارات|الاختبارات الالكترونيه|(?:Electronic )?Exams|Tests)$/i;
 const create=/^(?:انشاء الاختبارات|انشاء اختبار(?: جديد)?|اضافه (?:اختبار(?: جديد)?|الاختبارات)|(?:Add|Create)(?: (?:a|new))? (?:exam|test))(?:\s*\+)?$/i;
 const examRow=/^(?:\+\s*)?(?:انشاء )?(?:الاختبارات|الاختبار|الاختبارات الالكترونيه|(?:Electronic )?Exams|Tests)\s*\+?$/i;
 function cardCreate(scope){
  const explicit=card.action(scope,create);
  if(explicit)return explicit;
  const all=[...scope.querySelectorAll('li,tr,div,.list-group-item,[class*="course-action"],[class*="material-action"]')].filter(card.visible)
   .filter(row=>examRow.test(card.normalize(row.textContent)));
  const plusControls=new Set();
  for(const row of all){
   const plus=card.action(row,/^(?:\+|اضافه|انشاء|Add|Create)$/i);
   if(plus){plusControls.add(plus);continue;}
   for(const el of [...row.querySelectorAll('a,button,[role="button"]')].filter(card.visible)){
    if(/اضافه|انشاء|add|create/.test(card.normalize(el.getAttribute('title')).toLowerCase())||el.querySelector('[class*="plus"],[data-icon="plus"]'))plusControls.add(el);
   }
  }
  if(plusControls.size)return plusControls.size===1?[...plusControls][0]:null;
  const links=new Set(all.map(row=>card.action(row,examRow)).filter(Boolean));
  return links.size===1?[...links][0]:null;
 }
 const dropdown=/^(?:اضافه مفرده جديد(?:ه)?|Add new (?:question|item))$/i;
 const nextStep=/^(?:التالي|متابعه|Next|Continue)$/i;
 const selectClass=job=>root.NoorVisibleClass.select({className:job.course.label,grade:job.course.grade,verifiedClassFromDashboard:true,visibleOnly:true});
 function setField(el,value){
  const proto=el.tagName==='SELECT'?HTMLSelectElement.prototype:el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto,'value').set.call(el,value);
  el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));
  if(!el.value)throw Error('لم يقبل نور قيمة أحد حقول الاختبار المطلوبة.');
 }
 function dateValue(el,iso){
  if(el.type==='datetime-local')return iso+'T'+(/T(\d{2}:\d{2})/.exec(el.value)?.[1]||'00:00');
  if(el.type==='date')return iso;
  if(/^\d{1,2}\/\d{1,2}\/\d{4}/.test(el.value))return iso.split('-').reverse().join('/')+el.value.slice(el.value.indexOf(' ',0)>0?el.value.indexOf(' '):el.value.length);
  const suffix=/^\d{4}-\d{2}-\d{2}(\s+\d{2}:\d{2}(?::\d{2})?)$/.exec(el.value)?.[1];
  return iso+(suffix||'');
 }
 const sameDay=(date,other)=>/^\d{4}-\d{2}-\d{2}$/.test(date)&&other>=date;
 let running=false,timer;
 function later(ms=430){clearTimeout(timer);timer=setTimeout(advance,ms);}
 function go(job,element,stage){
  if(!active(job))return false;
  if(!element)return false;
  write({...job,stage,changedAt:Date.now()});
  if(!card.safeClick(element))throw Error('رابط نور غير مطابق لمسار الاختبار.');
  later();return true;
 }
 function wait(job,message){
  if(Date.now()-job.changedAt>12000)throw Error(message);
  later();
 }
 function examTypePattern(mode){
  if(mode==='qti')return /^(?:استيراد (?:الاختبار|اختبار)|import (?:test|exam)|QTI)(?=$|[\s:：])/i;
  return mode==='sequential'?/^(?:مفرده تلو الاخر|مفرده تلو الاخرى|one (?:item|question) at a time|sequential)(?=$|[\s:：])/i:
   /^(?:اختبار (?:تقليدي|اعتيادي)|(?:traditional|standard) (?:test|exam))(?=$|[\s:：])/i;
 }
 function selectedType(mode){
  const pattern=examTypePattern(mode);
  const button=action(pattern);
  if(button)return button;
  const selector='p,h2,h3,h4,label,div,span,.card-title';
  const text=el=>card.normalize(el.textContent);
  const options=[...document.querySelectorAll(selector)].filter(el=>card.visible(el)&&!el.closest('#stnNoorHub')&&pattern.test(text(el)));
  const readings=options.filter(el=>!options.some(child=>child!==el&&el.contains(child)));
  if(readings.length!==1)return null;
  const description=readings[0];
  const owner=description.closest('a,button,[role="button"],[onclick],label[for]');
  if(owner)return owner;
  const otherTypes=['sequential','traditional','qti'].filter(type=>type!==mode).map(examTypePattern);
  const tileCandidates='.card,.thumbnail,.list-group-item,[class*="exam-type"],[class*="exam_type"],[class*="quiz-type"],[class*="quiz_type"]';
  for(let el=description.parentElement,depth=0;el&&depth<5&&el!==document.body;el=el.parentElement,depth++){
   if([...el.querySelectorAll(selector)].some(child=>card.visible(child)&&otherTypes.some(type=>type.test(text(child)))))break;
   const controls=[...el.querySelectorAll('a,button,[role="button"],input[type="radio"]')].filter(card.visible);
   if(controls.length===1)return controls[0];
   if(controls.length>1)break;
   if(el.matches(tileCandidates)||el.querySelector('img,svg,i,[class*="icon"]'))return el;
  }
  return null;
 }
 async function advance(){
  if(running)return;
  const task=document.getElementById('stnHubService')?.value;
  if(task&&task!=='exam')return;
  let job=read();
  if(!job||job.paused||['done','qti_ready'].includes(job.stage))return;
  running=true;
  try{
   if(job.teacher!==await teacher())throw Error('تغيّر حساب المعلم.');
   if(!active(job))return;
   if(!/^\/teacher(?:\/|$)/i.test(location.pathname))throw Error('صفحة الاختبار الحالية خارج مسار المعلم.');
   const url=location.pathname+location.search;
   const numeric=location.pathname.match(/\/cid:(\d+)(?:\/|$)/i)?.[1];
   if(numeric&&job.course.cid&&numeric!==String(job.course.cid)&&['list','type','form','qti_form'].includes(job.stage))
    throw Error('يدل رابط نور على صف آخر.');
   if(job.stage==='card'){
    if(!card.isHome())return wait(job,'لم تفتح الصفحة الرئيسية للمعلم.');
    const next=card.next(job.course,2,feature,cardCreate);
    if(!next)return wait(job,'لم يظهر خيار الاختبار في الصفحة الثانية لبطاقة الصف.');
    const attempts=(job.cardAttempts||0)+1;
    if(attempts>12)throw Error('تعذر فتح الاختبار من بطاقة الصف.');
    return go({...job,cardAttempts:attempts},next.element,next.step==='create'?'list':next.step==='feature'?'list':'card');
   }
   if(job.stage==='list'){
    const next=action(create);
    if(next)return go(job,next,'type');
    if(job.mode==='qti'&&findQtiInput()){write({...job,stage:'qti_form',changedAt:Date.now()});later(0);return;}
    if(selectedType(job.mode)||field(document,titles)?.form){write({...job,stage:'type',changedAt:Date.now()});later(0);return;}
    const electronic=action(/^الاختبارات الالكترونيه$|^electronic exams$/i);
    if(electronic&&!job.openedElectronic)return go({...job,openedElectronic:true},electronic,'list');
    return wait(job,'لم يظهر زر إضافة اختبار جديد.');
   }
   if(job.stage==='type'){
    if(job.mode==='qti'&&findQtiInput()){write({...job,stage:'qti_form',changedAt:Date.now()});later(0);return;}
    const openedTitle=field(document,titles);
    if(job.mode!=='qti'&&openedTitle?.form&&field(openedTitle.form,duration)){write({...job,stage:'form',changedAt:Date.now()});later(0);return;}
    const next=selectedType(job.mode);
    if(next)return go(job,next,job.mode==='qti'?'qti_form':'form');
    const continueButton=action(nextStep);
    if(!job.classSelected&&continueButton&&root.NoorVisibleClass.hasChoices()){
     await selectClass(job);
     return go({...job,classSelected:true},continueButton,'type');
    }
    return wait(job,'لم يظهر نوع الاختبار المختار.');
   }
   if(job.stage==='qti_form'){
    const input=findQtiInput();
    if(!input)return wait(job,'لم يظهر حقل ملف QTI في نموذج استيراد الاختبار.');
    const teacherFile=(await browser.storage.local.get(job.fileKey))[job.fileKey];
    if(!active(job))return;
    if(!teacherFile||teacherFile.teacher!==job.teacher)throw Error('لم أجد ملف QTI لهذه العملية.');
    const accept=(input.accept||'').toLowerCase().split(',').map(s=>s.trim()).filter(Boolean);
    const basename=teacherFile.name.toLowerCase(),mime=teacherFile.type?.toLowerCase()||'';
    const acceptable=accept.some(value=>value.startsWith('.')?basename.endsWith(value):value===mime||value==='*/*'||value.endsWith('/*')&&mime.startsWith(value.slice(0,-1))||
     /zip/.test(value)&&basename.endsWith('.zip')||/xml/.test(value)&&basename.endsWith('.xml'));
    if(accept.length&&!acceptable)throw Error('حقل استيراد نور يطلب '+input.accept+'. اختر ملفًا يطابقه.');
    const bytes=Uint8Array.from(atob(teacherFile.data),c=>c.charCodeAt(0));
    const transfer=new DataTransfer();transfer.items.add(new File([bytes],teacherFile.name,{type:teacherFile.type}));
    input.files=transfer.files;
    input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
    if(input.files?.[0]?.name!==teacherFile.name)throw Error('لم يبق ملف QTI في حقل الرفع.');
    if(root.NoorVisibleClass?.hasChoices())await selectClass(job);
    if(!active(job))return;
    write({...job,stage:'qti_ready'});await browser.storage.local.remove(job.fileKey).catch(()=>{});
    status('أُرفق ملف QTI في نموذج نور. راجع الحقول واضغط استيراد داخل نور لرؤية نتيجة التحقق من الصيغة.');return;
   }
   if(job.stage==='form'){
    const title=field(document,titles);
    if(!title||!title.form){
     const continueButton=action(nextStep);
     if(!job.continuedType&&continueButton)return go({...job,continuedType:true},continueButton,'form');
     return wait(job,'لم يظهر نموذج الاختبار.');
    }
    const form=title.form,time=field(form,duration),start=field(form,publication),late=field(form,deadline);
    if(!time||!start||!late)return wait(job,'تعذر تمييز وقت الاختبار أو تاريخ النشر أو تاريخ التسليم المتأخر.');
    setField(title,job.title);setField(time,String(job.minutes));
    setField(start,dateValue(start,job.publish));setField(late,dateValue(late,job.deadline));
    if(!job.classSelected||root.NoorVisibleClass.hasChoices())await selectClass(job);
    if(!active(job))return;
    const save=card.action(form,/^(?:حفظ|حفظ الاختبار|اضافه|اضافه الاختبار|التالي|Save|Next|Create)$/i);
    if(!save)throw Error('لم يظهر زر حفظ الاختبار.');
    if(form.checkValidity&&!form.checkValidity())throw Error('يعرض نور حقولًا إلزامية غير مكتملة في نموذج الاختبار.');
    return go(job,save,'await_exam');
   }
   if(job.stage==='await_exam'){
    if(!action(dropdown))return wait(job,'لم تظهر صفحة مفردات الاختبار بعد الحفظ.');
    const heading=[...document.querySelectorAll('h1,h2,h3,h4,h5,h6,.page-title,.card-title')].some(
     el=>card.visible(el)&&card.normalize(el.textContent)===card.normalize(job.title));
    const confirmation=[...document.querySelectorAll('.alert-success,[role="status"]')].some(
     el=>!el.closest('#stnNoorHub')&&card.visible(el)&&/تم حفظ الاختبار|exam saved|test saved/i.test(card.normalize(el.textContent)));
    if(!heading&&!confirmation)return wait(job,'لم يتأكد فتح صفحة مفردات الاختبار الذي أُنشئ.');
    job={...job,listURL:url,stage:'generate',changedAt:Date.now()};write(job);
   }
   if(job.stage==='generate'){
    if(url!==job.listURL)throw Error('افتح صفحة مفردات هذا الاختبار لاستئناف التوليد.');
    status('جارٍ توليد مفردات الاختبار باستخدام Gemini…');
    const request=root.NoorGemini.makeRequest({grade:job.course.grade,subject:job.subject,unit:job.unit,lesson:job.lesson,count:job.count,
     kinds:job.kinds,title:job.title,description:job.topic,difficulty:'mixed'});
    const result=await root.NoorGemini.generateComplete(request,root.NoorSchema,
     attempt=>browser.runtime.sendMessage({type:'NOOR_ACTIVITY_GEMINI_GENERATE',...attempt,model:'gemini-3.5-flash-lite'}));
    if(!active(job))return;
    if(!result.allValid||result.questions.length!==job.count)throw Error('لم تجتز جميع المفردات التحقق من النوع والإجابة.');
    job={...job,questions:result.questions,index:0,stage:job.bulk?'open_bulk':'item',changedAt:Date.now()};write(job);
   }
   if(job.stage==='open_bulk'){
    const bulk=root.NoorBulkItems;
    if(!bulk?.supported(job.questions))throw Error('تتضمن المجموعة نوعًا يحتاج الإدراج المفرد.');
    const open=bulk.open();
    if(url!==job.listURL||!open)return wait(job,'لم يظهر زر إضافة مجموعة مفردات دفعة واحدة.');
    return go(job,open,'fill_bulk');
   }
   if(job.stage==='fill_bulk'){
    const bulk=root.NoorBulkItems;
    if(!bulk?.submit())return wait(job,'لم يظهر نموذج إنشاء المجموعة.');
    const save=await bulk.fill(job.questions,()=>active(job));
    return go(job,save,'await_bulk');
   }
   if(job.stage==='await_bulk'){
    const error=root.NoorBulkItems?.error();
    if(error)throw Error(error);
    if(url!==job.listURL||root.NoorBulkItems?.submit()||!action(dropdown))return wait(job,'لم يرجع نور إلى قائمة مفردات الاختبار بعد الإرسال.');
    write({...job,stage:'done'});status('أُرسلت مجموعة مفردات الاختبار مرة واحدة.');return;
   }
   if(job.stage==='item'){
    if(url!==job.listURL||!action(dropdown))return wait(job,'لم تظهر قائمة مفردات هذا الاختبار.');
    if(job.index>=job.questions.length){write({...job,stage:'done'});status('اكتمل إدراج '+job.index+' مفردة في اختبار نور.');return;}
    const item=job.questions[job.index];
    const menu=action(dropdown);
    let button=editor.findChoice?await editor.findChoice(item):editor.choose(item);
    if(!button&&menu){menu.click();await new Promise(resolve=>setTimeout(resolve,300));button=editor.choose(item);}
    if(!button)throw Error('لم يظهر خيار إنشاء المفردة الحالية في نور.');
    const link=button.closest('a');
    const target=link?.getAttribute('href')?.match(/^(?:https?:|\/)/i)?new URL(link.href,location.href):null;
    const editorURL=target?.pathname?target.pathname+target.search:null;
    return go({...job,beforeCount:editor.listCount(),editorURL},button,'editor');
   }
   if(job.stage==='editor'){
    const item=job.questions[job.index];
    if(url===job.listURL){
     try{editor.confirmKind(item);}catch(_){return wait(job,'لم يفتح محرر المفردة.');}
    }
    if(job.editorURL&&url!==job.editorURL)throw Error('صفحة تحرير المفردة الحالية ليست الصفحة المفتوحة من الاختبار.');
    await editor.fill(item);
    const save=editor.saveButton();
    if(!save)throw Error('لم يظهر زر حفظ المفردة.');
    return go(job,save,'await_item');
   }
   if(job.stage==='await_item'){
    const error=root.NoorBulkItems?.error();
    if(error)throw Error(error);
    if(url!==job.listURL||!action(dropdown))return wait(job,'لم يرجع نور إلى قائمة مفردات الاختبار بعد الإرسال. لم تُعد محاولة الحفظ.');
    write({...job,index:job.index+1,stage:'item',changedAt:Date.now()});later();
   }
  }catch(error){
   if(active(job)){write({...read(),paused:true,reason:String(error.message||error)});status(String(error.message||error));}
  }finally{running=false;}
 }
 function findQtiInput(){
  const options=[...document.querySelectorAll('input[type="file"]')].filter(el=>!el.disabled&&!el.closest('#stnNoorHub,#noor-prep-panel,#noor-smart-activities-root'));
  const named=options.filter(el=>/qti|استيراد|import/i.test([el.name,el.id,el.accept,...[...(el.labels||[])].map(label=>label.textContent)].join(' ')));
  return named.length===1?named[0]:named.length===0&&options.length===1?options[0]:null;
 }
 async function start(opts,file){
  const id=await teacher();
  if(!id||!opts.course?.label)throw Error('اختر صف الاختبار أولًا.');
  const {title,minutes,publish,deadline,mode,count,kinds}=opts;
  if(mode!=='qti'&&(!title||!Number.isInteger(minutes)||minutes<1||!sameDay(publish,deadline)||!/^\d{4}-\d{2}-\d{2}$/.test(deadline)))
   throw Error('أدخل العنوان والوقت وتاريخ النشر وتاريخ التسليم المتأخر.');
  if(mode!=='qti'&&(!['sequential','traditional'].includes(mode)||!Number.isInteger(count)||count<1||count>30||!kinds.length))
   throw Error('اختر نوع الاختبار وعدد المفردات وأنواعها.');
  const previous=read();
  if(previous&&!['done','qti_ready'].includes(previous.stage))throw Error('يوجد اختبار معلّق. استكمله أو أوقف هذه المهمة.');
  const job={...opts,id:crypto.randomUUID(),teacher:id,at:Date.now(),changedAt:Date.now(),stage:'card'};
  if(mode==='qti'){
   if(!file||!/\.(?:zip|xml|qti)$/i.test(file.name)||!file.size||file.size>8*1024*1024)throw Error('اختر حزمة QTI بامتداد ZIP أو XML أو QTI وبحجم حتى 8 ميغابايت.');
   job.fileKey='stnNoorExamQti:v1:'+job.id;
   const data=await new Promise((resolve,reject)=>{
    const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);
    reader.onerror=()=>reject(Error('تعذرت قراءة ملف QTI.'));reader.readAsDataURL(file);
   });
   await browser.storage.local.set({[job.fileKey]:{teacher:id,name:file.name,type:file.type,data}});
  }
  write(job);
  if(card.isHome())later(0);else location.assign(location.origin+'/teacher');
 }
 function cancel(){
  clearTimeout(timer);
  const fileKey=read()?.fileKey;
  sessionStorage.removeItem(KEY);
  if(fileKey)browser.storage.local.remove(fileKey).catch(()=>{});
 }
 function resume(){
  const job=read();
  if(!job||job.stage==='done')return;
  write({...job,paused:false,changedAt:Date.now()});later(0);
 }
 root.NoorExam=Object.freeze({start,cancel,resume,inspect:read});
 if(read()&&!read().paused)later(250);
})(globalThis);
