/* Noor Unified 2.8.43 — SCORM page-to-page publisher (Firefox content script).
 * Never sends a file to an invented endpoint. Uses the teacher's visible Noor
 * navigation, selects only uniquely identified form controls, verifies class
 * before attaching, and never claims a submission succeeded from a click.
 * Unknown Noor UI => stop, preserve the package, explain the blocker.
 */
(function(root){'use strict';
 if(window.top!==window||!/^\/teacher(?:\/|$)/i.test(location.pathname)||root.NoorScormPublisher)return;
 const JOB='stnScormPublishJob:v1',FILE='stnScormTempZip:v1:',MAX=5*1024*1024,TTL=45*60*1000;
 const norm=s=>String(s||'').normalize('NFKC').replace(/[إأآ]/g,'ا').replace(/[\u064b-\u065f\u0640]/g,'').replace(/\s+/g,' ').trim().toLowerCase();
 const tidy=s=>String(s||'').replace(/\s+/g,' ').trim();
 const sleep=t=>new Promise(r=>setTimeout(r,t));
 const inHub=el=>Boolean(el?.closest?.('#stnNoorHub,#noor-prep-panel'));
 const visible=el=>Boolean(el&&el.getClientRects().length&&getComputedStyle(el).visibility!=='hidden');
 // Noor's Digital Repository screens use different URLs from old /attachments/Scorm.
 // Recognize the teacher-facing library and upload form by several *independent*
 // visible clues from Noor's actual interface, not an invented fixed URL.
 const pageHeaders=()=>[...document.querySelectorAll('h1,h2,h3,h4,h5,.page-title,.card-title')]
   .filter(e=>visible(e)&&!inHub(e)).map(e=>norm(e.innerText||e.textContent));
 const isScorm=()=>/\/teacher\/attachments\/(?:index|upload)\/Scorm(?:\/|$)/i.test(location.pathname)
   ||pageHeaders().some(h=>/مكتبة الدروس التفاعلية|رفع درس تفاعلي جديد/.test(h));
 const isScormForm=()=>{
   const head=pageHeaders().some(h=>/رفع درس تفاعلي جديد|انشاء درس تفاعلي|اضافه درس تفاعلي/.test(h));
   const radios=[...document.querySelectorAll('input[type="radio"]')].filter(e=>!inHub(e));
   const scormChoice=radios.some(e=>/scorm/i.test((e.value||'')+' '+(e.closest('label,.form-check,.radio')?.textContent||'')));
   const uploads=[...document.querySelectorAll('input[type="file"]')].filter(e=>!inHub(e));
   return Boolean(head&&scormChoice&&uploads.length>=1);
 };
 const get=()=>{try{const j=JSON.parse(sessionStorage.getItem(JOB)||'null');if(!j)return null;if(Date.now()-j.at>TTL){sessionStorage.removeItem(JOB);return null}return j}catch(_){return null}};
 const set=j=>sessionStorage.setItem(JOB,JSON.stringify({...j,updated:Date.now()}));
 function confirmedSaved(j){
  if(!j?.batchTag||isScormForm())return false;
  // A batch-specific nonce is put in the uploaded *title* before submission.
  // A single actual Noor listing row bearing it is evidence of one new record.
  const expected=norm('STN-'+j.batchTag);
  const rows=[...document.querySelectorAll('table tbody tr,[role="row"]')].filter(e=>visible(e)&&!inHub(e));
  const found=rows.filter(e=>norm(e.textContent).includes(expected));
  if(found.length!==1)return false;
  j.phase='done';j.confirmedAt=Date.now();set(j);
  browser.storage.local.remove(fileKey(j)).catch(()=>{});
  root.dispatchEvent(new CustomEvent('stnNoorScormConfirmed',{detail:{id:j.id,batchTag:j.batchTag}}));
  return true;
 }
 function notice(message){
  const panel=document.getElementById('stnHubPanel'),s=document.getElementById('stnHubStatus');
  if(panel)panel.hidden=false;
  const svc=document.getElementById('stnHubService');if(svc&&svc.value!=='scorm'){svc.value='scorm';svc.dispatchEvent(new Event('change',{bubbles:true}));}
  if(s)s.textContent=String(message);
 }
 async function teacher(){try{return String(await root.NOOR_TEACHER_PROFILE?.active?.()||'')}catch(_){return ''}}
 const fileKey=j=>FILE+j.id;
 // Firefox content-script Xray wrappers can reject Uint8Array.subarray() with
 // "Permission denied to access property constructor" (Mozilla bug 1868675).
 // Access bytes only by index; do not use slice/subarray/apply on typed views.
 function encode(bytes){
  const parts=[];let block='';
  for(let i=0;i<bytes.length;i++){
   block+=String.fromCharCode(bytes[i]);
   if(block.length===8192){parts.push(block);block='';}
  }
  if(block)parts.push(block);
  return btoa(parts.join(''));
 }
 function decode(str){const s=atob(str);const a=new Uint8Array(s.length);for(let i=0;i<s.length;i++)a[i]=s.charCodeAt(i);return a}
 async function cleanup(j){if(!j)return;try{await browser.storage.local.remove(fileKey(j))}catch(_){}sessionStorage.removeItem(JOB)}
 async function cancel(){const j=get();await cleanup(j);notice(j?.phase==='submitted_unknown'?'ألغيت المتابعة في الإضافة؛ ربما وصل أمر الحفظ إلى نور بالفعل. تحقق من المكتبة قبل إنشاء درس جديد.':'ألغي النشر المعلّق دون إرسال أمر حفظ جديد. احتفظت بنسخة SCORM المنزلة.');}
 async function start(file,opts){
  if(!file||file.size<100||file.size>MAX)throw Error('الملف كبير جدًا للتنقل التلقائي (الحد 5 ميغابايت) أو فارغ. احتفظ بالنسخة المنزلة وارفعها يدويًا.');
  if(!/\.zip$/i.test(file.name)||!root.NoorScorm?.hasManifest?.(await file.arrayBuffer()))throw Error('حزمة SCORM ليست ZIP صالحًا بملف imsmanifest.xml.');
  if(get()&&get().phase!=='done')throw Error('هناك عملية SCORM قائمة أو غير مؤكدة؛ استكملها وتحقق من نتيجتها أو ألغ المتابعة بعد فحص نور، قبل بدء عملية جديدة.');
  const t=await teacher();
  if(!t||!opts.teacherId||t!==String(opts.teacherId))throw Error('لم تثبت هوية المعلم قبل نقل ملف SCORM.');
  const c=opts.course;
  if(!c?.verified||!/^\d+$/.test(String(c.cid||''))||!c.grade||!c.label||!c.subject||norm(c.subject)!==norm(opts.subject))throw Error('لم تثبت المادة والصف من بطاقة نور.');
  if(!opts.unit||!opts.lesson)throw Error('تحديد الوحدة والدرس في شجرة نور مطلوب.');
  const existing=get();if(existing)await cleanup(existing);
  const j={id:'s'+Date.now()+'-'+Math.random().toString(36).slice(2,9),at:Date.now(),teacherId:t,
   mode:opts.mode==='auto'?'auto':'review',phase:'route',step:'',clicks:0,
   cid:String(c.cid),grade:Number(c.grade),label:tidy(c.label),subject:tidy(opts.subject),
   semester:String(opts.semester),unit:tidy(opts.unit),lesson:tidy(opts.lesson),
   batchTag:/^[a-f0-9-]{1,24}$/i.test(String(opts.batchTag||''))?String(opts.batchTag):'',publishDate:String(opts.publishDate||''),
   filename:file.name,formPath:'',verifiedLesson:false,attached:false,lessonEvidence:opts.lessonEvidence||null};
  const bin=encode(new Uint8Array(await file.arrayBuffer()));
  try{await browser.storage.local.set({[fileKey(j)]:{at:j.at,teacherId:t,name:file.name,base64:bin}})}
  catch(e){throw Error('لم أستطع حفظ نسخة SCORM مؤقتًا أثناء التنقل: '+String(e?.message||e))}
  set(j);notice('حُفظ ملف SCORM مؤقتًا لهذه العملية؛ جارٍ فتح بوابة الدرس التفاعلي للصف المحدد.');
  setTimeout(()=>advance().catch(e=>pause(get(),String(e?.message||e))),250);
  return {ok:true,queued:true,id:j.id};
 }
 function uniqueLink(regex){
  // Noor uses anchors/buttons inside a course popover and repository tabs.
  const nodes=[...document.querySelectorAll('a,button,[role="button"],[onclick],input[type="button"],input[type="submit"]')]
   .filter(e=>visible(e)&&!e.disabled&&!inHub(e))
   .filter(e=>{const v=norm(e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||e.title);return v.length>0&&v.length<90&&regex.test(v)});
  const seen=new Set();return nodes.filter(e=>{const a=e.closest('a')||e,k=a.href||e.id||norm(e.textContent);if(seen.has(k))return false;seen.add(k);return true});
 }
 function oneAction(regex){const actions=uniqueLink(regex);return actions.length===1?actions[0]:null}
 function visiblePopover(){return [...document.querySelectorAll('.popover,.dropdown-menu,[role="menu"],[role="dialog"],[class*="popover"],[class*="course-actions"]')]
    .filter(e=>visible(e)&&!inHub(e)&&tidy(e.textContent).length<1400)}
 function activeBookCourse(j){const known=root.NoorCourseCatalog?.get?.(j.cid);return !!(known&&Number(known.grade)===j.grade&&norm(known.label)===norm(j.label))}
 function isCourseHome(){return /^\/teacher\/?$/i.test(location.pathname)&&root.NoorCourseCatalog?.cards?.()?.length>0}
 function takeNavigation(j,action,label){
  if(!action||!visible(action))return false;
  const target=action.closest('a')||action;
  if(target.tagName==='A'&&target.href){const u=new URL(target.href,location.href);
   if(u.origin!==location.origin||!/^\/teacher(?:\/|$)/i.test(u.pathname))return false;}
  if(j.step===label&&j.lastPath===location.pathname&&Date.now()-j.lastAt<2600)return false;
  if(j.clicks>=15)throw Error('تجاوزت الإضافة حد خطوات التنقل الآمنة ولم تتعرف على صفحة نور.');
  j.clicks++;j.phase='route';j.step=label;j.lastPath=location.pathname;j.lastAt=Date.now();set(j);
  notice('فتح: '+label+' ...');
  if(target.tagName==='A'&&target.target==='_blank')target.target='_self';
  target.click();
  // Popovers, tabs and AJAX navigation may not reload the document.
  setTimeout(()=>advance().catch(e=>pause(get(),String(e?.message||e))),950);
  setTimeout(()=>advance().catch(e=>pause(get(),String(e?.message||e))),2750);
  return true;
 }
 function pause(j,reason){if(!j)return;const reasonText=String(reason||'تعذر تحديد العنصر بشكل آمن').slice(0,350);
  j.phase='paused';j.reason=reasonText;set(j);
  notice('توقف النشر الآلي بأمان: '+reasonText+' — ملف SCORM محفوظ مؤقتًا، ولم أضغط حفظ. افتح الصفحة الصحيحة ثم اضغط «استكمال النشر الموجود».');
 }
 function pickNav(j){
  if(!activeBookCourse(j))throw Error('الصف المحدد لا يطابق بطاقة المادة المسجلة في نور.');
  // 1. Interactive lessons library: actual Noor label from screenshots.
  const create=oneAction(/^(?:رفع|انشاء|اضافه)\s+(?:درس|مساق)\s+تفاعلي(?:\s+جديد)?$/i);
  if(create&&takeNavigation(j,create,'رفع درس تفاعلي جديد'))return true;
  // 2. Digital repository landing on Video Library by default: switch tab.
  const lessonsTab=oneAction(/^مكتبة\s+الدروس\s+التفاعلية$/i);
  if(lessonsTab&&takeNavigation(j,lessonsTab,'مكتبة الدروس التفاعلية'))return true;
  // 3. Class popover second page: "إدارة المحتوى → المكتبة الرقمية".
  const repository=oneAction(/^(?:المكتبة\s+الرقمية|المكتبة\s+الالكترونية|المستودع\s+الرقمي)$/i);
  if(repository&&takeNavigation(j,repository,'المكتبة الرقمية'))return true;
  // 4. Noor's course menu has paginated actions: the second page is "إدارة المحتوى".
  const pops=visiblePopover(),menu=pops.filter(p=>/تحضير الدروس|ادارة المحتوى|المرفقات|المكتبة الرقمية/.test(norm(p.textContent)));
  if(menu.length===1){
   const next=[...menu[0].querySelectorAll('a,button,[role="button"]')].filter(e=>visible(e)&&/^(?:التالي|next|2|›|»)$/.test(norm(e.innerText||e.textContent||e.title)));
   if(next.length===1&&takeNavigation(j,next[0],'التالي في قائمة إدارة المحتوى'))return true;
  }
  // 5. Starting from teacher homepage, open only the exact verified class card.
  if(isCourseHome()&&pops.length===0){
   const cards=root.NoorCourseCatalog?.cards?.()||[];
   const matches=cards.filter(c=>norm(c.label)===norm(j.label));
   if(matches.length===1){
    const card=matches[0].element;
    const button=card.querySelector('[data-toggle="popover"],[data-bs-toggle="popover"],button,[role="button"]')||card;
    if(takeNavigation(j,button,'قائمة مادة '+j.label))return true;
   }
   if(matches.length>1)throw Error('ظهرت أكثر من بطاقة مطابقة للصف. لا يمكن اختيار إحداها عشوائيًا.');
  }
  // Cached Noor URL is useful only when *directly witnessed* for this class.
  // Do not invent digital-library URLs or reuse a URL for another grade.
  const known=root.NoorCourseCatalog?.get?.(j.cid),url=known?.routes?.scorm;
  if(url&&j.step!=='official_scorm_route'){
   const u=new URL(url,location.href);
   if(u.origin===location.origin&&/^\/teacher\/attachments\/(?:index|upload)\/Scorm/i.test(u.pathname)&&
      u.pathname!==location.pathname){
     j.step='official_scorm_route';j.phase='route';j.clicks++;set(j);location.assign(u.href);return true;
   }
  }
  return false;
 }
 function nearText(el){
  // Inspect only the *nearest* compact control group. Walking up to the full
  // form accidentally picks up the separate "صورة الغلاف" upload label.
  let node=el.parentElement;
  for(let depth=0;node&&depth<5;depth++,node=node.parentElement){
   if(node.tagName==='FORM'||node.tagName==='BODY')break;
   const direct=tidy(node.textContent);
   if(direct&&direct.length<135)return direct;
  }
  return '';
 }
 function fieldText(el){return norm([el.getAttribute('placeholder'),el.id,el.name,el.getAttribute('aria-label'),
  [...(el.labels||[])].map(x=>x.textContent).join(' '),el.closest('.form-group,.form-row,.form-control')?.querySelector('label')?.textContent,nearText(el)].join(' '))}
 function searchField(filter,selectors){
  const matches=[...document.querySelectorAll(selectors)].filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&filter(fieldText(e),e));
  if(matches.length===1)return matches[0];
  // Prefer an exact placeholder/name/id over a broad surrounding form-group.
  const direct=matches.filter(e=>filter(norm([e.placeholder,e.id,e.name,e.getAttribute('aria-label')].join(' ')),e));
  return direct.length===1?direct[0]:null;
 }
 function nativeValue(el,value){const proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:el.tagName==='SELECT'?HTMLSelectElement.prototype:HTMLInputElement.prototype;Object.getOwnPropertyDescriptor(proto,'value')?.set?.call(el,String(value));el.dispatchEvent(new Event('input',{bubbles:true}));el.dispatchEvent(new Event('change',{bubbles:true}));}
 function fileInput(){
  const inputs=[...document.querySelectorAll('input[type="file"]')].filter(e=>!e.disabled&&!inHub(e));
  const describe=e=>norm([e.id,e.name,e.accept,e.getAttribute('aria-label'),nearText(e)].join(' '));
  const cover=/(?:غلاف|صوره|صورة|cover|image|jpe?g|png|webp|avatar)/;
  const zip=/(?:scorm|zip|ملف|file|رفع|drop|upload)/;
  const candidates=inputs.filter(e=>!cover.test(describe(e))&&zip.test(describe(e)));
  if(candidates.length===1)return candidates[0];
  if(inputs.length===2){
   const c=inputs.filter(e=>cover.test(describe(e)));
   if(c.length===1)return inputs.find(e=>e!==c[0]);
  }
  return null;
 }
 function optionOfRadio(text){const want=norm(text);
  const radios=[...document.querySelectorAll('input[type="radio"]')].filter(e=>!e.disabled&&!inHub(e));
  const hits=radios.filter(e=>{const direct=norm((e.value||'')+' '+[...(e.labels||[])].map(x=>x.textContent).join(' '));
   const near=norm(e.closest('label,.form-check,.radio,.custom-control')?.textContent||'');
   return direct===want||direct.split(' ').includes(want)||near===want||near.split(' ').includes(want);
  });
  return hits.length===1?hits[0]:null;
 }
 function treeNodes(){
  const selectors='.jstree-anchor,.fancytree-title,[role="treeitem"],.tree-node-title,.treeview a,.tree a,.ztree a,[data-lesson-id]';
  return [...document.querySelectorAll(selectors)].filter(e=>visible(e)&&!inHub(e)&&!e.closest('nav')&&
    (e.matches('[role="treeitem"]')?Boolean(e.closest('[aria-label*="دروس"],[aria-label*="lesson"],.lesson-tree,.curriculum-tree')):true));
 }
 function treeCandidate(j){
  const nodes=treeNodes();
  const exact=nodes.filter(e=>norm(e.textContent)===norm(j.lesson));
  if(exact.length===1)return exact[0];
  if(exact.length>1)return null;
  // Noor's tree may abbreviate "Unit1: Stories: Lesson1" to "Lesson1".
  // Only accept a unique numbered lesson in the entire currently visible tree;
  // never guess between lessons with the same number in different units.
  const n=root.NoorLessonNumbers?.number?.(j.lesson,'lesson');
  if(!n)return null;
  const unitNumber=root.NoorLessonNumbers?.number?.(j.unit,'unit');
  const short=nodes.filter(e=>{
   const t=tidy(e.textContent);if(!t||t.length>=170)return false;
   // Science: 4-1 is lesson 1 INSIDE unit 4. Do not confuse it with Lesson 4.
   const pair=/(?:^|\s)(\d{1,2})\s*[-–.]\s*(\d{1,2})(?=\s|$)/.exec(t);
   if(pair)return unitNumber!==null&&Number(pair[1])===unitNumber&&Number(pair[2])===n;
   return /(?:lesson|الدرس|درس)\s*[:#.-]?\s*\d/i.test(t)&&
    root.NoorLessonNumbers?.number?.(t,'lesson')===n;
  });
  return short.length===1?short[0]:null;
 }
 async function expandUnitIfPossible(j){
  const nodes=treeNodes(),exact=nodes.filter(e=>norm(e.textContent)===norm(j.unit));
  if(exact.length!==1)return false;
  const unit=exact[0],branch=unit.closest('li,[role="treeitem"]')||unit;
  const toggle=branch.querySelector('.jstree-ocl,.fancytree-expander,[aria-label*="expand"],button[aria-expanded="false"]');
  if(toggle&&visible(toggle)){toggle.click();await sleep(500);return true}
  if(unit.getAttribute('aria-expanded')==='false'){unit.click();await sleep(500);return true}
  return false;
 }
 function treeSelected(node){if(!node)return false;
  const scope=node.closest('li,[role="treeitem"]')||node;
  return Boolean(node.getAttribute('aria-selected')==='true'||scope.getAttribute('aria-selected')==='true'||
   node.classList.contains('jstree-clicked')||node.classList.contains('fancytree-selected')||
   scope.classList.contains('jstree-checked')||scope.classList.contains('jstree-clicked')||
   scope.classList.contains('selected')||scope.querySelector('input[type="checkbox"]:checked'));
 }
 function treeOpen(){return uniqueLink(/^(?:عرض الشجره|عرض الشجرة|شجره الدروس|شجرة الدروس)$/i)}
 function exactSaveButton(){const els=[...document.querySelectorAll('button,input[type="submit"],a.btn')]
  .filter(e=>visible(e)&&!e.disabled&&!inHub(e));
  const names=/^(?:حفظ|حفظ ونشر|نشر|اضافه|اضافه الدرس|رفع|save|publish|submit)$/i;
  const matches=els.filter(e=>names.test(norm(e.textContent||e.value||e.title)));
  return matches.length===1?matches[0]:null;
 }
 function requiredUnfilled(){return [...document.querySelectorAll('input[required],select[required],textarea[required]')]
  .filter(e=>visible(e)&&!e.disabled&&!inHub(e)&&e.type!=='hidden'&&e.type!=='radio'&&e.type!=='checkbox'&&e.type!=='file')
  .filter(e=>!String(e.value||'').trim());}
 async function stage(j){
  if(!isScormForm())throw Error('نموذج رفع درس تفاعلي جديد في نور غير مفتوح أو لم يكتمل تحميله.');
  const c=root.NoorCourseCatalog?.get?.(j.cid);
  if(!c||norm(c.label)!==norm(j.label)||Number(c.grade)!==j.grade||norm(root.NoorCourseCatalog?.subjectOf?.(c.label)||'')!==norm(j.subject))throw Error('الصف أو المادة الحالية لا تطابق اختيارك.');
  const course={cid:j.cid,grade:j.grade,label:j.label,subject:j.subject,verified:true};
  const result=root.NoorScormClassEvidence?.ensureSelected?.(course);
  if(!result?.ok)throw Error('لم أتحقق من كتاب الصف والفصل المراد النشر له: '+(result?.reason||'not_found'));
  const type=optionOfRadio('SCORM');if(!type)throw Error('لم يظهر خيار واحد مؤكد لنوع الدرس SCORM في نور.');
  if(!type.checked){type.click();type.dispatchEvent(new Event('change',{bubbles:true}))}
  if(!type.checked)throw Error('تعذر تحديد SCORM في نوع الدرس.');
  const title=searchField(s=>/العنوان|\btitle\b/i.test(s),'input[type="text"],input:not([type]),textarea');
  if(!title)throw Error('لم أميز حقل عنوان الدرس عن باقي الحقول.');
  const wantedTitle=j.unit+' — '+j.lesson+(j.batchTag?' • STN-'+j.batchTag:'');
  if(!title.value||norm(title.value)!==norm(wantedTitle))nativeValue(title,wantedTitle);
  const desc=searchField(s=>/الوصف|\bdescription\b/i.test(s),'textarea,input[type="text"]');
  if(desc&&!desc.value)nativeValue(desc,'درس تفاعلي في '+j.subject+' — '+j.unit+' — '+j.lesson);
  const preparation=searchField(s=>/التحضير|preparation/i.test(s),'textarea,input[type="text"]');
  if(preparation&&!preparation.value)nativeValue(preparation,j.subject+' • '+j.unit+' • '+j.lesson);
  const lessonNotes=searchField(s=>/(?:^|\s)الدروس|lessons?/i.test(s),'textarea,input[type="text"]');
  if(lessonNotes&&!lessonNotes.value)nativeValue(lessonNotes,j.unit+' — '+j.lesson);
  const languages=[...document.querySelectorAll('select')].filter(e=>visible(e)&&!inHub(e)&&/اللغة|language/.test(fieldText(e)));
  if(languages.length===1&&!languages[0].value){const matching=[...languages[0].options].filter(o=>/english|الانجليزيه/.test(norm(o.textContent)));if(matching.length===1)nativeValue(languages[0],matching[0].value)}
  const date=searchField(s=>/تاريخ النشر|publish.*date|publication.*date/.test(s),'input[type="date"],input[type="text"]');
  if(date&&date.type==='date'){
   const local=new Date(Date.now()-new Date().getTimezoneOffset()*60000).toISOString().slice(0,10);
   if(!date.value)nativeValue(date,/^\d{4}-\d{2}-\d{2}$/.test(j.publishDate)?j.publishDate:local);
  }
  // Text-calendar widgets are not standardized and may require a picker. Never
  // submit a required publication date that Noor has not itself accepted.
  const dateConfirmed=Boolean(date&&String(date.value||'').trim());
  if(!treeCandidate(j)){
   const open=treeOpen();
   if(open.length===1&&j.phase!=='tree_opened'){
    j.phase='tree_opened';set(j);open[0].click();await sleep(800);
   }
  }
  if(!treeCandidate(j))await expandUnitIfPossible(j);
  const tree=treeCandidate(j);
  if(tree&&!treeSelected(tree)){
   j.phase='tree_selection';set(j);tree.click();await sleep(450);
  }
  const selected=treeSelected(treeCandidate(j));
  // Some Noor subjects have NO lesson tree on the SCORM form. Only if the tree
  // and tree opener are both absent, accept an earlier verified selection from
  // the *real Noor lesson dropdown* of the same teacher/class. Never synthesize
  // this evidence from the title we just inserted into the upload form.
  const e=j.lessonEvidence;
  const formProof=!treeNodes().length&&!treeOpen().length&&['form','unit_batch'].includes(e?.source)&&
   (e.source!=='unit_batch'||(e.teacherApproved===true&&j.batchTag&&(e.control||e.optionValue)))&&
   (e.selected===true||e.teacherChosen===true||e.source==='unit_batch')&&Number.isFinite(Number(e.observedAt))&&
   Date.now()-Number(e.observedAt)<45*60*1000&&
   root.NoorLessonEvidence?.norm?.(e.title)===root.NoorLessonEvidence?.norm?.(j.lesson)&&
   (root.NoorLessonEvidence?.norm?.(e.unit)===root.NoorLessonEvidence?.norm?.(j.unit)||
    root.NoorLessonNumbers?.number?.(e.unit,'unit')===root.NoorLessonNumbers?.number?.(j.unit,'unit'));
  if(!selected&&!formProof){
   throw Error('تعذر توثيق الدرس: إذا كانت الشجرة موجودة اختر منها؛ وإن كانت غير موجودة اختر الدرس من قائمة «الدروس» في نور قبل التوليد، ثم استكمل النشر.');
  }
  j.verifiedLesson=true;
  const input=fileInput();if(!input)throw Error('لم أميز خانة رفع ZIP عن خانة صورة الغلاف.');
  if(!input.files?.length){const temp=(await browser.storage.local.get(fileKey(j)))[fileKey(j)];
   if(!temp||temp.teacherId!==j.teacherId||temp.name!==j.filename)throw Error('اختفى الملف المؤقت أو اختلف حساب المعلم.');
   const bytes=decode(temp.base64),file=new File([bytes],temp.name,{type:'application/zip'});
   const dt=new DataTransfer();dt.items.add(file);input.files=dt.files;
   input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));
  }
  if(input.files?.length!==1||input.files[0].name!==j.filename)throw Error('لم يتأكد إرفاق الملف إلى حقل SCORM الصحيح.');
  j.attached=true;j.formPath=location.pathname;j.phase='staged';set(j);
  const preview=document.getElementById('stnHubPreview');
  if(preview){preview.hidden=false;preview.textContent='معاينة النشر قبل الحفظ\nالصف: '+j.label+'\nالمادة: '+j.subject+
   '\nالفصل: '+j.semester+'\nالوحدة: '+j.unit+'\nالدرس: '+j.lesson+'\nSCORM: '+j.filename+
   '\nحالة الرفع: ملف مرتبط بخانة ZIP\nتاريخ النشر: '+(dateConfirmed?date.value:'غير محدد');}
  notice('✓ تم تجهيز مسودة SCORM: الصف والدرس والملف ونوع SCORM مؤكدون. '+(j.mode==='auto'?'جارٍ فحص صلاحية الحفظ...':'ظهرت معاينة بيانات الدرس في لوحة الإضافة؛ راجعها واحفظ من نور. لم أضغط حفظ.'));
  if(j.mode!=='auto')return;
  await sleep(1500);
  if(!dateConfirmed)throw Error('تاريخ النشر لم يُؤكّد في نور. اختره من التقويم قبل الحفظ التلقائي.');
  // The portal may need time to finish processing ZIP after change event.
  if(location.pathname!==j.formPath||!input.isConnected||input.files?.length!==1||!(treeSelected(treeCandidate(j))||formProof)||!type.checked)throw Error('تغيّر النموذج أثناء تجهيز الملف؛ أوقف الحفظ.');
  if(requiredUnfilled().length)throw Error('في نموذج نور حقول مطلوبة غير مكتملة؛ توقفت قبل الحفظ.');
  const button=exactSaveButton();
  if(!button)throw Error('زر الحفظ/النشر النهائي غير مميز بدقة في هذه النسخة من نور. لم يُضغط حفظ.');
  j.phase='submitted_unknown';j.submittedAt=Date.now();set(j);
  notice('تم الضغط على زر الحفظ مرة واحدة. التحقق من قبول نور جارٍ؛ لا تكرر الإرسال.');
  button.click();
 }
 let running=false;
 async function advance(){
  if(running)return;
  const j=get();if(!j||!['route','paused','tree_opened','tree_selection'].includes(j.phase))return;
  running=true;
  try{
   const t=await teacher();if(t!==j.teacherId)throw Error('تغيّر حساب المعلم؛ لن يُستخدم ملف معلم آخر.');
   root.NoorCourseCatalog?.scan?.();
   if(!isScormForm()){
    if(pickNav(j))return;
    throw Error('لم أجد مسار نور «بطاقة الصف ← إدارة المحتوى ← المكتبة الرقمية ← مكتبة الدروس التفاعلية ← رفع درس تفاعلي جديد».');
   }
   await stage(j);
  }catch(e){pause(get(),String(e?.message||e))}finally{running=false}
 }
 async function resume(){const j=get();if(!j){notice('لا توجد عملية نشر SCORM معلقة.');return}
  if(j.phase==='submitted_unknown'){if(confirmedSaved(j)){notice('✓ تأكد ظهور SCORM في القائمة.');return;}notice('سبق الضغط على حفظ. افتح قائمة الدروس للتحقق، دون تكرار الإرسال.');return}
  if(j.phase==='staged'){notice('المسودة جاهزة للمراجعة. حفظها الآن يدويًا في نور، أو أعد العملية بخيار الحفظ التلقائي.');return}
  j.phase='route';set(j);notice('جارٍ استكمال SCORM من الصفحة الحالية...');advance();
 }
 root.NoorScormPublisher=Object.freeze({start,resume,cancel,inspect:()=>{const j=get();return j?{id:j.id,phase:j.phase,grade:j.grade,lesson:j.lesson,mode:j.mode,reason:j.reason,batchTag:j.batchTag}:null}});
 setTimeout(()=>{const j=get();if(j){
   if(j.phase==='submitted_unknown'){
    let checks=0;
    const verify=()=>{const active=get();if(!active||active.id!==j.id||active.phase!=='submitted_unknown')return;
     if(confirmedSaved(active)){notice('✓ تحقق ظهور الدرس التفاعلي في قائمة نور بعد الحفظ؛ يمكن الانتقال للدرس التالي.');return;}
     if(++checks<9)setTimeout(verify,1700);
     else notice('حالة حفظ SCORM غير مؤكدة. افتح قائمة نور للتحقق؛ لن يُرسل الدرس التالي أو يتكرر الحفظ دون إثبات.');
    };
    verify();return;
   }
   if(j.phase==='done'){root.dispatchEvent(new CustomEvent('stnNoorScormConfirmed',{detail:{id:j.id,batchTag:j.batchTag}}));return}
   if(j.phase==='staged'){notice('الدرس التفاعلي جاهز للمراجعة على هذه الصفحة. لن يتكرر الرفع بعد تحديث الصفحة.');return}
   if(j.phase==='route'||j.phase==='tree_opened'||j.phase==='tree_selection')advance();
   else if(j.phase==='paused')notice('عملية SCORM معلقة: '+j.reason+' — اضغط «استكمال النشر الموجود» بعد فتح صفحة نور الصحيحة.');
  }},950);
})(typeof globalThis==='object'?globalThis:this);
