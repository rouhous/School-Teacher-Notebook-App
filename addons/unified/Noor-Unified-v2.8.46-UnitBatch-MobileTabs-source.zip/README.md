# Noor Unified Firefox Extension — 2.8.46

Based on the complete 2.8.45 source, preserving the existing teacher login, course discovery, class evidence, preparation, grades, activity-import, Gemini, and SCORM modules.

## Teacher-facing additions

- On mobile, a narrower panel (max 66dvh) divided into **الصف والمحتوى** and **المهمة والإعدادات** tabs. Form input values remain mounted while switching tabs.
- Minimize/restore button directly next to Close, plus original drag handle and reset-position control.
- Compact generation and import buttons.
- For Activities and SCORM, **الدرس المحدد فقط** / **جميع دروس الوحدة المختارة في نور**.
- Publish-date fields and opt-in unit-wide automatic save toggles (checked by default only after the teacher chooses the unit-wide scope).
- One unit-wide activity run creates independent activities for each lesson and starts the existing Noor automator only once per lesson. The next lesson starts only after an exact completed Noor run record is observed.
- One SCORM ZIP is created per verified official lesson (one variant per lesson) and downloaded as a backup. Automatic upload is serialized. The subsequent file is not sent until the previous entry appears uniquely in Noor's list with the batch-specific STN reference attached to its title. Ambiguous or unconfirmed save pauses the unit queue.
- A cancel control stops future batch steps but cannot undo a form submission already sent to Noor.
- Existing individual-lesson generation and the existing image fallback modes are retained.

## Safety and compatibility

- Batch lessons must come from the current Noor lesson selector or from a teacher- and class-scoped official curriculum snapshot. No invented lesson numbers, API endpoints, or class IDs.
- Same subject, course label, teacher identity, and numeric course ID are verified before each batch step.
- The batch state persists in browser.storage.local across page navigation, but **does not automatically retry** uncertain submissions.
- When Noor shows a SCORM upload form without a tree, a teacher-approved *whole-unit* selection from Noor's actual lesson selector can be accepted, tied to its observed form option; an unrelated class cannot be used.
- Real account acceptance, successful backend publication, and automatic save in every Noor form variant require an end-to-end live Noor test. Successful local tests do not imply server-side validation.
- The extension must be signed by Mozilla with the existing GitHub workflow before ordinary Firefox installation. Never repack the original signed XPI.
